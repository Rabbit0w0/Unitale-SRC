package fr.unitale.games.fk;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerType;
import fr.unitale.games.fk.modules.game.FKGameModule.PrivacyStateBase;
import fr.unitale.games.fk.modules.launcher.FKLauncherModule;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.map.fk.FKMap;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.math.RandomUtils;
import fr.unitale.sdk.utils.resourcepack.ResourcePackType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.craftbukkit.v1_10_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Random;
import java.util.UUID;

public class FKEngine extends GameEngine<FKMap> {

	public static final int CHESTROOM_SIZE = 6;
	public static FKEngine __instance;
	public static boolean gamecore = true;
	private static String ADMIN_KEY = "ADMIN_FK";
	private int baseSize = 10;
	private int dayMax = 10;
	private boolean deathMatch = false;
	public ArrayList<Material> materials;

	public FKEngine(JavaPlugin plugin, String json) {
		super(plugin, json);
		ServerManager.type = ServerType.FALLENKINGDOM;
		__instance = this;
		mode = Mode.TEAM;

		try {
			final MapType mapt = MapType.fromString(Wrapper.map.replace("_var2", ""));
			gameMap = (FKMap) mapt.getInstance(Bukkit.getWorld(Wrapper.map.replace("_var2", "")));
			System.out.println(Wrapper.map);

		} catch (Exception e) {
			if (gameMap == null) {
				System.out.println("Impossible de trouver la map " + getConfig("map", "UNKNOW"));
				emergencyShutdown("Map unknow");
			}
			Bukkit.getServer().getPluginCommand("restart");
		}

		getInstance().setKeepOffline(true);
		getModuleManager().clear();
		getModuleManager().addModule(new FKLauncherModule());
		TeamModule<FKTeam> teammodule = new TeamModule<>(FKTeam.class);
		teammodule.setTeamSize(8);
		getModuleManager().addModule(teammodule, true);
		

		WaitingModule wait = new WaitingModule(FKLauncherModule.class);
		wait.setVoteStartByPlayers(()-> false);
		getModuleManager().addModule(wait, true);
		
		wait.setMaxPlayers(teammodule.getTeamSize()*teammodule.getNbTeam());
		wait.setMinPlayers(wait.getMaxPlayers()-4);
		wait.setVoteStartByPlayers(() -> false);
		
		Bukkit.getWorlds().get(0).setAutoSave(false);
		
		materials = new ArrayList<Material>();

	}
	
	public static FKEngine getInstance() {
		return __instance;
	}

	public DropModule initDropModule() {
		DropModule dm = new DropModule();

		// BLOCKS BROKEN
		dm.addConvertItem(ConvertType.BLOCK, Material.CACTUS, new UniItemStack(Material.WOOD));
		dm.addConvertItem(ConvertType.BLOCK, Material.FLINT,
				new UniItemStack(Material.ARROW, RandomUtils.nextInt(2, 6)));
		dm.addConvertItem(ConvertType.BLOCK, Material.GRAVEL,
				new UniItemStack(Material.ARROW, RandomUtils.nextInt(2, 6)));
		dm.addConvertItem(ConvertType.BLOCK, Material.SAND, new UniItemStack(Material.GLASS_BOTTLE));
		dm.addConvertItem(ConvertType.BLOCK, Material.COAL, new UniItemStack(Material.TORCH, 3));
		dm.addConvertItem(ConvertType.BLOCK, Material.IRON_ORE, new UniItemStack(Material.IRON_INGOT, 2));
		dm.addConvertItem(ConvertType.BLOCK, Material.GOLD_ORE, new UniItemStack(Material.GOLD_INGOT, 2));
		dm.addConvertItem(ConvertType.BLOCK, Material.DIAMOND, new UniItemStack(Material.DIAMOND, 2));
		dm.addConvertItem(ConvertType.BLOCK, Material.LOG, new UniItemStack(Material.LOG));
		dm.addConvertItem(ConvertType.BLOCK, Material.LOG_2, new UniItemStack(Material.LOG));
		dm.addConvertItem(ConvertType.BLOCK, Material.DEAD_BUSH, new UniItemStack(Material.BREAD, 3));
		dm.addConvertItem(ConvertType.BLOCK, Material.STONE, new UniItemStack(Material.COBBLESTONE));
		dm.addConvertItem(ConvertType.BLOCK, Material.BROWN_MUSHROOM, new UniItemStack(Material.MUSHROOM_SOUP, 2));
		dm.addConvertItem(ConvertType.BLOCK, Material.RED_MUSHROOM, new UniItemStack(Material.MUSHROOM_SOUP, 2));
		dm.addConvertItem(ConvertType.BLOCK, Material.EMERALD_ORE, new UniItemStack(Material.DIAMOND, 10));
		dm.addConvertItem(ConvertType.BLOCK, Material.SUGAR_CANE,
				new UniItemStack(Material.SUGAR_CANE, new Random().nextInt(4)));
		dm.addConvertItem(ConvertType.BLOCK, Material.WHEAT, new UniItemStack(Material.BREAD));
		dm.addConvertItem(ConvertType.BLOCK, Material.POTATO, new UniItemStack(Material.BAKED_POTATO));
		// ITEMS DROPPED
		dm.addConvertItem(ConvertType.DROP, Material.INK_SACK, new UniItemStack(Material.COOKED_FISH, 2));
		dm.addConvertItem(ConvertType.DROP, Material.ROTTEN_FLESH, new UniItemStack(Material.COOKED_BEEF, 2));
		dm.addConvertItem(ConvertType.DROP, Material.POTATO, new UniItemStack(Material.BAKED_POTATO));
		dm.addConvertItem(ConvertType.DROP, Material.RAW_BEEF, new UniItemStack(Material.COOKED_BEEF));
		dm.addConvertItem(ConvertType.DROP, Material.RAW_CHICKEN, new UniItemStack(Material.COOKED_CHICKEN));
		dm.addConvertItem(ConvertType.DROP, Material.RAW_FISH, new UniItemStack(Material.COOKED_FISH));
		dm.addConvertItem(ConvertType.DROP, Material.WOOL, new UniItemStack(Material.STRING, 2));
		dm.addConvertItem(ConvertType.DROP, Material.MUTTON, new UniItemStack(Material.COOKED_MUTTON));
		dm.addConvertItem(ConvertType.DROP, Material.RABBIT, new UniItemStack(Material.COOKED_RABBIT));
		dm.addConvertItem(ConvertType.DROP, Material.PORK, new UniItemStack(Material.GRILLED_PORK));
		dm.addConvertItem(ConvertType.DROP, Material.FEATHER, new UniItemStack(Material.ARROW));
		// ITEMS CRAFTED
		dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_AXE, new UniItemStack(Material.STONE_AXE));
		dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_HOE, new UniItemStack(Material.STONE_HOE));
		dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_PICKAXE, new UniItemStack(Material.STONE_PICKAXE));
		dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_SPADE, new UniItemStack(Material.STONE_SPADE));
		dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_SWORD, new UniItemStack(Material.STONE_SWORD));

		return dm;
	}

	public FKMap getGameMap() {
		return this.gameMap;
	}

	public int getBaseSize() {
		return this.baseSize;
	}

	public void setBaseSize(int b) {
		this.baseSize = b;
	}

	public int getDayMax() {
		return this.dayMax;
	}

	public void setDayMax(int d) {
		this.dayMax = d;
	}

	public FKTeam getTeam(Location l) {
		final TeamModule<FKTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);
		if (tm == null) {
			return null;
		}
		for (final FKTeam t : tm.getTeams()) {
			if (t != null && t.getBase() != null && t.getBase().contains(l)) {
				return t;
			}
		}
		return null;
	}

	public PrivacyStateBase whereAmI(Player p, Location l) {
		final FKTeam a = (FKTeam) UniTeam.getTeam(p);
		final FKTeam b = getTeam(l);

		if (b == null) {
			return PrivacyStateBase.OUTBASE;
		}
		if (a != null && a == b) {
			return PrivacyStateBase.INOWNBASE;
		}
		return PrivacyStateBase.INENEMYBASE;
	}

	public PrivacyStateBase whereAmI(Player p) {
		return (whereAmI(p, p.getLocation()));
	}

	public boolean isAdmin(UniPlayer p) {
		return (p.getStorage().getBoolean(ADMIN_KEY, false));
	}

	public boolean isAdmin(Player p) {
		return isAdmin((UniPlayer) p);
	}

	public void setAdmin(UniPlayer p, boolean admin) {
		p.getStorage().addBoolean(ADMIN_KEY, admin);
		if (admin) {
			p.sendMessage(Lang.arr(p, "game.fk.command.admin.set"));
		} else {
			p.sendMessage(Lang.str(p, "game.fk.command.admin.unset"));
		}
	}

	public void setAdmin(Player p, boolean admin) {
		setAdmin((UniPlayer) p, admin);
	}

	public void setAdmin(Player p) {
		setAdmin((UniPlayer) p, true);
	}

	public void setDeathMatch() {
		this.deathMatch = true;
		getOnlinePlayers().forEach(p -> p.sendMessage(Lang.str(p, "game.fk.day.max")));
		for (final Player p : this.getOnlinePlayers()) {
			p.setMaxHealth(6);
		}
	}

	public boolean isDeathMatch() {
		return this.deathMatch;
	}

	@Override
	public void userJoin(UniPlayer p) {
		Bukkit.getScheduler().runTask(getPlugin(), () -> {
			if (getMap().getType().equals(MapType.ANGEVSDEMON)) {
				ResourcePackType.FALLENKINGDOM_ANGE.send(p);
			} else {
				((CraftPlayer) p).getHandle().setResourcePack("null", "null");
			}
		});
		if (this.deathMatch) {
			p.setMaxHealth(6);
		}
		if (this.gameStatus == GameStatus.WAIT) {
			p.teleport(this.gameMap.getLobby());
		}
	}

	@Override
	protected void userWaitMove(Player player) {
		FKMap g = this.gameMap;

		if (g == null)
			return;
		if (player.getLocation().getWorld() != g.getWorld() || player.getLocation().distance(g.getLobby()) > 20) {
			player.teleport(this.gameMap.getLobby());
		}
	}

	public boolean availablePlayer(OfflinePlayer player) {
		return GameEngine.getInstance().isEliminated(player.getUniqueId()) || player.isOnline();
	}

	public boolean availablePlayer(UUID uuid) {
		OfflinePlayer player = Bukkit.getOfflinePlayer(uuid);
		return player != null && availablePlayer(player);
	}
	
	public ArrayList<Material> getMaterials() {
		return materials;
	}

	public void setMaterials(ArrayList<Material> materials) {
		this.materials = materials;
	}
}
