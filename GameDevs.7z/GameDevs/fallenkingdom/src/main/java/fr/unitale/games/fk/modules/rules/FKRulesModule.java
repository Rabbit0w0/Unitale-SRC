package fr.unitale.games.fk.modules.rules;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;

public class FKRulesModule extends Module<FKRulesListener> {

    public FKRulesModule() {
        this.moduleListener = new FKRulesListener(this);

        RulesType.NOTCHAPPLE.setValue(getConfig("NOTCHAPPLE", false));
        RulesType.BLOCKPOSE.setValue(getConfig("BLOCKPOSE", false));
        RulesType.DAYBEFOREASSAULT.setValue(getConfig("DAYBEFOREASSAULT", 0));
        RulesType.DAYBEFOREPVP.setValue(getConfig("DAYBEFOREPVP", 0));
        RulesType.LAVABUCKET.setValue(getConfig("LAVABUCKET", false));
        RulesType.NETHER.setValue(getConfig("NETHER", false));
        RulesType.POTIONLEVEL2.setValue(getConfig("POTIONLEVEL2", false));
        RulesType.STRENGHNERF.setValue(getConfig("STRENGHNERF", false));
        RulesType.NOTCHAPPLE.setValue(getConfig("NOTCHAPPLE", false));
        RulesType.ENDERPEARL.setValue(getConfig("ENDERPEARL", false));

        FKEngine.getInstance().getGameMap().setRules();
    }

    @Override
    public void startModule() {

    }

    @Override
    public void endModule() {

    }

    public enum RulesType {
        NOTCHAPPLE(Boolean.class, "game.fk.rules.notchapple"),
        POTIONLEVEL2(Boolean.class, "game.fk.rules.potionlv2"),
        STRENGHNERF(Boolean.class, "game.fk.rules.strengthpotion"),
        LAVABUCKET(Boolean.class, "game.fk.rules.lavabucket"),
        BLOCKPOSE(Boolean.class, "game.fk.rules.poseblock"),
        NETHER(Boolean.class, "game.fk.rules.nether"),
        DAYBEFOREPVP(Integer.class, "game.fk.rules.daybeforepvp"),
        DAYBEFOREASSAULT(Integer.class, "game.fk.rules.daybeforeassault"),
        ENDERPEARL(Boolean.class, "game.fk.rules.enderpearl");

        Integer intValue;
        Boolean boolValue;
        String name;
        private Class<?> type;

        RulesType(Class<?> type, String name) {
            this.type = type;
            this.intValue = 0;
            this.boolValue = false;
            this.name = name;
        }

        public String getName() {
            return this.name;
        }

        public Class<?> getType() {
            return this.type;
        }

        public Object getValue() {
            if (this.type == Integer.class) {
                return this.intValue;
            }
            return this.boolValue;
        }

        public void setValue(int v) {
            this.intValue = v;
        }

        public void setValue(boolean v) {
            this.boolValue = v;
        }

        public String getString(UniPlayer player) {
            if (getType() == Integer.class) {
                return Lang.str(player, "game.fk.rules.generic", Lang.str(player, name), getValue().toString());
            } else {
                return Lang.str(player, "game.fk.rules.generic", Lang.str(player, name), Lang.str(player, (((Boolean) getValue()) ? "generic.yes" : "generic.no")));
            }
        }
    }

}
