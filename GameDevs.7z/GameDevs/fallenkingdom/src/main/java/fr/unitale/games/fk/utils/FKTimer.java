package fr.unitale.games.fk.utils;

import java.util.Map.Entry;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.event.maps.MapsEvent;
import fr.unitale.games.fk.modules.game.FKGameModule;
import fr.unitale.games.fk.modules.game.utils.Money;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.utils.chat.Title;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.data.Storage;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;

public class FKTimer extends UniTimer {
	private final TeamModule<FKTeam> tm;
	private int day;
	public int timepvp = 301; // Définition de la phase de pvp en seconde
	public int timeassault = 901; // Définition de la phase de assault en seconde

	public FKTimer() {
		super("FK_DAYTIMER");
		this.day = 1;
		this.tm = GameEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);
	}

	private void updateTime() {
		Player p;
		UniScoreboard b;

		// calcul time phase update
		if (timeassault >= 0) {
			this.timeassault--;
		}
		if (timepvp >= 0) {
			this.timepvp--;
		}

		for(UniPlayer x : FKEngine.getInstance().getOnlinePlayers()) {
			final FKTeam t = (FKTeam) UniTeam.getTeam(x);
			Money.addMoney((UniPlayer) x, t.getCountMoneyUpgrade());
		}

		for (Entry<UUID, Storage> e : GameEngine.getInstance().getMapStorages().entrySet()) {
			p = Bukkit.getPlayer(e.getKey());
			
			if (p != null && ((UniPlayer) p).getEndScoreboard() != null) {
				((UniPlayer) p).getEndScoreboard().updateScore("fk_time", this.getITime());
				if (timepvp == -1) {
					((UniPlayer) p).getEndScoreboard().updateScore("PVP", Lang.str(p, "game.fk.pvp.on"));
				} else if (timepvp >= 0) {
					((UniPlayer) p).getEndScoreboard().updateScore("PVP", Lang.str(p, "game.fk.scoreboard.pvp",
							TimeManager.getTimeFromInt(timepvp).replace("m", ":").replace("s", "")));
				}

				if (timeassault == -1) {
					((UniPlayer) p).getEndScoreboard().updateScore("ASSAULT", Lang.str(p, "game.fk.assault.on"));
				} else {
					((UniPlayer) p).getEndScoreboard().updateScore("ASSAULT", Lang.str(p, "game.fk.scoreboard.assault",
							TimeManager.getTimeFromInt(timeassault).replace("m", ":").replace("s", "")));
				}
				FKTeam t = (FKTeam) UniTeam.getTeam(p);
				((UniPlayer) p).getEndScoreboard().updateScore("Health_Core", " "+t.getHealthCore()+"/"+t.getHealthCoreMax()+ChatColor.RED + " ❤");
			} else {
				b = (UniScoreboard) e.getValue().getObject(GameEngine.SCOREBOARD_STORAGE);
				if (b != null)
					b.updateScore("fk_time", this.getITime());
				if (timepvp == -1)
					b.updateScore("PVP", Lang.str("game.fk.pvp.on"));
				else if (timepvp >= 0)
					b.updateScore("PVP", Lang.str("game.fk.scoreboard.pvp", TimeManager.getTimeFromInt(timepvp))
							.replace("m", ":").replace("s", ""));

				if (timeassault == -1)
					b.updateScore("ASSAULT", Lang.str("game.fk.assault.on"));
				else if (timeassault >= 0)
					b.updateScore("ASSAULT", Lang.str("game.fk.scoreboard.assault",
							TimeManager.getTimeFromInt(timeassault).replace("m", ":").replace("s", "")));
				b.updateScore("Health_Core", "2000");
			}

			// Update phase pvp
			if (timepvp == 0)
				Title.sendTitle(p, "", Lang.str(p, "game.fk.pvp.on"));

			// Update phase assault
			if (timeassault == 0)
				Title.sendTitle(p, "", Lang.str(p, "game.fk.assault.on"));
		}
	}

	private void updateDay() {
		Player p;
		for (Entry<UUID, Storage> e : GameEngine.getInstance().getMapStorages().entrySet()) {
			p = Bukkit.getPlayer(e.getKey());
			if (p != null) {
				((UniPlayer) p).getEndScoreboard().updateScore("fk_day",
						Lang.str(p, "game.fk.day", String.valueOf(this.day)));
			}
		}
	}

	@Override
	protected void userUpdate() {
		boolean b = false;

		if (getTime() == 600) {
			setTime(0, 0);
			this.day++;
			b = true;
			if (this.day == FKEngine.getInstance().getDayMax()) {
				FKEngine.getInstance().setDeathMatch();
			}
		}
		// Event time Mobs
		else if (this.day == 2 && getTime() == 1) {
			for (MapsEvent events : MapsEvent.values()) {
				if (events.getName().equals(Wrapper.map)) {
					events.getEvent();
				}
			}
		}

		updateTime();
		if (b)
			updateDay();

	}

	public int getDay() {
		return this.day;
	}

	private UniScoreboard createBoard() {
		final UniScoreboard board = new UniScoreboard();

		board.createSideBoard(UniColor.ORANGE + "FallenKingdoms");
		board.createLifeScore();
		board.createBelowNameLifeScore();
		board.addScore("fk_day", "Jour " + this.day, 0, DisplaySlot.SIDEBAR);
		board.addScore("fk_time", this.getITime(), 1, DisplaySlot.SIDEBAR);

		int i = 0;

		board.addScore("Team_Space", " ", i + 2, DisplaySlot.SIDEBAR);

		for (final FKTeam t : tm.getTeams()) {
			board.addScore("base_" + t.getName(), i + 3, DisplaySlot.SIDEBAR);
			i++;
		}

		board.addScore("AFTER_BASE", "  ", i + 4, DisplaySlot.SIDEBAR);

		for (UniPlayer p : FKEngine.getInstance().getOnlinePlayers()) {
			if (FKEngine.getInstance().getModuleManager().getModule(FKGameModule.class).canPvP()) {
				board.updateScore("PVP", Lang.str(p, "game.fk.pvp.on"));
			} else {
				board.addScore("PVP", TimeManager.getTimeFromInt(timepvp), i + 5, DisplaySlot.SIDEBAR);
			}

			if (FKEngine.getInstance().getModuleManager().getModule(FKGameModule.class).canAssault()) {
				board.updateScore("ASSAULT", Lang.str(p, "game.fk.assault.on"));
			} else {
				board.addScore("ASSAULT", TimeManager.getTimeFromInt(timeassault), i + 6, DisplaySlot.SIDEBAR);
			}

		}

		board.addScore("Obejectf1_Space", "   ", i + 7, DisplaySlot.SIDEBAR);
		board.addScore("Health_Core", "2000", i + 8, DisplaySlot.SIDEBAR);
		board.addScore("Obejectf1_Space", "    ", i + 9, DisplaySlot.SIDEBAR);

		board.addScore("Goldtitle", "Golds :", i + 10, DisplaySlot.SIDEBAR);
		for (UniPlayer p : FKEngine.getInstance().getOnlinePlayers())
			board.addScore("Money", Money.getMoney(p).toString() + " ⛃", i + 11, DisplaySlot.SIDEBAR);

		board.addScore("IP", UniColor.YELLOW + "‣ play.unitale.fr", i + 12, DisplaySlot.SIDEBAR);
		return board;
	}

	public void setBoard() {
		for (final Player p : GameEngine.getInstance().getOnlinePlayers()) {
			setBoard((UniPlayer) p);
		}
	}

	public void setBoard(UniPlayer p) {
		p.setScoreboard(createBoard());
	}

}
