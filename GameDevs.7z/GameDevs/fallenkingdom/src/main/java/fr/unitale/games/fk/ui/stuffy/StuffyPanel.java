package fr.unitale.games.fk.ui.stuffy;

import fr.unitale.games.fk.modules.game.utils.Money;
import fr.unitale.games.fk.modules.game.utils.Stuffys;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIClickPanel;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.entity.Player;

public class StuffyPanel extends UIClickPanel<Stuffys> implements UIFormHandler<Stuffys> {
    private Integer count = 1;

    public StuffyPanel(Player p) {
        super(54);

        int slotarmor = 0;
        int slotsword = 0;

        for (Stuffys up : Stuffys.values()) {
            if (up.getStuffys().contains("BRIDGE")) {
                setComponent(14, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
            } else if (up.getStuffys().contains("TNT")) {
                setComponent(15, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
            } else if (up.getStuffys().contains("SWORD_")) {
                setComponent(slotsword + 10, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotsword += 1;
            } else if (up.getStuffys().contains("HELMET")) {
                setComponent(slotarmor + 19, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotarmor += 1;
            } else if (up.getStuffys().contains("CHESTPLATE")) {
                setComponent(slotarmor + 25, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotarmor += 1;
            } else if (up.getStuffys().contains("LEGGINGS")) {
                setComponent(slotarmor + 31, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotarmor += 1;
            } else if (up.getStuffys().contains("BOOTS")) {
                setComponent(slotarmor + 37, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotarmor += 1;
            } else if (up.getStuffys().contains("FLINTANDSTEEL")) {
                setComponent(slotsword + 21, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
            } else if (up.getStuffys().contains("IRON_PICKAXE")) {
                setComponent(slotsword + 20, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotsword += 9;
            } else if (up.getStuffys().contains("GOLDEN_APPLE")) {
                setComponent(slotsword + 20, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
                slotsword += 9;
            } else if (up.getStuffys().contains("BOW")) {
                setComponent(slotsword + 20, new UIButton<>(up, up.getItemstack((UniPlayer) p)));
            } else if (up.getStuffys().contains("ARROW")) {
                setComponent(slotsword + 21, new UIButton<>(up, new UniItemStack(up.getItem().getType(), 16)
                        .setName(Lang.str(p, up.getKeylang(), up.getLvl().toString())).setLores(Lang.str(p, "game.fk.item.price", up.getPrice().toString()))));
            }
        }

    }

    @Override
    public void onSubmit(Player player, Stuffys value) {
        if (Money.removeMoneyStuffys((UniPlayer) player, value.getKeyTag())) {
            if (value.getKeyTag().contains("BRIDGE")) {
                player.getInventory().addItem(Stuffys.valueOf(value.getKeyTag()).getItemstack((UniPlayer) player)
                        .setName(Lang.str(player, Stuffys.valueOf(value.getKeyTag()).getKeylang(), count.toString())));
                count++;
            } else if (value.getKeyTag().contains("ARROW")) {
                UniItemStack arrow = new UniItemStack(Stuffys.valueOf(value.getKeyTag()).getItem().getType(), 16);
                player.getInventory().addItem(arrow);
            } else {
                Stuffys.addItem(player, Stuffys.valueOf(value.getKeyTag()).getItem().getType());
            }
        }
    }
}
