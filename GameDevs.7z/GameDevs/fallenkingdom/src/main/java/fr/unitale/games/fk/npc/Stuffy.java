package fr.unitale.games.fk.npc;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import fr.unitale.games.fk.ui.interact.StuffyInteract;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.morphs.model.data.NPCPlayerMorphData;
import fr.unitale.sdk.npcs.NPCAPI;
import fr.unitale.sdk.npcs.NPCData;
import fr.unitale.sdk.npcs.NPCDataFactory;
import fr.unitale.sdk.utils.auth.EditableGameProfile;

public class Stuffy {
    private Block b;
    private int x;
    private int y;
    private World w;
    private int z;

    public Stuffy(Block b) {
        this.setBlock(b);

        this.x = b.getX();
        this.y = b.getY()+1;
        this.z = b.getZ() + 8;
        this.w = Bukkit.getWorlds().get(0);
        
        w.getBlockAt(new Location(w, x, y-1, z)).setType(Material.BEDROCK);
        w.getBlockAt(new Location(w, x+1, y-1, z)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x+1, y-1, z)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x-1, y-1, z)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x-1, y-1, z)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x, y-1, z+1)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x, y-1, z+1)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x, y-1, z-1)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x, y-1, z-1)) .setData((byte) 7);
        
        
        NPCData data = new NPCDataFactory().create();

        data.setSpawnLocation(new Location(Bukkit.getWorlds().get(0), x+0.5, y+0.5, z+0.5));
        data.setInteraction(new StuffyInteract());
        data.setMorphData(new NPCPlayerMorphData(getProfile("Forgeron")).setName("Forgeron"));
        data.setInvulnerable(true);
        
         UnitaleSDK.getAPI(NPCAPI.class).spawn(data);
    }
    

    public Block getBlock() {
        return b;
    }

    public void setBlock(Block b) {
        this.b = b;
    }

    private GameProfile getProfile(String name) {
        final EditableGameProfile profile = new EditableGameProfile(UUID.randomUUID(), name);
        profile.setLegacy(true);
        profile.setProperty("textures", new Property("textures",
                "eyJ0aW1lc3RhbXAiOjE1ODUwNjU5ODU2MTYsInByb2ZpbGVJZCI6IjhiMzAxYWQ3NGY2NTQ0MzY4Yzg2OWYyZjU3ZDdjOGYzIiwicHJvZmlsZU5hbWUiOiJIeUJvdCIsInNpZ25hdHVyZVJlcXVpcmVkIjp0cnVlLCJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjIyNDY0MjdkMzg1YTI0ZGNjZjZiM2E5YjA5ODlkOGQ0YjkyMGZmOTk1ZmM0ODI5NWFkMjk0ODk2Zjk1NDg5In19fQ==",
                "Wua1L4WSL3ar0XiDSc1W844wER4HuG6MMMDXoHTNTLpd4jPzEjNtqVIZbsHMjNY/KKdjoF6rS9jPGdYwMIOeuzbkLZe10bM1X0osHLjPg+OtTMljkcALJbRrhCS0b4EtDJHJwaoUrEqf8bWEiNTfoWGNKNh3pJH+r8Nch5TjUR81uzHQ5WkXSA2MnCO1/4Wi/GZ4jgf+IKq2EEvt7AkrOnrob/NPHRIawz8a0hygJ6XuIsd9Qyi+u3KG/z7gBPaNuJt+0uj3fjC3pAs+rRFPYKqP8kspiyODiAvXlpWUxxCDlYtENZqkhTjZmLqZ1qW6qOKzZ0bmtqDyEbfKCH9b0P5brQgNjA4lOgxdO2FDk5kDswt7JgB2EKhhw4uHpRnCZK1of2UIvNkta4afZUalsBktCOJeARbEbeAK359uvyZGyjWs2MT2slhOBNga9xLTFafxw/kG6GUS/lp2BaW6NQP3gr21Ol08jYjVhHeApSAaspx2GX8owP+1gd5mszXEPyQsPgjnYcXnuv806ZKhWqbreugeoLNzWJIeNgDA2V33QV97ep34Lnjux3oe8H4Cbxqtybp3jCe56YghlPWhpcC2OofteN4riFjGnnKGZmE4xHDAxBdYyvAReqVEPMYf5HVPsObuEg1gcGPbeKMaOnEJTih+gqJ1IYtenicD4mk="));
        return profile;
    }
}
