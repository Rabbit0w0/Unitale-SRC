package fr.unitale.games.fk.kit;

import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.features.fallenkingdoms.FKKitType;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.Dye;

import java.util.Arrays;

public enum Kit {
    PALADIN(FKKitType.ENCHANTER_1,
            new ItemStack[]{new UniItemStack(Material.EXP_BOTTLE, 16), addLapis(8),
                    addBookEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, 1)},
            new ItemStack[]{new UniItemStack(Material.EXP_BOTTLE, 24), addLapis(10),
                    addBookEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, 1),
                    addBookEnchant(Enchantment.DAMAGE_ALL, 1, 1)},
            new ItemStack[]{new UniItemStack(Material.EXP_BOTTLE, 32), addLapis(16),
                    addBookEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, 2),
                    addBookEnchant(Enchantment.DAMAGE_ALL, 1, 1)},
            new ItemStack[]{new UniItemStack(Material.EXP_BOTTLE, 45), addLapis(24),
                    addBookEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, 2),
                    addBookEnchant(Enchantment.DAMAGE_ALL, 1, 2),
                    addBookEnchant(Enchantment.KNOCKBACK, 2, 1)},
            new ItemStack[]{new UniItemStack(Material.EXP_BOTTLE, 64), addLapis(32),
                    addBookEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, 2),
                    addBookEnchant(Enchantment.DAMAGE_ALL, 1, 2), addBookEnchant(Enchantment.THORNS, 1, 2),
                    addBookEnchant(Enchantment.KNOCKBACK, 2, 1)});

    private IKit feature;
    private ItemStack[][] items;

    Kit(IKit feature, ItemStack[] level1, ItemStack[] level2, ItemStack[] level3, ItemStack[] level4,
        ItemStack[] level5) {
        this.feature = feature;
        this.items = new ItemStack[5][];
        this.items[0] = level1;
        this.items[1] = level2;
        this.items[2] = level3;
        this.items[3] = level4;
        this.items[4] = level5;
    }

    public static ItemStack addLapis(int account) {
        Dye d = new Dye();
        d.setColor(DyeColor.BLUE);
        return d.toItemStack(account);
    }

    public static ItemStack addBookEnchant(Enchantment enchant, int lvl, int account) {
        UniItemStack i = new UniItemStack(Material.ENCHANTED_BOOK, account);
        i.addUnsafeEnchantment(enchant, lvl);
        return i;
    }

    public static Kit fromFeature(IKit kit) {
        return Arrays.stream(values())
                .filter(k -> k.getFeature().getKitKey().equals(kit.getKitKey()))
                .findFirst()
                .orElse(null);
    }

    public static void reward(UniPlayer p, IKit kit) {
        Kit k = Kit.fromFeature(kit);
        if (k != null && k.getItems(kit.getLevel()) != null) {
            p.getInventory().addItem(k.getItems(kit.getLevel()));
        }
    }

    public IKit getFeature() {
        return feature;
    }

    public ItemStack[] getItems(int level) {
        return (level > 0 && level <= 5) ? items[level - 1] : null;
    }
}
