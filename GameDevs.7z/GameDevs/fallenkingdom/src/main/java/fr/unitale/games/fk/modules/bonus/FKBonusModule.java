package fr.unitale.games.fk.modules.bonus;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;

public class FKBonusModule extends Module<FKBonusListener> {
	private final DropModule module;

	public FKBonusModule() {
		super();
		this.moduleListener = new FKBonusListener(this);

		FKBonus.SPEEDPOTION.setEnable(getConfig("SPEEDPOTION", false));
		FKBonus.DOUBLEORE.setEnable(getConfig("DOUBLEORE", false));
		FKBonus.POWEREDCREEPER.setEnable(getConfig("POWEREDCREEPER", false));
		FKBonus.UHC.setEnable(getConfig("UHC", false));
		FKBonus.FULLMOON.setEnable(getConfig("FULLMOON", false));
		FKBonus.STARTERPACK.setEnable(getConfig("STARTERPACK", false));
		FKBonus.RANDOMCHEST.setEnable(getConfig("RANDOMCHEST", false));
		FKBonus.LUCKYBLOCK.setEnable(getConfig("LUCKYBLOCK", false));
		FKBonus.CREEPER_PERCENT = getConfig("CREEPER_PERCENT", 15);

		this.module = new DropModule();
		GameEngine.getInstance().getModuleManager().addModule(this.module, false);
	}

	@Override
	public void startModule() {
		if (FKBonus.DOUBLEORE.isEnable() || FKBonus.POWEREDCREEPER.isEnable()) {
			GameEngine.getInstance().getModuleManager().loadModule(DropModule.class);
		}
		initBonus();
	}

	@Override
	public void endModule() {

	}

	void setPlayerBonus(UniPlayer player) {
		if (FKBonus.SPEEDPOTION.isEnable()) {
			player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2000000000, 2));
		}
	}

	private void initBonus() {
		if (FKBonus.DOUBLEORE.isEnable()) {
			this.module.addConvertItem(ConvertType.BLOCK, Material.IRON_ORE, new ItemStack(Material.IRON_ORE, 2));
			this.module.addConvertItem(ConvertType.BLOCK, Material.DIAMOND, new ItemStack(Material.DIAMOND, 2));
			this.module.addConvertItem(ConvertType.BLOCK, Material.GOLD_INGOT, new ItemStack(Material.GOLD_INGOT, 2));
			this.module.addConvertItem(ConvertType.BLOCK, Material.COAL_ORE, new ItemStack(Material.COAL_ORE, 2));
			this.module.addConvertItem(ConvertType.BLOCK, Material.EMERALD, new ItemStack(Material.EMERALD, 2));
			this.module.addConvertItem(ConvertType.BLOCK, Material.INK_SACK, (byte) 4,
					new ItemStack(Material.EMERALD, 2, (byte) 4));
		}
		if (FKBonus.POWEREDCREEPER.isEnable()) {
			for (final Entity e : Bukkit.getServer().getWorlds().get(0).getEntities()) {
				if (e instanceof Creeper) {
					((Creeper) e).setPowered(true);
				}
			}
		}

		for (final Player p : GameEngine.getInstance().getOnlinePlayers()) {
			setPlayerBonus((UniPlayer) p);
		}

		if (FKBonus.FULLMOON.isEnable()) {
			WeatherAPI.setTime(TimeSet.MIDNIGHT);
			WeatherAPI.disableWeather();
			WeatherAPI.rainDisable();
			WeatherAPI.disableTime();
		}

		if (FKBonus.LUCKYBLOCK.isEnable()) {
			FKEngine.getInstance().getGameMap().spawnLucky();
		}

		if (FKBonus.RANDOMCHEST.isEnable()) {
			reload();
			new BukkitRunnable() {

				@Override
				public void run() {
					reload();
				}
			}.runTaskTimer(GameEngine.getInstance().getPlugin(), 0, 6000);
		}
	}

	@SuppressWarnings("deprecation")
	private void reload() {
		FKEngine.getInstance().getGameMap().reloadChest();
		GameEngine.getInstance().broadcast(ChatColor.GREEN + "Les coffres ont étés ravitaillés!");
	}

	public enum FKBonus {
		SPEEDPOTION(false), DOUBLEORE(false), POWEREDCREEPER(false), UHC(false), FULLMOON(false), STARTERPACK(false),
		RANDOMCHEST(false), LUCKYBLOCK(false);

		public static int CREEPER_PERCENT = 10;
		private boolean activated;

		FKBonus(boolean b) {
			this.activated = b;
		}

		public boolean isEnable() {
			return this.activated;
		}

		public void setEnable(boolean b) {
			this.activated = b;
		}
	}
}
