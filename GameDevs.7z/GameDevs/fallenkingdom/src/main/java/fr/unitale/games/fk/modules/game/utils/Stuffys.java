package fr.unitale.games.fk.modules.game.utils;

import org.bukkit.Material;
import org.bukkit.entity.Player;

import fr.unitale.sdk.features.IFeature;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.SkullProfile;
import fr.unitale.sdk.utils.items.UniItemStack;

public enum Stuffys implements IFeature {
    HELMET_V1("HELMET_V1", "game.fk.item.stuffy.helmet", new UniItemStack(Material.CHAINMAIL_HELMET), 1, 50),
    HELMET_V2("HELMET_V2", "game.fk.item.stuffy.helmet", new UniItemStack(Material.IRON_HELMET), 2, 150),
    HELMET_V3("HELMET_V3", "game.fk.item.stuffy.helmet", new UniItemStack(Material.DIAMOND_HELMET), 3, 300),

    CHESTPLATE_V1("CHESTPLATE_V1", "game.fk.item.stuffy.chestplate", new UniItemStack(Material.CHAINMAIL_CHESTPLATE), 1, 50),
    CHESTPLATE_V2("CHESTPLATE_V2", "game.fk.item.stuffy.chestplate", new UniItemStack(Material.IRON_CHESTPLATE), 2, 150),
    CHESTPLATE_V3("CHESTPLATE_V3", "game.fk.item.stuffy.chestplate", new UniItemStack(Material.DIAMOND_CHESTPLATE), 3, 300),

    LEGGINGS_V1("LEGGINGS_V1", "game.fk.item.stuffy.leggings", new UniItemStack(Material.CHAINMAIL_LEGGINGS), 1, 50),
    LEGGINGS_V2("LEGGINGS_V2", "game.fk.item.stuffy.leggings", new UniItemStack(Material.IRON_LEGGINGS), 2, 150),
    LEGGINGS_V3("LEGGINGS_V3", "game.fk.item.stuffy.leggings", new UniItemStack(Material.DIAMOND_LEGGINGS), 3, 300),

    BOOTS_V1("BOOTS_V1", "game.fk.item.stuffy.boots", new UniItemStack(Material.CHAINMAIL_BOOTS), 1, 50),
    BOOTS_V2("BOOTS_V2", "game.fk.item.stuffy.boots", new UniItemStack(Material.IRON_BOOTS), 2, 150),
    BOOTS_V3("BOOTS_V3", "game.fk.item.stuffy.boots", new UniItemStack(Material.DIAMOND_BOOTS), 3, 300),

    SWORD_V1("SWORD_V1", "game.fk.item.stuffy.sword", new UniItemStack(Material.GOLD_SWORD), 1, 50),
    SWORD_V2("SWORD_V2", "game.fk.item.stuffy.sword", new UniItemStack(Material.IRON_SWORD), 2, 200),
    SWORD_V3("SWORD_V3", "game.fk.item.stuffy.sword", new UniItemStack(Material.DIAMOND_SWORD), 3, 300),

    FLINTANDSTEEL("FLINTANDSTEEL", "game.fk.item.stuffy.lighter", new UniItemStack(Material.FLINT_AND_STEEL), 1, 300),

    IRON_PICKAXE("IRON_PICKAXE", "game.fk.item.stuffy.pickaxe_iron", new UniItemStack(Material.IRON_PICKAXE), 1, 200),

    GOLDEN_APPLE("GOLDEN_APPLE", "game.fk.item.stuffy.apple_in_gold", new UniItemStack(Material.GOLDEN_APPLE), 1, 200),

    BOW("BOW", "game.fk.item.stuffy.bow", new UniItemStack(Material.BOW), 1, 200),
    ARROW("ARROW", "game.fk.item.stuffy.arrow", new UniItemStack(Material.ARROW), 1, 100),

    TNT("TNT", "game.fk.item.stuffy.tnt", new UniItemStack(Material.TNT), 1, 200),

    BRIDGE_V1("BRIDGE_V1", "game.fk.item.stuffy.bridge", SkullProfile.STONE.getItem(), 1, 300);

    private String stuffy, keylang;
    private Integer price, lvl;
    private UniItemStack itemstack;

    Stuffys(String upgrade, String keylang, UniItemStack itemstack, Integer lvl, Integer price) {
        this.stuffy = upgrade;
        this.keylang = keylang;
        this.itemstack = itemstack;
        this.setLvl(lvl);
        this.price = price;
    }

    public static void addItem(Player p, Material item) {
        p.getInventory().addItem(new UniItemStack(item));
    }

    @Override
    public UniItemStack getItem() {
        return itemstack;
    }

    @Override
    public String getKeyTag() {
        return stuffy;
    }

    /**
     * @return the upgrade
     */
    public String getStuffys() {
        return stuffy;
    }

    /**
     * @return the price
     */
    public Integer getPrice() {
        return price;
    }

    /**
     * @return the itemstack
     */
    public UniItemStack getItemstack(UniPlayer p) {
        return itemstack.setName(Lang.str(p, getKeylang(), getLvl().toString()))
                .setLores(Lang.str(p, "game.fk.item.price", getPrice().toString()));
    }

    /**
     * @param itemstack the itemstack to set
     */
    public void setItemstack(UniItemStack itemstack) {
        this.itemstack = itemstack;
    }

    /**
     * @return the keylang
     */
    public String getKeylang() {
        return keylang;
    }

    /**
     * @param keylang the keylang to set
     */
    public void setKeylang(String keylang) {
        this.keylang = keylang;
    }

    /**
     * @return the lvl
     */
    public Integer getLvl() {
        return lvl;
    }

    /**
     * @param lvl the lvl to set
     */
    public void setLvl(Integer lvl) {
        this.lvl = lvl;
    }
}
