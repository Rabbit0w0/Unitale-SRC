package fr.unitale.games.fk.event;

import fr.unitale.sdk.utils.event.UnitaleEvent;

public class FKEvent extends UnitaleEvent {

}
