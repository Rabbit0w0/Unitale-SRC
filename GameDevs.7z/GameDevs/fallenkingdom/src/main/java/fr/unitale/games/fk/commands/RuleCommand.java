package fr.unitale.games.fk.commands;

import fr.unitale.games.fk.modules.rules.FKRulesModule.RulesType;
import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.util.List;

public class RuleCommand extends AbstractCommand {

    public RuleCommand() {
        super("rule");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof UniPlayer) {
            UniPlayer p = (UniPlayer) sender;
            for (RulesType rt : RulesType.values()) {
                p.sendMessage(rt.getString(p));
            }
            return true;
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }
}
