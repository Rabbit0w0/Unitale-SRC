package fr.unitale.games.fk.utils;

import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.modules.game.utils.Upgrade;
import fr.unitale.games.fk.modules.game.utils.upgrades.RunBreakBlock;
import fr.unitale.games.fk.modules.game.utils.upgrades.RunFallingBlock;
import fr.unitale.games.fk.modules.game.utils.upgrades.RunSetBlock;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import fr.unitale.sdk.utils.area.AreaAPI;
import fr.unitale.sdk.utils.area.Cuboid;
import net.minecraft.server.v1_10_R1.NBTCompressedStreamTools;
import net.minecraft.server.v1_10_R1.NBTTagCompound;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;

import java.io.IOException;

public class Base extends Cuboid {

	public static Boolean b = true;
	int t = 1;
	private FKTeam team;
	private Schematic BASE_STRUCTURE_1;
	private Location loc;
	private byte color = 0;
	private String nameschema;

	public Base(FKTeam team, Location center, double size) {
		super(team.getName() + "_base", center, size);
		this.team = team;
		UnitaleSDK.getAPI(AreaAPI.class).addArea(this);
	}

	public Base(FKTeam team, Location center, double x, double y, double z) {
		super(team.getName() + "_base", center, x, y, z);
		this.team = team;
		UnitaleSDK.getAPI(AreaAPI.class).addArea(this);
	}

	/*
	 * Show size base
	 */

	public FKTeam getTeam() {
		return this.team;
	}

	public void createBaseBuild(Material mat) {
		final int x = (int) (this.center.getBlockX() - this.xSize / 2);
		final int y = this.center.getBlockY();
		final int z = (int) (this.center.getBlockZ() - this.zSize / 2);
		Block b;

		for (int i = 0; i < this.xSize; i++) {
			for (int k = 0; k < this.zSize; k++) {
				if (i == 0 || i == this.xSize - 1 || k == 0 || k == this.zSize - 1) {
					b = this.center.getWorld().getBlockAt(x + i, y, z + k);
					b.setType(mat);
				}
			}
		}

		for (int i = -3; i < 4; i++) {
			for (int k = -3; k < 4; k++) {
				b = this.center.getWorld().getBlockAt(this.center.getBlockX() + i, y - 1, this.center.getBlockZ() + k);
				b.setType(Material.BEDROCK);
			}
		}
	}

	public void upgradeWall(int radius, Material material) {
		if (material == Material.STAINED_CLAY)
			color = getTeam().getColor().getWoolByte();
		new RunFallingBlock(center, getTeam().getQueueWall(), radius, material, color).run();
	}

	public void upgradeCore(UniPlayer p, String upgradename, Integer height) {

		destroySchematic(getSchematics(upgradename));
		// Build Core
		new RunSetBlock(
				new Location(Bukkit.getWorlds().get(0), center.getX() - 3, center.getY() - 2, center.getZ() - 3),
				getTeam().getQueueCore(), getSchematics(upgradename)).run();
		// set new max heal core max
		getTeam().setHealthCoreMax(getTeam().getHealthCoreMax() + Upgrade.valueOf("HEADMAX_" + height).getHeight(),
				Upgrade.valueOf("HEADMAX_" + height).getHeight());
		// set new heal
		getTeam().setHealthCore(p, getTeam().getHealthCore() + Upgrade.valueOf("HEADMAX_" + height).getHeight());
		// Set Money increment
		getTeam().setCountMoneyUpgrade(getTeam().getCountMoneyUpgrade() + 1);
	}

	public void upgradeFarm(String upgradename) {
		SchematicAPI.pasteSchematic(
				new Location(Bukkit.getWorlds().get(0), center.getX() - 8, center.getY() - 1, center.getZ() - 8),
				getSchematics(upgradename));
	}

	public void upgradeFall(int count, Material material) {
		new RunBreakBlock(center, getTeam().getQueueFall(), count, material).run();
	}

	public void upgradeRegenCore(Player p, int health) {
		getTeam().setHealthCore((UniPlayer) p, getTeam().getHealthCore() + health);
	}

	// Upgrade Enchantement
	public void upgradeEnchant() {
		World world = center.getWorld();
		loc = center.getBlock().getLocation().add(6, 4, -6);

		getTeam().setCountBiblioUpgrade(getTeam().getCountBiblioUpgrade() + 1);

		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() - 1, loc.getY(), loc.getBlockZ() + 2));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() + 1, loc.getY(), loc.getBlockZ() + 2));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() + 2, loc.getY(), loc.getBlockZ() - 1));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() + 2, loc.getY(), loc.getBlockZ()));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() + 2, loc.getY(), loc.getBlockZ() + 1));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() - 1, loc.getY(), loc.getBlockZ() - 2));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX(), loc.getY(), loc.getBlockZ() - 2));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() + 1, loc.getY(), loc.getBlockZ() - 2));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() - 2, loc.getY(), loc.getBlockZ() - 1));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() - 2, loc.getY(), loc.getBlockZ()));
		getTeam().getQueueBiblio().add(new Location(world, loc.getBlockX() - 2, loc.getY(), loc.getBlockZ() + 1));

		for (Location locs : getTeam().getQueueBiblio()) {
			RunFallingBlock(locs, Material.BOOKSHELF);
			if (getTeam().getCountBiblioUpgrade() == 3) {
				RunFallingBlock(locs.add(0, 4, 0), Material.WOOD_STEP);
			}
		}

		if (getTeam().getCountBiblioUpgrade() == 1) {
			RunFallingBlock(loc, Material.ENCHANTMENT_TABLE);
		}

		getTeam().getQueueBiblio().clear();

		if (getTeam().getCountBiblioUpgrade() == 3) {
			Bukkit.getScheduler().scheduleSyncRepeatingTask(UnitaleSDK.getInstance(),
					() -> loc.getWorld().spawnEntity(loc, EntityType.THROWN_EXP_BOTTLE), 0, 60L * 3);
		}
	}

	public void RunFallingBlock(Location loc, Material material) {
		FallingBlock f = loc.getWorld().spawnFallingBlock(loc.add(0.5, 0, 0.5), material, (byte) 0);
		f.setDropItem(false);
	}

	// Destroy Schematics
	private void destroySchematic(Schematic s) {
		for (int x = (center.getBlockX() - s.getWidth() / 2); x <= center.getBlockX() + s.getWidth() / 2; x++) {
			for (int y = (center.getBlockY()) - 1; y <= center.getBlockY() + s.getHeight() - 2; y++) {
				for (int z = (center.getBlockZ() - s.getLength() / 2); z <= center.getBlockZ()
						+ s.getLength() / 2; z++) {
					Location l = center.clone();
					l.setX(x);
					l.setY(y);
					l.setZ(z);
					l.getBlock().setType(Material.AIR);
				}
			}
		}
	}

	public Schematic getSchematics(String upgradename) {
		try {
			if (Wrapper.map.contains("angevsdemon") && !upgradename.contains("FARM")) {
				nameschema = Wrapper.map.toUpperCase().replace("_VAR2", "") + "_"
						+ getTeam().getColor().name().toUpperCase() + "_" + upgradename;
			} else if (upgradename.contains("FARM")) {
				nameschema = upgradename;
			} else {
				nameschema = Wrapper.map.toUpperCase().replace("1VS1", "").replace("VS1", "").replace("VS1", "")
						.replace("_VAR2", "") + "_" + upgradename;
			}
			System.out.println(nameschema);
			NBTTagCompound compound1 = NBTCompressedStreamTools
					.a(Wrapper.class.getResourceAsStream("model/" + nameschema + ".schematic"));
			BASE_STRUCTURE_1 = SchematicAPI.loadSchematic(compound1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return BASE_STRUCTURE_1;
	}
}
