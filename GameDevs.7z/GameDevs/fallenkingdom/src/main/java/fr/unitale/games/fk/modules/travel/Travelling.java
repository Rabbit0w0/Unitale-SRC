package fr.unitale.games.fk.modules.travel;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.sdk.thread.SDKPool;
import org.bukkit.Bukkit;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Travelling {

    private final List<TravellingPoint> points = new LinkedList<>();
    private long timeBetweenPoints = 90L;
    private Runnable actionAtEnd;

    public Travelling(long timeBetweenPoints, TravellingPoint... points){
        this.timeBetweenPoints = timeBetweenPoints;
        this.points.addAll(Arrays.asList(points));
    }

    public long getTimeBetweenPoints() {
        return timeBetweenPoints;
    }

    public List<TravellingPoint> getPoints() {
        return points;
    }

    public void setActionAtEnd(Runnable actionAtEnd) {
        this.actionAtEnd = actionAtEnd;
    }

    public void start(){
        SDKPool.execute(() -> {
            int i = 0;
            while (i < points.size()){
                TravellingPoint p = points.get(i);
                p.sendAll();
                i++;
                try {
                    Thread.sleep(getTimeBetweenPoints() * 50);//getting ticks to ms
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if(actionAtEnd != null){
                Bukkit.getScheduler().runTask(FKEngine.getInstance().getPlugin(), () -> actionAtEnd.run());
            }
        });
    }
}
