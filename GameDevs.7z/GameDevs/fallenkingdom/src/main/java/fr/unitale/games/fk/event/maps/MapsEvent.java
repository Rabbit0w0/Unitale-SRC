package fr.unitale.games.fk.event.maps;

import fr.unitale.games.fk.event.maps.nordique.Nordique;
import fr.unitale.sdk.gameengine.map.MapType;

public enum MapsEvent { // todo a revoir

    ANGEVSDEMON(MapType.ANGEVSDEMON.getName()), ANGEVSDEMON_VAR2(MapType.ANGEVSDEMON.getName() + "_var2"),
    AANDOVALE1vs1vs1(MapType.AANDOVALE1VS1VS1.getName());

    private String name;
    private Object event;

    MapsEvent(String name) {
        this.name = name;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the event
     */
    public Object getEvent() {
        if (name.contains(MapType.ANGEVSDEMON.getName())) {
            new AngeVsDemon();
        } else if (name.contains(MapType.NORDIQUE.getName())) {
            new Nordique();
        } else if (name.contains(MapType.CANDY_1VS1.getName()) || name.contains(MapType.CANDY_1VS1VS1.getName())
                || name.contains(MapType.AANDOVALE1VS1.getName())
                || name.contains(MapType.AANDOVALE1VS1VS1.getName())) {
            new Candy_Anderval();
        }
        return event;
    }

    /**
     * @param event the event to set
     */
    public void setEvent(Object event) {
        this.event = event;
    }
}
