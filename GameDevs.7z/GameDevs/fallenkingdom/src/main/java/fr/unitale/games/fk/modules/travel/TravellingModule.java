package fr.unitale.games.fk.modules.travel;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.maps.Maps;
import fr.unitale.games.fk.modules.game.FKGameModule;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.Bukkit;

public class TravellingModule extends Module<TravellingListener> {

    public TravellingModule() {
        this.moduleListener = new TravellingListener(this);
    }

    @Override
    public void startModule() {
        // Pas de base mais besoin actuellement
        FKEngine.getInstance().setGameStatus(GameStatus.GAME);
        UnitaleSDK.unloadAPI(API.CHAT);
        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);

        final TeamModule<FKTeam> tm = FKEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);
        tm.getTeams()
                .stream()
                .filter(t -> !t.isEmpty())
                .forEach(t -> {
                    t.addCrystal();
                    t.tpBaseTravelling();
                });

        final Maps map = Maps.fromOriginalMap(FKEngine.getInstance().getMap().getType());
        if(map == null){
            UniLogger.error("FOUND NULL MAP WHEN ASKING FOR MAP "+FKEngine.getInstance().getMap().getType());
            return;
        }

        final Travelling trav = map.getTravelling(Bukkit.getWorld("world"));
        trav.setActionAtEnd(() -> {
            FKEngine.getInstance().getModuleManager().removeModule(TravellingModule.class);
            FKEngine.getInstance().getModuleManager().addModule(new FKGameModule(), true);
        });
        trav.start();
    }


    @Override
    public void endModule() {

    }
}