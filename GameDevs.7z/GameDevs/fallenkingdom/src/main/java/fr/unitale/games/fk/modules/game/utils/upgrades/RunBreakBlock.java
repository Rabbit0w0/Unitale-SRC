package fr.unitale.games.fk.modules.game.utils.upgrades;

import java.util.List;
import java.util.ListIterator;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import fr.unitale.sdk.UnitaleSDK;

public class RunBreakBlock implements Runnable {

	private int raduis, task, maxY, minY, maxX, maxZ, minX, minZ;
	private Material material;
	private Location center;
	private List<Block> queue;

	public RunBreakBlock(Location center, List<Block> queue, int raduis, Material material) {
		this.center = center;
		this.raduis = raduis;
		this.material = material;
		this.queue = queue;
	}

	public void run() {
		maxX = (int) (center.getX() + raduis + 9);
		maxZ = (int) (center.getZ() + raduis + 9);
		minX = (int) (center.getX() - raduis - 9);
		minZ = (int) (center.getZ() - raduis - 9);
		minY = (int) (center.getY() - 4);

		if (material.equals(Material.AIR))
			maxY = (int) (center.getY() + 2);
		else
			maxY = (int) (center.getY() - 2);

		for (int x = minX; x <= maxX; x++) {
			for (int z = minZ; z <= maxZ; z++) {
				for (int y = minY; y <= maxY; y++) {
					if (x == minX || x == maxX || z == minZ || z == maxZ) {
						Block b = center.getWorld().getBlockAt(x, y, z);
						queue.add(b);
					}
				}
			}
		}

		spawnBlock();
	}

	public void spawnBlock() {
		ListIterator<Block> iterable = queue.listIterator();
		task = Bukkit.getScheduler().scheduleSyncRepeatingTask(UnitaleSDK.getInstance(), new Runnable() {
			boolean t = false;

			@Override
			public void run() {

				int timesPerRun = 1;
				if (queue.size() < timesPerRun) {
					timesPerRun = queue.size();
				}

				t = false;

				while (timesPerRun >= 0 && iterable.hasNext()) {

					Block block = iterable.next();
					block.getLocation().add(0, 1, 0).getBlock().setType(material);
					timesPerRun--;
					t = true;

				}

				if (!t) {
					queue.clear();
					setStair(raduis);
					Bukkit.getScheduler().cancelTask(task);
				}
			}
		}, 0, 2L);
	}
	
	// to do
	public void setStair(int raduis) {
		System.out.println(raduis);
		center.getWorld().getBlockAt(maxX - 1, minY + 1, maxZ).setType(Material.COBBLESTONE);
		center.getWorld().getBlockAt(maxX, minY + 2, maxZ).setType(Material.COBBLESTONE);
		center.getWorld().getBlockAt(maxX, minY + 1, maxZ - 1).setType(Material.COBBLESTONE);

		center.getWorld().getBlockAt(minX + 1, minY + 1, minZ).setType(Material.COBBLESTONE);
		center.getWorld().getBlockAt(minX, minY + 2, minZ).setType(Material.COBBLESTONE);
		center.getWorld().getBlockAt(minX, minY + 1, minZ + 1).setType(Material.COBBLESTONE);
		if (raduis == 5) {
			center.getWorld().getBlockAt(maxX - 2, minY + 1, maxZ - 1).setType(Material.AIR);
			center.getWorld().getBlockAt(maxX - 1, minY + 2, maxZ - 1).setType(Material.AIR);
			center.getWorld().getBlockAt(maxX - 1, minY + 1, maxZ - 2).setType(Material.AIR);

			center.getWorld().getBlockAt(minX + 2, minY + 1, minZ + 1).setType(Material.AIR);
			center.getWorld().getBlockAt(minX + 1, minY + 2, minZ + 1).setType(Material.AIR);
			center.getWorld().getBlockAt(minX + 1, minY + 1, minZ + 2).setType(Material.AIR);
		}
	}

}
