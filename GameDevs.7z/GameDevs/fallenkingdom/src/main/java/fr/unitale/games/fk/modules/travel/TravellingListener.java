package fr.unitale.games.fk.modules.travel;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import fr.unitale.sdk.gameengine.modules.ModuleListener;

public class TravellingListener extends ModuleListener<TravellingModule> {

    public TravellingListener(TravellingModule module) {
        super(module);
    }

    @EventHandler
    public void onPlayerLeave(final PlayerQuitEvent event) {
    }

    @EventHandler
    public void onPlayerLeave(final PlayerMoveEvent e) {
        Player player = e.getPlayer();
        player.teleport(player);
    }
}
