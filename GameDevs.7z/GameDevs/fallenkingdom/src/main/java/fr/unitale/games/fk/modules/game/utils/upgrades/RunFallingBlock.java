package fr.unitale.games.fk.modules.game.utils.upgrades;

import java.util.List;
import java.util.ListIterator;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.FallingBlock;

import fr.unitale.sdk.UnitaleSDK;

public class RunFallingBlock implements Runnable {
	private int radius, deep, task;
	private Material material;
	private Location center;
	private List<Block> queue;
	private byte color;

	public RunFallingBlock(Location center, List<Block> queue, int radius, Material material, byte color) {
		this.center = center;
		this.radius = radius;
		this.material = material;
		this.queue = queue;
		this.color = color;
		this.deep = 6;
	}

	public void run() {
		int maxX = (int) (center.getX() + radius);
		int maxZ = (int) (center.getZ() + radius);
		int minX = (int) (center.getX() - radius);
		int minZ = (int) (center.getZ() - radius);
		for (int x = minX; x <= maxX; x++) {
			for (int z = minZ; z <= maxZ; z++) {
				for (int y = (int) center.getY(); y <= (center.getY() + deep); y++) {
					if (x == minX || x == maxX || z == minZ || z == maxZ) {
						Block b2 = center.getWorld().getBlockAt(x, y + 6, z);
						Block b = center.getWorld().getBlockAt(x, y - 3, z);
						b2.setType(Material.AIR);
						b.setType(Material.AIR);
						queue.add(b2);

					}
				}
			}
		}

		spawnBlockFalling();
	}

	public void spawnBlockFalling() {
		ListIterator<Block> iterable = queue.listIterator();
		task = Bukkit.getScheduler().scheduleSyncRepeatingTask(UnitaleSDK.getInstance(), new Runnable() {
			boolean t = false;

			@SuppressWarnings("deprecation")
			@Override
			public void run() {

				int timesPerRun = 1;
				if (queue.size() < timesPerRun) {
					timesPerRun = queue.size();
				}

				t = false;

				while (timesPerRun >= 0 && iterable.hasNext()) {

					Block block = iterable.next();
					Location loc = block.getLocation();
					FallingBlock f = loc.getWorld().spawnFallingBlock(loc.add(0.5, 0, 0.5), material, color);
					f.setDropItem(false);
					timesPerRun--;
					t = true;

				}

				if (!t) {
					queue.clear();
					Bukkit.getScheduler().cancelTask(task);
				}
			}

		}, 0, 2L);
	}
}
