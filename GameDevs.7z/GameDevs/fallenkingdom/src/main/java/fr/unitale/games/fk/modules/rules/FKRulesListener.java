package fr.unitale.games.fk.modules.rules;

import org.bukkit.Material;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import fr.unitale.games.fk.modules.rules.FKRulesModule.RulesType;
import fr.unitale.sdk.gameengine.modules.ModuleListener;

public class FKRulesListener extends ModuleListener<FKRulesModule> {

    public FKRulesListener(FKRulesModule module) {
        super(module);
    }

    @EventHandler
    public void onBrew(BrewEvent e) {
        if ((Boolean) RulesType.POTIONLEVEL2.getValue()) {
            return;
        }
        if (e.getContents().getIngredient().getType() == Material.GLOWSTONE) {
            e.getContents().setIngredient(new ItemStack(Material.AIR));
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent e) {
        if (!(Boolean) RulesType.ENDERPEARL.getValue() && e.getEntity() instanceof EnderPearl) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        Player player = e.getPlayer();
        if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
            if (!(Boolean) RulesType.ENDERPEARL.getValue()
                    && player.getInventory().getItemInMainHand().getType().equals(Material.ENDER_PEARL)) {
                e.setCancelled(true);
            }
        }
    }
}
