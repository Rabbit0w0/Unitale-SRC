package fr.unitale.games.fk.modules.game.utils;

import org.bukkit.Material;
import org.bukkit.Sound;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.features.IFeature;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.SkullProfile;
import fr.unitale.sdk.utils.items.UniItemStack;

public enum Upgrade implements IFeature {

	WALL_1("WALL_1", "game.fk.item.upgrade.wall", 10, new UniItemStack(Material.STAINED_CLAY), null, 1, 200),
	WALL_2("WALL_2", "game.fk.item.upgrade.wall", 11, new UniItemStack(Material.STAINED_CLAY), null, 2, 500),
	WALL_3("WALL_3", "game.fk.item.upgrade.wall", 12, new UniItemStack(Material.STAINED_CLAY), null, 3, 1000),
	WALL_4("WALL_4", "game.fk.item.upgrade.wall", 12, new UniItemStack(Material.STAINED_CLAY), null, 4, 2500),
	WALL_MAX("WALL_MAX", "game.fk.item.upgrade.max", 12, new UniItemStack(Material.ENDER_STONE), null, 4, 0),

	FALL_1("FALL_1", "game.fk.item.upgrade.moat", 4, SkullProfile.PISTON.getItem(), Material.AIR, 1, 300),
	FALL_2("FALL_2", "game.fk.item.upgrade.moat", 5, SkullProfile.PISTON.getItem(), Material.AIR, 2, 750),
	FALL_3("FALL_3", "game.fk.item.upgrade.moat", 6, SkullProfile.PISTON.getItem(), Material.LAVA, 3, 1500),
	FALL_MAX("FALL_MAX", "game.fk.item.upgrade.max", 6, SkullProfile.PISTON.getItem(), Material.LAVA, 3, 0),

	ENCHANT_1("ENCHANT_1", "game.fk.item.upgrade.enchant", SkullProfile.ENCHANT_1.getItem(), 1, 300),
	ENCHANT_2("ENCHANT_2", "game.fk.item.upgrade.enchant", SkullProfile.ENCHANT_2.getItem(), 2, 750),
	ENCHANT_3("ENCHANT_3", "game.fk.item.upgrade.enchant", SkullProfile.ENCHANT_3.getItem(), 3, 1500),
	ENCHANT_MAX("ENCHANT_MAX", "game.fk.item.upgrade.max", SkullProfile.ENCHANT_3.getItem(), 4, 0),

	CORE_1("CORE_1", "game.fk.item.upgrade.core", SkullProfile.CORE_1.getItem(), 1, 500),
	CORE_2("CORE_2", "game.fk.item.upgrade.core", SkullProfile.CORE_2.getItem(), 2, 1500),
	CORE_3("CORE_3", "game.fk.item.upgrade.core", SkullProfile.CORE_3.getItem(), 3, 3000),
	CORE_MAX("CORE_MAX", "game.fk.item.upgrade.max", SkullProfile.CORE_3.getItem(), 4, 0),

	GOLEM("GOLEM", "Protecteur", 5, SkullProfile.GOLEM.getItem(), Material.LAVA, 1, 1000),

	ANVIL("ANVIL", "Enclume", new UniItemStack(Material.ANVIL), 1, 1000),

	FARM_1("FARM_1", "game.fk.item.upgrade.farm", SkullProfile.FARM.getItem(), 1, 300),
	FARM_2("FARM_2", "game.fk.item.upgrade.farm", SkullProfile.FARM.getItem(), 2, 750),
	FARM_MAX("FARM_MAX", "game.fk.item.upgrade.max", SkullProfile.FARM.getItem(), 1, 0),

	NIGHTVISION_1("NIGHTVISION_1", "game.fk.item.upgrade.effect.nightvision", SkullProfile.POTION_FORCE.getItem(), 1, 300),
	NIGHTVISION_MAX("NIGHTVISION_MAX", "game.fk.item.upgrade.max", SkullProfile.POTION_FORCE.getItem(), 1, 0),

	HEADMAX_1("REGEN_1", "game.fk.item.upgrade.core.regen", SkullProfile.HEAL.getItem(), 1, 500, 200),
	HEADMAX_2("REGEN_2", "game.fk.item.upgrade.core.regen", SkullProfile.HEAL.getItem(), 2, 750, 250),
	HEADMAX_3("REGEN_3", "game.fk.item.upgrade.core.regen", SkullProfile.HEAL.getItem(), 3, 750, 300),
	HEADMAX_MAX("REGEN_MAX", "game.fk.item.upgrade.max", SkullProfile.HEAL.getItem(), 4, 750, 0),

	REGEN("REGEN_1", "game.fk.item.upgrade.core.heal", SkullProfile.HEAL.getItem(), 100, 200),

	PROTECTED_1("PROTECTED_1", "game.fk.item.upgrade.effect.protect", SkullProfile.POTION_REGENE.getItem(), 1, 300),
	PROTECTED_2("PROTECTED_2", "game.fk.item.upgrade.effect.protect", SkullProfile.POTION_REGENE.getItem(), 2, 750),
	PROTECTED_MAX("PROTECTED_MAX", "game.fk.item.upgrade.max", SkullProfile.POTION_REGENE.getItem(), 4, 0),

	SPEED_1("SPEED_1", "game.fk.item.upgrade.effect.speed", SkullProfile.POTION_SPEED.getItem(), 1, 1000),
	SPEED_2("SPEED_2", "game.fk.item.upgrade.effect.speed", SkullProfile.POTION_SPEED.getItem(), 2, 3000),
	SPEED_MAX("SPEED_MAX", "game.fk.item.upgrade.max", SkullProfile.POTION_SPEED.getItem(), 4, 0);

	private String upgrade, keylang;
	private Material materiel;
	private Integer raduis, price, lvl, height;
	private UniItemStack itemstack;

	Upgrade(String upgrade, String keylang, Integer raduis, UniItemStack itemstack, Material materiel, Integer lvl,
			Integer price) {
		this.upgrade = upgrade;
		this.keylang = keylang;
		this.raduis = raduis;
		this.materiel = materiel;
		this.itemstack = itemstack;
		this.lvl = lvl;
		this.price = price;
	}

	Upgrade(String upgrade, String keylang, UniItemStack itemstack, Integer lvl, Integer price) {
		this.upgrade = upgrade;
		this.keylang = keylang;
		this.itemstack = itemstack;
		this.lvl = lvl;
		this.price = price;
	}

	Upgrade(String upgrade, String keylang, UniItemStack itemstack, Integer lvl, Integer height, Integer price) {
		this.upgrade = upgrade;
		this.keylang = keylang;
		this.itemstack = itemstack;
		this.height = height;
		this.lvl = lvl;
		this.price = price;
	}
	
	public static boolean addUpgrade(UniPlayer p, String upgrade) {
		final FKTeam atk = (FKTeam) UniTeam.getTeam(p);
		if (Money.getMoney(p) >= 0) {
			if (Money.getMoney(p) >= Upgrade.valueOf(upgrade).getPrice()) {
				addUpgradeTeam(p, upgrade);
				p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 10f, 10f);
				atk.getOnlinePlayers()
						.forEach(
								xt -> xt.sendTitle("",
										Lang.str(xt, "game.fk.item.upgrade.team.broadcast", p.getName())
												+ " " + Lang
														.str(xt, Upgrade.valueOf(upgrade).getKeylang(),
																Upgrade.valueOf(upgrade).getLvl().toString())
														.toLowerCase()));
				Money.removeMoney(p, Upgrade.valueOf(upgrade).getPrice());
				return true;
			}
		}
		return false;
	}

	public static void addUpgradeTeam(UniPlayer p, String upgrade) {
		final FKTeam atk = (FKTeam) UniTeam.getTeam(p);
		for (UniPlayer x : FKEngine.getInstance().getOnlinePlayers()) {
			FKTeam all = (FKTeam) UniTeam.getTeam(x);
			if (atk == all) {
				p.getStorage().addString(upgrade, upgrade);
				x.getStorage().addString(upgrade, upgrade);
			}
		}
	}

	public static boolean removeUpgrade(UniPlayer p, String upgrade) {
		final FKTeam atk = (FKTeam) UniTeam.getTeam(p);

		if (containsUpgrade(p, upgrade)) {
			for (UniPlayer x : FKEngine.getInstance().getOnlinePlayers()) {
				FKTeam all = (FKTeam) UniTeam.getTeam(x);
				if (atk == all) {
					removeUpgradeTeam(p, upgrade);
					return true;
				}
			}
		}
		return false;
	}

	public static void removeUpgradeTeam(UniPlayer p, String upgrade) {
		final FKTeam atk = (FKTeam) UniTeam.getTeam(p);

		if (containsUpgrade(p, upgrade)) {
			for (UniPlayer x : FKEngine.getInstance().getOnlinePlayers()) {
				FKTeam all = (FKTeam) UniTeam.getTeam(x);
				if (atk == all) {
					x.getStorage().removeString(upgrade);
				}
			}
		}
	}

	public static boolean containsUpgrade(UniPlayer p, String upgrade) {
		try {
			if (p.getStorage().getString(upgrade) != null) {
				return true;
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	@Override
	public UniItemStack getItem() {
		return itemstack;
	}

	@Override
	public String getKeyTag() {
		return upgrade;
	}

	/**
	 * @return the upgrade
	 */
	public String getUpgrade() {
		return upgrade;
	}

	/**
	 * @return the materiel
	 */
	public Material getMateriel() {
		return materiel;
	}

	/**
	 * @return the raduis
	 */
	public Integer getRaduis() {
		return raduis;
	}

	/**
	 * @return the price
	 */
	public Integer getPrice() {
		return price;
	}

	/**
	 * @return the itemstack
	 */
	public UniItemStack getItemstack(UniPlayer p) {
		if (!getKeylang().contains("max")) {
			return itemstack.setName(Lang.str(p, keylang, getLvl().toString()))
					.setLores(Lang.str(p, "game.fk.item.price", getPrice().toString()));
		} else {
			return itemstack.setName(Lang.str(p, keylang, getLvl().toString()))
					.setLores(Lang.str(p, "game.fk.item.price", 0));
		}
	}

	/**
	 * @return the keylang
	 */
	public String getKeylang() {
		return keylang;
	}

	/**
	 * @param keylang the keylang to set
	 */
	public void setKeylang(String keylang) {
		this.keylang = keylang;
	}

	/**
	 * @return the lvl
	 */
	public Integer getLvl() {
		return lvl;
	}

	/**
	 * @param lvl the lvl to set
	 */
	public void setLvl(Integer lvl) {
		this.lvl = lvl;
	}

	/**
	 * @return the height
	 */
	public Integer getHeight() {
		return height;
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(Integer height) {
		this.height = height;
	}
}
