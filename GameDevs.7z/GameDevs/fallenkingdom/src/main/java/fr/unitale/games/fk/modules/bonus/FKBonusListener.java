package fr.unitale.games.fk.modules.bonus;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.modules.bonus.FKBonusModule.FKBonus;
import fr.unitale.games.fk.modules.game.FKGameModule.PrivacyStateBase;
import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;
import org.bukkit.event.entity.EntitySpawnEvent;

import java.util.Random;

public class FKBonusListener extends ModuleListener<FKBonusModule> {

    public FKBonusListener(FKBonusModule module) {
        super(module);
    }

    @EventHandler
    public void onMobSpawn(EntitySpawnEvent e) {
        if (!FKBonus.POWEREDCREEPER.isEnable()) {
            return;
        }
        if (e.getEntity() instanceof Creeper && new Random().nextInt(FKBonus.CREEPER_PERCENT) >= 11) {
            ((Creeper) e.getEntity()).setPowered(true);
        }
    }

    @EventHandler
    public void onPlayerJoin(GamePlayerJoinEvent e) {
        this.module.setPlayerBonus(e.getPlayer());
    }

    @EventHandler
    public void regen(EntityRegainHealthEvent ev) {
        if (!FKBonus.UHC.isEnable() || ev.getRegainReason() != RegainReason.SATIATED) {
            return;
        }

        if (ev.getEntity() instanceof Player
                && FKEngine.getInstance().whereAmI((Player) ev.getEntity()) != PrivacyStateBase.INOWNBASE) {
            ev.setCancelled(true);
        }
    }
}
