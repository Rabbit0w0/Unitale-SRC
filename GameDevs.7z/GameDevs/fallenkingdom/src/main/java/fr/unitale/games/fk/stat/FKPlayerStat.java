package fr.unitale.games.fk.stat;

import fr.unitale.sdk.players.money.IMoneyTransactionType;
import fr.unitale.sdk.stat.PlayerStatType;
import fr.unitale.sdk.stat.PlayerStatType.PlayerStatMode;

public class FKPlayerStat {
    public static PlayerStatType ENDERDRAGON = new PlayerStatType("stat.dragon", "ENDERDRAGON", "EnderDragon tué", PlayerStatMode.ADDITIONNABLE);
    public static PlayerStatType OBJECTIV = new PlayerStatType("stat.obj", "OBJECTIV", "Objectif(s) terminé(s)", PlayerStatMode.ADDITIONNABLE);
    private static PlayerStatType[] content = new PlayerStatType[]{OBJECTIV, ENDERDRAGON};

    public static PlayerStatType[] values() {
        return content;
    }

    public enum FKMoneyTransaction implements IMoneyTransactionType {
        OBJECTIV, ENDERDRAGON
    }

}
