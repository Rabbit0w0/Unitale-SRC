package fr.unitale.games.fk.maps;

import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class GeneratorOres {
    private int b, X, Y, Z, yR, oreint;
    private Material ore;
    private double d4, d5;
    private Player p;
    private ArrayList<Chunk> chunks = new ArrayList<>();
    private World world;
    private Random r = new Random();
    private Location locfinale;
    private boolean isStone;
    private Material[] materials = new Material[]{Material.STONE, Material.COAL_ORE, Material.IRON_ORE,
            Material.EMERALD_ORE, Material.DIAMOND_ORE, Material.GOLD_ORE, Material.LAPIS_ORE, Material.REDSTONE_ORE};
    private int count;

    public GeneratorOres(Player p) {
        this.p = p;
        this.world = p.getWorld();
        this.locfinale = p.getLocation();
        generate();
    }

    public GeneratorOres(Location loc) {
        this.world = loc.getWorld();
        this.locfinale = loc;
        generate();
    }

    public boolean generate() {

        yR = r.nextInt(70);
        Block b = world.getBlockAt(locfinale.getBlockX(), yR, locfinale.getBlockZ());

        oreint = r.nextInt(materials.length);

        if (oreint > 0) {
            this.ore = materials[oreint];
        } else {
            this.ore = materials[1];
        }
        this.b = Minerais.valueOf(this.ore.name()).getSize();

        d4 = (double) Minerais.valueOf(this.ore.name()).getMaxy();
        d5 = (double) Minerais.valueOf(this.ore.name()).getMiny();
        X = 0;
        Z = 0;
        count = 0;
        int chance = r.nextInt(400);
        if (chance < Minerais.valueOf(this.ore.name()).getPercentage() / 40) { // The chance of spawning

            X = r.nextInt(15);
            Z = r.nextInt(15);
            Y = new Random().nextInt((int) (d4 + (d5 - d4) * (double) 1 / (double) this.b));

            isStone = true;

            while (isStone && count < 6) {
                count++;

                if (b.getChunk().getBlock(X, Y, Z).getType() == Material.STONE
                        || b.getChunk().getBlock(X, Y, Z).getType() == Material.GRAVEL) {
                    b.getChunk().getBlock(X, Y, Z).setType(this.ore);
                    switch (r.nextInt(10)) { // The direction chooser
                        case 0:
                            X++;
                            break;
                        case 1:
                            Y++;
                            break;
                        case 2:
                            Z++;
                            break;
                        case 3:
                            X--;
                            break;
                        case 4:
                            Y--;
                            break;
                        case 5:
                            Z--;
                            break;
                    }
                    isStone = (b.getChunk().getBlock(X, Y, Z).getType() == Material.STONE)
                            && (b.getChunk().getBlock(X, Y, Z).getType() != this.ore)
                            || (b.getChunk().getBlock(X, Y, Z).getType() == Material.GRAVEL);
                } else {
                    isStone = false;
                }
            }
        }
        return true;
    }

    /**
     * @return the b
     */
    public Integer getB() {
        return b;
    }

    /**
     * @param b the b to set
     */
    public void setB(Integer b) {
        this.b = b;
    }

    /**
     * @param b the b to set
     */
    public void setB(int b) {
        this.b = b;
    }

    /**
     * @return the ore
     */
    public Material getOre() {
        return ore;
    }

    /**
     * @param ore the ore to set
     */
    public void setOre(Material ore) {
        this.ore = ore;
    }

    /**
     * @return the chunk
     */
    public ArrayList<Chunk> getChunk() {
        return chunks;
    }

    /**
     * @param chunk the chunk to set
     */
    public void setChunk(ArrayList<Chunk> chunk) {
        this.chunks = chunk;
    }

    /**
     * @return the x
     */
    public int getX() {
        return X;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        X = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return Y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        Y = y;
    }

    /**
     * @return the z
     */
    public int getZ() {
        return Z;
    }

    /**
     * @param z the z to set
     */
    public void setZ(int z) {
        Z = z;
    }

    /**
     * @return the yR
     */
    public int getyR() {
        return yR;
    }

    /**
     * @param yR the yR to set
     */
    public void setyR(int yR) {
        this.yR = yR;
    }

    /**
     * @return the oreint
     */
    public int getOreint() {
        return oreint;
    }

    /**
     * @param oreint the oreint to set
     */
    public void setOreint(int oreint) {
        this.oreint = oreint;
    }

    /**
     * @return the p
     */
    public Player getP() {
        return p;
    }

    /**
     * @param p the p to set
     */
    public void setP(Player p) {
        this.p = p;
    }

    /**
     * @return the d4
     */
    public double getD4() {
        return d4;
    }

    /**
     * @param d4 the d4 to set
     */
    public void setD4(double d4) {
        this.d4 = d4;
    }

    /**
     * @return the d5
     */
    public double getD5() {
        return d5;
    }

    /**
     * @param d5 the d5 to set
     */
    public void setD5(double d5) {
        this.d5 = d5;
    }

    /**
     * @return the chunks
     */
    public ArrayList<Chunk> getChunks() {
        return chunks;
    }

    /**
     * @param chunks the chunks to set
     */
    public void setChunks(ArrayList<Chunk> chunks) {
        this.chunks = chunks;
    }

    /**
     * @return the r
     */
    public Random getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(Random r) {
        this.r = r;
    }

    /**
     * @return the isStone
     */
    public boolean isStone() {
        return isStone;
    }

    /**
     * @param isStone the isStone to set
     */
    public void setStone(boolean isStone) {
        this.isStone = isStone;
    }

    /**
     * @return the materials
     */
    public Material[] getMaterials() {
        return materials;
    }

    /**
     * @param materials the materials to set
     */
    public void setMaterials(Material[] materials) {
        this.materials = materials;
    }
}
