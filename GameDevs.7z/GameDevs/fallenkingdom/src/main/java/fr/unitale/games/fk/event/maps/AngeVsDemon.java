package fr.unitale.games.fk.event.maps;

import java.util.Collections;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.FallingBlock;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.util.Vector;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.Title;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.items.UniItemStack;

public class AngeVsDemon implements Listener {
	public static byte eventRouge = 14;
	public static byte eventBlue = 3;
	private FKTeam t;
	private Random r = new Random();

	public AngeVsDemon() {
		GameEngine.getInstance().getPlugin().getServer().getPluginManager().registerEvents(this,
				UnitaleSDK.getInstance());
		Title.sendTitle("",  Lang.str("game.fk.event.angevsdemon"));

		final TeamModule<FKTeam> tm = FKEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);
		for (final FKTeam t : tm.getTeams()) {
			this.t = t;
			for (int i = 0; i < 20; i++) {
				spawnEvent();
			}
		}
	}

	public void spawnEvent() {
		World ws = Bukkit.getWorlds().get(0);

		int x = r.nextInt(10);
		int y = 40;
		int z = r.nextInt(10);

		float xf = (float) (-2 + (Math.random() * (float) ((2 - -2))));
		float yf = (float) (-3 + (Math.random() * (float) ((2 - -2))));
		float zf = (float) (-2.5 + (Math.random() * (float) ((2.5 - -2.5))));

		Location loc = t.getBase().getCenter();

		@SuppressWarnings("deprecation")
		FallingBlock f = ws.spawnFallingBlock(new Location(ws, loc.getX() + x, loc.getY() + y, loc.getZ() + z),
				Material.OBSIDIAN, (byte) 0);
		f.setVelocity(new Vector(xf, yf, zf));
		f.setDropItem(false);
		f.setCustomNameVisible(false);
		if (t.getColor().equals(UniColor.LIGHT_BLUE))
			f.setCustomName("Rouge");
		else
			f.setCustomName("Bleu");
	}

	@EventHandler
	public void onBlockFall(EntityChangeBlockEvent e) {
		if (e.getEntity() instanceof FallingBlock) {
			Material changingTo = ((FallingBlock) e.getEntity()).getMaterial();

			if (changingTo.equals(Material.OBSIDIAN)) {
				e.setCancelled(true);

				Location loc = e.getEntity().getLocation();
				ArmorStand ar = (ArmorStand) e.getEntity().getWorld()
						.spawnEntity(e.getBlock().getLocation().add(0.50, -1.5, 0.75), EntityType.ARMOR_STAND);
				ar.setVisible(false);
				ar.setInvulnerable(false);
				ar.setAI(false);
				ar.setHelmet(new UniItemStack(Material.NETHER_STAR));
				loc.getWorld().createExplosion(loc, 0);
				if (e.getEntity().getCustomName().contains("Bleu")) {
					e.getBlock().setType(Material.STAINED_GLASS);
					e.getBlock().setData(eventBlue);
				} else {
					e.getBlock().setType(Material.STAINED_GLASS);
					e.getBlock().setData(eventRouge);
				}

			}
		}
	}

	@EventHandler
	public void EntityDamage(BlockBreakEvent e) {
		final Location l = e.getPlayer().getLocation();
		final FKTeam atk = (FKTeam) UniTeam.getTeam(e.getPlayer());

		if (e.getBlock().getType().equals(Material.STAINED_GLASS)) {
			if (e.getBlock().getData() == eventRouge) {
				if (atk.getColor().equals(UniColor.RED)) {
					e.setCancelled(true);
					e.getBlock().setType(Material.AIR);
					l.getWorld().dropItem(l.add(0, 1, 0), getCrystaux((UniPlayer) e.getPlayer(), eventRouge,
							Lang.str(e.getPlayer(), "game.fk.event.angevsdemon.crystaldark")));
					deleteArmor(e.getBlock().getLocation());
				} else {
					e.setCancelled(true);
				}
			} else if (e.getBlock().getData() == eventBlue) {
				if (atk.getColor().equals(UniColor.LIGHT_BLUE)) {
					e.setCancelled(true);
					e.getBlock().setType(Material.AIR);
					l.getWorld().dropItem(l.add(0, 1, 0), getCrystaux((UniPlayer) e.getPlayer(), eventBlue,
							Lang.str(e.getPlayer(), "game.fk.event.angevsdemon.crystallight")));
					deleteArmor(e.getBlock().getLocation());
				} else {
					e.setCancelled(true);
				}
			}
		}

	}

	public void deleteArmor(Location loc) {
		for (Entity e : loc.getWorld().getNearbyEntities(loc, 1, 2, 1)) {
			if (e instanceof ArmorStand) {
				e.remove();
			}

		}
		
	}

	public static UniItemStack getCrystaux(UniPlayer p, byte teamcolor, String string) {
		return new UniItemStack(Material.STAINED_GLASS, teamcolor).setName(Lang.str(p, string))
				.setLores(Collections.singletonList(Lang.str(p, "game.fk.item.price", 100 + "")));

	}
}
