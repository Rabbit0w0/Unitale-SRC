package fr.unitale.games.fk;

import fr.unitale.games.fk.maps.GeneratorOres;
import fr.unitale.games.fk.maps.Maps;
import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Wrapper extends JavaPlugin {
    public static final String CONFIG_NAME = "fk.json";
    public static String map = "";
    public static boolean randommap;
    public static JSONObject jsonob;
    private static JavaPlugin instance;
    public FKEngine fkengine;
    public File file;
	private Location loc1, loc2, locfinale;
	
    /**
     * Get a config value
     *
     * @param <T>    type of the argument needed, defined by the default value to return
     * @param path   {@link String} path of the value to get as "path.to.my.value"
     * @param def    default value to set if not found
     * @param config
     * @return the needed value
     */
    @SuppressWarnings("unchecked")
    public static <T> T getConfig(String path, T def, JSONObject config) {
        if (config == null) {
            return def;
        }

        final String[] nodes = path.contains(".") ? path.split("\\.") : new String[]{path};
        JSONObject node = config;
        for (int i = 0; i < nodes.length - 1; i++) {
            final String next = nodes[i];
            final Object found = node.get(next);
            if (found instanceof JSONObject) {
                node = (JSONObject) found;
            } else {
                return def;
            }
        }
        final Object value = node.get(nodes[nodes.length - 1]);
        if (value == null) {
            return def;
        }
        if (def.getClass().isAssignableFrom(value.getClass())) {
            return (T) value;
        } else if (Number.class.isAssignableFrom(def.getClass()) && Number.class.isAssignableFrom(value.getClass())) {
            //TODO Codé de façon un peu porcine. À changer quand on aura le temps de se pencher sur ce problème
            try {
                final Constructor<?> constructor = def.getClass().getDeclaredConstructor(String.class);
                return (T) constructor.newInstance(value.toString());
            } catch (final Exception e) {
                e.printStackTrace();
            }
        }
        return def;
    }

    public static JavaPlugin getInstance() {
        return instance;
    }

    @Override
    public void onLoad() {
        UnitaleSDK.loadAPI(API.UI, API.MORPH, API.AREA, API.GLOWING, API.SCHEMATIC, API.CUSTOM_ENTITIES, API.ADVANCEMENT, API.NPC, API.LANGUAGE);

        file = new File("plugins", CONFIG_NAME);
        String json = GameEngine.getJSONContent(file);
        JSONParser parser = new JSONParser();
        try {
            jsonob = (JSONObject) parser.parse(json);
            randommap = getConfig("MapRamdom", true, jsonob);
            map = getConfig("Map", "angevsdemon", jsonob);
        } catch (ParseException e1) {
            e1.printStackTrace();
            System.exit(0);
        }

        if (randommap|| map.equalsIgnoreCase("null")) {
            List<String> maps = new ArrayList<>();
            for (Maps map : Maps.values()) {
                maps.add(map.getName());
            }

            int mapCount = maps.size();
            Random randomGenerator = new Random();
            int random = randomGenerator.nextInt(mapCount);
            map = maps.get(random);
            System.out.print(map);
        }
        map = map.toLowerCase();
        
        File srcFolder = new File(map);
        File destFolder = new File("world/");
        if (!srcFolder.exists()) {
        	System.out.println(srcFolder);
            System.out.println("Directory does not exist.");
            System.exit(0);
        } else {
            try {
                copyFolder(srcFolder, destFolder);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(0);
            }
        }
    }

    @Override
    public void onEnable() {
        UniLogger.info("FK Wrapper launched !");

        // Ore generator
		this.loc1 = new Location(Bukkit.getWorlds().get(0), -300, 0, -450);
		this.loc2 = new Location(Bukkit.getWorlds().get(0), 450, 255, 300);

		try {
			setBlock(loc1, loc2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// Start Games Instance
        if (file.exists()) {
            fkengine = new FKEngine(this, GameEngine.getJSONContent(file));
        } else {
            fkengine = new FKEngine(this, GameEngine.getDefaultJSONContent(Wrapper.class, CONFIG_NAME));
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        deleteWorld(new File("world/"));
        deleteWorld(new File("world_the_end/"));
        deleteWorld(new File("world_nether/"));
    }

    public void copyFolder(File src, File dest) throws IOException {
        if (src.isDirectory()) {
            // if directory not exists, create it
            if (!dest.exists()) {
                dest.mkdir();
            }

            // list all the directory contents
            String[] files = src.list();
            for (String file : files) {
                // construct the src and dest file structure
                File srcFile = new File(src, file);
                File destFile = new File(dest, file);
                // recursive copy
                copyFolder(srcFile, destFile);
            }

        } else {
            // if file, then copy it
            // Use bytes stream to support all file types
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dest);

            byte[] buffer = new byte[1024];

            int length;
            // copy the file content in bytes
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }

            in.close();
            out.close();
        }
    }

    public boolean deleteWorld(File path) {
        if (path.exists()) {
            File[] files = path.listFiles();
            for (File value : files) {
                if (value.isDirectory()) {
                    deleteWorld(value);
                } else {
                    value.delete();
                }
            }
        }
        return (path.delete());
    }
    
    //Get Blocks Ore and generate
	public void setBlock(Location pos1, Location pos2) throws Exception {

		if (pos1.getWorld() != pos2.getWorld())
			throw new Exception("Le monde n'est pas le même entre les deux points");
		if (pos1.getBlockX() > pos2.getBlockX()) {
			Location tmp = pos1;
			pos1 = pos2;
			pos2 = tmp;
		}
		if (pos1.getBlockZ() > pos2.getBlockZ()) {
			Location tmp = pos1;
			pos1 = pos2;
			pos2 = tmp;
		}
		for (int x = pos1.getBlockX(); x <= pos2.getBlockX(); x++) {
			for (int z = pos1.getBlockZ(); z <= pos2.getBlockZ(); z++) {
				for (int y = pos1.getBlockY(); y <= pos2.getBlockY(); y++) {
					Block b = pos1.getWorld().getBlockAt(x, y, z);
					if (b.getType().equals(Material.AIR)) {
						Chunk c = pos1.getWorld().getChunkAt(b);
						boolean need = false;
						if (!c.isLoaded()) {
							c.load();
							need = true;
						}
						this.locfinale = b.getLocation();
						new GeneratorOres(this.locfinale);
						if (need)
							c.unload();
					}
				}
			}
		}
	}
}
