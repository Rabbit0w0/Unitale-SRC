package fr.unitale.games.fk.event.maps.nordique;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.utils.area.AreaAPI;
import fr.unitale.sdk.utils.area.Cuboid;
import org.bukkit.Location;
import org.bukkit.block.Block;

import java.util.LinkedList;
import java.util.List;

public class Castel extends Cuboid {

    public Castel(Location center, double size) {
        super("CASTEL", center, size);
        UnitaleSDK.getAPI(AreaAPI.class).addArea(this);
    }

    public List<Block> getBlocks() {
        final List<Block> b = new LinkedList<>();
        final int x = (int) (this.center.getBlockX() - this.xSize / 2);
        final int y = (int) (this.center.getBlockY() - this.ySize / 2);
        final int z = (int) (this.center.getBlockZ() - this.zSize / 2);

        for (int i = 0; i < this.xSize; i++) {
            for (int j = 0; j < this.ySize; j++) {
                for (int k = 0; k < this.zSize; k++) {
                    b.add(this.center.getWorld().getBlockAt(x + i, y + j, z + k));
                }
            }
        }
        return b;
    }
}
