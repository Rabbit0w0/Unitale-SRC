package fr.unitale.games.fk.event.maps;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.event.Listener;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.maps.Maps;
import fr.unitale.games.fk.ui.interact.PawnkioNoirInteract;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.morphs.model.data.NPCPlayerMorphData;
import fr.unitale.sdk.npcs.NPCAPI;
import fr.unitale.sdk.npcs.NPCData;
import fr.unitale.sdk.npcs.NPCDataFactory;
import fr.unitale.sdk.utils.auth.EditableGameProfile;
import fr.unitale.sdk.utils.chat.Title;

public class Candy_Anderval implements Listener {

	public Candy_Anderval() {

		GameEngine.getInstance().getPlugin().getServer().getPluginManager().registerEvents(this,
				UnitaleSDK.getInstance());
		Title.sendTitle("", Lang.str("game.fk.event.candy_anderval"));

		if (Maps.valueOf(Wrapper.map.toUpperCase()).getName().contains(MapType.CANDY_1VS1.getName())) {
			Block b = FKEngine.getInstance().getGameMap().getLobby().add(10, 0, 6).getBlock();
			spawnNpcNoir(b);
		} else if (Maps.valueOf(Wrapper.map.toUpperCase()).getName().contains(MapType.AANDOVALE1VS1.getName())) {
			Block b = new Location(Bukkit.getWorlds().get(0), -30, 95, 0).getBlock();
			spawnNpcNoir(b);
		}
	}

	public void spawnNpcNoir(Block b) {
		NPCData data1 = new NPCDataFactory().spawnLocation(b.getLocation()).interaction(new PawnkioNoirInteract())
				.morph(new NPCPlayerMorphData(getProfile("Marchand noir")).setName("Marchand noir")).create();
		Bukkit.getWorlds().get(0).getBlockAt(new Location(Bukkit.getWorlds().get(0), b.getLocation().getX(),
				b.getLocation().getY() - 1, b.getLocation().getZ())).setType(Material.BEDROCK);
		Entity e = UnitaleSDK.getAPI(NPCAPI.class).spawn(data1);
		e.setInvulnerable(true);
		e.setGravity(true);
	}

	private GameProfile getProfile(String name) {
		final EditableGameProfile profile = new EditableGameProfile(UUID.randomUUID(), name);
		profile.setLegacy(true);
		profile.setProperty("textures", new Property("textures",
				"eyJ0aW1lc3RhbXAiOjE1ODUwNjUyOTMzODUsInByb2ZpbGVJZCI6IjhiMzAxYWQ3NGY2NTQ0MzY4Yzg2OWYyZjU3ZDdjOGYzIiwicHJvZmlsZU5hbWUiOiJIeUJvdCIsInNpZ25hdHVyZVJlcXVpcmVkIjp0cnVlLCJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2ZkNzAyZDUyOTRmZTJjYzkzY2JiMDQ4NDVmZDQzNDA3OTJjOTQzOTkyMDlkZDE1Mjg3ODEwMWI3ZGI1YjQ2MCJ9fX0=",
				"Wa/l9ilb0ZdJhU9sp7Q/+5uki+rpeyhi/45CgJhziDTI4Gj0EUlOaMR9RCsjvBP3Oo+4IgBqWNiVsrlT30ExHvGjQKQ7Xh1Ns4ne3tbS/Fbp9oGEKZlJlXHp/8KzCYGXRlnv9lwgsS2zNfqNx8oQBVTs+K51u8i0fdduMLJ6mxzTvgNdM6DHow5gXavbWXxU+6X+j2PFDc1z4tWG7B38Hl4akbjhTR6OEIy4/lJA+eIIma3XSQj9o5KE52DGDs9aMxPwIqH6+rYfqcsR0x29lFsJVJcm2uCSUyK1aZdVwjVtSoRJqtM+NhrsZykB4z8MJjlPuvoCYVAmW8kLqjb3MatzWNqJ7VxWmpzJ+kanIQB0DM41MrTyTJCm2+qxHq3lTC8lCkUWTHW1EuIxPJ9dYcKJgcK0dzjiiDR824RA8JUBGH7K5W4j3He3aTxsT201IH+rf4LbeZh5fsvc21UBWcQDlggwrOuFnXEukPX/tzXez3XwxgTtPW2Q0FEpj5yGRpzd002EFNms9swtLyVOZtMEUFRrXDzBRUa445tjT/vo4RM+suLQPPvtS5QUfwGGItcEm6sWYaCSVigwWrRLks6mOz2VYMIEAN4mX7X9kwG6JXLfrVSb2C8nKPifNwlkTWEjfnN0OPzCC5f07+UNZ0Mr3k2xOz9h1WMoJ4UHyxg="));
		return profile;
	}
}
