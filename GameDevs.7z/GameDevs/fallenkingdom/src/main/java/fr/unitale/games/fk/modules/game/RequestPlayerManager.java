package fr.unitale.games.fk.modules.game;

import fr.unitale.api.QueueApi;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.api.type.ServerTypes.ServerType;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateOfflinePlayer;
import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerQuitEvent;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.server.ServerManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.PlayerInventory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

public class RequestPlayerManager implements Listener {
	private final GameEngine<?> engine;
	private boolean active;
	private Map<UUID, EliminatedPlayer> prevInventories;
	private Map<UUID, EliminatedPlayer> inventories;

	public RequestPlayerManager() {
		this.engine = GameEngine.getInstance();
		this.active = false;
		this.prevInventories = new LinkedHashMap<>();
		this.inventories = new LinkedHashMap<>();
	}

	public void open() {
		this.active = true;
	}

	public void close() {
		this.active = false;
		this.prevInventories.clear();
		this.inventories.clear();

	}

	@EventHandler
	public void onGamePlayerQuit(GamePlayerQuitEvent e) {
		prevInventories.put(e.getPlayer().getUniqueId(), new EliminatedPlayer(e.getPlayer()));
	}

	@EventHandler
	public void onGamePlayerJoin(GamePlayerJoinEvent e) {
		if (UniTeam.getTeam(e.getPlayer()) != null) {
			this.prevInventories.remove(e.getPlayer().getUniqueId());
			return;
		}
		if (this.inventories.size() == 0 || !this.active)
			return;
		Entry<UUID, EliminatedPlayer> inv = getFirstInventory();

		if (inv != null) {
			e.getPlayer().getInventory().clear();
			e.getPlayer().getInventory().addItem(inv.getValue().getInventory().getContents());
			e.getPlayer().setLevel(inv.getValue().getLevel());
			e.getPlayer().setExp(inv.getValue().getXp());
			e.getPlayer().teleport(inv.getValue().getLocation());
			this.inventories.remove(inv.getKey());
		}

		if (this.inventories.size() == 0) {

			QueueApi.getInstance().endRequest(GameEngine.getInstance().getGameUuid());
		}
	}

	private Entry<UUID, EliminatedPlayer> getFirstInventory() {
		TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
		if (tm == null)
			return null;
		UniTeam smaller = null;
		int size = 0;
		for (UniTeam t : tm.getTeams()) {
			if (smaller == null || t.getCompetingCount() < size) {
				smaller = t;
				size = t.getCompetingCount();
			}
		}
		Entry<UUID, EliminatedPlayer> r = null;
		for (Entry<UUID, EliminatedPlayer> e : this.inventories.entrySet()) {
			if (e.getValue().getTeam() == smaller)
				return e;
			r = e;
		}
		return r;
	}

	@EventHandler
	public void onEliminateOfflinePlayer(EliminateOfflinePlayer e) {
		EliminatedPlayer p = this.prevInventories.get(e.getUUID());
		if (p != null) {
			this.inventories.put(e.getUUID(), p);
			this.prevInventories.remove(e.getUUID());
			resetRequest();
		}
	}

	private void resetRequest() {
		final int player = this.inventories.size();
		final String mapName = (engine.getMap() != null) ? engine.getMap().getType().name() : null;
		final boolean vip = engine.isVip();
		TeamModule<UniTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
		int maxplayer = tm.getTeamSize()*tm.getNbTeam();
		QueueApi.getInstance().request(GameEngine.getInstance().getGameUuid(), ServerType.FALLENKINGDOM, mapName, ServerMode.NORMAL, Mode.TEAM, tm.getTeamSize(), maxplayer-GameEngine.getInstance().getOnlinePlayers().size(), maxplayer, vip);
	}

	public static class EliminatedPlayer {
		private final PlayerInventory inventory;
		private final Location location;
		private final int level;
		private final float xp;
		private final UniTeam team;

		public EliminatedPlayer(PlayerInventory inv, Location loc, int lvl, float xp, UniTeam team) {
			this.inventory = inv;
			this.location = loc.clone();
			this.level = lvl;
			this.xp = xp;
			this.team = team;
		}

		public EliminatedPlayer(Player player) {
			this(player.getInventory(), player.getLocation(), player.getLevel(), player.getExp(),
					UniTeam.getTeam(player));
		}

		public PlayerInventory getInventory() {
			return inventory;
		}

		public Location getLocation() {
			return location;
		}

		public int getLevel() {
			return level;
		}

		public float getXp() {
			return xp;
		}

		public UniTeam getTeam() {
			return team;
		}
	}
}
