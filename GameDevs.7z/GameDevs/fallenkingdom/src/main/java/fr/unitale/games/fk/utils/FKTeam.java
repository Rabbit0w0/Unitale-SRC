package fr.unitale.games.fk.utils;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Cow;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.maps.Maps;
import fr.unitale.games.fk.npc.Pawnkio;
import fr.unitale.games.fk.npc.Stuffy;
import fr.unitale.games.fk.npc.Upgrader;
import fr.unitale.sdk.bar.BarAPI;
import fr.unitale.sdk.bar.EndBar;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.Title;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import fr.unitale.sdk.utils.color.UniColor;

public class FKTeam extends UniTeam {
	private final EndBar captureBar;
	// Player can teleport to nether and end
	protected boolean canGoNether, canGoEnd;
	private Base base;
	private boolean defend, attack, warningalert, barLinked;
	private String money = "MONEY";
	// Effect niveau effect
	private Integer healthCore, healthCoreMax, countMoneyUpgrade, countBiblioUpgrade, effectSpeed, effectNightVision,
			effectAbsorption;
	private EnderCrystal endercrystal;
	private List<Block> queueWall, queueFall, queueCore;
	private ArrayList<Location> queueBiblio;

	public FKTeam(String name, UniColor color, int size) {
		super(name, color, size);

		this.base = null;
		this.defend = false;
		this.attack = false;
		this.barLinked = false;
		this.warningalert = true;
		this.healthCore = 4000;
		this.healthCoreMax = 4000;
		this.captureBar = BarAPI.generateDefaultBar(getHealthCore() + "", BarColor.BLUE);
		this.endercrystal = null;
		this.effectSpeed = -1;
		this.effectAbsorption = 0;
		this.effectNightVision = 0;
		queueWall = new ArrayList<>();
		queueFall = new ArrayList<>();
		queueCore = new ArrayList<>();
		queueBiblio = new ArrayList<>();

		this.canGoNether = true;
		this.canGoEnd = true;
		this.countMoneyUpgrade = 1;
		this.countBiblioUpgrade = 0;
	}

	public static UniColor getHealth(int heals, int healmax) {

		double heal = (heals / healmax) * heals;

		if (heal <= healmax) {
			return UniColor.GREEN;
		} else if (heal != healmax && heal > healmax / 2) {
			return UniColor.ORANGE;
		} else if (heal >= healmax / 2) {
			return UniColor.RED;
		} else {
			return UniColor.BROWN;
		}
	}

	/*
	 * Delete lobby
	 */
	private void destroyLobby(Location center) {
		for (int x = (center.getBlockX() - 30) - 1; x <= center.getBlockX() + 30; x++) {
			for (int y = (center.getBlockY() - 15) - 1; y <= center.getBlockY() + 15; y++) {
				for (int z = (center.getBlockZ() - 30) - 1; z <= center.getBlockZ() + 30; z++) {
					Location l = center.clone();
					l.setX(x);
					l.setY(y);
					l.setZ(z);
					l.getBlock().setType(Material.AIR);
				}
			}
		}
	}

	public void iniBar(String s) {
		this.captureBar.setTitle(s);
	}

	public void iniFailedBar(String s) {
		this.captureBar.valueConfig(1, 1);
		this.captureBar.setColor(BarColor.RED);
		this.captureBar.setTitle(s);
	}

	public void iniFailedBar() {
		iniFailedBar(ChatColor.RED + "/!\\ Team incomplete /!\\");
	}

	public void updateBar(int value) {
		final int max = 100;
		this.captureBar.setValue(max - value + value);
		if (value <= (max / 4)) {
			this.captureBar.setColor(BarColor.RED);
		} else if (value <= (max / 2)) {
			this.captureBar.setColor(BarColor.YELLOW);
		} else {
			this.captureBar.setColor(BarColor.GREEN);
		}
	}

	public void setLink(UniPlayer p) {
		if (this.barLinked) {
			linkBar(p);
		} else {
			unlinkBar(p);
		}
	}

	public void linkBar() {
		this.barLinked = true;
		for (final UniPlayer p : this.getOnlinePlayers()) {
			linkBar(p);
		}
	}

	public void unlinkBar() {
		this.barLinked = false;
		for (final UniPlayer p : this.getOnlinePlayers()) {
			unlinkBar(p);
		}
	}

	public void linkBar(UniPlayer p) {
		this.captureBar.joinBar(p);
	}

	public void unlinkBar(UniPlayer p) {
		this.captureBar.quitBar(p);
	}

	@Override
	public void playerQuit(Player p) {
		this.captureBar.removePlayer((UniPlayer) p);
	}

	public Base getBase() {
		return base;
	}

	public void setBase(Base base) {
		this.base = base;
	}

	public boolean isDefending() {
		return this.defend;
	}

	public boolean isAttacking() {
		return this.attack;
	}

	// teleport start game
	public void tpBase() {
		for (UniPlayer p : getOnlinePlayers()) {
			p.teleport(this.base.getCenter().add(2, 0, 0));
			p.getStorage().addInteger(money, 0);
		}
		PlayerCollector.doForEach(p -> {
			getOnlinePlayers().forEach(x -> {
				p.showPlayer(x);
				x.setAllowFlight(false);
				x.setFlying(false);
			});
		});

	}

	// Teleport for generate npc
	public void tpBaseTravelling() {
		for (Maps maps : Maps.values()) {
			if (maps.getName().equals(Wrapper.map) && maps.isDeletelobby()) {
				destroyLobby(FKEngine.getInstance().getGameMap().getWorldSpawn());
			}
		}
		final Location teleportLoc = base.getCenter().add(2, 0, 0);
		PlayerCollector.doForEach(p -> {
			p.teleport(teleportLoc);
			p.getStorage().addInteger(money, 0);
			p.getInventory().clear();
			getOnlinePlayers().forEach(x -> {
				p.hidePlayer(x);
				x.setAllowFlight(true);
				x.setFlying(true);
			});
		});
	}

	// Create Npc and base
	public void addCrystal() {
		final int x = getBase().getCenter().getBlock().getX();
		final int z = getBase().getCenter().getBlock().getZ();
		final int y = getBase().getCenter().getBlock().getY();

		final Block b = getBase().getCenter().getBlock().getWorld().getBlockAt(x, y, z);

		// Creat Wall init
		getBase().createBaseBuild(Material.COBBLESTONE);

		// Creat Npc init base
		final Pawnkio kio = new Pawnkio(b);
		kio.setNpc();
		kio.initHoloText();
		kio.initHoloTextmini();
		new Stuffy(b);
		new Upgrader(b);
	}

	private void spawnAnimal(Location center, Class<? extends Entity> c, int off) {
		final double x = Math.cos(off);
		final double z = Math.sin(off);
		center.getWorld().spawn(new Location(center.getWorld(), center.getX() + x * 3.5D + 0.5D, center.getY(),
				center.getZ() + z * 3.5D + 0.5D), c);
	}

	public void spawnAnimal() {
		Location l = getBase().getCenter();
		l.setY(l.getY() + 1);
		int off = 0;
		for (int i = 0; i < 3; i++) {
			spawnAnimal(l, Sheep.class, off++);
			spawnAnimal(l, Cow.class, off++);
			spawnAnimal(l, Chicken.class, off++);
			spawnAnimal(l, Pig.class, off++);
		}
	}

	public void title(String title) {
		title(title, null);
	}

	public void title(String title, String subtitle) {
		for (final OfflinePlayer op : this.getOfflinePlayers()) {
			if (op.isOnline()) {
				Title.sendTitle(op.getPlayer(), title, subtitle);
			}
		}
	}

	public void explodeBase() {
		this.base = null;
	}

	public boolean isCanGoNether() {
		return canGoNether;
	}

	public void setCanGoNether(boolean canGoNether) {
		this.canGoNether = canGoNether;
	}

	public boolean isCanGoEnd() {
		return canGoEnd;
	}

	public void setCanGoEnd(boolean canGoEnd) {
		this.canGoEnd = canGoEnd;
	}

	@Override
	public void setSpawn(Location l) {
		super.setSpawn(l);
		if (this.base != null)
			return;
		final int s = 29;

		System.out.println("Une base de " + s);
		setBase(new Base(this, l, s, 200D, s));
		// Remove Structure Init Buildeur
		destroyCenterBase(this.base.getCenter(), 6);

		this.endercrystal = getBase().getCenter().getWorld().spawn(getBase().getCenter().add(0.5, 0, 0.5),
				EnderCrystal.class);
		this.endercrystal.setCustomNameVisible(false);
		this.endercrystal.setCustomName(getHealthCore().toString());
		this.endercrystal.setTicksLived(getHealthCoreMax());
		this.endercrystal.setGlowing(true);
		this.endercrystal.setShowingBottom(false);
	}

	/*
	 * Delete center base
	 */
	private void destroyCenterBase(Location center, int radius) {
		for (int x = (center.getBlockX() - radius) - 1; x <= center.getBlockX() + radius; x++) {
			for (int y = (center.getBlockY()); y <= center.getBlockY() + 5; y++) {
				for (int z = (center.getBlockZ() - radius) - 1; z <= center.getBlockZ() + radius; z++) {
					Location l = center.clone();
					l.setX(x);
					l.setY(y);
					l.setZ(z);
					l.getBlock().setType(Material.AIR);
				}
			}
		}
	}

	/**
	 * @return the healthCore
	 */
	public Integer getHealthCore() {
		return healthCore;
	}

	/**
	 * @param healthCore the healthCore to set
	 */
	public void setHealthCore(UniPlayer p, Integer healthCore) {
		this.healthCore = healthCore;
		if (getHealthCore() > getHealthCoreMax()) {
			this.healthCore = getHealthCoreMax();
			getEndercrystal().setCustomName(Lang.str(p, "game.fk.core.heal", getHealthCoreMax().toString()));
			getCaptureBar().setTitle(Lang.str(p, "game.fk.core.heal", getHealthCoreMax().toString()));
		} else {
			getEndercrystal().setCustomName(Lang.str(p, "game.fk.core.heal", getHealthCore().toString()));
			getCaptureBar().setTitle(Lang.str(p, "game.fk.core.heal", getHealthCore().toString()));
		}
	}

	public void killTeam() {
		for (UniPlayer x : getOnlinePlayers()) {
			x.setHealth(0);
		}
	}

	/**
	 * @return the healthCoreMax
	 */
	public Integer getHealthCoreMax() {
		return healthCoreMax;
	}

	/**
	 * @param healthCoreMax the healthCoreMax to set
	 */
	public void setHealthCoreMax(Integer healthCoreMax, int count) {
		this.healthCoreMax = healthCoreMax;
		broadcast("Amélioration de " + count + " points max de votre coeurs");
	}

	/**
	 * @return the defend
	 */
	public boolean isDefend() {
		return defend;
	}

	public void setDefend(boolean b) {
		this.defend = b;
	}

	/**
	 * @return the attack
	 */
	public boolean isAttack() {
		return attack;
	}

	public void setAttack(boolean b) {
		this.attack = b;
	}

	/**
	 * @return the captureBar
	 */
	public EndBar getCaptureBar() {
		return captureBar;
	}

	/**
	 * @return the barLinked
	 */
	public boolean isBarLinked() {
		return barLinked;
	}

	/**
	 * @param barLinked the barLinked to set
	 */
	public void setBarLinked(boolean barLinked) {
		this.barLinked = barLinked;
	}

	/**
	 * @return the money
	 */
	public String getMoney() {
		return money;
	}

	/**
	 * @param money the money to set
	 */
	public void setMoney(String money) {
		this.money = money;
	}

	/**
	 * @return the endercrystal
	 */
	public EnderCrystal getEndercrystal() {
		return endercrystal;
	}

	/**
	 * @return the countMoneyUpgrade
	 */
	public Integer getCountMoneyUpgrade() {
		return countMoneyUpgrade;
	}

	/**
	 * @param countMoneyUpgrade the countMoneyUpgrade to set
	 */
	public void setCountMoneyUpgrade(Integer countMoneyUpgrade) {
		this.countMoneyUpgrade = countMoneyUpgrade;
	}

	/**
	 * @return the effectSpeed
	 */
	public Integer getEffectSpeed() {
		return effectSpeed;
	}

	/**
	 * @param effectSpeed the effectSpeed to set
	 */
	public void setEffectSpeed(Integer effectSpeed) {
		this.effectSpeed = effectSpeed;
		for (UniPlayer x : getOnlinePlayers())
			x.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 99999, getEffectSpeed(), false, false));
	}

	/**
	 * @return the effectAbsorption
	 */
	public Integer getEffectAbsorption() {
		return effectAbsorption;
	}

	/**
	 * @param effectAbsorption the effectAbsorption to set
	 */
	public void setEffectAbsorption(Integer effectAbsorption) {
		this.effectAbsorption = effectAbsorption;
		for (UniPlayer x : getOnlinePlayers())
			x.setMaxHealth(20 + getEffectAbsorption());
	}

	/**
	 * @return the queueWall
	 */
	public List<Block> getQueueWall() {
		return queueWall;
	}

	/**
	 * @return the queueFall
	 */
	public List<Block> getQueueFall() {
		return queueFall;
	}

	/**
	 * @param queueFall the queueFall to set
	 */
	public void setQueueFall(List<Block> queueFall) {
		this.queueFall = queueFall;
	}

	public boolean isQueueWall(Player p) {
		if (queueWall.size() == 0) {
			return true;
		} else {
			p.sendMessage(Lang.str(p, "game.fk.upgrade.wall"));
			return false;
		}
	}

	public boolean isQueueFall(Player p) {
		if (queueFall.size() == 0) {
			return true;
		} else {
			p.sendMessage(Lang.str(p, "game.fk.upgrade.moat"));
			return false;
		}
	}

	public boolean isQueueCore(Player p) {
		if (queueCore.size() == 0) {
			return true;
		} else {
			p.sendMessage(Lang.str(p, "game.fk.upgrade.core"));
			return false;
		}
	}

	/**
	 * @return the queueBiblio
	 */
	public ArrayList<Location> getQueueBiblio() {
		return queueBiblio;
	}

	/**
	 * @return the countBiblioUpgrade
	 */
	public Integer getCountBiblioUpgrade() {
		return countBiblioUpgrade;
	}

	/**
	 * @param countBiblioUpgrade the countBiblioUpgrade to set
	 */
	public void setCountBiblioUpgrade(Integer countBiblioUpgrade) {
		this.countBiblioUpgrade = countBiblioUpgrade;
	}

	/**
	 * @return the queueCore
	 */
	public List<Block> getQueueCore() {
		return queueCore;
	}

	public int getEffectNightVision() {
		return effectNightVision;

	}

	public void setEffectNightVision(UniPlayer p) {
		p.addPotionEffect(
				new PotionEffect(PotionEffectType.NIGHT_VISION, 5 * 60 * 20, effectNightVision, false, false));
	}

	public void cleatEffectNightVision(UniPlayer p) {
		p.removePotionEffect(PotionEffectType.NIGHT_VISION);
	}

	public void setEffectNightVision(int effectNightVision) {
		this.effectNightVision = effectNightVision;
		for (UniPlayer x : getOnlinePlayers())
			x.setMaxHealth(20 + getEffectAbsorption());
	}

	public boolean getAttackWarning() {
		return warningalert;
	}

	public void setAttackWarning(boolean warningalert) {
		this.warningalert = warningalert;
	}

}
