package fr.unitale.games.fk.modules.travel;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.Title;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public class TravellingPoint implements Comparable<TravellingPoint>{

    private static int TRAVELLINGPOINT_INC = 0;

    private Location loc;
    private Title title;
    private int id;

    public TravellingPoint(Location loc, Title title){
        id = TRAVELLINGPOINT_INC++;
        this.loc = loc;
        this.title = title;
    }

    public Location getLoc() {
        return loc;
    }

    public Title getTitle() {
        return title;
    }

    public void send(UniPlayer p){
        Bukkit.getScheduler().runTask(FKEngine.getInstance().getPlugin(), () -> {
            p.teleport(loc);
            p.sendTitle(Lang.str(p, title.getTitle()), Lang.str(p, title.getSubtitle()));
        });
    }

    public void sendAll(){
        PlayerCollector.doForEach(this::send);
    }

    @Override
    public int compareTo(TravellingPoint o) {
        return Integer.compare(id, o.id);
    }
}
