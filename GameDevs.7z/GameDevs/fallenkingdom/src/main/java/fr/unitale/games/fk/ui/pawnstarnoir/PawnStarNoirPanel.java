package fr.unitale.games.fk.ui.pawnstarnoir;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.event.maps.AngeVsDemon;
import fr.unitale.games.fk.maps.Maps;
import fr.unitale.games.fk.modules.game.utils.Money;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIClickPanel;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.SoundCreator;

public class PawnStarNoirPanel extends UIClickPanel<Money> implements UIFormHandler<Money> {
    private String name;
    private UniItemStack cryst;

    public PawnStarNoirPanel(UniPlayer p) {
        super(36);

        int slotsword = 9;

        for (Money money : Money.values()) {
            if (slotsword == 17)
                slotsword = 20;

            if (money.getItem() == Material.BEACON && Maps.valueOf(Wrapper.map.toUpperCase()).getName().contains(MapType.ANGEVSDEMON.getName())) {
                final FKTeam atk = (FKTeam) UniTeam.getTeam(p);

                if (!atk.getColor().equals(UniColor.LIGHT_BLUE)) {
                    name = Lang.str(p, "game.fk.event.angevsdemon.crystaldark");
                    cryst = AngeVsDemon.getCrystaux(p, AngeVsDemon.eventRouge, name);
                } else {
                    name = Lang.str(p, "game.fk.event.angevsdemon.crystallight");
                    cryst = AngeVsDemon.getCrystaux(p, AngeVsDemon.eventBlue, name);
                }
                setComponent(31, new UIButton<>(money, cryst));
            }
            if (money.getItem() != Material.BEACON) {
                setComponent(slotsword, new UIButton<>(money, new UniItemStack(money.getItem())
                        .setLores(Lang.str(p, "game.fk.item.price", money.getMoney(2).toString()))));
            }
            slotsword++;
        }
    }

    @Override
    public void onSubmit(Player player, Money value) {
        for (ItemStack i : player.getInventory().getStorageContents()) {
            try {
                if (value.getItem() == i.getType()) {
                    Money.addMoney((UniPlayer) player, value.getMoney(2) * i.getAmount());
                    player.getInventory().remove(i);
                } else if (Material.LOG_2 == i.getType()) {
                    Money.addMoney((UniPlayer) player, Money.valueOf("LOG").getMoney(2) * i.getAmount());
                    player.getInventory().remove(i);
                } else if (i.getItemMeta().getDisplayName().contains("Wood")) {
                    Money.addMoney((UniPlayer) player, value.getMoney(2) * i.getAmount());
                    player.getInventory().remove(i);
                } else if (i.getItemMeta().getDisplayName().contains("Cristaux")) {
                    Money.addMoney((UniPlayer) player, value.getMoney(2) * i.getAmount());
                    player.getInventory().remove(i);
                    SoundCreator.playSound(Sound.ENTITY_ENDERDRAGON_FLAP, 1L, player);
                    ParticleEffect.VILLAGER_HAPPY.display(player.getVelocity().clone().multiply(1), 0.5f,
                            player.getLocation());
                }
            } catch (Exception e) {
            }
        }
    }

}
