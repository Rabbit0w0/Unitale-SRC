package fr.unitale.games.fk.modules.game.utils.upgrades;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.schematics.Schematic;

public class RunSetBlock implements Runnable {
    private int task;
    private Location center;
    private List<Block> queue;
    private List<Integer> queueMat = new ArrayList<>();
    private List<Byte> queueData = new ArrayList<>();
    private Schematic schematic;
    private int materialInt = 0;
    private byte materialData;

    public RunSetBlock(Location center, List<Block> queue, Schematic schematic) {
        this.center = center;
        this.schematic = schematic;
        this.queue = queue;
    }


    public void run() {

        byte[] blocks = schematic.getBlocks();
        byte[] blockData = schematic.getData();
        short length = schematic.getLength();
        short width = schematic.getWidth();
        short height = schematic.getHeight();

        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                for (int z = 0; z < length; ++z) {
                    final int index = y * width * length + z * width + x;
                    final Block block = center.clone().add(x, y, z).getBlock();
                    if (index >= blocks.length || index >= blockData.length) {
                        continue;
                    }

                    materialInt = (blocks[index] & 0xFF);
                    materialData = blockData[index];
                    if (Material.AIR.getId() != materialInt) {
                        queueMat.add(materialInt);
                        queue.add(block);
                        queueData.add(materialData);
                    }
                }
            }
        }
        spawnBlock();
    }

    public void spawnBlock() {
        ListIterator<Block> iterable = queue.listIterator();
        ListIterator<Integer> iterablemat = queueMat.listIterator();
        ListIterator<Byte> iterableData = queueData.listIterator();
        task = Bukkit.getScheduler().scheduleSyncRepeatingTask(UnitaleSDK.getInstance(), new Runnable() {
            boolean t = false;

            @SuppressWarnings("deprecation")
            @Override
            public void run() {

                int timesPerRun = 1;
                if (queue.size() < timesPerRun) {
                    timesPerRun = queue.size();
                }

                t = false;

                while (timesPerRun >= 0 && iterable.hasNext() && iterablemat.hasNext() && iterableData.hasNext()) {
                    Block block = iterable.next();
                    Location loc = block.getLocation().add(0, 1, 0);
                    loc.getBlock().setTypeId(iterablemat.next());
                    loc.getBlock().setData(iterableData.next());
                    timesPerRun--;
                    t = true;
                }

                if (!t) {
                    queue.clear();
                    queueMat.clear();
                    queueData.clear();
                    Bukkit.getScheduler().cancelTask(task);
                }
            }
        }, 0, 4L);
    }

}
