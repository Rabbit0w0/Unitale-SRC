package fr.unitale.games.fk.commands;

import java.util.List;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.players.UniPlayer;

public class SuicideCommand extends AbstractCommand {

	public SuicideCommand() {
		super("suicide");
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof UniPlayer)) {
			return false;
		}
		UniPlayer p = (UniPlayer) sender;
		p.setHealth(0);
		return true;
	}

	@Override
	public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
		return null;
	}
}
