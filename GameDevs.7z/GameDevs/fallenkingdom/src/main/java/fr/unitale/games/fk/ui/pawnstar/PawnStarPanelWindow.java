package fr.unitale.games.fk.ui.pawnstar;

import org.bukkit.entity.Player;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIWindow;

public class PawnStarPanelWindow extends UIWindow {
    public PawnStarPanelWindow(Player p) {
        super(54, "");

        addPanel("main", new PawnStarPanel((UniPlayer) p));
        showPanel("main");
    }
}
