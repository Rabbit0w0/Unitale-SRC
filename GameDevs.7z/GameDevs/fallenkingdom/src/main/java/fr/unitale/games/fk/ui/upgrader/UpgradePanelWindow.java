package fr.unitale.games.fk.ui.upgrader;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIWindow;
import org.bukkit.entity.Player;

public class UpgradePanelWindow extends UIWindow {

    public UpgradePanelWindow(Player p) {
        super(27, "");

        addPanel("main", new UpgradePanel((UniPlayer) p));

        showPanel("main");
    }

}
