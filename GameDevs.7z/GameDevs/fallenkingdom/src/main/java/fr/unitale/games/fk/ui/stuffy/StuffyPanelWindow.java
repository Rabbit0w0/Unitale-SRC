package fr.unitale.games.fk.ui.stuffy;

import fr.unitale.sdk.ui.elements.UIWindow;
import org.bukkit.entity.Player;

public class StuffyPanelWindow extends UIWindow {

    public StuffyPanelWindow(Player p) {
        super(54, "");

        addPanel("main", new StuffyPanel(p));
        showPanel("main");
    }
}
