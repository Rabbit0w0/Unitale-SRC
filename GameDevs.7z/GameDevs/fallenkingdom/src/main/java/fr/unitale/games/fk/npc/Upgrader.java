package fr.unitale.games.fk.npc;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import fr.unitale.games.fk.ui.interact.UpgraderInteract;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.morphs.model.data.NPCPlayerMorphData;
import fr.unitale.sdk.npcs.NPCAPI;
import fr.unitale.sdk.npcs.NPCData;
import fr.unitale.sdk.npcs.NPCDataFactory;
import fr.unitale.sdk.utils.auth.EditableGameProfile;

public class Upgrader {
    private Block b;
    private int x;
    private int y;
    private World w;
    private int z;

    public Upgrader(Block b) {

        this.setBlock(b);
        this.x = b.getX()-2;
        this.y = b.getY()+1;
        this.z = b.getZ()+8;
        this.w = Bukkit.getWorlds().get(0);
        
        w.getBlockAt(new Location(w, x, y-1, z)).setType(Material.BEDROCK);
        w.getBlockAt(new Location(w, x+1, y-1, z)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x+1, y-1, z)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x-1, y-1, z)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x-1, y-1, z)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x, y-1, z+1)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x, y-1, z+1)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x, y-1, z-1)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x, y-1, z-1)) .setData((byte) 7);
        
        NPCData data = new NPCDataFactory().create();

        data.setSpawnLocation(new Location(Bukkit.getWorlds().get(0), x+0.5, y+0.5, z+0.5));
        data.setInteraction(new UpgraderInteract());
        data.setMorphData(new NPCPlayerMorphData(getProfile("Batisseur"))
                .setName("Batisseur"));
        data.setInvulnerable(true);
        
        UnitaleSDK.getAPI(NPCAPI.class).spawn(data);
    }

    public Block getBlock() {
        return b;
    }

    public void setBlock(Block b) {
        this.b = b;
    }

    private GameProfile getProfile(String name) {
        final EditableGameProfile profile = new EditableGameProfile(UUID.randomUUID(), name);
        profile.setLegacy(true);
        profile.setProperty("textures", new Property("textures",
                "eyJ0aW1lc3RhbXAiOjE1ODUwNjU3NjM4NDMsInByb2ZpbGVJZCI6IjhiMzAxYWQ3NGY2NTQ0MzY4Yzg2OWYyZjU3ZDdjOGYzIiwicHJvZmlsZU5hbWUiOiJIeUJvdCIsInNpZ25hdHVyZVJlcXVpcmVkIjp0cnVlLCJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWQ0NmMwODY4ZGZiNDUwNGNjOGYwZTBiYmE0NDQzMDI1YzIzMmViMjRlYTg5YTAyN2E3NDE4OWRkNDVlMmE3YiJ9fX0=",
                "hcY9/w+m0LC5CNT9lLUXkMlnDukH6pApCJohQSO22pXLGkKwhrtyeIBrhLmuADLI1EjOynMPF4LmNo+BDzixlTGxqp8k20Yu1iwJ1lxZbx25G7+TK/7jBPSt+WsuSRGF8tFpbuYJ7orknIXEJrN7Aslq/dIF1fioZgfp5ttE6KS1sCYpDcrElI7cVTim3QmpNsOJa8aV4rTFXBn6N9qnnqaRw/JaYKC62qKDRDfhHDf5+nHgMGsUkFsI+sQcJpUug0KC4nv8JRdYiQbNvU7j0CBSaF28LJXV9sU/erXipj7RnkWJiHETNxnNZ3YRiDdNkOTGR6TE3mkzocl/giFHKF6t2F1Mg0stSUfU0HlmG2oJeuKcTNyJmhWU0Rhl+/ccmn+wiehpP+I+xSrs1umxTnXfpU3z0ELQDr7qVliVR+nv9GnIgca90+dGo80ZYer4AQm8UiWKm/PiO1tovtELR3YurM73/SqgLpumBJSL4v+IJieEcPw5It5gEFLlN5LhdxBkQIgamjyeWswqulSGfz4FX+pPthmxZjo5yqeNx3AvCwxk7E2NsmBHKRgkOvqqTY3vlZl9gEP2ik9oWc/9v7aczlXakSwpy1DfJl6U+t2vqnfgdW98uL6HHKWIgCNzfET82giG+pSxYnY0ZRmM+owKOxqhNtde0yB9PH/D/Qo="));
        return profile;
    }
}
