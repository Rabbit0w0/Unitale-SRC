package fr.unitale.games.fk.ui.pawnstarnoir;

import org.bukkit.entity.Player;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIWindow;

public class PawnStarNoirPanelWindow extends UIWindow {

    public PawnStarNoirPanelWindow(Player p) {
        super(54, "");

        addPanel("main", new PawnStarNoirPanel((UniPlayer) p));
        showPanel("main");
    }
}
