package fr.unitale.games.fk.ui.upgrader;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import fr.unitale.games.fk.modules.game.utils.Money;
import fr.unitale.games.fk.modules.game.utils.Upgrade;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIClickPanel;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.utils.items.UniItemSkull;
import fr.unitale.sdk.utils.items.UniItemStack;

public class UpgradePanel extends UIClickPanel<Upgrade> implements UIFormHandler<Upgrade> { // TODO tout le ui à revoir

	private int count1, count2, count3, count4, count5, count6, count7, count8;

	public UpgradePanel(UniPlayer p) {
		super(54);

		for (Upgrade up : Upgrade.values()) {
			 if (up.getUpgrade().contains("WALL")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count1 < 1) {
						setComponent(12, new UIButton<>(up, up.getItemstack(p)));
						count1++;
					}
				} else {
					setComponent(12, new UIButton<>(up, up.getItemstack(p)));
				}
			}else if (up.getUpgrade().contains("FALL")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count2 < 1) {
						setComponent(10, new UIButton<>(up, up.getItemstack(p)));
						count2++;
					}
				} else {
					setComponent(10, new UIButton<>(up, up.getItemstack(p)));
				}
			} else if (up.getUpgrade().contains("ENCHANT")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count3 < 1) {
						setComponent(20, new UIButton<>(up, up.getItemstack(p)));
						count3++;
					}
				} else {
					setComponent(20, new UIButton<>(up, up.getItemstack(p)));
				}
			} else if (up.getUpgrade().contains("PROTECTED")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count4 < 1) {
						setComponent(14, new UIButton<>(up, up.getItemstack(p)));
						count4++;
					}
				} else {
					setComponent(14, new UIButton<>(up, up.getItemstack(p)));
				}
			} else if (up.getUpgrade().contains("SPEED")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count5 < 1) {
						setComponent(16, new UIButton<>(up, up.getItemstack(p)));
						count5++;
					}
				} else {
					setComponent(16, new UIButton<>(up, up.getItemstack(p)));
				}
			} else if (up.getUpgrade().contains("CORE")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count6 < 1) {
						setComponent(22, new UIButton<>(up, up.getItemstack(p)));
						count6++;
					}
				} else {
					setComponent(22, new UIButton<>(up, up.getItemstack(p)));
				}
			} else if (up.getUpgrade().contains("FARM")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count7 < 1) {
						setComponent(24, new UIButton<>(up, up.getItemstack(p)));
						count7++;
					}
				} else {
					setComponent(24, new UIButton<>(up, up.getItemstack(p)));
				}

			} else if (up.getUpgrade().contains("NIGHTVISION")) {
				if (!Upgrade.containsUpgrade(p, up.getUpgrade())) {
					if (count8 < 1) {
						setComponent(30, new UIButton<>(up, up.getItemstack(p)));
						count8++;
					}
				} else {
					setComponent(30, new UIButton<>(up, up.getItemstack(p)));
				}

			} else if (up.getUpgrade().contains("ANVIL")) {
				setComponent(32, new UIButton<>(up, up.getItemstack(p)));

			} else if (up.getUpgrade().contains("REGEN")) {
				setComponent(40, new UIButton<>(up, up.getItemstack(p)));
			}
		}

	}

	public static UniItemSkull createSkullValue(String url, String name) {
		try {
			UniItemSkull item = new UniItemSkull();
			final GameProfile profile = item.getProfile();
			profile.getProperties().put("textures", new Property("textures", url));
			item.setOwner(profile);
			return item;
		} catch (Exception e) {
			return new UniItemSkull();
		}
	}

	@Override
	public void onSubmit(Player player, Upgrade value) {
		FKTeam t = (FKTeam) UniTeam.getTeam(player);

		if (value.getKeyTag().contains("MAX")) {
			return;
		}

		if (value.getKeyTag().contains("WALL")) {
			if (t.isQueueWall(player) && Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.getBase().upgradeWall(Upgrade.valueOf(value.getKeyTag()).getRaduis(),
						Upgrade.valueOf(value.getKeyTag()).getItem().getType());
				count1 = 0;
				player.closeInventory();
			}

		} else if (value.getKeyTag().contains("FALL")) {
			if (t.isQueueFall(player) && Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.getBase().upgradeFall(value.getRaduis(), Upgrade.valueOf(value.getKeyTag()).getMateriel());
				t.getBase().createBaseBuild(Material.AIR);
				count2 = 0;
				player.closeInventory();
			}

		} else if (value.getKeyTag().contains("ENCHANT")) {
			if (Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.getBase().upgradeEnchant();
				count3 = 0;
				player.closeInventory();
			}
		} else if (value.getKeyTag().contains("PROTECTED")) {
			Upgrade.removeUpgrade((UniPlayer) player, value.getKeyTag());
			if (Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.setEffectAbsorption(t.getEffectAbsorption() + value.getLvl());
				count4 = 0;
				player.closeInventory();
			}
		} else if (value.getKeyTag().contains("SPEED")) {
			player.removePotionEffect(PotionEffectType.SPEED);
			Upgrade.removeUpgrade((UniPlayer) player, value.getKeyTag());
			if (Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.setEffectSpeed(t.getEffectSpeed() + 1);
				count5 = 0;
				player.closeInventory();
			}
		} else if (value.getKeyTag().contains("CORE")) {
			if (t.isQueueCore(player) && Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.getBase().upgradeCore((UniPlayer) player, value.getKeyTag(), value.getLvl());
				count6 = 0;
				player.closeInventory();
			}
		} else if (value.getKeyTag().contains("FARM")) {
			Upgrade.removeUpgrade((UniPlayer) player, value.getKeyTag());
			if (Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.getBase().upgradeFarm(value.getKeyTag());
				count7 = 0;
				player.closeInventory();
			}
		} else if (value.getKeyTag().contains("REGEN")) {
			if (Money.getMoney((UniPlayer) player) >= value.getPrice()) {
				if (t.getHealthCore() < t.getHealthCoreMax()) {
					Money.removeMoney((UniPlayer) player, value.getPrice());
					t.getBase().upgradeRegenCore(player, value.getLvl());
				}
			}
		} else if (value.getKeyTag().contains("ANVIL")) {
			if (Money.getMoney((UniPlayer) player) >= value.getPrice()) {
				Money.removeMoney((UniPlayer) player, value.getPrice());
				player.getInventory().addItem(new UniItemStack(Material.ANVIL));
			}
		} else if (value.getKeyTag().contains("NIGHTVISION")) {
			if (Money.getMoney((UniPlayer) player) >= value.getPrice()
					&& Upgrade.addUpgrade((UniPlayer) player, value.getKeyTag())) {
				t.setEffectNightVision(1);
				count8 = 0;
				player.closeInventory();
			}
		}

	}
}
