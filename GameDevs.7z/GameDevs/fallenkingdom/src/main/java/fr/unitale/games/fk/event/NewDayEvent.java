package fr.unitale.games.fk.event;

public class NewDayEvent extends FKEvent {
    private final int day;

    public NewDayEvent(int d) {
        this.day = d;
    }

    public int getDay() {
        return day;
    }
}
