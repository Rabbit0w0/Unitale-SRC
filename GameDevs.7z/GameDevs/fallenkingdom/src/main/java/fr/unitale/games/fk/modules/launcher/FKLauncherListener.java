package fr.unitale.games.fk.modules.launcher;

import fr.unitale.sdk.gameengine.modules.ModuleListener;

public class FKLauncherListener extends ModuleListener<FKLauncherModule> {

    public FKLauncherListener(FKLauncherModule module) {
        super(module);
    }

   
}
