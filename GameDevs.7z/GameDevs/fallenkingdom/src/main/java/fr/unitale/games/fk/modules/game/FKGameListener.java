package fr.unitale.games.fk.modules.game;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.EnchantingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.Dye;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.event.NewDayEvent;
import fr.unitale.games.fk.modules.game.FKGameModule.PrivacyStateBase;
import fr.unitale.games.fk.modules.game.utils.Money;
import fr.unitale.games.fk.utils.Base;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateTeamEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.map.fk.FKMap;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.area.AreaJoinEvent;
import fr.unitale.sdk.utils.area.AreaLeaveEvent;
import fr.unitale.sdk.utils.area.AreaMoveEvent;
import fr.unitale.sdk.utils.chat.ChatUtils;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.items.UniItemStack;
import net.md_5.bungee.api.ChatColor;

public class FKGameListener extends ModuleListener<FKGameModule> {
	private static final List<Material> farm = Arrays.asList(Material.POTATO, Material.CARROT, Material.WHEAT);
	private static final List<Material> canPlace = Arrays.asList(Material.TNT, Material.LAVA, Material.WATER,
			Material.STATIONARY_LAVA, Material.STATIONARY_WATER, Material.REDSTONE_TORCH_ON,
			Material.REDSTONE_TORCH_OFF, Material.FIRE, Material.WALL_SIGN, Material.SIGN_POST, Material.TORCH);
	private static final List<Material> canBreakOther = Arrays.asList(Material.TNT, Material.LAVA, Material.WATER,
			Material.STATIONARY_WATER, Material.STATIONARY_LAVA, Material.FIRE);

	private static final HashMap<UUID, Long> tempnomoney = new HashMap<>();

	String message, cap;

	private final FKEngine fk;
	private BukkitTask task;
	private int t;

	public FKGameListener(FKGameModule module) {
		super(module);
		this.fk = FKEngine.getInstance();
	}

	@EventHandler
	public void onNewDay(NewDayEvent e) {
		if (this.getModule().canPvP()) {
			this.module.getRequestPlayerManager().close();
		}

	}

	/*
	 * Block Listener
	 */

	@EventHandler
	public void onBlockPlace(BlockPlaceEvent e) {
		final Location l = e.getBlock().getLocation();
		final FKTeam t = (FKTeam) UniTeam.getTeam(e.getPlayer());
		final PrivacyStateBase privacy = fk.whereAmI(e.getPlayer(), l);

		switch (privacy) {
		// in the world
		case OUTBASE:
			if (e.getBlock().getType() == Material.WORKBENCH
					&& e.getBlock().getRelative(0, -1, 0).getType() != Material.WORKBENCH)
				e.setCancelled(false);
			else if (!canPlace.contains(e.getBlock().getType())) {
				e.setCancelled(true);
			}

			if (e.getBlock().getType() == Material.TNT) {
				if (!this.getModule().canAssault()) {
					e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.tnt.noassault"));
				} else if (e.getBlock().getRelative(0, -1, 0).getType() == Material.TNT
						|| e.getBlock().getRelative(0, -1, 0).getType() == Material.AIR) {
					e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.tnt.no"));
				}
				e.setCancelled(true);
			}

			break;

		case INENEMYBASE:
			if (e.getBlock().getType() == Material.TNT) {
				if (!this.getModule().canAssault()) {
					e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.tnt.noassault"));
					e.setCancelled(true);
				} else if (e.getBlock().getRelative(0, -1, 0).getType() == Material.TNT
						|| e.getBlock().getRelative(0, -1, 0).getType() == Material.AIR) {
					e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.tnt.no"));
					e.setCancelled(true);
				}

			} else {
				e.setCancelled(true);
			}
			// in player's base
		default:
			final int x = t.getBase().getCenter().getBlockX();
			final int y = t.getBase().getCenter().getBlockY();
			final int z = t.getBase().getCenter().getBlockZ();

			if (Math.abs(e.getBlockPlaced().getLocation().getBlockX() - x) <= 3
					&& Math.abs(e.getBlockPlaced().getLocation().getBlockY() - y) <= 5
					&& Math.abs(e.getBlockPlaced().getLocation().getBlockZ() - z) <= 3) {
				e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.place.no"));
				e.setCancelled(true);
			}
			break;
		}

	}

	@EventHandler
	public void onBlockBreak(BlockBreakEvent e) {
		final Location l = e.getBlock().getLocation();

		if (e.getPlayer() == null) {
			return;
		}

		if (farm.contains(e.getBlock().getType())) {
			Material mat = e.getBlock().getType();
			if (mat.equals(Material.POTATO)) {
				e.getPlayer().getInventory().addItem(new ItemStack(Material.BAKED_POTATO));
			} else {
				e.getBlock().breakNaturally(new UniItemStack(mat));
			}
			e.getBlock().setType(mat);
			e.setCancelled(true);
		}
		if (e.getBlock().getType().equals(Material.SOIL)) {
			e.setCancelled(true);
		}
		e.getBlock().getDrops().stream().filter(item -> item.getType().equals(Material.LOG_2)).forEach(i -> {
			e.getBlock().setType(Material.AIR);
			ItemMeta itemm = i.getItemMeta();
			message = Money.valueOf("LOG").getItem().toString().toLowerCase();
			cap = message.substring(0, 1);
			cap = cap.toUpperCase();

			message = message.substring(1);
			itemm.setDisplayName(UniColor.ORANGE + cap + message);
			itemm.setLore(Collections.singletonList(
					Lang.str(e.getPlayer(), "game.fk.item.price", Money.valueOf("LOG").getMoney().toString())));
			i.setItemMeta(itemm);

			e.getBlock().getDrops().clear();
			e.getPlayer().getInventory().addItem(i);

		});

		e.getBlock().getDrops().stream().filter(
				item -> fk.getMaterials().contains(item.getType()) && !e.getBlock().getType().equals(Material.SKULL))
				.forEach(i -> {
					e.getBlock().setType(Material.AIR);
					ItemMeta itemm = i.getItemMeta();
					message = i.getType().name().toString().toLowerCase();
					cap = message.substring(0, 1);
					cap = cap.toUpperCase();

					message = message.substring(1);
					itemm.setDisplayName(UniColor.ORANGE + cap + message);
					itemm.setLore(Collections.singletonList(Lang.str(e.getPlayer(), "game.fk.item.price",
							Money.valueOf(i.getType().name()).getMoney().toString())));
					i.setItemMeta(itemm);

					e.getBlock().getDrops().clear();
					e.getPlayer().getInventory().addItem(i);

					// Give experience
					switch (i.getType()) {
					case COAL:
						e.getPlayer().giveExp(5);
						break;
					case DIAMOND:
						e.getPlayer().giveExp(7);
						break;
					case REDSTONE:
						e.getPlayer().giveExp(5);
						break;
					case EMERALD:
						e.getPlayer().giveExp(7);
						break;

					default:
						break;
					}

				});

		// Give experience and smelt item player
		switch (e.getBlock().getType()) {
		case GOLD_ORE:
			e.getBlock().setType(Material.AIR);
			e.getPlayer().getInventory().addItem(new UniItemStack(Material.GOLD_INGOT));
			e.getPlayer().giveExp(1);
			break;
		case IRON_ORE:
			e.getBlock().setType(Material.AIR);
			e.getPlayer().getInventory().addItem(new UniItemStack(Material.IRON_INGOT));
			e.getPlayer().giveExp(1);
			break;
		default:
			break;
		}

		FKMap map = FKEngine.getInstance().getGameMap();

		PrivacyStateBase privacy = fk.whereAmI(e.getPlayer(), l);

		switch (privacy) {
		case INENEMYBASE:
			if (!canBreakOther.contains(e.getBlock().getType()) || !map.canBreak(e.getBlock())
					|| (e.getBlock().getType() == Material.CHEST)) {
				e.setCancelled(true);
			}
			break;

		case INOWNBASE:
			final FKTeam t = (FKTeam) UniTeam.getTeam(e.getPlayer());
			final int x = t.getBase().getCenter().getBlockX();
			final int y = t.getBase().getCenter().getBlockY();
			final int z = t.getBase().getCenter().getBlockZ();

			if (Math.abs(e.getBlock().getLocation().getBlockX() - x) <= 3
					&& Math.abs(e.getBlock().getLocation().getBlockY() - y) <= 5
					&& Math.abs(e.getBlock().getLocation().getBlockZ() - z) <= 3) {
				e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.break.no"));
				e.setCancelled(true);
			}
			break;

		default:
			break;
		}
	}

	@EventHandler
	public void EntityDamage(EntityDamageEvent e) {
		Entity entity = e.getEntity();
		switch (entity.getType()) {

		case ENDER_CRYSTAL:
			e.setCancelled(true);

			if (((EntityDamageByEntityEvent) e).getDamager() instanceof Player) {
				FKTeam t = (FKTeam) UniTeam.getTeam((Player) ((EntityDamageByEntityEvent) e).getDamager());
				FKTeam tenemy = fk.getTeam(((EntityDamageByEntityEvent) e).getDamager().getLocation());

				if (t == tenemy)
					return;

				if (this.getModule().canAssault()) {
					// Damage warning enemy
					if (tenemy.getAttackWarning()) {
						tenemy.getOnlinePlayers().forEach(p -> {
							tenemy.title("", Lang.str(p, "game.fk.attack.core"));
							p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 2f, 2f);
							p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 2f, 2f);
							tenemy.setAttackWarning(false);
							Bukkit.getScheduler().runTaskLater(FKEngine.getInstance().getPlugin(), () -> {
								tenemy.setAttackWarning(true);
							}, 60 * 20L);
						});
					}
					tenemy.getOnlinePlayers().forEach(p -> {
						if (tenemy.getHealthCore() == tenemy.getHealthCoreMax())
							tenemy.broadcast(Lang.str(p, "game.fk.attack.core"));

						if (tenemy.getHealthCore() < 11) {
							tenemy.unlinkBar();
							tenemy.setHealthCore(p, (int) (tenemy.getHealthCore() - e.getDamage()));
							tenemy.getCaptureBar().setTitle(Lang.str(p, "game.fk.core.heal", 0 + ""));
							t.getCaptureBar().setTitle(Lang.str(p, "game.fk.core.heal.enemy",
									tenemy.getColor() + tenemy.getName(), 0 + ""));
							tenemy.eliminate();
							tenemy.killTeam();
							tenemy.getEndercrystal().remove();
							Money.addMoney(p, 200);
						} else {
							tenemy.setHealthCore(p, (int) (tenemy.getHealthCore() - e.getDamage()));
							t.getCaptureBar().setTitle(Lang.str(p, "game.fk.core.heal.enemy",
									tenemy.getColor() + tenemy.getName(), tenemy.getHealthCore().toString()));
							tenemy.updateBar(tenemy.getHealthCore());
							tenemy.iniBar(Lang.str(p, "game.fk.core.heal", tenemy.getHealthCore().toString()));
							tenemy.linkBar();
						}
					});
				}
			}
			break;
		case PLAYER:
			if (!this.getModule().canPvP() && e.getCause().equals(DamageCause.ENTITY_ATTACK)
					&& ((EntityDamageByEntityEvent) e).getDamager() instanceof Player) {
				e.setCancelled(true);
			}
			if (entity.getName().equals("Marchand noir") || entity.getName().equals("Marchand")
					|| entity.getName().equals("Forgeron") || entity.getName().equals("Batisseur")) {
				e.setCancelled(true);
			}
			break;
		default:
			break;
		}

	}

	/*
	 * Player Listener
	 */

	@EventHandler
	public void onPlayerTeleportEvent(PlayerTeleportEvent e) {
		final FKTeam t = (FKTeam) UniTeam.getTeam(e.getPlayer());
		if (e.getCause() == TeleportCause.END_PORTAL) {
			if (!FKEngine.getInstance().getMap().isCanGoEnd() || (t != null && !t.isCanGoEnd())) {
				e.setCancelled(true);
			}
		} else if (e.getCause() == TeleportCause.NETHER_PORTAL) {
			if (!FKEngine.getInstance().getMap().isCanGoNether() || (t != null && !t.isCanGoNether())) {
				e.setCancelled(true);
			}
		}
	}

	@EventHandler
	public void onEliminateTeam(EliminateTeamEvent e) {
		final int count = e.getCompetingTeams();
		final FKTeam t = (FKTeam) e.getTeam();

		t.getOnlinePlayers().forEach(o -> {
			StatManager.getInstance().addStat(o.getPlayer(), PlayerGameStat.DEFEAT);
		});

		PlayerCollector.doForEach(p -> {
			p.sendMessage(Lang.str(p, "game.fk.team.eliminated", t.getName()));
		});

		if (count <= 1) {
			module.win(count);
		}

		t.explodeBase();
	}

	@EventHandler
	public void onEntityDeath(EntityDeathEvent e) {
		if (e.getEntity().getKiller() == null)
			return;
		if (e.getEntityType() == EntityType.PLAYER)
			return;
		if (e.getEntity().getKiller().getType() == EntityType.PRIMED_TNT
				&& e.getEntityType() == EntityType.ENDER_CRYSTAL)
			return;

		final UniPlayer killer = (UniPlayer) e.getEntity().getKiller();

		e.getDrops().stream().filter(Objects::nonNull).forEach(item -> {
			if (fk.getMaterials().contains(item.getType())) {
				ItemMeta itemm = item.getItemMeta();
				message = item.getType().name().toLowerCase();

				cap = message.substring(0, 1);
				cap = cap.toUpperCase();

				message = message.substring(1);
				itemm.setDisplayName(UniColor.ORANGE + cap + message);
				itemm.setLore(Collections.singletonList(Lang.str(killer, "game.fk.item.price",
						Money.valueOf(item.getType().name()).getMoney().toString())));
				item.setItemMeta(itemm);

				e.getDrops().clear();
				e.getEntity().getWorld().dropItemNaturally(e.getEntity().getLocation(), item);
			}
		});
	}

	@EventHandler
	public void onEntityExplodeEvent(EntityExplodeEvent e) {

		if (e.getEntity() instanceof EnderCrystal) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		final UniPlayer p = (UniPlayer) e.getPlayer();
		final FKTeam team = (FKTeam) UniTeam.getTeam(p);

		final String timestampKey = "TIMESTAMP";
		final long lo = p.getStorage().getLong(timestampKey, 0L);
		final long c = Calendar.getInstance().getTime().getTime();
		final int TIME_SYNC_SCOREBOARD = 200;

		if (c - lo < TIME_SYNC_SCOREBOARD)
			return;

		p.getStorage().addLong(timestampKey, c);

		final TeamModule<FKTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);
		final UniScoreboard board = p.getEndScoreboard();

		if (tm == null || board == null)
			return;

		updateTeamPosition(p, (FKTeam) UniTeam.getTeam(p), tm);
		Location l;

		for (final FKTeam t : tm.getTeams()) {
			if (t.isEliminated()) {
				board.updateScore("base_" + t.getName(),
						t.getColor().getChatColor() + Lang.str(p, "game.fk.team.eliminated", t.getName()));
			} else if (t.getBase() != null) {
				l = t.getBase().getCenter();
				if (t == team) {
					board.updateScore("base_" + t.getName(),
							Lang.str(p, "game.fk.team.base.my.distance", getDistance(l, p.getLocation())));
				} else {
					board.updateScore("base_" + t.getName(), t.getColor().getChatColor() + Lang.str(p,
							"game.fk.team.base.other.distance", t.getName(), getDistance(l, p.getLocation())));
				}
			}
		}

		if (team.getEffectNightVision() != 0 && e.getPlayer().getLocation().getY() <= 70) {
			team.setEffectNightVision((UniPlayer) e.getPlayer());
		}
	}

	@EventHandler
	public void onPlayerDeath(PlayerDeathEvent e) {
		final FKTeam t = (FKTeam) UniTeam.getTeam(e.getEntity());
		final UniPlayer deadPlayer = (UniPlayer) e.getEntity();
		final UniPlayer killerPlayer = (UniPlayer) e.getEntity().getKiller();

		e.setDeathMessage("");

		if (killerPlayer == null) {
			FKEngine.getInstance().broadcast("game.fk.killed", e.getEntity().getName());
		} else {
			final UniTeam tk = UniTeam.getTeam(killerPlayer);
			FKEngine.getInstance().broadcast("game.fk.kill", t.getColor() + e.getEntity().getName(),
					tk.getColor() + killerPlayer.getName());

			final long now = (System.currentTimeMillis() / 1000 / 60);
			final long nowtemp = (System.currentTimeMillis() / 1000 / 60) + 1;

			if (tempnomoney.containsKey(deadPlayer.getUniqueId())) {
				final double ts = tempnomoney.get(deadPlayer.getUniqueId()).doubleValue() - now;
				if (ts <= 0) {
					tempnomoney.remove(deadPlayer.getUniqueId());
					killerPlayer.sendMessage(Lang.str(killerPlayer, "game.fk.death.money"));
					Money.addMoney(killerPlayer, 100);
				}
			} else {
				Money.addMoney(killerPlayer, 100);
				killerPlayer.sendMessage(Lang.str(killerPlayer, "game.fk.death.money"));
				tempnomoney.put(deadPlayer.getUniqueId(), nowtemp);
			}

			StatManager.getInstance().addStat(killerPlayer, PlayerGameStat.KILL);
		}

		for (ItemStack i : e.getDrops()) {
			if (i == null)
				continue;
			if (i.getType().equals(Material.WOOD_SWORD) || i.getType().equals(Material.WOOD_PICKAXE)) {
				i.setType(Material.AIR);
			}
		}

		deadPlayer.setHealth(deadPlayer.getMaxHealth());
		deadPlayer.setFoodLevel(20);

		deadPlayer.getPlayer().setGameMode(GameMode.SPECTATOR);
		deadPlayer.getPlayer().sendTitle(Lang.str(deadPlayer, "game.fk.respawn.title"),
				Lang.str(deadPlayer, "game.fk.respawn.subtitle"));
		deadPlayer.teleport(t.getBase().getCenter().add(2, 1, 0));

		Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), () -> {
			deadPlayer.teleport(t.getBase().getCenter().add(2, 1, 0));
			deadPlayer.getPlayer().setGameMode(GameMode.SURVIVAL);
			deadPlayer.getPlayer().getInventory().addItem(new UniItemStack(Material.WOOD_SWORD));
			deadPlayer.getPlayer().getInventory().addItem(new UniItemStack(Material.WOOD_PICKAXE));
			deadPlayer.getPlayer().getActivePotionEffects().clear();
		}, 90L);

		if (FKEngine.getInstance().isDeathMatch()) {
			deadPlayer.setHealth(6);
			deadPlayer.setMaxHealth(6);
		}
	}

	public static Boolean getHealthR(double d, int healmax) {

		double heal = (d / healmax) * d;

		if (heal <= healmax) {
			return true;
		} else if (heal != healmax && heal > healmax / 2.0) {
			return true;
		} else
			return heal >= healmax / 2.0;
	}

	private static String getDistance(Location a, Location playerLocation) {
		if (a.getWorld() != playerLocation.getWorld())
			return ChatColor.RED + "/!\\???/!\\";
		return ChatUtils.getDirectionLocation(playerLocation.clone(), a.clone()) + " ("
				+ ((int) a.distance(playerLocation)) + " b)";
	}

	/*
	 * Bridge
	 */
	@EventHandler
	public void InteractPhysical(PlayerInteractEvent e) {
		// No Break Crop
		if (e.getAction() == Action.PHYSICAL) {
			Block block = e.getClickedBlock();

			if (block == null)
				return;

			int blockType = block.getTypeId();

			if (blockType == Material.SOIL.getId()) {
				e.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);
				e.setCancelled(true);

				block.setTypeId(blockType);
				block.setData(block.getData());
			}
		}

		// Set Pont
		Player player = e.getPlayer();
		if (e.getItem() == null)
			return;
		else if (!e.getItem().hasItemMeta())
			return;
		if (e.getItem().getType().equals(Material.SKULL_ITEM)) {
			if (e.getItem().getItemMeta().getDisplayName().contains("pont")) {
				e.setCancelled(true);
				player.getInventory().remove(e.getItem());
				final Location loc = player.getEyeLocation();
				final Vector direction = loc.getDirection().normalize();
				t = 0;
				task = Bukkit.getScheduler().runTaskTimer(UnitaleSDK.getInstance(), () -> {
					t += 1;
					double xtrav = direction.getX() * t;
					double ytrav = loc.getWorld().getHighestBlockYAt(loc) - loc.getWorld().getHighestBlockYAt(loc) - 1;
					double ztrav = direction.getZ() * t;
					loc.add(xtrav, ytrav, ztrav);

					Block b = loc.getWorld().getBlockAt(loc);
					if (b.getType().equals(Material.AIR) || b.getType().equals(Material.WATER)
							|| b.getType().equals(Material.LAVA) || b.getType().equals(Material.STATIONARY_LAVA)
							|| b.getType().equals(Material.STATIONARY_WATER)) {
						b.setType(Material.COBBLESTONE);
						player.getInventory().remove(e.getItem());
					}
					loc.subtract(xtrav, ytrav, ztrav);
					if (t > 5) {
						task.cancel();
					}
				}, 0, 1);

			}
		}

	}

	@EventHandler()
	public void onPlayerBucketEmpty(PlayerBucketEmptyEvent e) {
		if (fk.whereAmI(e.getPlayer(), e.getBlockClicked().getLocation()).equals(PrivacyStateBase.INENEMYBASE)) {
			if (e.getBucket().toString().contains("WATER")) {
				e.setCancelled(true);
			}
		}
	}

	private void updateTeamPosition(UniPlayer p, FKTeam team, TeamModule<FKTeam> tm) {
		final UniScoreboard board = p.getEndScoreboard();
		int i = 0;
		// int dist;
		Player onp;
		for (final OfflinePlayer op : team.getOfflinePlayers()) {

			if (GameEngine.getInstance().isEliminated(op.getUniqueId())) {
				board.updateScore("mate_" + i, ChatColor.BLACK + "" + ChatColor.BOLD + ChatColor.STRIKETHROUGH + "/!\\"
						+ op.getName() + "/!\\");
			} else if (!op.isOnline()) {
				board.updateScore("mate_" + i, ChatColor.RED + "" + ChatColor.BOLD + "ø " + op.getName() + " ø");
			} else if (!op.getPlayer().getUniqueId().equals(p.getUniqueId())) {
				onp = Bukkit.getPlayer(op.getUniqueId());
				// dist = (int) p.getLocation().distance(onp.getLocation());
				board.updateScore("mate_" + i,
						ChatColor.GREEN + onp.getName() + getDistance(onp.getLocation(), p.getLocation()));
			}
			i++;
		}
		final int size = tm.getTeamSize();
		while (i < size) {
			board.updateScore("mate_" + i, " ");
			i++;
		}
	}

	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent e) {
		UniTeam t = UniTeam.getTeam(e.getPlayer());

		if (t == null)
			return;
		for (UniPlayer p : t.getOnlineCompetingPlayers()) {
			if (!p.getUniqueId().equals(e.getPlayer().getUniqueId())) {
				return;
			}
		}
		if (!t.isEliminated())
			t.eliminate();
	}

	@EventHandler
	public void onPlayerJoin(GamePlayerJoinEvent e) {
		final FKTeam t = (FKTeam) UniTeam.getTeam(e.getPlayer());
		if (t != null) {
			t.setLink(e.getPlayer());
		}
	}

	@EventHandler
	public void onPlayerChat(AsyncPlayerChatEvent e) {
		Player p = e.getPlayer();
		String message = e.getMessage();
		UniTeam t = UniTeam.getTeam(p);
		if (message.startsWith("!")) {
			e.setFormat(t.getColor() + "[" + t.getName() + "] " + p.getName() + ":" + UniColor.WHITE + " " + message);
		} else {
			if (t != null) {
				e.setCancelled(true);
				t.broadcast("*" + t.getColor() + "[Team][" + p.getName() + "]: " + message);
			}
		}
	}

	/*
	 * Event Enchantement
	 */

	@EventHandler
	public void onInventoryOpen(InventoryOpenEvent e) {
		FKTeam t = (FKTeam) UniTeam.getTeam((Player) e.getPlayer());
		if (t.getCountBiblioUpgrade() == 3 && e.getInventory() instanceof EnchantingInventory) {
			EnchantingInventory inv = (EnchantingInventory) e.getInventory();
			Dye d = new Dye();
			d.setColor(DyeColor.BLUE);
			ItemStack i = d.toItemStack();
			i.setAmount(64);
			inv.setItem(1, i);
		}
	}

	@EventHandler
	public void onInventoryClose(InventoryCloseEvent e) {
		FKTeam t = (FKTeam) UniTeam.getTeam((Player) e.getPlayer());
		if (e.getInventory() instanceof EnchantingInventory && t.getCountBiblioUpgrade() >= 3) {
			e.getInventory().remove(Material.INK_SACK);
		}
	}

	@EventHandler
	public void onInventoryClose(InventoryClickEvent e) {
		if (e.getInventory() instanceof EnchantingInventory) {
			FKTeam t = (FKTeam) UniTeam.getTeam((Player) e.getWhoClicked());
			if (t.getCountBiblioUpgrade() == 3
					&& e.getCurrentItem().getType().equals(new UniItemStack(Material.INK_SACK).getType()))
				e.setCancelled(true);
		}
	}

	/*
	 *
	 * Area Listener
	 *
	 */

	@EventHandler
	public void onAreaMove(AreaMoveEvent e) {
		if (!(e.getArea() instanceof Base))
			return;

		Base b = (Base) e.getArea();

		final FKTeam def = b.getTeam();
		final FKTeam atk = (FKTeam) UniTeam.getTeam(e.getPlayer());

		if (def != atk) {
			if (!atk.isAttacking() && isAssaulting(def, atk) && this.getModule().canAssault()) {
				tryToAssault(e.getPlayer(), def, atk);
			} else if (!this.getModule().canAssault()) {
				atk.iniFailedBar(Lang.str(e.getPlayer(), "game.fk.endbar.assaultdeny"));
			}
			atk.linkBar(e.getPlayer());
		}
	}

	@EventHandler
	public void onAreaJoin(AreaJoinEvent e) {
		if (e.getArea() instanceof Base) {
			Base b = (Base) e.getArea();
			FKTeam t = (FKTeam) UniTeam.getTeam(e.getPlayer());
			if (t == b.getTeam()) {
				e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.join.base"));
				t.iniBar(Lang.str(e.getPlayer(), "game.fk.core.heal", t.getHealthCore().toString()));
				t.getCaptureBar().setColor(BarColor.BLUE);
				t.linkBar(e.getPlayer());
			} else {
				e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.join.baseother",
						b.getTeam().getColor() + b.getTeam().getName()));
			}
		}
	}

	@EventHandler
	public void onAreaLeave(AreaLeaveEvent e) {
		if (e.getArea() instanceof Base) {
			Base b = (Base) e.getArea();
			FKTeam t = (FKTeam) UniTeam.getTeam(e.getPlayer());
			if (t == b.getTeam()) {
				e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.leave.base"));
				e.getPlayer().getActivePotionEffects().clear();
				t.unlinkBar(e.getPlayer());
			} else {
				e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.fk.leave.baseother",
						b.getTeam().getColor() + b.getTeam().getName()));
				t.unlinkBar(e.getPlayer());
			}

		}
	}

	private void coreCapture(FKTeam defender, FKTeam assault, int heal) {
		assault.updateBar(heal);
		if (heal == 0) {
			for (UniPlayer x : assault.getOnlinePlayers())
				assault.title(Lang.str(x, "game.fk.captured", defender.getName()));
			for (UniPlayer x : defender.getOnlinePlayers())
				defender.title(Lang.str(x, "game.fk.eliminated", assault.getName()));
			defender.eliminate();
			// defender.setDefend(false);
			assault.setAttack(false);
			assault.unlinkBar();
		}
	}

	private void tryToAssault(UniPlayer p, FKTeam defender, FKTeam assault) {
		try {
			if (defender.isDefending() || defender.isEliminated() || assault.isEliminated()) {
				return;
			}
			for (UniPlayer x : assault.getOnlinePlayers()) {
				assault.iniBar(Lang.str(x, "game.fk.capturebar", defender.getColor() + defender.getName()));
				assault.linkBar(x);
			}
			assault.broadcast(Lang.str(p, "game.fk.attack", defender.getColor() + defender.getName()));

			defender.broadcast(Lang.str(p, "game.fk.attack.defend", assault.getColor() + assault.getName()));
			// defender.setDefend(true);
			assault.setAttack(true);
			coreCapture(defender, assault, 1);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private boolean isAssaulting(FKTeam defender, FKTeam assault) {
		if (defender == null || assault == null) {
			return false;
		}

		for (final OfflinePlayer op : assault.getOfflinePlayers()) {
			if (!FKEngine.getInstance().availablePlayer(op)) {
				return false;
			}
		}
		return true;
	}

}
