package fr.unitale.games.fk.npc;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import fr.unitale.games.fk.ui.interact.PawnkioInteract;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.morphs.model.data.NPCPlayerMorphData;
import fr.unitale.sdk.npcs.NPCAPI;
import fr.unitale.sdk.npcs.NPCData;
import fr.unitale.sdk.npcs.NPCDataFactory;
import fr.unitale.sdk.utils.auth.EditableGameProfile;

public class Pawnkio {
    private ArmorStand armorstandminitext, armorstand;
    private int x, y, z;
    private World w;

    public Pawnkio(Block b) {
        this.x = b.getX()+2;
        this.y = b.getY()+1;
        this.z = b.getZ()+8;
        this.w = Bukkit.getWorlds().get(0);
    }

	public void setNpc() {
    	
        w.getBlockAt(new Location(w, x, y-1, z)).setType(Material.BEDROCK);
        w.getBlockAt(new Location(w, x+1, y-1, z)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x+1, y-1, z)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x-1, y-1, z)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x-1, y-1, z)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x, y-1, z+1)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x, y-1, z+1)) .setData((byte) 7);
        w.getBlockAt(new Location(w, x, y-1, z-1)).setType(Material.STEP);
        w.getBlockAt(new Location(w, x, y-1, z-1)) .setData((byte) 7);
        
        NPCData data = new NPCDataFactory().create();

        data.setSpawnLocation(new Location(Bukkit.getWorlds().get(0), x+0.5, y+0.5, z+0.5));
        data.setInteraction(new PawnkioInteract());
        data.setMorphData(new NPCPlayerMorphData(getProfile("Marchand")).setName("Marchand"));
        data.setInvulnerable(true);
        
        UnitaleSDK.getAPI(NPCAPI.class).spawn(data);
    }

    public void initHoloText() {
        // Hologram info
        Location loc = new Location(w, x+0.5, y + 1.75, z+0.5);
        for (Entity en : loc.getChunk().getEntities()) {
            if (en.getType().equals(EntityType.ARMOR_STAND))
                en.remove();
        }
        initHoloTextmini();
        this.armorstand = w.spawn(new Location(w, x+0.5, y + 1.75, z+0.5), ArmorStand.class);
        this.armorstand.setCustomNameVisible(true);
        this.armorstand.setSmall(true);
        this.armorstand.setCustomName("Bonjour je vous rachetes vos objets");
        this.armorstand.setVisible(false);
        this.armorstand.setGravity(false);
    }

    public void initHoloTextmini() {
        this.armorstandminitext = w.spawn(new Location(w, x+0.5, y + 1.5, z+0.5), ArmorStand.class);
        this.armorstandminitext.setCustomNameVisible(true);
        this.armorstandminitext.setSmall(true);
        this.armorstandminitext.setCustomName("Faites clique droit pour vendre les items");
        this.armorstandminitext.setVisible(false);
        this.armorstandminitext.setGravity(false);
    }

    private GameProfile getProfile(String name) {
        final EditableGameProfile profile = new EditableGameProfile(UUID.randomUUID(), name);
        profile.setLegacy(true);
        profile.setProperty("textures", new Property("textures",
                "eyJ0aW1lc3RhbXAiOjE1ODUwNjY0OTQ5NTMsInByb2ZpbGVJZCI6IjhiMzAxYWQ3NGY2NTQ0MzY4Yzg2OWYyZjU3ZDdjOGYzIiwicHJvZmlsZU5hbWUiOiJIeUJvdCIsInNpZ25hdHVyZVJlcXVpcmVkIjp0cnVlLCJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMzJiZjgxYTFjMDY5ZGJiY2UxMTRlYTlkZGQyOGI0YWNiMTQyZGQzZDE0ODEyMDY2MzcxNDVmZjI2MTU0NjRhYyJ9fX0=",
                "KbZWzjfb2P/db0I9YqOo98E12W+gcxhzlbc5q1fFYp8Ss8Fp/en25VzE73ogo6x/knhJ9fqGvsZZinXLeLVi+sIWcWQgJ8AyeSDqkH6fcDsjTJlqFbTIu3ETlJxY0iWHohEec3IbmjdpBM7R5YLDQtiCw4cDZOFN5Qo+cbpk/htBWKUPi9oS7iZuIvFV7CBsLGAeO7phSRanHi7rDoLq2XMbSE9hFrpVlgjPeQZoNU8pqVwfqookcJ8D569k9TrSnxPpNBXCLJeIGRbtNqvHeSLF1DVxUTvFjfuSWUvMnW1HyHh7bKGLnDF0G89+2zMjwxCjvtKQJ3YXXtlBC2Oceq3ajxOHbdYoQdG8R5PLBPNFq/j+OQ0Mw6AkAlB1/EtLPjs5ssqV/Sga3M/JnQ2Cngwl7/fj1TNitLORqBxNKy7k14U0kYPtNGjkJA9pij5DSZ+/GlhEJ5PA0HfhQpbRqprvG15ERlNNx7W0iNRuYQdDUp0YH74ELiUNfBRc4mtBlKRpMUiCoiJUes2lmrlxAbQqKuaDH3fEyOlzDBLaySFiyTuAQ+wO30ezcnyVqlHkqP+egsZpjS4G/4qAkGuAah044hw3r+21Hf5CrRyrjs6ljYfu1D5N4FnCw8pFV+f3OEQ9mK3P1FPCnstnK4lPt6W6MASUEB2zyOvm/kSEm6w="));
        return profile;
    }
}
