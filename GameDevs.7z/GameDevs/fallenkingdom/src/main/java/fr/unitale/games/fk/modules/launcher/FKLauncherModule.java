package fr.unitale.games.fk.modules.launcher;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.modules.travel.TravellingModule;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.utils.weather.WeatherAPI;

public class FKLauncherModule extends Module<FKLauncherListener> {

	public FKLauncherModule() {

		WeatherAPI.clear();
		WeatherAPI.disableWeather();

		System.out.println("getConfig(baseSize) = " + getConfig("baseSize", 30));
		System.out.println("getConfig(daymax) = " + getConfig("daymax", 10));

		FKEngine.getInstance().setBaseSize(getConfig("baseSize", 30));
		FKEngine.getInstance().setDayMax(getConfig("daymax", 10));
		
	}

	@Override
	public void startModule() {
		GameEngine.getInstance().getModuleManager().removeModule(this.getClass());

	}

	@Override
	public void endModule() {
		
		for (final Player p : GameEngine.getInstance().getOnlinePlayers()) {
			p.setBedSpawnLocation(FKEngine.getInstance().getGameMap().getWorldSpawn(), true);
			p.teleport(FKEngine.getInstance().getGameMap().getWorldSpawn());
		}
		
		// Set GameRule
		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule doFireTick false");
		WeatherAPI.setTime(0L);
		WeatherAPI.rainDisable();
		WeatherAPI.disableTime();
		WeatherAPI.thunderDisable();
		WeatherAPI.addOneDay();
		GameEngine.getInstance().getModuleManager().addModule(new TravellingModule(), true);
	}
}
