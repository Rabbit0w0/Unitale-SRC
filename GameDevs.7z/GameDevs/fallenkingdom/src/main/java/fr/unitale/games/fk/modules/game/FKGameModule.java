package fr.unitale.games.fk.modules.game;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.api.type.MoneyType;
import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.commands.RuleCommand;
import fr.unitale.games.fk.commands.SuicideCommand;
import fr.unitale.games.fk.modules.bonus.FKBonusModule;
import fr.unitale.games.fk.modules.rules.FKRulesModule;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.games.fk.utils.FKTimer;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.weather.WeatherAPI;

public class FKGameModule extends Module<FKGameListener> {
	private final RequestPlayerManager requestPlayerManager;
	private FKTimer timer;

	public FKGameModule() {
		this.moduleListener = new FKGameListener(this);

		GameEngine.getInstance().getModuleManager().addModule(new FKBonusModule());
		GameEngine.getInstance().getModuleManager().addModule(new FKRulesModule());

		this.requestPlayerManager = new RequestPlayerManager();
	}

	@Override
	public void startModule() {

		final TeamModule<FKTeam> tm = FKEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);
		for (final FKTeam t : tm.getTeams()) {
			if (!t.isEmpty()) {
				t.tpBase();
				t.spawnAnimal();
			}
		}
		GameEngine.getInstance().getModuleManager().loadModule(FKBonusModule.class);
		GameEngine.getInstance().getModuleManager().loadModule(FKRulesModule.class);

		PlayerGameStat.VICTORY.setMoney(MoneyType.GOLD, 75);
		PlayerGameStat.VICTORY.setMoney(MoneyType.EMERALDS, 2);
		PlayerGameStat.DEFEAT.setMoney(MoneyType.GOLD, 40);

		this.timer = (FKTimer) TimeManager.getInstance().addTimer(new FKTimer());

		this.timer.setBoard();

		PlayerCollector.doForEach(p -> {
			p.getInventory().addItem(new ItemStack(Material.WOOD_PICKAXE));
			p.getInventory().addItem(new ItemStack(Material.WOOD_SWORD));

			p.getInventory().addItem(new ItemStack(Material.COOKED_BEEF, 32));

			p.setMaxHealth(20);
			p.setHealth(20);
			p.setFoodLevel(40);
			p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 100, 4));
			p.setAllowFlight(false);
			p.setGameMode(GameMode.SURVIVAL);

			p.sendMessage(ChatColor.GOLD + "List des règles: " + ChatColor.DARK_PURPLE + "/rule");
			((UniPlayer) p).getStorage().addInteger("MONEYDEATH", 1);
			((UniPlayer) p).getStorage().addInteger("MONEY", 1);
		});

		new RuleCommand().register();
		new SuicideCommand().register();

		Bukkit.getPluginManager().registerEvents(this.requestPlayerManager, UnitaleSDK.getInstance());
		this.requestPlayerManager.open();

		// Set GameRule
		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule doFireTick false");
		WeatherAPI.setTime(0L);
		WeatherAPI.rainDisable();
		WeatherAPI.disableTime();
		WeatherAPI.thunderDisable();
		WeatherAPI.addOneDay();

	}

	@Override
	public void endModule() {

	}

	public void win(int competing) {
		if (competing == 0) {
			GameEngine.getInstance().endGame(400L);
			GameEngine.getInstance().getModuleManager().removeModule(this.getClass());
			return;
		}

		final TeamModule<FKTeam> tm = FKEngine.getInstance().getModuleManager().getTeamModule(FKTeam.class);

		for (final FKTeam t : tm.getTeams()) {
			if (!t.isEliminated()) {
				win(t);
				t.title(Lang.str("game.fk.win.title"));
				GameEngine.getInstance().getModuleManager().removeModule(this.getClass());
				GameEngine.getInstance().endGame(400L);
				return;
			}
		}
	}

	private void win(FKTeam t) {
		final GameEngine<?> e = GameEngine.getInstance();
		e.broadcast("game.fk.win", t.getColor() + t.getName());
		for (final Player p : t.getOnlinePlayers()) {
			e.spawk(p);
			getTimer().pause();
			StatManager.getInstance().addStat(p, PlayerGameStat.VICTORY);
		}
	}

	public FKTimer getTimer() {
		return this.timer;
	}

	public RequestPlayerManager getRequestPlayerManager() {
		return requestPlayerManager;
	}

	public boolean canPvP() {
		return timer.timepvp <= 0;
	}

	public boolean canAssault() {
		return timer.timeassault <= 0;
	}

	public enum PrivacyStateBase {
		INOWNBASE, INENEMYBASE, OUTBASE
	}
}
