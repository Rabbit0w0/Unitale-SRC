package fr.unitale.games.fk.event.maps.nordique;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.boss.BarColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.games.fk.utils.FKTeam;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.bar.BarAPI;
import fr.unitale.sdk.bar.EndBar;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.area.AreaJoinEvent;
import fr.unitale.sdk.utils.area.AreaLeaveEvent;
import fr.unitale.sdk.utils.chat.Title;

public class Nordique implements Listener {
    private final EndBar captureBar;
    private boolean barLinked;
    private UniPlayer ep;

    public Nordique() {
        BarAPI api = UnitaleSDK.getAPI(BarAPI.class);
        this.captureBar = BarAPI.generateDefaultBar("ø", BarColor.BLUE);

        GameEngine.getInstance().getPlugin().getServer().getPluginManager().registerEvents(this, UnitaleSDK.getInstance());

        new Castel(new Location(Bukkit.getWorlds().get(0), 177, 74, -53), 10);

        Title.sendTitle("", "game.fk.event.nordique");
        api.registerBar(captureBar);
    }

    @EventHandler
    public void onAreaMove(AreaJoinEvent e) {
        if (!(e.getArea() instanceof Castel))
            return;
        linkBar();
        tryToAssault();
        ep = e.getPlayer();
    }

    @EventHandler
    public void onAreaLeave(AreaLeaveEvent e) {
        if (!(e.getArea() instanceof Castel))
            return;
        unlinkBar();
    }

    private void coreCapture(int time) {
        if (time == 0) {

            final FKTeam atk = (FKTeam) UniTeam.getTeam(ep);
            for (UUID x : atk.getContent()) {
                UniPlayer pt = (UniPlayer) Bukkit.getPlayer(x);
                pt.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 5 * 60 * 60, 1, false, false));
            }
            FKEngine.getInstance().broadcast("game.fk.event.nordique.win", atk.getName());
            HandlerList.unregisterAll(this);
            unlinkBar();
        } else {
            Bukkit.getScheduler().scheduleSyncDelayedTask(GameEngine.getInstance().getPlugin(), () -> {
                updateBar(time);
                coreCapture(time - 1);
            }, 20L);
        }
    }

    private void tryToAssault() {
        coreCapture(59); // todo  ?
    }

    public void iniBar(String s) {
        this.captureBar.setTitle(s);
    }

    public void iniFailedBar(String s) {
        this.captureBar.valueConfig(1, 1);
        this.captureBar.setColor(BarColor.RED);
        this.captureBar.setTitle(s);
    }

    public void updateBar(int value) {
        final int max = 100;
        this.captureBar.setValue(max - value);
        if (value <= (max / 4)) {
            this.captureBar.setColor(BarColor.RED);
        } else if (value <= (max / 2)) {
            this.captureBar.setColor(BarColor.YELLOW);
        } else {
            this.captureBar.setColor(BarColor.GREEN);
        }
    }

    public void setLink(UniPlayer p) {
        if (this.barLinked) {
            linkBar();
        } else {
            unlinkBar();
        }
    }

    public void linkBar() {
        barLinked = true;
        for (final UniPlayer p : FKEngine.getInstance().getOnlinePlayers()) {
            this.captureBar.joinBar(p);
        }
    }

    public void unlinkBar() {
        barLinked = false;
        for (final UniPlayer p : FKEngine.getInstance().getOnlinePlayers()) {
            this.captureBar.quitBar(p);
        }
    }
}
