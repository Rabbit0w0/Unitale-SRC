package fr.unitale.games.fk.maps;

import fr.unitale.games.fk.modules.travel.Travelling;
import fr.unitale.games.fk.modules.travel.TravellingPoint;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.chat.Title;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.stream.Stream;

public enum Maps {

    ANGEVSDEMON(MapType.ANGEVSDEMON.getName(), true, MapType.ANGEVSDEMON,
            new TravellingPoint(
                    new Location(null, 123.3, 106, 71.7, -40.9f, 48.0f),
                    new Title("game.fk.travel.title.one", "game.fk.travel.subtitle.one")),
            new TravellingPoint(
                    new Location(null, 154, 78, 104, 133.2f, 26.2f),
                    new Title("game.fk.travel.title.two", "game.fk.travel.subtitle.two")),
            new TravellingPoint(
                    new Location(null, 154, 78, 104, 133.2f, 26.2f),
                    new Title("game.fk.travel.title.three", "game.fk.travel.subtitle.three")),
            new TravellingPoint(
                    new Location(null, -142, 89, 122, 48.5f, 28.0f),
                    new Title("game.fk.travel.title.four", "game.fk.travel.subtitle.four")),
            new TravellingPoint(
                    new Location(null, -142, 89, 122, 48.5f, 28.0f),
                    new Title("game.fk.travel.title.map.angevsdemon", "game.fk.travel.subtitle.map.angevsdemon"))
    ),
    ANGEVSDEMON_VAR2(MapType.ANGEVSDEMON.getName() + "_var2", true, MapType.ANGEVSDEMON, ANGEVSDEMON.travellingPoints),

    AANDOVALE1VS1VS1(MapType.AANDOVALE1VS1VS1.getName(), false, MapType.AANDOVALE1VS1VS1,
            new TravellingPoint(
                    new Location(null, 100, 107, 36, 138.6f, 28.2f),
                    new Title("game.fk.travel.title.one", "game.fk.travel.subtitle.one")),
            new TravellingPoint(
                    new Location(null, 92, 99, 32, 135.3f, 14.4f),
                    new Title("game.fk.travel.title.two", "game.fk.travel.subtitle.two")),
            new TravellingPoint(
                    new Location(null, 92, 99, 32, 135.3f, 14.4f),
                    new Title("game.fk.travel.title.three", "game.fk.travel.subtitle.three")),
            new TravellingPoint(
                    new Location(null, -110, 110, 22, 135.0f, 25.0f),
                    new Title("game.fk.travel.title.four", "game.fk.travel.subtitle.four")),
            new TravellingPoint(
                    new Location(null, -46.5, 103, 13, -123.6f, 43.0f),
                    new Title("game.fk.travel.title.map.candy_anderval", "game.fk.travel.subtitle.map.candy_anderval"))
    );

    private String name;
    private boolean deletelobby;
    private TravellingPoint[] travellingPoints;
    private MapType originalMap;

    Maps(String name, boolean deletelobby, MapType originalMap, TravellingPoint... points) {
        this.name = name;
        this.deletelobby = deletelobby;
        this.travellingPoints = points;
        this.originalMap = originalMap;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the deletelobby
     */
    public boolean isDeletelobby() {
        return deletelobby;
    }

    /**
     * @param deletelobby the deletelobby to set
     */
    public void setDeletelobby(boolean deletelobby) {
        this.deletelobby = deletelobby;
    }

    public Travelling getTravelling(World world) {
        final Travelling travel = new Travelling(90L, travellingPoints);
        travel.getPoints().forEach(p -> p.getLoc().setWorld(world));
        return travel;
    }

    public MapType getOriginalMap() {
        return originalMap;
    }

    public static Maps fromOriginalMap(MapType type) {
        return Stream.of(values()).filter(m -> m.originalMap.equals(type)).findFirst().orElse(null);
    }
}
