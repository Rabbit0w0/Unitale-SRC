package fr.unitale.games.fk.modules.game.utils;

import org.bukkit.Material;

import fr.unitale.games.fk.FKEngine;
import fr.unitale.sdk.players.UniPlayer;

public enum Money {
	EVENT(Material.BEACON, 100), LOG(Material.LOG, 1), COAL(Material.COAL, 2), IRON_INGOT(Material.IRON_INGOT, 5),
	REDSTONE(Material.REDSTONE, 3), GOLD_INGOT(Material.GOLD_INGOT, 10), DIAMOND(Material.DIAMOND, 20),
	EMERALD(Material.EMERALD, 50), SPIDER_EYE(Material.SPIDER_EYE, 5), STRING(Material.STRING, 5),
	BONE(Material.BONE, 5), ENDER_PEARL(Material.ENDER_PEARL, 20), ROTTEN_FLESH(Material.ROTTEN_FLESH, 5);

	private Integer money;
	private Material item;
	private byte data;

	Money(Material item, Integer money) {
		this.item = item;
		this.money = money;
		// add item listener
		FKEngine.getInstance().getMaterials().add(getItem());
	}

	/*
	 * Remove Money
	 */
	public static void removeMoney(UniPlayer p, Integer money) {
		p.getStorage().addInteger("MONEY", p.getStorage().getInteger("MONEY") - money);
		p.getEndScoreboard().updateScore("Money", p.getStorage().getInteger("MONEY").toString() + " ⛃");
	}

	public static boolean removeMoneyUpgrade(UniPlayer p, String upgrade) {
		if (Money.getMoney(p) >= 0) {
			if (Money.getMoney(p) >= Upgrade.valueOf(upgrade).getPrice()) {
				Money.removeMoney(p, Upgrade.valueOf(upgrade).getPrice());
				return true;
			}
		}
		return false;
	}

	public static boolean removeMoneyStuffys(UniPlayer p, String upgrade) {
		if (Money.getMoney(p) >= 0) {
			if (Money.getMoney(p) >= Stuffys.valueOf(upgrade).getPrice()) {
				Money.removeMoney(p, Stuffys.valueOf(upgrade).getPrice());
				return true;
			}
		}
		return false;
	}

	/*
	 * Add Money
	 */
	public static void addMoney(UniPlayer p, double d) {
		try {
			p.getStorage().addInteger("MONEY", (int) (d + getMoney(p)));
			p.getEndScoreboard().updateScore("Money", getMoney(p).toString() + " ⛃");
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	/*
	 * Get Money
	 */
	public static Integer getMoney(UniPlayer p) {
		return p.getStorage().getInteger("MONEY");
	}

	/**
	 * @return the money
	 */
	public Integer getMoney() {
		return money;
	}

	/**
	 * @return the money
	 */
	public Integer getMoney(Integer multi) {
		return money * multi;
	}

	/**
	 * @return the item
	 */
	public Material getItem() {
		return item;
	}

	/**
	 * @return the data
	 */
	public byte getData() {
		return data;
	}

}
