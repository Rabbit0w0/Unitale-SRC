package fr.unitale.games.fk.ui.interact;

import org.bukkit.entity.Player;

import fr.unitale.games.fk.ui.pawnstarnoir.PawnStarNoirPanelWindow;
import fr.unitale.sdk.npcs.NPCInteraction;
import net.minecraft.server.v1_10_R1.Entity;

public class PawnkioNoirInteract implements NPCInteraction {

    @Override
    public String getName() {
        // TODO Auto-generated method stub
        return "custom npc interaction";
    }

	@Override
	public void onInteractLeft(Player player, Entity npc) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onInteractRight(Player player, Entity npc) {
		 new PawnStarNoirPanelWindow(player).open(player);
		
	}
}