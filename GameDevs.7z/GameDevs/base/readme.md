*************************************
* 			INTRODUCTION            *
*************************************

Bienvenue sur le projet "Base" qui vous expliquera au mieux l'utilité de chaque class
sous l'API SDKGames2.

Pour cette exemple notre jeux aura le nom de "Base" et on utilisera le diminutif en "Bs" pour
ne pas avoir des noms de class très long.

Vois-ci un "schéma" du déroullement de chaque class : 

Start : Wrapper -> Création de l'instance en fonction des valeurs donner dans notre -> BsInstanceType puis initialisation des valeurs de notre jeux
(Equipe, points, API, Map WaittingRoom etc..) -> BsInstance puis notre Instance N°1 est en ligne.

Connection d'un joueur : BsInstance -> téléportation dans notre Waitting-Room puis assignation du SB -> BsWaitingModule.

Début du Mini-Jeux : BsWaitingModule -> Chargement du module BsPreGameModule (Suppesion du module BsWaitingModule) chargement 
(Equipe, équipement etc..) pendant le décompte des 5 secondes lancement de l'instance N°2 puis après les 5 secondes (Suppesion du module BsPreGameModule)
puis chargement du module -> BsGameModule.

Fin du Mini-Jeux: Passage sur le module -> BsEndModule (Suppresion du module BsGameModule) puis téléportation des joueurs aux Hub 
suppression de l'instance.

N'oubliez pas de modifier le pom.properties et le pom.xml !

