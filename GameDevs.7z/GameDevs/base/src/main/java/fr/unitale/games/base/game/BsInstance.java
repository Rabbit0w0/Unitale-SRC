package fr.unitale.games.base.game;

import org.apache.commons.lang3.StringUtils;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.scoreboard.DisplaySlot;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.base.game.modules.BsWaitingModule;
import fr.unitale.games.base.map.BsMap;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.game2.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.firework.FireworkFactory;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;

public class BsInstance extends Instance<BsInstance> {
	
	/*
	 * Le core de votre instance (Création d'équipe, assignation des points, chargement des API nécessaire ou à désactivé
	 * lancement de la Waitting Room, et divers méthode pour le re-spawn, pour la victoire etc..) 
	 */
	
	private int teamSize;

    public BsInstance(Engine<BsInstance> engine, MapType mapType, int teamSize, ServerTypes.ServerMode mode) {
        super(engine, "bs.json", false);
        
        this.teamSize = teamSize;
        
        ServerManager.type = ServerTypes.ServerType.GAME;
        setMode(ServerTypes.Mode.TEAM);
        setServerMode(mode);

        // set rewards
        PlayerGameStat STAT = new PlayerGameStat();
        STAT.VICTORY.setMoney(MoneyType.GOLD, 50);
        STAT.DEFEAT.setMoney(MoneyType.GOLD, 25);
        setGameStat(STAT);

        //register team module
        final TeamModule<BsInstance, UniTeam> tm = new TeamModule<>(this);
        tm.setTeamSize(teamSize);
        tm.setDispatchTeam(true);
        register(tm);
        
        // load map and team
        final BsMap map = (BsMap) mapType.getInstance(this);
        map.createTeam(tm);
        setMap(map);        

        // manage weather
        WeatherAPI.disableTime();
        WeatherAPI.clear();
        WeatherAPI.setTime(TimeSet.DAY);

        // waiting module
        BsWaitingModule waitingModule = new BsWaitingModule(this) {
            // remove waiting room
            @Override
            public void updateWaitingModule() {
                super.updateWaitingModule();
                if (getTimer().getTime() < 4 && getTimer().getTime() > 0) {
                    getInstance().getOnlinePlayers().forEach(player -> player.sendTitle(
                            Lang.str("game.bs.title.starting_in"),
                            getTimer().getTime() + " " + Lang.str("game.bs.title.second")
                                    + (getTimer().getTime() == 1 ? "" : "s")
                    ));
                    SoundCreator.playSound(Sound.BLOCK_NOTE_BASS, 1f, getOnlinePlayers());
                }
            }
        };
        waitingModule.setBoard(getBoard());
        register(waitingModule);
    }

    @Override
    public void onJoin(UniPlayer player) {
        super.onJoin(player);
        player.teleport(this.getMap(BsMap.class).getWaitingRoomLocation());
        getModule(BsWaitingModule.class).getBoard().updateScore("time", ChatColor.GREEN + Lang.str("game.sw.board.waiting", String.valueOf(getOnlinePlayers().size()), String.valueOf(getMax())));
    }
    
    /**
     * Send team win
     * @param team
     */
    public void win(UniTeam team) {
        for (final UniPlayer p : getOnlinePlayers()) {
            if (team.contains(p)) {
                FireworkFactory.spawnRandomFirework(p.getLocation(), true);
                p.getInventory().clear();
                p.setHealth(20);
        		p.setAllowFlight(true);
        		p.setFlying(true);
                victoryPlayer(p);
            } else {
                defeatPlayer(p);
            }
        }
    }
    
    @Override
    public int getMin() {
        return teamSize * 2;
    }

    @Override
    public int getMax() {
        return teamSize * 12;
    }
	
	public int getTeamSize() {
        return teamSize;
    }
	
	public void updateBoard() {
		getOnlinePlayers().stream().filter(p -> p.getScoreboard() != null).forEach(p -> p.getEndScoreboard().updateScore("time", ChatColor.GREEN + Lang.str("game.sw.board.waiting", String.valueOf(getOnlinePlayers().size()), String.valueOf(getMax()))));
	}

    protected UniScoreboard getBoard() {
        final UniScoreboard b = new UniScoreboard();
        int i = 0;

        b.createSideBoard(ChatColor.GOLD + "SheepWars");

        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("map_text", Lang.str("game.sw.board.map", getMap().getType().toString()), i++, DisplaySlot.SIDEBAR);
        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("time", Lang.str("game.sw.board.waiting", String.valueOf(getOnlinePlayers().size()), String.valueOf(getMax())), i++, DisplaySlot.SIDEBAR);
        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("play_unitale", (ChatColor.YELLOW + "‣ play.unitale.fr"), i++, DisplaySlot.SIDEBAR);
        return b;
    }
}
