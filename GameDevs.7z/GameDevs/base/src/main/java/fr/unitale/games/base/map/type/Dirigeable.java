package fr.unitale.games.base.map.type;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.games.base.map.BsMap;
import fr.unitale.games.base.map.BsMapType;

public class Dirigeable extends BsMap {

    public Dirigeable(String name, World world) {
        super(BsMapType.BS_DIRIGEABLE, name, world, 6, 
        		new Location(world, -2, 189, 73), // lobby
                new Location(world, -77, 176, -13, -1, 2), //Team red
                new Location(world, -77, 176, 18, 178, -0), //Team blue
                new Location(world, -77, 177, 3, -85, 11)); //Team spec
    }
}
