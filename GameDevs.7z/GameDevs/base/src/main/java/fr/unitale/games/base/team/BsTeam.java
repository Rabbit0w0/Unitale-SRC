package fr.unitale.games.base.team;

import fr.unitale.games.base.game.BsInstance;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;

public class BsTeam extends UniTeam {

    public BsTeam(Instance<BsInstance> instance, String name, UniColor color, int size) {
        super(instance, name, color, size);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BsTeam swTeam = (BsTeam) o;
        return swTeam.getName().equals(getName());
    }
}
