package fr.unitale.games.base.game.modules;

import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.base.game.BsInstance;
import fr.unitale.games.base.map.BsMap;
import fr.unitale.sdk.game2.event.instance.PlayerJoinInstanceEvent;
import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import fr.unitale.sdk.players.UniPlayer;

public class BsWaitingModule extends WaitingModule<BsInstance> {

    public BsWaitingModule(BsInstance instance) {
        super(instance, new BsPreGameModule(instance));
    }
    
    /*
     * On annule les dégats pendant la Waitting Room
     */
    @EventHandler
    public void on(EntityDamageEvent e) {
        if (e.getEntity().getType() != EntityType.PLAYER) return;
        if (getInstance().getStatus() != ServerTypes.GameStatus.GAME && getInstance().contains((UniPlayer) e.getEntity()))
            e.setCancelled(true);
    }
    
    /*
     * On re-TP le joueur a la location de la Waitting Room quand il saute (valeur Y à changer en fonction de map) 
     */
    
    @EventHandler
    public void on(PlayerMoveEvent ev) {
    	final UniPlayer player = (UniPlayer) ev.getPlayer();
    	final BsMap map = (BsMap) instance.getMap();
    	if ((int)player.getLocation().getY() == 150 && player.getLocation().getY() > 150) {
    		player.teleport(map.getWaitingRoomLocation());
    	}
    }

    /*
     * On update le SB quand le joueur rejoint la Waitting Room
     */
    @EventHandler
    protected void userJoin(PlayerJoinInstanceEvent event) {
        if (getInstance().getUniqueId().equals(event.getInstance().getUniqueId())) {            
            getInstance().updateBoard();
        }
    }
}
