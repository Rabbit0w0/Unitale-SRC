package fr.unitale.games.base.game.modules;

import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

import fr.unitale.games.base.game.BsInstance;
import fr.unitale.sdk.game2.event.eliminate.EliminateTeamEvent;
import fr.unitale.sdk.game2.event.instance.PlayerQuitInstanceEvent;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;

public class BsGameModule extends Module<BsInstance> {
	
	/*
	 * Cette class va définir toute les actions (Listeners) pendant votre Mini-Jeux
	 * Il y a certain Listeners qui sont important comme : 
	 * - PlayerQuitInstanceEvent
	 * - EliminateTeamEvent
	 * - PlayerDeathEvent
	 * et plein d'autre afin de mettre une fin de jeux ou compléter un bojectif précis 
	 * Il y a une liste de listeners vide mais vous pouvez rajouter d'autre si nécessaire et
	 * supprimer celle que vous n'utiliser pas bien sur 
	 */
	
	public int task = 0;
	
	public BsGameModule(BsInstance instance) {
		super(instance, new BsEndModule(instance));		
	}
	
	private UniTimer BsGametimer;
	
	@Override
    protected void onRegistered() {		
		BsGametimer = TimeManager._instance.addTimer(new UniTimer("BS_GAME_TIMER_" + UUID.randomUUID().toString(), new Updater() {

			@Override
			public void start() {}
			
			@Override
			public void update() {
				updateGame();
			}
			@Override
			public void end() {
				instance.unregister(BsGameModule.this);
				TimeManager._instance.removeTimer(BsGametimer);
			}			
		}));
	}
	
	public void updateGame() {
		setTimerBoard(ChatColor.AQUA + "Fight: " + ChatColor.YELLOW + this.BsGametimer.getITime());
	}
	
	private void setTimerBoard(String s) {
        for (UniPlayer p : instance.getOnlinePlayers()) {
            p.getEndScoreboard().updateScore("time", s);
        }
    }
	
	@EventHandler
	public void on(EntityExplodeEvent ev) {}
	
	@EventHandler
    public void on(PlayerDeathEvent ev) {}

	@EventHandler
    public void on(EliminateTeamEvent ev) {}
	
	@EventHandler
    public void on(PlayerQuitInstanceEvent ev) {}
	
    @EventHandler
	public void on(AsyncPlayerChatEvent ev) {}
	
	@EventHandler
	public void on(PlayerInteractEvent ev) {}
	
	@EventHandler
	public void on(PlayerPickupItemEvent  ev) {}
	
	@EventHandler
	public void entityDamage(EntityDamageEvent e) {}
	
	@EventHandler
	public void on(EntityDeathEvent ev) {}
	
	@EventHandler
	public void on(ProjectileHitEvent ev) {}
	
	@EventHandler
	public void on(EntityShootBowEvent ev){}
	
	@EventHandler
    public void onItemBreakDamage(PlayerItemBreakEvent ev){}
	
	@EventHandler
	public void on(EntityDamageByEntityEvent ev) {}
	
    @EventHandler
    public void on(BlockBreakEvent ev) {}
    
    @EventHandler
    public void on(BlockPlaceEvent ev) {}
    
    @EventHandler
    public void on(PlayerMoveEvent ev) {}
	
	@EventHandler
	public void on(EntityChangeBlockEvent e) {}
	
    public UniTimer getTimer() {
        return BsGametimer;
    }
}
