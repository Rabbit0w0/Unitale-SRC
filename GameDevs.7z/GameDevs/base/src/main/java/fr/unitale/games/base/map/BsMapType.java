package fr.unitale.games.base.map;

import fr.unitale.games.base.map.type.Dirigeable;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;

public class BsMapType extends MapType {
	
	/*
	 * Liste de mes map qui sont dans votre package type 
	 */
	
	public static final BsMapType BS_DIRIGEABLE = new BsMapType("BS_DIRIGEABLE", "dirigeable", Dirigeable.class, "game.bs.map.dirigeable");
	
	protected BsMapType(String key, String name, Class<? extends GameMap> clazz, String publicName) {
		super(key, name, clazz, publicName);
	}

	public static BsMapType[] values() {
		return new BsMapType[] {
				BS_DIRIGEABLE,
		};
	}

    @Override
    public boolean shouldDeleteMapWhenUnloading() {
        return true;
    }
}
