package fr.unitale.games.base.game.modules;

import java.util.List;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import fr.unitale.games.base.game.BsInstance;
import fr.unitale.games.base.map.BsMap;
import fr.unitale.sdk.game2.event.instance.PlayerQuitInstanceEvent;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;
import fr.unitale.sdk.utils.items.UniItemStack;

public class BsPreGameModule extends Module<BsInstance> {
	
	private UniTimer SwPreGameTimer;
	private static final int WAITING_TIME = 5;

    protected BsPreGameModule(BsInstance instance) {
    	super(instance, new BsGameModule(instance));
    }
    
    /*
     * On charge les composants de notre game (téléportation, ouverture d'une porte, 
     * cinématique, équipement de nos joueur, téléportation des équipes) 
     */    
    @Override
    protected void onRegistered() {
    	for (UniPlayer p : instance.getOnlinePlayers()) {
    		p.setGameMode(GameMode.SURVIVAL);
    		p.getInventory().clear();
            p.setHealth(20);
            p.setMaxHealth(20);
            p.setSaturation(20);
            p.getActivePotionEffects().clear();
            p.getInventory().addItem(new UniItemStack(Material.WOOD_SWORD));
            p.getInventory().addItem(new UniItemStack(Material.BOW));
            p.updateInventory();
            UniLogger.info("init player " + p.getName() + " done !");
    	}
    	instance.getMap(BsMap.class).spawnTeams();
    	
    	this.SwPreGameTimer = TimeManager._instance.addTimer(new UniTimer("SW_PRE_GAME_TIMER_" + UUID.randomUUID().toString(), new Updater() {
        	public void start() {}

            public void update() {
            	if(BsPreGameModule.this.SwPreGameTimer.getSeconds() >= WAITING_TIME) {
            		BsPreGameModule.this.SwPreGameTimer.setTime(0, 0);
            		setTimerBoard(ChatColor.GOLD + Lang.str("game.sw.start"));
            		TimeManager._instance.removeTimer(SwPreGameTimer);
            		instance.unregister(BsPreGameModule.this);
            	}else {
            		setTimerBoard(ChatColor.AQUA + Lang.str("game.sw.start.in", WAITING_TIME - BsPreGameModule.this.SwPreGameTimer.getSeconds()));
            	}
            }

            public void end() {}
        }));
    }
    
    /*
     * On update notre SB
     */
    
    private void setTimerBoard(String s) {
        for (UniPlayer p : instance.getOnlinePlayers()) {
            p.getEndScoreboard().updateScore("time", s);
        }
    }
    
    /*
     * On bloque le déplacement du joueur car il y a un décompte de 5 seconde pendant la PreGameModule
     */    
    @EventHandler
    public void on(PlayerMoveEvent event) {
        if (!check(event)) return;
        UniTeam team = UniTeam.getTeam(getInstance(), event.getPlayer().getUniqueId());
        if (event.getPlayer().getLocation().distance(team.getSpawn()) > 2) {
            event.getPlayer().teleport(team.getSpawn());
        }
    }
    
    
    /*
     * On check si pendant la PreGameModule il reste suffisament de joueur 
     */
    @EventHandler
    public void on(PlayerQuitInstanceEvent event) {
        if (!check(event)) return;

        final List<UniTeam> win = instance.getAvailableTeams();
        if (win.size() == 1) {
            instance.win(win.get(0));
            instance.endGame(200);
            instance.unregister(this);
        }
    }
    
    
    /*
     * On annule les intéraction pendant la PreGameModule
     */
    @EventHandler
    public void on(PlayerInteractEvent event) {
        if (!check(event)) return;
        event.setCancelled(true);
    }
    
    /*
     * On annule les dégats pendant la PreGameModule
     */

    @EventHandler(priority = EventPriority.LOW)
    public void on(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof UniPlayer) || !check((UniPlayer) event.getEntity())) return;
        event.setCancelled(true);
    }

    /*
     * On annule les shoot des arcs pendant la PreGameModule
     */
    @EventHandler
    public void on(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof UniPlayer) || !check((UniPlayer) event.getEntity())) return;
        event.setCancelled(true);
    }
}
