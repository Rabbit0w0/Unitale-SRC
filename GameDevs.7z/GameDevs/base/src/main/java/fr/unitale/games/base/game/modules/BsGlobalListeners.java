package fr.unitale.games.base.game.modules;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.GlobalListener;
import fr.unitale.sdk.players.UniPlayer;

public class BsGlobalListeners extends GlobalListener {
	
	/*
	 * Cette class est très importante, même si pour certain Mini-Jeux elle peu parfois 
	 * contenir seulement 1 listener, elle permet de mettre en place des listeners 
	 * essentiel pendant toute la duré du Mini-Jeux (instance)
	 */

	/*
     * Cancel damages in waiting room
     */
    @EventHandler
    public void on(EntityDamageEvent event) {
        if (event.getEntity().getType() != EntityType.PLAYER) return;
        if (GameSDK2.getInstance((Player) event.getEntity()).getStatus().equals(ServerTypes.GameStatus.WAIT)) {
            event.setCancelled(true);
        }
    }
    
    /*
     * manage inventory click
     */
    @EventHandler
    public void on(InventoryClickEvent e) {
    	UniPlayer p = (UniPlayer)e.getWhoClicked();
    	ItemStack it = e.getCurrentItem();
    	if (it == null)return;
    	if (it.getType().toString().contains("LEATHER_")) {
    	      e.setCancelled(true);
    	      p.updateInventory();
    	      p.closeInventory();
    	      return;
    	} 
    }
    
    /*
	 * manage food
	 */
	@EventHandler
	public void on(FoodLevelChangeEvent ev) {
	    ev.setCancelled(true); 
	  }
    
    /*
	 * manage drop
	 */
	@EventHandler
	public void on(PlayerDropItemEvent ev) {
		ev.setCancelled(true);
	}
    
    /**
     * manage craft inventory
     */
    @EventHandler
    public void on(PrepareItemCraftEvent ev) {
    	ev.getInventory().setResult(new ItemStack(Material.AIR));
    }  
    
    /**
     * manage entity spawning 
     */
    @EventHandler
    public void on(CreatureSpawnEvent ev) {
    	if(ev.getEntityType() != EntityType.SHEEP && ev.getEntityType() != EntityType.DROPPED_ITEM) {
    		ev.setCancelled(true);
    	}
    } 
}
