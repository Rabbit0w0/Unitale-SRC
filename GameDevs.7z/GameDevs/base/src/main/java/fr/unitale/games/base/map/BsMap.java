package fr.unitale.games.base.map;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.games.base.game.BsInstance;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;

public abstract class BsMap extends GameMap<TeamModule<BsInstance, UniTeam>> {

    private int teamSize;
    private final Location waitingRoom;
    
    protected UniTeam red;
    protected UniTeam blue;
    private final Location redLocation;
    private final Location blueLocation;
    private final Location specLocation;
    
    /*
     * constructor de vos map à changer en fonction de vos location nécessaire 
     */

    public BsMap(MapType type, String name, World world, int teamSize, Location waitingRoom, Location r, Location b, Location s) {
        super(type, name, world);
        this.team = true;
        this.teamSize = teamSize;
        this.waitingRoom = waitingRoom;
        this.redLocation = r;
        this.blueLocation = b;
        this.specLocation = s;
    }
    
    public void createTeam(TeamModule<BsInstance, UniTeam> tm) {
        this.red = tm.addTeam(UniColor.RED, "Rouge");
        this.blue = tm.addTeam(UniColor.BLUE, "Bleu");
        red.setSpawn(getRedLocation());
        blue.setSpawn(getBlueLocation());
    }
    
    public Location getRedLocation() {
        return this.redLocation;
    }

    public Location getBlueLocation() {
        return this.blueLocation;
    }
    
    public Location getSpecLocation() {
        return this.specLocation;
    }
    
    public void spawnTeams() {
    	this.red.teleportation(this.redLocation);
    	this.blue.teleportation(this.blueLocation);
    }

    public int getTeamSize() {
        return this.teamSize;
    }

    public Location getWaitingRoomLocation() {
        return this.waitingRoom;
    }
}
