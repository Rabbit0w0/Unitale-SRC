package fr.unitale.games.base.game;

import java.util.Objects;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.base.map.BsMapType;
import fr.unitale.sdk.game2.instance.InstanceType;

public class BsInstanceType implements InstanceType {
	private ServerTypes.ServerMode mode;
	private BsMapType map;
	private int size;
	
	
	/*
	 * Cette class va permettre de renseignier le type :
	 * - Type de serveur
	 * - Taille des équipes
	 * - Le nombre d'équipe
	 * Ainsi qu'un fichier en .json dans (src/main/resources) pour indiquer 
	 * quelques information essentielle concernant votre Mini-Jeux
	 */
	
	public BsInstanceType() {
		
	}
	
	public BsInstanceType(BsInstance instance) {
		this.map = (BsMapType) instance.getMap().getType();
		this.mode = instance.getServerMode();
        this.size = instance.getTeamSize();
	}
	
	public BsInstanceType(BsMapType map, int size, ServerTypes.ServerMode mode) {
		this.map = map;
		this.mode = mode;
        this.size = size;
	}
	
	@Override
	public InstanceType fromJson(String s) {
		/*final JsonObject object = new JsonParser().parse(s).getAsJsonObject();
        return new FkInstanceType(
                MapType.fromString(FKMapType.values(), object.get("map").getAsString())
        );*/

        // pour les tests en local
		return new BsInstanceType(
                BsMapType.BS_DIRIGEABLE,
                1,
                ServerTypes.ServerMode.NORMAL
        );
	}
	
	public BsMapType getMap() {
		return map;
	}
	
	public ServerTypes.ServerMode getMode() {
        return mode;
    }

    public int getSize() {
        return size;
    }
	
	@Override
    public boolean equals(Object object) {
        if (object instanceof BsInstanceType) {
        	BsInstanceType other = (BsInstanceType) object;
        	return other.getMap().getName().equals(map.getName()) && other.getMode().equals(mode) && other.getSize() == size;
        } else if (object instanceof BsInstance) {
        	BsInstance other = (BsInstance) object;
        	return other.getMap().getType().getName().equals(map.getName()) && other.getServerMode().equals(mode) && other.getTeamSize() == size;
        } else {
            return false;
        }
    }
	
	@Override
    public int hashCode() {
        return Objects.hash(map, mode, size);
    }

    @Override
    public String toString() {
    	return "SwInstanceType [" + map.getName() + ", " + mode.toString() + ", " + size + "]";
    }

}
