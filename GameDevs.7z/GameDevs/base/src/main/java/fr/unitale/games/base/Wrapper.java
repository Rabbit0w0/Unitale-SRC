package fr.unitale.games.base;

import java.util.List;
import java.util.stream.Collectors;

import org.bukkit.plugin.java.JavaPlugin;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.base.game.BsInstance;
import fr.unitale.games.base.game.BsInstanceType;
import fr.unitale.games.base.game.modules.BsGlobalListeners;
import fr.unitale.games.base.map.BsMapType;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.instance.InstanceType;
import fr.unitale.sdk.game2.room.PassingRoom;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.utils.chat.UniLogger;

public class Wrapper extends JavaPlugin {
	
	@Override
	public void onEnable() {
		UniLogger.info("Base Wrapper launched !");
		
		// Mettre le gameplay de la 1.8
        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);
        
        // Un register qui seras actif pendant toute l'instance (Obligatoire même si la class est vide) 
        GameSDK2.register(new BsGlobalListeners());   
        
        //init instance factory
        Engine<BsInstance> engine = new Engine<BsInstance>(this, new BsInstanceType(), new PassingRoom()) {

            @Override
            public List<Instance<BsInstance>> getInstances(InstanceType instanceType) {
            	BsInstanceType type = (BsInstanceType) instanceType;
                return getInstances().stream()
                        .filter(instance -> type.getMode() == instance.getServerMode() && ((BsInstance) instance).getTeamSize() == type.getSize())
                        .collect(Collectors.toList());
            }
        };
        
        //pour les tests en local
        engine.addFactory(new BsInstanceType(
        		BsMapType.BS_DIRIGEABLE,
        		1,
        		ServerTypes.ServerMode.NORMAL
        ), f -> new BsInstance(
        		engine,
        		BsMapType.BS_DIRIGEABLE,
        		1,
        		ServerTypes.ServerMode.NORMAL
        ));   
        
        //Liste des map pendant la mise production 
        /*Arrays.stream(SwMapType.values()).forEach(type -> IntStream.range(1, 4).forEach(i -> {
    	engine.addFactory(new SwInstanceType(type, i, ServerTypes.ServerMode.NORMAL), f -> new SwInstance(engine, type, i, ServerTypes.ServerMode.NORMAL));
    	}));*/
        
        //start the engine
        GameSDK2.startEngine(engine);
	}
}
