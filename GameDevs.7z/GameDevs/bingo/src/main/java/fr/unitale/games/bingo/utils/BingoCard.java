package fr.unitale.games.bingo.utils;

import fr.unitale.games.bingo.utils.ui.BingoCardWindow;
import fr.unitale.sdk.utilitarians.AbstractUtilitarian;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;

public class BingoCard extends AbstractUtilitarian {

    public BingoCard() {
        super("BingoCard");
    }

    @Override
    public void action(Player player, Action action, ItemStack item) {
        new BingoCardWindow(player).open(player);
    }
}
