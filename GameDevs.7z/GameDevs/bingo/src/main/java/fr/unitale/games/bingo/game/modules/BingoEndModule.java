package fr.unitale.games.bingo.game.modules;

import fr.unitale.games.bingo.game.BingoInstance;
import fr.unitale.games.bingo.game.BingoInstanceType;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class BingoEndModule extends Module<BingoInstance> {

    public BingoEndModule(BingoInstance instance) {
        super(instance);
    }

    @Override
    protected void onRegistered() {
        for (UniPlayer player : getInstance().getOnlinePlayers()) {
            player.clear();
            player.setGameMode(GameMode.ADVENTURE);
            UniItemStack leave = new UniItemStack(Material.BED, Lang.str(player, "game.wait.item.leave"));
            player.getInventory().setItem(8, leave);
            UniItemStack playAgain = new UniItemStack(Material.WOOD_BUTTON, Lang.str(player, "game.wait.item.play_again"));
            player.getInventory().setItem(0, playAgain);
        }
    }

    @EventHandler
    public void on(EntityDamageEvent event) {
        if (!check(event.getEntity().getUniqueId())) return;

        event.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent ev) {
        if (!check(ev.getPlayer())) return;

        final UniItemStack item = UniItemStack.fromItemStack(ev.getPlayer().getInventory().getItemInMainHand());
        if (item == null || !(ev.getAction().equals(Action.RIGHT_CLICK_BLOCK) || ev.getAction().equals(Action.RIGHT_CLICK_AIR))) {
            return;
        }

        final UniPlayer player = (UniPlayer) ev.getPlayer();
        if (ev.getPlayer().getInventory().getItemInMainHand().getType() == Material.BED) {
            player.sendToHub();
        } else if (ev.getPlayer().getInventory().getItemInMainHand().getType() == Material.WOOD_BUTTON) {
            instance.onQuit(player);

            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hidePlayer(player);
                player.hidePlayer(p);
            }
            player.getInventory().clear();
            player.setGameMode(GameMode.ADVENTURE);

            BingoInstanceType type = new BingoInstanceType(instance);
            GameSDK2.getEngine().getRoom().onJoin((UniPlayer) ev.getPlayer(), type);
        }

        ev.setCancelled(true);
    }
}
