package fr.unitale.games.bingo.team;

import fr.unitale.games.bingo.objectives.Objectives;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;

public class BingoTeam extends UniTeam{

    private Objectives objectives;
    private boolean[] objectives_over;

    public BingoTeam(Instance<?> instance, String name, UniColor color, int size, Objectives objectives) {
        super(instance, name, color, size);
        this.objectives = objectives;
        this.objectives_over = new boolean[objectives.getObjectives().size()];
    }

    public Objectives getObjectives() {
        return objectives;
    }

    public void setObjectives(Objectives objectives) {
        this.objectives = objectives;
    }

    public boolean[] getObjectives_over() {
        return objectives_over;
    }

    public void setObjectives_over(boolean[] objectives_over) {
        this.objectives_over = objectives_over;
    }
}
