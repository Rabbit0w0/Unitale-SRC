package fr.unitale.games.bingo;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.bingo.game.BingoInstance;
import fr.unitale.games.bingo.game.BingoInstanceType;
import fr.unitale.games.bingo.game.modules.BingoGlobalListeners;
import fr.unitale.games.bingo.map.BingoMap;
import fr.unitale.games.bingo.map.BingoMapType;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.instance.InstanceType;
import fr.unitale.sdk.game2.room.PassingRoom;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Wrapper extends JavaPlugin {
    public static Engine<BingoInstance> engine;
    @Override
    public void onEnable() {
        UniLogger.info("Binog Wrapper launched !");

        // set gameplay
        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);

        // register global listeners
        GameSDK2.register(new BingoGlobalListeners());

        // init instance factories

       engine = new Engine<BingoInstance>(this, new BingoInstanceType(), new PassingRoom()) {

            @Override
            public List<Instance<BingoInstance>> getInstances(InstanceType instanceType) {
                BingoInstanceType type = (BingoInstanceType) instanceType;
                return getInstances().stream() // c'est pas très jouly mais temporairement ça marche
                        .filter(instance -> ((BingoInstance) instance).getTeamSize() == type.getSize())
                        .collect(Collectors.toList());
            }
        };

        /* pour les tests en local */
        engine.addFactory(new BingoInstanceType(
                BingoMapType.CLASSIC,
                1,
                ServerTypes.ServerMode.NORMAL
        ), f -> new BingoInstance(
                engine,
                BingoMapType.CLASSIC,
                1,
                ServerTypes.ServerMode.NORMAL
        ));

//        engine.addFactory(new BingoInstanceType(type, i, ServerTypes.ServerMode.NORMAL), f -> new BingoInstance(engine, type, i, ServerTypes.ServerMode.NORMAL));
//        Arrays.stream(BingoMapType.values()).forEach(type -> IntStream.range(1, 4).forEach(i -> {
//            engine.addFactory(new BingoInstanceType(type, i, ServerTypes.ServerMode.NORMAL), f -> new BingoInstance(engine, type, i, ServerTypes.ServerMode.NORMAL));
//        }));

        GameSDK2.startEngine(engine);
    }
}
