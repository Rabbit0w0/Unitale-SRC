package fr.unitale.games.bingo.map;

import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.lang.Lang;

public class BingoMapType extends MapType {
//    Lang.str("game.bingo.map.classic.name")
    public static final BingoMapType CLASSIC = new BingoMapType("BINGO_CLASSIC", "bingo_classic", BingoMap.class, "CLASSIC");
    protected BingoMapType(String key, String name, Class<? extends GameMap> clazz, String publicName) {
        super(key, name, clazz, publicName);
    }
    public static BingoMapType[] values() {
        return new BingoMapType[]{
                CLASSIC
        };
    }
        @Override
    public boolean shouldDeleteMapWhenUnloading() {
        return true;
    }
}
