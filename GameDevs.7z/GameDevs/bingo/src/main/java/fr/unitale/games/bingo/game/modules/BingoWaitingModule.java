package fr.unitale.games.bingo.game.modules;

import fr.unitale.games.bingo.game.BingoInstance;
import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.game2.event.instance.PlayerJoinInstanceEvent;
import fr.unitale.sdk.players.UniPlayer;

public class BingoWaitingModule extends WaitingModule<BingoInstance> { // todo cleanup code

    public BingoWaitingModule(BingoInstance instance) {
        super(instance, new BingoPreGameModule(instance));
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent e) {
        if (e.getEntity().getType() != EntityType.PLAYER) return;
        if (getInstance().getStatus() != ServerTypes.GameStatus.GAME && getInstance().contains((UniPlayer) e.getEntity()))
        e.setCancelled(true);
    }

    @EventHandler
    protected void userJoin(PlayerJoinInstanceEvent event) {
        if (getInstance().getUniqueId().equals(event.getInstance().getUniqueId())) {
            getInstance().setGameElo();
        }
    }
 }
