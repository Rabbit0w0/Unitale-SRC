package fr.unitale.games.bingo.utils.ui;

import fr.unitale.games.bingo.team.BingoTeam;
import fr.unitale.sdk.ui.elements.UIWindow;
import org.bukkit.entity.Player;

public class BingoCardWindow extends UIWindow {
    private Player player;


    public BingoCardWindow(Player p) {
        super(27,"Bingo Card");
        addPanel("Main", new BingoCardPanel(player));
        showPanel("Main");
    }

    public Player getPlayer() {
        return player;
    }
}
