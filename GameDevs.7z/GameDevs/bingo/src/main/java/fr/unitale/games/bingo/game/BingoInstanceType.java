package fr.unitale.games.bingo.game;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.bingo.map.BingoMapType;
import fr.unitale.sdk.game2.instance.InstanceType;
import fr.unitale.sdk.game2.map.MapType;

import java.util.Objects;

public class BingoInstanceType implements InstanceType {
    private BingoMapType map;
    private ServerTypes.ServerMode mode;
    private int size;

    public BingoInstanceType() {
    }

    public BingoInstanceType(BingoInstance instance) {
        this.map = (BingoMapType) instance.getMap().getType();
        this.mode = instance.getServerMode();
        this.size = instance.getTeamSize();
    }

    public BingoInstanceType(BingoMapType map, int size, ServerTypes.ServerMode mode) {
        this.map = map;
        this.mode = mode;
        this.size = size;
    }

    public BingoMapType getMap() {
        return map;
    }

    public ServerTypes.ServerMode getMode() {
        return mode;
    }

    public int getSize() {
        return size;
    }

    @Override
    public InstanceType fromJson(String json) {
//        final JsonObject object = new JsonParser().parse(json).getAsJsonObject();
//        return new BingoInstanceType(
//                MapType.fromString(BingoMapType.values(), object.get("map").getAsString()),
//                object.get("teamSize").getAsInt(),
//                ServerTypes.ServerMode.fromString(object.get("serverMode").getAsString())
//        );
        /* pour les tests en local*/
        return new BingoInstanceType(
                BingoMapType.CLASSIC,
                1,
                ServerTypes.ServerMode.NORMAL
        );

    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof BingoInstanceType) {
            BingoInstanceType other = (BingoInstanceType) object;
            return other.getMap().getName().equals(map.getName()) && other.getMode().equals(mode) && other.getSize() == size;
        } else if (object instanceof BingoInstance) {
            BingoInstance other = (BingoInstance) object;
            return other.getMap().getType().getName().equals(map.getName()) && other.getServerMode().equals(mode) && other.getTeamSize() == size;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(map, mode, size);
    }

    @Override
    public String toString() {
        return "ArenaInstanceType [" + map.getName() + ", " + mode.toString() + ", " + size + "]";
    }
}
