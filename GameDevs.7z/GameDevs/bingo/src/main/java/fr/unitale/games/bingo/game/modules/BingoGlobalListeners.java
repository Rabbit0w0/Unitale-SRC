package fr.unitale.games.bingo.game.modules;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.GlobalListener;

public class BingoGlobalListeners extends GlobalListener {

    /*
     * Cancel damages in waiting room
     */
    @EventHandler
    public void on(EntityDamageEvent event) {
        if (event.getEntity().getType() != EntityType.PLAYER) return;
        if (GameSDK2.getInstance((Player) event.getEntity()).getStatus().equals(ServerTypes.GameStatus.WAIT)) {
            event.setCancelled(true);
        }
    }
}
