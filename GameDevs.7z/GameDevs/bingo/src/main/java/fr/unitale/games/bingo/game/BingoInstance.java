package fr.unitale.games.bingo.game;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.api.type.ServerTypes.ServerType;
import fr.unitale.games.bingo.game.modules.BingoWaitingModule;
import fr.unitale.games.bingo.map.BingoMap;
import fr.unitale.games.bingo.team.BingoTeam;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.game2.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.resourcepack.ResourcePackType;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import org.apache.commons.lang3.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.scoreboard.DisplaySlot;

import java.util.Random;

public class BingoInstance extends Instance<BingoInstance> {
    private int teamSize;

    public BingoInstance(Engine<BingoInstance> engine, MapType mapType, int teamSize, ServerTypes.ServerMode mode) {
        super(engine, "bingo.json", false);

        this.teamSize = teamSize;
        ServerManager.type = ServerTypes.ServerType.fromString("BINGO");
        setServerMode(mode);
        setMode(ServerTypes.Mode.TEAM);

        setMinPlayers(teamSize * 2);
        setMaxPlayers(teamSize * 2);

        // set rewards
        PlayerGameStat STAT = new PlayerGameStat();
        // team
        if (teamSize > 1) {
            STAT.VICTORY.setMoney(MoneyType.GOLD, 8);
            STAT.DEFEAT.setMoney(MoneyType.GOLD, 6);
            if (new Random().nextInt(5) == 0) {
                STAT.VICTORY.setMoney(MoneyType.EMERALDS, 1);
            }
            // solo
        } else {
            STAT.VICTORY.setMoney(MoneyType.GOLD, 6);
            STAT.DEFEAT.setMoney(MoneyType.GOLD, 4);
            if (new Random().nextInt(6) == 0) {
                STAT.VICTORY.setMoney(MoneyType.EMERALDS, 1);
            }
        }

        setGameStat(STAT);

        // load maps
        final BingoMap map = (BingoMap) mapType.getInstance(this);
//        final BingoMap map = (BingoMap) mapType.create(this, "CLASSIC");

        setMap(map);

        // disable weather
        WeatherAPI.disableTime();
        WeatherAPI.clear();
        WeatherAPI.setTime(TimeSet.DAY);
        // team module
        final TeamModule<BingoInstance, BingoTeam> teamModule = new TeamModule<>(this);
        teamModule.setTeamSize(teamSize);
        teamModule.setSizeRestrict(true);
        register(teamModule);

        // wait module
        BingoWaitingModule waitingModule = new BingoWaitingModule(this) {

            @Override
            public void updateWaitingModule() { // todo
                super.updateWaitingModule();
                if (getTimer().getTime() < 4 && getTimer().getTime() > 0) {
                    getInstance().getOnlinePlayers().forEach(player -> player.sendTitle(
                            Lang.str("game.arena.title.starting_in"),
                            getTimer().getTime() + " " + Lang.str("game.arena.title.second")
                                    + (getTimer().getTime() == 1 ? "" : "s")
                    ));
                    SoundCreator.playSound(Sound.BLOCK_NOTE_BASS, 1f, getOnlinePlayers());
                } else if (getTimer().getTime() == 0) {/*
                    getInstance().getOnlinePlayers().forEach(player -> player.sendTitle(
                            "§e§lPréparez-vous au combat !",
                            "Ouverture des grilles dans 10 secondes..."
                    ));
                    SoundCreator.playSound(Sound.BLOCK_NOTE_PLING, 1f, getOnlinePlayers());*/
                }
            }
        };

        waitingModule.setBoard(getBoard());
        register(waitingModule);
        // updateBoard(waitingModule.getBoard());
    }

    @Override
    public void onJoin(UniPlayer player) {
        super.onJoin(player);
        Bukkit.getScheduler().runTask(GameSDK2.getInstance(), () -> {
            if (ServerManager.type == ServerType.ARENA_WTF) {
                ResourcePackType.ARENA.send(player);
            }
        });

        // update online players
        UniLogger.info("module is: " + getModule(BingoWaitingModule.class));
        UniLogger.info("board is: " + getModule(BingoWaitingModule.class).getBoard());
        getModule(BingoWaitingModule.class).getBoard().updateScore("time", ChatColor.GREEN + Lang.str("game.arena.board.waiting", String.valueOf(getOnlinePlayers().size()), String.valueOf(getMax())));
    }


    public int getTeamSize() {
        return teamSize;
    }


    public void updateBoard() {
        getOnlinePlayers().stream()
                .filter(p -> p.getScoreboard() != null)
                .filter(p -> p.getScoreboard().getScores("elo_text") != null)
                .forEach(p -> p.getEndScoreboard().updateScore("elo_text", Lang.str("game.arena.board.elo_average", String.valueOf(getGameElo()))));
    }

    protected UniScoreboard getBoard() {
        final UniScoreboard b = new UniScoreboard();
        int i = 0;

        b.createLifeScore();
        b.createBelowNameLifeScore();

        b.createSideBoard(ChatColor.GOLD + " " + ChatColor.GREEN + "Bingo");

        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("time", Lang.str("game.arena.board.waiting", getOnlinePlayers().size(), getMax()), i++, DisplaySlot.SIDEBAR);
        return b;
    }
}
