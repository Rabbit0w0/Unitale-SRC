package fr.unitale.games.bingo.utils.ui;

import fr.unitale.games.bingo.Wrapper;
import fr.unitale.games.bingo.game.BingoInstance;
import fr.unitale.games.bingo.team.BingoTeam;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIBlock;
import fr.unitale.sdk.ui.elements.UIPanel;
import fr.unitale.sdk.ui.elements.UIVisualizer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.Random;

public class BingoCardPanel extends UIPanel {

    public static Random rand = new Random();
    private final UIBlock block;

    public BingoCardPanel(Player player) {
        super(27);
        block = new UIBlock(3, 3);
        createDecoration(player);
        setComponent(3, block);
    }

    @Override
    public void update(){
        super.update();
        Player player = ((BingoCardWindow)getWindow()).getPlayer();
        Instance instance = GameSDK2.getInstance(player);
        BingoTeam team = (BingoTeam) UniTeam.getTeam(instance, player.getUniqueId());
        System.out.println(team.getObjectives());
    }

}
