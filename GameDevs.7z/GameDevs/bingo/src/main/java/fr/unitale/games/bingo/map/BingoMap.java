package fr.unitale.games.bingo.map;

import fr.unitale.games.bingo.game.BingoInstance;
import fr.unitale.games.bingo.team.BingoTeam;
import fr.unitale.games.bingo.objectives.Objectives;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;
import org.bukkit.Difficulty;
import org.bukkit.World;

public class BingoMap extends GameMap<TeamModule<BingoInstance, BingoTeam>> {
    private BingoTeam south;
    private BingoTeam north;
    public BingoMap(MapType type, String name, World world) {
        super(type, name, world);
        this.team = true;
        this.world.setDifficulty(Difficulty.EASY);
    }

    public BingoMap(String name, World world) {
        super(BingoMapType.CLASSIC, name, world);
        this.team = true;
        this.world.setDifficulty(Difficulty.EASY);
    }


    public void createTeam(TeamModule<BingoInstance, BingoTeam> tm) {
        Objectives o = new Objectives(3);
        this.north = tm.addTeam(UniColor.ORANGE, "Nord", 3);
        this.north.setObjectives(o);
        this.south = tm.addTeam(UniColor.LIME, "Sud", 3 );
        this.south.setObjectives(o);
        this.north.setSpawn(this.world.getHighestBlockAt(this.world.getSpawnLocation()).getLocation().add(0,1,0));
        this.south.setSpawn(this.world.getHighestBlockAt(this.world.getSpawnLocation()).getLocation().add(0,1,0));
    }


    public void spawnTeams(){
        this.north.teleportation();
        this.south.teleportation();
    }

    public UniTeam getSouthTeam() {
        return this.south;
    }

    public UniTeam getNorthTeam() {
        return this.north;
    }
}