package fr.unitale.games.bingo.utils;

import org.bukkit.Material;

public class PossibleMaterials {
    public static Material[] EASY = {
            Material.GOLD_SWORD,
            Material.IRON_AXE,
            Material.GOLD_AXE,
            Material.WOOD_AXE,
            Material.STONE_AXE,
            Material.DIAMOND,
            Material.DIAMOND_AXE,
            Material.DIAMOND_BARDING,
            Material.DIAMOND_BLOCK,
    };
}
