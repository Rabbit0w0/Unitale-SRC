package fr.unitale.games.bingo.objectives;

import fr.unitale.games.bingo.utils.PossibleMaterials;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Random;

public class Objectives {

    private ArrayList<UniItemStack> objectives;
    public static Random rand = new Random();
    public Objectives(ArrayList<UniItemStack> objectives) {
        this.objectives = objectives;
    }

    public Objectives(int size){
        this.objectives = Objectives.generateRandomObjectives(size*size);
    }

    public static ArrayList<UniItemStack> generateRandomObjectives(int size){
        ArrayList<UniItemStack> l = new ArrayList<>();
        for (int position =0; position < size; position++){
            Material m = PossibleMaterials.EASY[rand.nextInt(PossibleMaterials.EASY.length)];
            l.add(new UniItemStack(m));
        }
        return l;
    }

    public ArrayList<UniItemStack> getObjectives() {
        return objectives;
    }

}
