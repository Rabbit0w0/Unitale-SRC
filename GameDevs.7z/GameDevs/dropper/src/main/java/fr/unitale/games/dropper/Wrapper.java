package fr.unitale.games.dropper;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class Wrapper extends JavaPlugin {

	public static final String CONFIG_NAME = "dropper.json";

	@Override
	public void onEnable() {
		UniLogger.info("Dropper Wrapper launched !");
		final File file = new File("plugins", CONFIG_NAME);
		if (file.exists()) {
			new DropperEngine(this, GameEngine.getJSONContent(file));
		} else {
			new DropperEngine(this, GameEngine.getDefaultJSONContent(Wrapper.class, CONFIG_NAME));
		}
		super.onEnable();
	}
}
