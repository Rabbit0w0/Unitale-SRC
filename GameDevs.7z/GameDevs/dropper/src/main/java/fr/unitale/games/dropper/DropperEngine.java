package fr.unitale.games.dropper;

import fr.unitale.games.dropper.modules.game.DropperModule;
import fr.unitale.games.dropper.stat.DropperPlayerStat;
import fr.unitale.games.dropper.util.DropperWaitingRoom;
import fr.unitale.games.dropper.util.DropperWorld;
import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Team;

public class DropperEngine extends GameEngine<GameMap> {

	public static final String boardMap = "BOARD_DRP_MAP";
	public static final String playerMapList = "PLAYER_DRP_MAP";
	public static final String boardDeath = "BOARD_DRP_DEATH";
	public static final String boardTime = "BOARD_DRP_TIME";
	public static final String boardPlace = "BOARD_DRP_PLACE";
	private static DropperEngine __instance;

	World spawn;

	public DropperEngine(JavaPlugin plugin, String json) {
		super(plugin, json);
		__instance = this;

		ServerManager.type = ServerTypes.ServerType.DROPPER;
		serverMode = ServerTypes.ServerMode.fromString(getConfig("servermode", "NORMAL"));
		mode = ServerTypes.Mode.SOLO;
		setKeepOffline(true);

		UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);
		//new SSCommand().register();

		this.spawn = Bukkit.getWorlds().get(0);
		DropperWorld.initWorld(this.spawn);
		getModuleManager().addModule(new DropperModule());
		final WaitingModule wm = new WaitingModule(DropperModule.class);
		wm.setRoom(new DropperWaitingRoom());
		getModuleManager().addModule(wm, true);

		PlayerGameStat.PLACE_1.setMoney(MoneyType.GOLD, 7);
		PlayerGameStat.PLACE_1.setMoney(MoneyType.EMERALDS, 1);
		PlayerGameStat.PLACE_2.setMoney(MoneyType.GOLD, 5);
		PlayerGameStat.PLACE_3.setMoney(MoneyType.GOLD, 2);
		PlayerGameStat.PARTICIPATION.setMoney(MoneyType.GOLD, 10);
		
		DropperPlayerStat.PERFECT.setMoney(MoneyType.GOLD, 10);
		
		Bukkit.getPluginManager().registerEvents(new DropperEngineListener(), UnitaleSDK.getInstance());
	}

	public static DropperEngine getInstance() {
		return __instance;
	}

	@SuppressWarnings("deprecation")
	public void initBoard(UniPlayer p) {
		final UniScoreboard b = new UniScoreboard();

		b.addObjective("_MAP_", "dummy", DisplaySlot.PLAYER_LIST, "Map");

		PlayerCollector.doForEach(player -> b.addScore(playerMapList + player.getUniqueId().toString(), player.getName(), 1, DisplaySlot.PLAYER_LIST));

		b.createSideBoard("Dropper");
		b.addScore(boardMap, "MAP", 0, DisplaySlot.SIDEBAR);
		b.addScore("SPACER_1", " ", 1, DisplaySlot.SIDEBAR);
		b.addScore(boardTime + 0, p.getStorage().getString(boardTime + 0, "Map1: --:--"), 2, DisplaySlot.SIDEBAR);
		b.addScore(boardTime + 1, p.getStorage().getString(boardTime + 1, "Map2: --:--"), 3, DisplaySlot.SIDEBAR);
		b.addScore(boardTime + 2, p.getStorage().getString(boardTime + 2, "Map3: --:--"), 4, DisplaySlot.SIDEBAR);
		b.addScore(boardTime + 3, p.getStorage().getString(boardTime + 3, "Map4: --:--"), 5, DisplaySlot.SIDEBAR);
		b.addScore("SPACER_2", "  ", 6, DisplaySlot.SIDEBAR);
		b.addScore(boardDeath, ChatColor.RED + "Mort: " + p.getStorage().getInteger(DropperModule.playerDeath, 0), 7, DisplaySlot.SIDEBAR);
		b.addScore("SPACER_3", "   ", 8, DisplaySlot.SIDEBAR);
		b.addScore(boardPlace, p.getStorage().getString(boardPlace, "Place: ?"), 9, DisplaySlot.SIDEBAR);

		final Team t = b.getBoard().registerNewTeam("NO_COLLISION");
		PlayerCollector.doForEach(t::addPlayer);
		p.setScoreboard(b);
	}

	@Override
	protected void userJoin(UniPlayer player) {
		if (gameStatus == ServerTypes.GameStatus.WAIT) {
			player.teleport(spawn.getSpawnLocation());
		} else {
			final DropperModule dm = this.getModuleManager().getModule(DropperModule.class);
			initBoard(player);
			final int n = player.getStorage().getInteger(DropperModule.playerMap, 0);
			if (dm != null) {
				dm.teleportPlayerTo(player, n);
			}
		}
	}

	@Override
	protected void userQuit(UniPlayer player) {
		if (gameStatus != ServerTypes.GameStatus.GAME) return;
		final DropperModule m = this.getModuleManager().getModule(DropperModule.class);
		if (m != null) {
			m.tryEnd(player);
		}
	}

	public World getDropperSpawn() {
		return (this.spawn);
	}

}
