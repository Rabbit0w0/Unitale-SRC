package fr.unitale.sdk.gameengine.modules.randomtp;

import org.bukkit.Location;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UniPlayerEvent;

public class UnitaleTpEvent extends UniPlayerEvent{

	private Location location;
	private final boolean ground;
	private boolean cancelled;
	
	public UnitaleTpEvent(UniPlayer player, Location location, boolean ground) {
		super(player);
		this.location = location;
		this.ground = ground;
		this.cancelled = false;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public boolean isGround() {
		return ground;
	}

	public boolean isCancelled() {
		return cancelled;
	}

	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}

}
