package fr.unitale.sdk.gameengine.modules.kit;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.bukkit.entity.Player;

import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UICloseButton;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.ui.elements.UIRobotPanel;
import fr.unitale.sdk.ui.elements.sorters.GridSortPattern;
import fr.unitale.sdk.ui.elements.style.UIIcon;

public class KitChoicePanel extends UIRobotPanel implements UIFormHandler<IKit> {

    public KitChoicePanel(Player p) {
        super(54, new GridSortPattern());

        createDecoration(p);

        setRawComponent(8, new UICloseButton(UIIcon.ACTION_CLOSE.clone().translate(p)));
        setRawComponent(7, new UIButton<IKit>(null, UIIcon.ACTION_REMOVE.clone().translate(p)));

        UniPlayer ep = (UniPlayer) p;
        KitChoiceModule cm = GameEngine.getInstance().getModuleManager().getModule(KitChoiceModule.class);
        if (cm != null) {
            Map<String, IKit> possessed = new HashMap<String, IKit>();
            for (IKit kit : cm.getKits()) {
                if (ep.getFeatures().has(kit)) {
                    IKit k = possessed.get(kit.getKitKey());
                    if (k != null) {
                        if (kit.getLevel() > k.getLevel()) {
                            possessed.put(kit.getKitKey(), kit);
                        }
                    } else {
                        possessed.put(kit.getKitKey(), kit);
                    }
                }
            }

            int i = 0;
            for (Entry<String, IKit> entry : possessed.entrySet()) {
                setComponent(i, new UIButton<>(entry.getValue(), entry.getValue().getItem().translate(p)));
                i++;
            }
        }
    }

    @Override
    public void onSubmit(Player player, IKit value) {
        KitChoiceModule cm = GameEngine.getInstance().getModuleManager().getModule(KitChoiceModule.class);
        if (cm != null) {
            cm.setKit(player, value);
        }
    }
}
