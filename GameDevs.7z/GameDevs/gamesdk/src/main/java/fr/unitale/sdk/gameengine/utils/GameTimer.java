package fr.unitale.sdk.gameengine.utils;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.utils.generic.UniTimer;

public class GameTimer extends UniTimer {

    public GameTimer() {
        super("GAME_ENGINE_TIMER");
    }

    @Override
    protected void userUpdate() {
        GameEngine.getInstance().updateOfflinePlayer();
    }
}
