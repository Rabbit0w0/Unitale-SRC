package fr.unitale.sdk.gameengine.modules.team;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.unitale.sdk.commands.AbstractCommand;

public class ChatTeamCommand extends AbstractCommand {

    public ChatTeamCommand() {
        super("t");
    }

    private String formatMessage(String[] args) {
        return Arrays.stream(args).map(s -> s + " ").collect(Collectors.joining());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player) || args.length < 1) return false;
        if (((Player) sender).getGameMode().equals(GameMode.SPECTATOR)) return true;
        UniTeam t = UniTeam.getTeam((Player) sender);
        if (t != null) {
            t.broadcast(t.getColor() + "[Team][" + sender.getName() + "]: " + formatMessage(args));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }

}
