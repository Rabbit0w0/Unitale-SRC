package fr.unitale.sdk.gameengine.map.guesswho;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.color.UniColor;

public class GuessWhoMap extends GameMap {
    private UniTeam hunter;
    private UniTeam villager;

    private int huntSize;
    private int villageSize;

    protected final List<Location> spawns;

    public GuessWhoMap(MapType type, String name, World world, int huntSize, int villageSize) {
        super(type, name, world);
        this.team = true;
        this.huntSize = huntSize;
        this.villageSize = villageSize;
        this.spawns = new LinkedList<>();
    }

    public void setSize(int h, int v) {
        this.huntSize = h;
        this.villageSize = v;
    }

    @Override
    public void createTeam(TeamModule<?> tm) {
        this.hunter = tm.addTeam(UniColor.GREEN, "Chasseur");
        this.hunter.setSize(this.huntSize);

        this.villager = tm.addTeam(UniColor.ORANGE, "Villageois");
        this.villager.setSize(this.villageSize);
    }

    public UniTeam getHunter() {
        return hunter;
    }

    public UniTeam getVillager() {
        return villager;
    }

    public void randomTp(UniPlayer p) {
        p.teleport(this.spawns.get((int) (Math.random() * this.spawns.size())));
    }

    public void spawnPlayers() {
        Collection<UniPlayer> players = new LinkedList<UniPlayer>(GameEngine.getInstance().getOnlinePlayers());
        for (UniPlayer p : players) {
            if (this.hunter.contains(p)) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 3));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100, 3));
            }
            randomTp(p);
        }
    }
}
