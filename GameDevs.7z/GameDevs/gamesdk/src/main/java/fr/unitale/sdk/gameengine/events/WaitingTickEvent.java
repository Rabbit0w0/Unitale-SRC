package fr.unitale.sdk.gameengine.events;

import fr.unitale.sdk.gameengine.events.game.GameEvent;

public class WaitingTickEvent extends GameEvent {

    private final int tick;

    public WaitingTickEvent(int tick) {
        this.tick = tick;
    }

    public int getTick() {
        return tick;
    }
}
