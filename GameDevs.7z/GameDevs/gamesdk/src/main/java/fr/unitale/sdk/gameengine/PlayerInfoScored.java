package fr.unitale.sdk.gameengine;

import java.util.UUID;

import fr.unitale.sdk.scoreboard.UniScoreboard;

public abstract class PlayerInfoScored extends PlayerInfo {

    UniScoreboard board;

    public PlayerInfoScored(UUID uuid) {
        this(uuid, true);
    }

    public PlayerInfoScored(UUID uuid, boolean life) {
        super(uuid);
        this.board = new UniScoreboard();
        if (life) {
            this.board.createLifeScore();
        }
        this.board.createSideBoard(GameEngine.getInstance().getConfig("scoreboardName", "GameBoard"));
    }

    public UniScoreboard getBoard() {
        return (this.board);
    }

    public void resetBoard() {
        this.board.clear();
    }
}
