package fr.unitale.sdk.gameengine.map.firestorm;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class Frigiel extends FirestormMap {

    public Frigiel(String name, World world) {
        super(MapType.FIRESTORM_FRIGIEL, name, world, new Location(world, 804, 104, 917),
                new Location(world, 804, 122, 917), 5);
        this.bonus.add(new Location(world, 796, 86, 917));
        this.bonus.add(new Location(world, 806, 80, 919));
        this.bonus.add(new Location(world, 799, 70, 919));
        this.bonus.add(new Location(world, 812, 54, 920));
        this.bonus.add(new Location(world, 813, 44, 917));
        this.bonus.add(new Location(world, 794, 53, 920));
        this.bonus.add(new Location(world, 798, 59, 913));
        this.bonus.add(new Location(world, 794, 75, 910));
        this.bonus.add(new Location(world, 824, 75, 920));
        this.bonus.add(new Location(world, 802, 104, 914));
        this.bonus.add(new Location(world, 806, 104, 924));
        this.bonus.add(new Location(world, 806, 95, 922));
        this.bonus.add(new Location(world, 804, 90, 913));
        this.bonus.add(new Location(world, 796, 89, 924));
        this.bonus.add(new Location(world, 799, 86, 912));
        this.bonus.add(new Location(world, 804, 78, 916));
        this.bonus.add(new Location(world, 804, 63, 915));
    }
}
