package fr.unitale.sdk.gameengine.modules.randomtp;

import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkUnloadEvent;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.team.event.PlayerJoinTeamEvent;
import fr.unitale.sdk.players.UniPlayer;

public class RandomTPModuleListener extends ModuleListener<RandomTPModule>{

	public RandomTPModuleListener(RandomTPModule module) {
		super(module);
	}
	
	@EventHandler
	public void playerJoin(PlayerJoinEvent e){
		if (getModule().getMode() != Mode.SOLO || GameEngine.getInstance().getGameStatus() != GameStatus.WAIT)return;
		Location l = getModule().setUserLocation(e.getPlayer());
		if (l != null){
			getModule().sendCircleChunk((UniPlayer)e.getPlayer(), l, this.module.getCircle());
		}
	}
	
	@EventHandler
	public void playerQuit(PlayerQuitEvent e){
		if (getModule().getMode() != Mode.SOLO || GameEngine.getInstance().getGameStatus() != GameStatus.WAIT)return;
		Location l = getModule().getUserLocation(e.getPlayer());
		if (l != null) {
			getModule().soloSpawn.put(l, null);
		}
	}
	
	@EventHandler
	public void onPlayerJoinTeam(PlayerJoinTeamEvent e){
		if (getModule().getMode() != Mode.TEAM || GameEngine.getInstance().getGameStatus() != GameStatus.WAIT)return;
		Location l = getModule().teamSpawn.get(e.getTeam());
		if (l != null) {
			getModule().sendCircleChunk(e.getPlayer(), l, this.module.getCircle());
		}
	}
	
	@EventHandler
	public void unloadChunk(ChunkUnloadEvent e) {
		if(GameEngine.getInstance().getGameStatus() == GameStatus.WAIT) {
			e.setCancelled(true);
		}
	}

}
