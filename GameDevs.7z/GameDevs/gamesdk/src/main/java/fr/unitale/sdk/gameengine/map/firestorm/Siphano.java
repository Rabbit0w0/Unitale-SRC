package fr.unitale.sdk.gameengine.map.firestorm;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class Siphano extends FirestormMap {

    public Siphano(String name, World world) {
        super(MapType.FIRESTORM_SIPHANO, name, world, new Location(world, 809, 79, 899),
                new Location(world, 808, 96, 898), 5);
        this.bonus.add(new Location(world, 829, 47, 899));
        this.bonus.add(new Location(world, 795, 82, 897));
        this.bonus.add(new Location(world, 797, 24, 898));
        this.bonus.add(new Location(world, 808, 27, 892));
        this.bonus.add(new Location(world, 801, 44, 895));
        this.bonus.add(new Location(world, 793, 67, 894));
        this.bonus.add(new Location(world, 801, 71, 903));
        this.bonus.add(new Location(world, 819, 59, 895));
        this.bonus.add(new Location(world, 810, 60, 898));
        this.bonus.add(new Location(world, 806, 55, 895));
        this.bonus.add(new Location(world, 798, 51, 893));
        this.bonus.add(new Location(world, 803, 59, 895));
        this.bonus.add(new Location(world, 807, 51, 896));
        this.bonus.add(new Location(world, 802, 55, 893));
        this.bonus.add(new Location(world, 796, 75, 899));
        this.bonus.add(new Location(world, 814, 75, 901));
        this.bonus.add(new Location(world, 796, 27, 899));
        this.bonus.add(new Location(world, 799, 39, 893));
        this.bonus.add(new Location(world, 810, 35, 891));

    }
}
