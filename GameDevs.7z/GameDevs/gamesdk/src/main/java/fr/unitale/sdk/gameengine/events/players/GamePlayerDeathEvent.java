package fr.unitale.sdk.gameengine.events.players;

import fr.unitale.sdk.players.UniPlayer;

public class GamePlayerDeathEvent extends GamePlayerEvent {
    boolean isKill;

    public boolean isKill() {
        return isKill;
    }

    public GamePlayerDeathEvent(UniPlayer player) {
        super(player);
        isKill = false;
    }
}
