package fr.unitale.sdk.gameengine.modules.wait.events;

/**
 * Thrown when the timer has been cancelled in wait module
 */
public class WaitTimeAbortEvent extends WaitEvent {

    public WaitTimeAbortEvent() {
    }
}
