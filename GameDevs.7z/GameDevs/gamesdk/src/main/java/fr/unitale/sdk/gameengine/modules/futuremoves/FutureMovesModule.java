package fr.unitale.sdk.gameengine.modules.futuremoves;

import java.util.function.Predicate;

import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.players.UniPlayer;

public class FutureMovesModule extends Module<FutureMovesModuleListener> {
    private boolean jetPackEnabled = true;
    private Predicate<UniPlayer> canWallJump = p -> true;
    private float levitationPower = 1;

    public FutureMovesModule() {
        this.moduleListener = new FutureMovesModuleListener(this);
    }

    @Override
    public void startModule() {
        UnitaleSDK.enableAPI(API.BAR);
    }

    @Override
    public void endModule() {
    }

    /**
     * @return is jetpack enabled
     */
    public boolean isJetPackEnabled() {
        return jetPackEnabled;
    }

    /**
     * @param jetPackEnabled whether to enable or disable jetpack
     */
    public FutureMovesModule setJetPackEnabled(boolean jetPackEnabled) {
        this.jetPackEnabled = jetPackEnabled;
        return this;
    }

    /**
     * @return the canWallJump
     */
    public Predicate<UniPlayer> getCanWallJump() {
        return canWallJump;
    }

    /**
     * @param canWallJump the canWallJump to set
     */
    public FutureMovesModule setCanWallJump(Predicate<UniPlayer> canWallJump) {
        this.canWallJump = canWallJump;
        return this;
    }

    /**
     * @return the levitationPower
     */
    public float getLevitationPower() {
        return levitationPower;
    }

    /**
     * Levitation will be applied when jetpack is enabled, the high in block will be 0.9*power
     *
     * @param levitationPower the levitationPower to set
     */
    public FutureMovesModule setLevitationPower(float levitationPower) {
        this.levitationPower = levitationPower;
        return this;
    }
}
