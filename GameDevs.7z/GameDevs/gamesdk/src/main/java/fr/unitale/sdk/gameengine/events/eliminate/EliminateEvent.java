package fr.unitale.sdk.gameengine.events.eliminate;

import fr.unitale.sdk.gameengine.events.game.GameEvent;

public class EliminateEvent extends GameEvent {

}
