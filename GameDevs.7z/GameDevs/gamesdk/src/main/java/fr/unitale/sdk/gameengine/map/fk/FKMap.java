package fr.unitale.sdk.gameengine.map.fk;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.data.Triple;
import fr.unitale.sdk.utils.items.UniItemStack;

public class FKMap extends GameMap {

    private final List<Location> chests;
    private final List<Location> lucky;
    private final Map<Location, Integer> wools;

    private final Location worldSpawn;
    private final Location lobby;

    private final List<Triple<Location, UniColor, String>> teams;

    private final List<UniItemStack> chestItem;

    private final FKMapListener event;

    private final List<Material> noBreakable;

    private final List<Material> noPlace;

    protected static World world = Bukkit.getWorlds().get(0);

    protected boolean canGoNether;
    protected boolean canGoEnd;

    public FKMap(MapType t, String name, Location lobby) {
        super(t, name, world);

        this.worldSpawn = lobby.clone();
        this.lobby = lobby;

        setSpawn();

        this.chests = new LinkedList<>();
        this.lucky = new LinkedList<>();
        this.wools = new LinkedHashMap<>();

        this.teams = new LinkedList<>();
        this.chestItem = new LinkedList<>();

        this.event = new FKMapListener(this);

        this.noBreakable = new LinkedList<>();
        this.noPlace = new LinkedList<>();

        this.canGoNether = true;
        this.canGoEnd = true;

        this.team = true;

        Bukkit.getPluginManager().registerEvents(this.event, UnitaleSDK.getInstance());
    }

    public FKMap(MapType t, String name, Location lobby, Location worldSpawn) {
        super(t, name, world);

        this.worldSpawn = worldSpawn;
        this.lobby = lobby;

        setSpawn();

        this.chests = new LinkedList<>();
        this.lucky = new LinkedList<>();
        this.wools = new LinkedHashMap<>();

        this.teams = new LinkedList<>();
        this.chestItem = new LinkedList<>();

        this.event = new FKMapListener(this);

        this.noBreakable = new LinkedList<Material>();
        this.noPlace = new LinkedList<Material>();

        this.team = true;

        Bukkit.getPluginManager().registerEvents(this.event, UnitaleSDK.getInstance());
    }

    private void reloadChest(Chest c) {
        final int count = (int) (Math.random() * 4) + 2;
        for (int i = 0; i < count; i++) {
            c.getInventory().addItem(this.chestItem.get((int) (Math.random() * this.chestItem.size())));
        }
    }

    public void reloadChest() {
        if (this.chestItem.size() == 0) {
            return;
        }
        this.chests.stream()
                .filter(l -> l.getBlock().getType() == Material.CHEST).map(l -> (Chest) l.getBlock().getState())
                .forEach(this::reloadChest);
    }

    private void setSpawn() {
        FKMap.world.setSpawnLocation(this.worldSpawn.getBlockX(), this.worldSpawn.getBlockY(), this.worldSpawn.getBlockZ());
    }

    protected void addChestItem(UniItemStack item) {
        this.chestItem.add(item);
    }

    protected void addChest(int x, int y, int z) {
        this.chests.add(new Location(FKMap.world, x, y, z));
    }

    protected void addLucky(int x, int y, int z) {
        this.lucky.add(new Location(FKMap.world, x, y, z));
    }

    protected void addWool(int x, int y, int z, int color) {
        this.wools.put(new Location(FKMap.world, x, y, z), color);
    }

    protected void addTeam(int x, int y, int z, UniColor color, String name) {
        this.teams.add(new Triple<Location, UniColor, String>(new Location(FKMap.world, x, y, z), color, name));
    }

    public Triple<Location, UniColor, String> getTeam(int spawn) {
        return ((this.teams.size() > spawn) ? this.teams.get(spawn) : null);
    }

    public boolean isWool(Location l) {
        return this.wools.containsKey(l);
    }

    public boolean isWool(Block b) {
        return isWool(b.getLocation());
    }

    public boolean isLucky(Location l) {
        return this.lucky.contains(l);
    }

    public boolean isLucky(Block b) {
        return isLucky(b.getLocation());
    }

    public void removeLucky(Location l) {
        this.lucky.remove(l);
    }

    public Map<Location, Integer> getWools() {
        return this.wools;
    }

    @SuppressWarnings("deprecation")
    public void spawnWool() {
        for (final Entry<Location, Integer> e : this.wools.entrySet()) {
            e.getKey().getBlock().setType(Material.WOOL);
            e.getKey().getBlock().setData((byte) e.getValue().intValue());
        }
    }

    public void spawnLucky() {

    }

    public Location getWorldSpawn() {
        return worldSpawn;
    }

    public Location getLobby() {
        return lobby;
    }

    public void setRules() {
    }

    public boolean canBreak(Block b) {
        return true;
    }

    public List<Material> getNoBreakable() {
        return noBreakable;
    }

    public List<Material> getNoPlace() {
        return noPlace;
    }

    public boolean isCanGoNether() {
        return canGoNether;
    }

    public void setCanGoNether(boolean canGoNether) {
        this.canGoNether = canGoNether;
    }

    public boolean isCanGoEnd() {
        return canGoEnd;
    }

    public void setCanGoEnd(boolean canGoEnd) {
        this.canGoEnd = canGoEnd;
    }

    @Override
    public void createTeam(TeamModule<?> tm) {
        UniTeam team;
        for (Triple<Location, UniColor, String> t : this.teams) {
            team = tm.addTeam(t.getB(), t.getC());
            team.setSpawn(t.getA());
        }
    }

    public void load() {
    }

    public void start() {
    }

    public void populateFirstChest(Chest c) {

    }
}
