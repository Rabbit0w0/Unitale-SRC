package fr.unitale.sdk.gameengine.modules.team;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.color.UniColor;

public class TeamModule<T extends UniTeam> extends Module<TeamModuleListener> {
    private List<T> teams;
    private int teamSize;
    private boolean teamKill;
    private Class<T> clazz;
    private boolean sizeRestricted;
    private boolean dispatchTeam;
    private TeamDispatcher<T> dispatcher;

    @SuppressWarnings("unchecked")
    public TeamModule() {
        this((Class<T>) UniTeam.class);
    }

    public TeamModule(Class<T> clazz) {
        this.moduleListener = new TeamModuleListener(this);
        this.teams = new Vector<>();

        this.teamSize = getConfig("teamSize", 10);
        this.teamKill = getConfig("teamKill", false);
        this.sizeRestricted = getConfig("sizeRestricted", false);

        this.clazz = clazz;
        this.dispatchTeam = true;
        this.dispatcher = null;
    }

    public T getNewTeam(String s, UniColor color) {
        return getNewTeam(s, color, teamSize);
    }

    @SuppressWarnings("unchecked")
    public T getNewTeam(String s, UniColor color, int size) {
        try {
            Constructor<T> construct = clazz.getConstructor(String.class, UniColor.class, int.class);
            return construct.newInstance(s, color, size);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            UniLogger.error("Unable to create a team of type " + clazz.toString());
            return (T) new UniTeam(s, color, size);
        }
    }

    private void loadJsonTeam() {
        JSONObject jsonTeam;
        for (final Object obj : getConfig("teams", new JSONArray()).toArray()) {
            jsonTeam = (JSONObject) obj;
            addTeam(UniColor.getFromWoolByte((byte) Math.toIntExact((long) jsonTeam.get("color"))),
                    (String) jsonTeam.get("name"), teamSize);
        }
    }

    private void loadMapTeam() {
        GameMap m = GameEngine.getInstance().getMap();
        if (m != null) m.createTeam(this);
    }

    @Override
    public void startModule() {
        new ChatTeamCommand().register();
        GameEngine<?> e = GameEngine.getInstance();
        if (e.getServerMode().equals(ServerMode.GUILD)) {
            return;
        }
        if (e.getMode() == Mode.TEAM) {
            if (e.getMap() != null && e.getMap().isTeam()) {
                loadMapTeam();
            } else loadJsonTeam();
        }
    }

    @Override
    public void endModule() {
    }

    public boolean sizeRestricted() {
        return sizeRestricted;
    }

    public void setSizeRestrict(boolean b) {
        sizeRestricted = b;
    }

    @SuppressWarnings("deprecation")
    public void createTeamBoard(UniPlayer p) {
        Team t;
        for (final T team : this.teams) {
            t = UniTeam.reloadTeamBoard(p.getEndScoreboard(true).getBoard(), team);
            for (final OfflinePlayer op : team.getOfflinePlayers()) {
                t.addPlayer(op);
            }
        }
    }

    public int getTeamSize() {
        return this.teamSize;
    }

    public void setTeamSize(int teamSize) {
		this.teamSize = teamSize;
	}

	public T addTeam(T team) {
        if (this.teams.size() > 15) {
            return null;
        }
        this.teams.add(team);
        return team;
    }

    public T addTeam(UniColor color, String name) {
        return addTeam(color, name, this.teamSize);
    }

    public T addTeam(UniColor color, String name, int size) {
        return (addTeam(getNewTeam(name, color, size)));
    }

    public UniTeam getFirstAvailableTeam() {
        for (final UniTeam it : this.teams) {
            if (it.size() < it.getSize()) {
                return (it);
            }
        }
        return (null);
    }

    public T getBiggerAvailableTeam() {
        T team = null;
        final int size = -1;

        for (final T it : this.teams) {
            if (it.size() > size && it.size() < it.getSize()) {
                team = it;
            }
        }
        return (team);
    }

    public int getNbTeam() {
        return (this.teams.size());
    }

    public UniColor getColor(Player p) {
        return ((UniTeam.getTeam(p) != null) ? UniTeam.getTeam(p).getColor() : UniColor.WHITE);
    }

    public boolean isTeamKillPermitted() {
        return teamKill;
    }

    public void dispatch() {
        if (this.dispatcher == null) {
            //set a team for all players without teams
            for (Player p : GameEngine.getInstance().getOnlinePlayers()) {
                UniTeam team = UniTeam.getTeam(p);
                if (team == null) {
                    UniTeam smallerTeam = getSmallerTeam();
                    if (smallerTeam != null) {
                        smallerTeam.addPlayer(p);
                    } else {
                        UniLogger.warning("found null when asking for smallest team (team amount = " + getNbTeam() + ") ! sending player to hub !");
                        ((UniPlayer) p).sendToHub();
                    }
                }
            }

            //check for a single team filled with players
            int emptyTeamsCount = 0;
            for (UniTeam t : teams) {
                if (t.isEmpty()) emptyTeamsCount++;
            }
            if (emptyTeamsCount == teams.size() - 1) {//if there's only one team filled with players
                //we balance
                UniTeam nonEmpty = teams.stream().filter(t -> !t.isEmpty()).findFirst().orElse(null);
                UniTeam newTeam = getFirstAvailableTeam();
                int halPlayerCount = nonEmpty.getCompetingCount() / 2;
                for (int i = 0; i < halPlayerCount; i++) {
                    UniPlayer player = nonEmpty.getFirstAvailablePlayer();
                    player.sendMessage(Lang.str(player, "game.team.menu.limited"));
                    nonEmpty.removePlayer(player);
                    newTeam.addPlayer(player);
                }
            }

            //if we have to dispatch players in every teams
            if (this.dispatchTeam) {
                while (getDistanceTeams() > 1) {
                    UniTeam higher = getHigherTeam();
                    UniTeam smaller = getSmallerTeam();
                    Player p = higher.getOnlinePlayers().get(higher.getOnlinePlayers().size() - 1);
                    p.sendMessage(Lang.str(p, "game.team.menu.limited"));

                    higher.removePlayer(p);
                    smaller.addPlayer(p);
                }
            }

            for (UniTeam t : this.teams) {
                if (t.isEmpty()) t.burnAtStart();
            }
        } else {
            this.dispatcher.dispatch();
        }
    }

    public T getSmallerTeam() {
        int mostSize = Integer.MAX_VALUE;
        T mostTeam = null;
        for (final T team : getTeams()) {
            if (team.size() < mostSize) {
                mostTeam = team;
                mostSize = team.size();
            }
        }
        return mostTeam;
    }

    public T getHigherTeam() {
        int mostSize = 0;
        T mostTeam = null;
        for (final T team : getTeams()) {
            if (team.size() > mostSize) {
                mostTeam = team;
                mostSize = team.size();
            }
        }
        return mostTeam;
    }

    public int getDistanceTeams() {
        return getHigherTeam().getOnlinePlayers().size() - getSmallerTeam().getOnlinePlayers().size();
    }

    public List<T> getTeams() {
        return teams;
    }

    public T getTeam(String name) {
		return teams.stream()
				.filter(team -> team.getName().equals(name))
				.findFirst()
				.orElse(null);
	}

    public void removeTeam(T team) {
        teams.remove(team);
    }

    public boolean isDispatchTeam() {
        return dispatchTeam;
    }

    public void setDispatchTeam(boolean dispatchTeam) {
        this.dispatchTeam = dispatchTeam;
    }

    public TeamDispatcher<T> getDispatcher() {
        return dispatcher;
    }

    public void setDispatcher(TeamDispatcher<T> dispatcher) {
        this.dispatcher = dispatcher;
    }

    public void removePlayerFromTeam(UUID player) {
		teams.stream().filter(team -> team.contains(player)).forEach(team -> team.unsafeRemovePlayer(player));
    }

    public void removePlayerFromTeam(Player player) {
        removePlayerFromTeam(player.getUniqueId());
    }
}
