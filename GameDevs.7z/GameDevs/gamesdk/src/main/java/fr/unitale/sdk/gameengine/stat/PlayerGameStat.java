package fr.unitale.sdk.gameengine.stat;

import fr.unitale.sdk.players.money.IGameMoneyTransactionType;
import fr.unitale.sdk.stat.PlayerStatType;
import fr.unitale.sdk.stat.PlayerStatType.PlayerStatMode;

public class PlayerGameStat {

    //TODO PLACE_1 to PLACE_3 seems to be relative to dropper only

    /**
     * An enum of all available game money transaction for a game
     */
    public static enum GameMoneyTransaction implements IGameMoneyTransactionType {
        KILL, DEATH, VICTORY, DEFEAT, PLACE_1, PLACE_2, PLACE_3, ENDGAME, GOLDEN_APPLE_CRAFTED, PARTICIPATION;
    }

    public static PlayerStatType PLACE_1 = new PlayerStatType("stat.game.dropper.place_1", "PLACE_1",
            "Classement (1er)", PlayerStatMode.UNIQUE, GameMoneyTransaction.PLACE_1);
    public static PlayerStatType PLACE_2 = new PlayerStatType("stat.game.dropper.place_2", "PLACE_2",
            "Classement (2nd)", PlayerStatMode.UNIQUE, GameMoneyTransaction.PLACE_2);
    public static PlayerStatType PLACE_3 = new PlayerStatType("stat.game.dropper.place_3", "PLACE_3",
            "Classement (3ème)", PlayerStatMode.UNIQUE, GameMoneyTransaction.PLACE_3);
    public static PlayerStatType VICTORY = new PlayerStatType("stat.game.victory", "VICTORY", "Victoire",
            PlayerStatMode.UNIQUE, GameMoneyTransaction.VICTORY);
    public static PlayerStatType DEFEAT = new PlayerStatType("stat.game.defeate", "DEFEATE", "Defaite",
            PlayerStatMode.UNIQUE, GameMoneyTransaction.DEFEAT);
    public static PlayerStatType PARTICIPATION = new PlayerStatType("stat.game.participation", "PARTICIPATION",
            "Participation", PlayerStatMode.UNIQUE, GameMoneyTransaction.PARTICIPATION);
    public static PlayerStatType KILL = new PlayerStatType("stat.game.kill", "KILL", "Nombre de kill",
            PlayerStatMode.ADDITIONNABLE, GameMoneyTransaction.KILL);
    public static PlayerStatType DEATH = new PlayerStatType("stat.game.death", "DEATH", "Nombre de mort",
            PlayerStatMode.ADDITIONNABLE, GameMoneyTransaction.DEATH);
    public static PlayerStatType GOLDEN_APPLE_CRAFTED = new PlayerStatType("stat.game.goldenapple.crafted",
            "GOLDEN_APPLE_CRAFTED", "Pommes d'or crafté(s)", PlayerStatMode.ADDITIONNABLE,
            GameMoneyTransaction.GOLDEN_APPLE_CRAFTED);

    private static PlayerStatType[] content = new PlayerStatType[]{
            PLACE_1,
            PLACE_2,
            PLACE_3,
            VICTORY,
            DEFEAT,
            PARTICIPATION,
            KILL,
            DEATH,
            GOLDEN_APPLE_CRAFTED
    };

    public static PlayerStatType[] values() {
        return content;
    }

    public static PlayerStatType getPlace(int place) {
        switch (place) {
            case 1:
                return PLACE_1;
            case 2:
                return PLACE_2;
            case 3:
                return PLACE_3;
            default:
                return null;
        }
    }

}
