package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.map.fk.utils.Locker;
import fr.unitale.sdk.gameengine.map.fk.utils.TeamUnlocker;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.event.TeamUnlockChestEvent;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.color.UniColor;

public class IceVSFire extends FKMap {

    private Locker locker;

    public IceVSFire(String name, World world) {
        super(MapType.ICEVSFIRE, name, new Location(FKMap.world, 617, 146, -310), new Location(FKMap.world, 608, 73, -318));

        this.addTeam(654, 62, -445, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(605, 62, -150, UniColor.RED, "Rouge");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);

        locker = new Locker();
    }

    @Override
    public void load() {
        final TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
        if (tm == null || tm.getNbTeam() != 2) return;
        this.locker.addLock(new FKUnlock(30L, tm.getTeams().get(0), FKMap.world.getBlockAt(0, 0, 0)));
        this.locker.addLock(new FKUnlock(30L, tm.getTeams().get(1), FKMap.world.getBlockAt(0, 0, 0)));

    }

    @Override
    public void start() {
        for (UniPlayer p : GameEngine.getInstance().getOnlinePlayers()) {
            p.sendMessage(ChatColor.GOLD + "Impossible de pénétrer dans l'END sans crocheter le coffre adverse");
        }
    }

    public class FKUnlock extends TeamUnlocker<UniTeam> {

        public FKUnlock(Long timeToUnlock, UniTeam team, Block b) {
            super(timeToUnlock, team, b);
        }

        @Override
        protected void success() {
            this.getTeam().broadcast(ChatColor.RED + "Crochetage intérompu");
            Bukkit.getPluginManager().callEvent(new TeamUnlockChestEvent(this.getTeam(), this.getBlock()));
        }

        @Override
        protected void failure() {
            this.getTeam().broadcast(ChatColor.RED + "Crochetage intérompu");
        }
    }
}
