package fr.unitale.sdk.gameengine.modules.kit;

import fr.unitale.api.Response;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.players.PlayerAPI;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.data.Tuple;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class KitChoiceModule extends Module<KitChoiceListener> {
    public static final String KEY = "KIT_CHOICE_ITEM";
    public static String KIT_KEY = "PLAYER_KIT";

    private Response<Tuple<UniPlayer, KitChoiceModule>> kitUpdate;
    private IKit[] kits;
    //position of the item to choose a kit in the inventory
    private int itemPos;

    public KitChoiceModule(Class<? extends IKit> kitType, Response<Tuple<UniPlayer, KitChoiceModule>> kitUpdate) {
        moduleListener = new KitChoiceListener(this);
        this.itemPos = 0;
        kits = kitType.getEnumConstants();
        this.kitUpdate = kitUpdate;
    }

    public int getItemPos() {
        return itemPos;
    }

    public void setItemPos(int itemPos) {
        this.itemPos = itemPos;
    }

    IKit[] getKits() {
        return kits;
    }

    public IKit getKit(Player p) {
        return (IKit) ((UniPlayer) p).getStorage().getObject(KIT_KEY, null);
    }

    public IKit getKit(Player p, IKit defaultKit) {
        return (IKit) ((UniPlayer) p).getStorage().getObject(KIT_KEY, defaultKit);
    }

    public void setKit(Player p, IKit kit) {
        ((UniPlayer) p).getStorage().addObject(KIT_KEY, kit);
        addItem((UniPlayer) p);
    }

    void onKitUpdate(UniPlayer p) {
        if (kitUpdate != null) {
            kitUpdate.success(new Tuple<>(p, this));
        }
    }

    void addItem(UniPlayer p) {
        PlayerAPI.getPlayerContainer(p.getUniqueId()).thenAccept(res -> {
            if (res.getPlayer() == null) return;

            UniPlayer ep = res.getPlayer();
            UniItemStack item = getKit(ep) == null
                    ? new UniItemStack(Material.STICK)
                    : getKit(ep).getItem().clone();

            item.addKey(KEY).setTranslatedNameDesc(ep, "game.kit.choose");

            ep.getInventory().setItem(itemPos, item);
        });
    }

    @Override
    public void startModule() {
        for (Player p : GameEngine.getInstance().getOnlinePlayers()) {
            addItem((UniPlayer) p);
        }
    }

    @Override
    public void endModule() {
        for (Player p : GameEngine.getInstance().getOnlinePlayers()) {
            p.getInventory().setItem(0, new ItemStack(Material.AIR));
        }
    }
}
