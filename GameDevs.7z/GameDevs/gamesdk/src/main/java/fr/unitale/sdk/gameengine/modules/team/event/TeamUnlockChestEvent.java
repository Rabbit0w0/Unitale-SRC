package fr.unitale.sdk.gameengine.modules.team.event;

import org.bukkit.block.Block;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;

public class TeamUnlockChestEvent extends TeamEvent{

	private final Block block;
	
	public TeamUnlockChestEvent(UniTeam team, Block b) {
		super(team);
		this.block = b;
	}

	public Block getBlock() {
		return block;
	}

}
