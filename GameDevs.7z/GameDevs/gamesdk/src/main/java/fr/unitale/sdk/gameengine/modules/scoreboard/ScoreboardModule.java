package fr.unitale.sdk.gameengine.modules.scoreboard;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;

import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.scoreboard.UniScore;
import fr.unitale.sdk.scoreboard.UniScoreboard;

public class ScoreboardModule extends Module<ScoreboardListener> {
    UniScoreboard board;
    Objective[] objective;
    Map<String, UniScore> scores;

    public ScoreboardModule() {
        this.moduleListener = new ScoreboardListener(this);

        this.objective = new Objective[3];
        this.objective[0] = null;
        this.objective[1] = null;
        this.objective[2] = null;

        //TODO pas de probleme sans definition de board ?

        this.scores = new HashMap<>();
    }

    public void addScore(String id, String data, int zIndex, DisplaySlot where) {
        this.scores.put(id, new UniScore(id, data, zIndex, this.objective[getIdObjective(where)]));
    }

    public void updateScore(String id, String data) {
        final UniScore score = this.scores.get(id);
        if (score != null) {
            score.setData(data);
        }
    }

    public UniScoreboard getBoard() {
        return this.board;
    }

    public void createLifeScore() {
        addObjective("Life", "health", DisplaySlot.PLAYER_LIST, null);
    }

    public void createSideBoard() {
        addObjective("GameBoard", "dummy", DisplaySlot.SIDEBAR, "Game");
    }

    public boolean addObjective(String name, String type, DisplaySlot where, String dName) {
        final int id = getIdObjective(where);
        if (id == -1) {
            return (false);
        }
        if (this.objective[id] != null) {
            return (false);
        }

        this.objective[id] = board.getBoard().registerNewObjective(name, type);
        this.objective[id].setDisplaySlot(where);
        if (dName != null) {
            this.objective[id].setDisplayName(dName);
        }
        return (true);
    }

    public int getIdObjective(DisplaySlot where) {
        if (where == DisplaySlot.BELOW_NAME) {
            return 0;
        } else if (where == DisplaySlot.SIDEBAR) {
            return 1;
        } else if (where == DisplaySlot.PLAYER_LIST) {
            return 2;
        }
        return -1;
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }
}
