package fr.unitale.sdk.gameengine.commands;

import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;

/**
 * Allow to see all teams available
 */
public class AvailableCommand extends AbstractCommand {

    public AvailableCommand() {
        super("available");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        GameEngine<?> e = GameEngine.getInstance();
        if (!(sender instanceof Player)) return false;
        Player p = (Player) sender;
        if (!p.isOp()) return false;
        if (e.getMode() == Mode.TEAM) {
            p.sendMessage(ChatColor.YELLOW + "--------------------");
            for (UniTeam t : e.getCompetingTeams()) {
                p.sendMessage(t.getColor() + t.getName());
            }
        }
        p.sendMessage(ChatColor.YELLOW + "--------------------");
        for (UniPlayer ep : e.getCompetingPlayers()) {
            p.sendMessage(ChatColor.AQUA + ep.getName());
        }
        p.sendMessage(ChatColor.YELLOW + "--------------------");
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }

}
