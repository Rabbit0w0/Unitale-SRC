package fr.unitale.sdk.gameengine.modules;

import org.bukkit.event.Listener;

/**
 * A module Listener
 *
 * @param <T> {@link Module} related type
 */
public abstract class ModuleListener<T extends Module<?>> implements Listener {

    protected T module;

    public ModuleListener(T module) {
        this.module = module;
    }

    protected T getModule() {
        return module;
    }
}
