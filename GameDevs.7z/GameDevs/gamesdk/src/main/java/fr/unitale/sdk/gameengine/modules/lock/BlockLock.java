package fr.unitale.sdk.gameengine.modules.lock;

import org.bukkit.block.Block;

public abstract class BlockLock extends ALock {
    protected Block block;

    public BlockLock(long timeToUnlock, Block block) {
        super(timeToUnlock);
        this.block = block;
    }

    public Block getBlock() {
        return this.block;
    }

    public boolean is(Block b) {
        return this.block.equals(b);
    }

    public void tryUnlock(Block b) {
        if (is(b)) tryUnlock();
    }
}
