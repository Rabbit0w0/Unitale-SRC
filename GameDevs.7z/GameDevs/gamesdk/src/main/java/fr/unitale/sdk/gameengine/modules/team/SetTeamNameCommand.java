package fr.unitale.sdk.gameengine.modules.team;

import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.data.Triple;
import fr.unitale.sdk.utils.string.StringValidator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.util.List;
import java.util.stream.IntStream;

public class SetTeamNameCommand extends AbstractCommand {

    public SetTeamNameCommand() {
        super("teamname");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof UniPlayer) {
            UniPlayer ep = (UniPlayer) sender;
            UniTeam team = UniTeam.getTeam(ep.getUniqueId());
            if (team != null) {
                if (team.getOwner() != null && team.getOwner().equals(ep.getUniqueId())) {
                    final String newName = getStringFromArg(args);
                    Triple<Boolean, Boolean, String> validated = StringValidator.validate(newName);

                    //if not valid
                    if (!validated.getA()) {
                        ep.sendMessage(Lang.str(ep, "generic.input.invalid"));
                        return true;
                    }
                    TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
                    if (tm != null) {
                        if (tm.getTeams().stream().anyMatch(t -> t.getName().equals(newName))) {
                            ep.sendMessage(Lang.str(ep, "game.wait.team.name.alreadytaken"));
                            return true;
                        }
                    }
                    team.setName(newName);
                    team.broadcast("game.wait.team.renamed", ep.getChatDisplayName(), team.getName());
                } else {
                    ep.sendMessage("game.wait.team.notleader");
                }
            } else {
                ep.sendMessage("game.wait.noteam");
            }
        }
        return true;
    }

    public static String getStringFromArg(String[] args) {
        if (args.length == 0) {
            return "";
        }

        StringBuilder s = new StringBuilder(args[0]);
        IntStream.range(1, args.length).forEach(i -> s.append(" ").append(args[i]));
        return s.length() > 16 ? s.substring(0, 16) : s.toString();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }
}