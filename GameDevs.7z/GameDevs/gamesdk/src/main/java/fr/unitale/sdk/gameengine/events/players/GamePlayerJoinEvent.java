package fr.unitale.sdk.gameengine.events.players;

import fr.unitale.sdk.players.UniPlayer;

public class GamePlayerJoinEvent extends GamePlayerEvent {

    public GamePlayerJoinEvent(UniPlayer player) {
        super(player);
    }
}
