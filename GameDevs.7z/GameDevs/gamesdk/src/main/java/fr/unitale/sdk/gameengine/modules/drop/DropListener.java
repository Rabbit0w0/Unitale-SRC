package fr.unitale.sdk.gameengine.modules.drop;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class DropListener extends ModuleListener<DropModule> {

    private static Map<Material, Short> materials = setMaterialMap();

    private static Map<Material, Short> setMaterialMap() {
        materials = new LinkedHashMap<>();

        materials.put(Material.WOOD_AXE, (short) 59);
        materials.put(Material.WOOD_HOE, (short) 59);
        materials.put(Material.WOOD_PICKAXE, (short) 59);
        materials.put(Material.WOOD_SWORD, (short) 59);
        materials.put(Material.WOOD_SPADE, (short) 59);

        materials.put(Material.IRON_AXE, (short) 250);
        materials.put(Material.IRON_HOE, (short) 250);
        materials.put(Material.IRON_PICKAXE, (short) 250);
        materials.put(Material.IRON_SWORD, (short) 250);
        materials.put(Material.IRON_SPADE, (short) 250);

        materials.put(Material.GOLD_AXE, (short) 32);
        materials.put(Material.GOLD_HOE, (short) 32);
        materials.put(Material.GOLD_PICKAXE, (short) 32);
        materials.put(Material.GOLD_SWORD, (short) 32);
        materials.put(Material.GOLD_SPADE, (short) 32);

        materials.put(Material.STONE_AXE, (short) 131);
        materials.put(Material.STONE_HOE, (short) 131);
        materials.put(Material.STONE_PICKAXE, (short) 131);
        materials.put(Material.STONE_SWORD, (short) 131);
        materials.put(Material.STONE_SPADE, (short) 131);

        materials.put(Material.DIAMOND_AXE, (short) 1561);
        materials.put(Material.DIAMOND_HOE, (short) 1561);
        materials.put(Material.DIAMOND_PICKAXE, (short) 1561);
        materials.put(Material.DIAMOND_SWORD, (short) 1561);
        materials.put(Material.DIAMOND_SPADE, (short) 1561);

        return materials;
    }

    public DropListener(DropModule module) {
        super(module);
    }

    @EventHandler
    public void onBrew(BrewEvent e) {

    }

    @EventHandler
    public void onPrepareItemCraft(PrepareItemCraftEvent e) {
        ItemStack convert = this.module.getItem(ConvertType.CRAFT, e.getRecipe().getResult());
        if (convert != null) {
            e.getInventory().setResult(convert);
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) {
            return;
        }
        for (int i = 0; i < e.getDrops().size(); i++) {
            e.getDrops().set(i, this.module.getItem(ConvertType.DROP, e.getDrops().get(i)));
        }
        this.module.dropEntityItems(e.getEntityType(), e.getEntity().getLocation());
    }

    void dropItem(Location l, ItemStack is) {
        l.getWorld().dropItem(new Location(l.getWorld(), l.getBlockX() + 0.5, l.getBlockY() + 0.5, l.getBlockZ() + 0.5), is);
    }

    void giveOrDrop(Player p, ItemStack is) {
        final int n = p.getInventory().firstEmpty();
        if (n == -1) {
            dropItem(p.getLocation(), is);
        } else {
            p.getInventory().addItem(is);
            p.updateInventory();
        }
    }

    @EventHandler
    public void onPlayerFish(PlayerFishEvent e) {
        final ItemStack fish = this.module.getFish();

        if (fish != null) {
            e.setCancelled(true);
            giveOrDrop(e.getPlayer(), fish);
        }
    }

    private void checkBreak(ItemStack is, Player owner) {
        if (!materials.containsKey(is.getType())) return;
        short d = materials.getOrDefault(is.getType(), (short) 0);
        if (is.getDurability() >= d) {
            int i = owner.getInventory().first(is);
            if (i < 9 && i >= 0) {
                owner.getWorld().playSound(owner.getLocation(), Sound.ENTITY_ITEM_BREAK, 1, 1);
                owner.getInventory().setItem(i, null);
            }
        }
    }

    private void damageItem(ItemStack is, Player owner) {
        Bukkit.getScheduler().scheduleSyncDelayedTask(GameEngine.getInstance().getPlugin(), () -> {
			is.setDurability((short) (is.getDurability() + 1));
			checkBreak(is, owner);
		}, 1L);
    }

    private void dropBreakBlock(Player p, Block b) {
        UniItemStack hand = UniItemStack.fromItemStack(p.getInventory().getItemInMainHand());
        Collection<ItemStack> drops = b.getDrops();

        b.setType(Material.AIR);

        drops.forEach(d -> dropItem(b.getLocation(), module.getItem(ConvertType.BLOCK, d)));

        module.dropBlockItems(b.getType(), b.getLocation());

        if (hand != null && hand.getType() != Material.AIR && materials.containsKey(hand.getType()) && !hand.getItemMeta().spigot().isUnbreakable()) {
            damageItem(hand, p);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        UniPlayer player = (UniPlayer) e.getPlayer();
        //get drops from block if the tool used is the item in player's hand
        Collection<ItemStack> drops = b.getDrops(player.getInventory().getItemInMainHand());

        //player need to be in survival and the convert list should not be empty
        if (e.isCancelled() || !player.getGameMode().equals(GameMode.SURVIVAL) || !ConvertType.BLOCK.containsOne(drops))
            return;

        //set the experience from the module
        Integer n = module.getMaterialXp(b.getType());
        if (n != null) {
            ExperienceOrb ex2 = player.getWorld().spawn(player.getLocation(), ExperienceOrb.class);
            ex2.setExperience(n);
        }

        //handle block breaking
        dropBreakBlock(player, b);

        //if block should drop XP then drop XP
        if (e.getExpToDrop() > 0) {
            ExperienceOrb ex = player.getWorld().spawn(player.getLocation(), ExperienceOrb.class);
            ex.setExperience(e.getExpToDrop());
        }

        //cancel the block break
        e.setCancelled(true);
    }
}
