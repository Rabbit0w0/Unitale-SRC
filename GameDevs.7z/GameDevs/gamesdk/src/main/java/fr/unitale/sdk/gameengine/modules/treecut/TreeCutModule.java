package fr.unitale.sdk.gameengine.modules.treecut;

import java.util.LinkedList;
import java.util.Queue;
import java.util.function.Function;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.features.uhc.UHCRunKitType;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.gameengine.modules.kit.KitChoiceModule;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.data.Tuple;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.math.RandomUtils;

public class TreeCutModule extends Module<TreeCutListener> {

    private static final int MAX_LOG_BREAK = 15;
    private static final int MAX_LEAVES_BREAK = 10;

    private double appleDropPercent;
    private final DropModule dm;
    private Queue<Tuple<Block, UniPlayer>> blocks = new LinkedList<>();
    private boolean run = false, checkKit, breakLeaves = true;
    private Function<UniPlayer, Double> appleDropBonus;

    public TreeCutModule(DropModule dropmodule, boolean checkKit) {
        this.moduleListener = new TreeCutListener(this);
        this.dm = dropmodule;
        this.appleDropPercent = GameEngine.getInstance().getConfig("AppleDrop", 1.0);
        this.appleDropBonus = (k) -> 0.0D;
        this.checkKit = checkKit;
    }

    public TreeCutModule(DropModule dropModule) {
        this(dropModule, false);
    }

    public TreeCutModule() {
        this(null);
    }

    public TreeCutModule setAppleDropBonus(Function<UniPlayer, Double> function) {
        this.appleDropBonus = function;
        return this;
    }

    /**
     * @return the breakLeaves
     */
    public boolean doesBreakLeaves() {
        return breakLeaves;
    }

    /**
     * @param breakLeaves the breakLeaves to set
     */
    public TreeCutModule setBreakLeaves(boolean breakLeaves) {
        this.breakLeaves = breakLeaves;
        return this;
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    private void recursiveLeavesBreak(UniPlayer p, Location l, Block b, DropModule dm, int n) {
        if (n <= 0 || b == null || dm == null || this.blocks.stream().anyMatch(t -> t.getA().equals(b)) || (b.getType() != Material.LEAVES && b.getType() != Material.LEAVES_2))
            return;

        breakBlock(b, p);

        // around x axis
        recursiveLeavesBreak(p, l, b.getRelative(1, 0, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(1, 1, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(1, -1, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, 0, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, 1, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, -1, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, -1, 0), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, 1, 0), dm, n - 1);
        // around z axis
        recursiveLeavesBreak(p, l, b.getRelative(0, 1, 1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, 1, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, -1, 1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, -1, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, 0, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(0, 0, 1), dm, n - 1);
        //angle 1
        recursiveLeavesBreak(p, l, b.getRelative(1, 0, 1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(1, 1, 1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(1, -1, 1), dm, n - 1);
        //angle 2
        recursiveLeavesBreak(p, l, b.getRelative(-1, 0, 1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, 1, 1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, -1, 1), dm, n - 1);
        //angle 3
        recursiveLeavesBreak(p, l, b.getRelative(-1, 0, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, 1, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(-1, -1, -1), dm, n - 1);
        //angle 4
        recursiveLeavesBreak(p, l, b.getRelative(1, 0, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(1, -1, -1), dm, n - 1);
        recursiveLeavesBreak(p, l, b.getRelative(1, 1, -1), dm, n - 1);
    }

    private void recursiveLogBreak(UniPlayer p, Location l, Block b, DropModule dm, int n) {
        //BLOCK BREAKING
        if (b == null || dm == null || n <= 0 || this.blocks.stream().anyMatch(t -> t.getA().equals(b))) return;

        if ((b.getType() == Material.LEAVES || b.getType() == Material.LEAVES_2) && doesBreakLeaves()) {
            // around x axis
            recursiveLeavesBreak(p, l, b.getRelative(1, 0, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(1, 1, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(1, -1, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, 0, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, 1, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, -1, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, -1, 0), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, 1, 0), dm, MAX_LEAVES_BREAK);
            // around z axis
            recursiveLeavesBreak(p, l, b.getRelative(0, 1, 1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, 1, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, -1, 1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, -1, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, 0, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(0, 0, 1), dm, MAX_LEAVES_BREAK);
            //angle 1
            recursiveLeavesBreak(p, l, b.getRelative(1, 0, 1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(1, 1, 1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(1, -1, 1), dm, MAX_LEAVES_BREAK);
            //angle 2
            recursiveLeavesBreak(p, l, b.getRelative(-1, 0, 1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, 1, 1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, -1, 1), dm, MAX_LEAVES_BREAK);
            //angle 3
            recursiveLeavesBreak(p, l, b.getRelative(-1, 0, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, 1, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(-1, -1, -1), dm, MAX_LEAVES_BREAK);
            //angle 4
            recursiveLeavesBreak(p, l, b.getRelative(1, 0, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(1, -1, -1), dm, MAX_LEAVES_BREAK);
            recursiveLeavesBreak(p, l, b.getRelative(1, 1, -1), dm, MAX_LEAVES_BREAK);
            return;
        } else if (b.getType() != Material.LOG && b.getType() != Material.LOG_2) return;

        breakBlock(b, p);

        // around x axis
        recursiveLogBreak(p, l, b.getRelative(1, 0, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(1, 1, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(1, -1, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, 0, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, 1, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, -1, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, -1, 0), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, 1, 0), dm, n - 1);
        // around z axis
        recursiveLogBreak(p, l, b.getRelative(0, 1, 1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, 1, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, -1, 1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, -1, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, 0, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(0, 0, 1), dm, n - 1);
        //angle 1
        recursiveLogBreak(p, l, b.getRelative(1, 0, 1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(1, 1, 1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(1, -1, 1), dm, n - 1);
        //angle 2
        recursiveLogBreak(p, l, b.getRelative(-1, 0, 1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, 1, 1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, -1, 1), dm, n - 1);
        //angle 3
        recursiveLogBreak(p, l, b.getRelative(-1, 0, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, 1, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(-1, -1, -1), dm, n - 1);
        //angle 4
        recursiveLogBreak(p, l, b.getRelative(1, 0, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(1, -1, -1), dm, n - 1);
        recursiveLogBreak(p, l, b.getRelative(1, 1, -1), dm, n - 1);
    }

    public void blockBreak(UniPlayer p, Location l, Block b) {
        recursiveLogBreak(p, l, b, this.dm, MAX_LOG_BREAK);
    }

    private void timeBreak() {
        new BukkitRunnable() {
            @Override
            public void run() {
                breakAsyncBlock();
            }
        }.runTaskLater(UnitaleSDK.getInstance(), 1L);
    }

    private void breakAsyncBlock() {
        Tuple<Block, UniPlayer> tuple;
        Location l;

        for (int i = 0; i < 30; i++) {
            if (this.blocks.isEmpty()) {
                this.run = false;
                return;
            }

            tuple = this.blocks.remove();
            if (tuple.getA().getType() != Material.AIR) {
                l = tuple.getA().getLocation().clone().add(0.5, 0.5, 0.5);
                if (tuple.getA().getType() == Material.LEAVES || tuple.getA().getType() == Material.LEAVES_2) {
                    if (checkKit) {
                        dropApple(tuple.getA(), l, this.appleDropPercent + this.appleDropBonus.apply(tuple.getB()));
                    } else {
                        dropApple(tuple.getA(), l, appleDropPercent);
                    }

                } else if (this.dm != null) {
                    tuple.getA().getWorld().dropItemNaturally(l, dm.getItem(ConvertType.BLOCK, tuple.getA().getType()));
                } else {
                    tuple.getA().breakNaturally();
                }

                tuple.getA().setType(Material.AIR);
            }
        }

        if (!this.blocks.isEmpty()) timeBreak();
        else this.run = false;
    }

    private void breakBlock(Block b, UniPlayer p) {
        this.blocks.add(new Tuple<>(b, p));
        if (!this.run) {
            timeBreak();
            this.run = true;
        }
    }

    //Drop apple for a given block at a given loc with a given percent of chance
    private void dropApple(Block b, Location l, double percent) {
        if (RandomUtils.nextDouble(0, 100) > 100.0 - percent) {
            b.getLocation().getWorld().dropItemNaturally(l, new UniItemStack(Material.APPLE));
        }
    }
}
