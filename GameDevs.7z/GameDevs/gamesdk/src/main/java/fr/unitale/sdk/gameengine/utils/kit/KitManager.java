package fr.unitale.sdk.gameengine.utils.kit;

import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.entity.Player;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class KitManager {
    private static KitProvider provider;

    private static final String STORAGE_KEY = "uhc:kits";
    private static final Map<Class<?>, Map<Integer, AbstractKit>> KITS = new HashMap<>();

    public static void setupKit(KitProvider kitProvider, IKit[] iKits) {
        provider = kitProvider;
        Arrays.stream(iKits).forEach(type -> {
            Class<? extends AbstractKit> clazz = getTypeFromKit(type);
            KITS.compute(clazz, (k, v) -> {
                Map<Integer, AbstractKit> kits = v;
                if (kits == null) {
                    kits = new HashMap<>();
                }
                try {
                    kits.put(type.getLevel(), clazz.getConstructor(IKit.class).newInstance(type));
                } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                    e.printStackTrace();
                }
                return kits;
            });
        });
    }

    public static <T extends AbstractKit> T fromPlayer(Player player, Class<? extends AbstractKit> clazz) {
        if (!(player instanceof UniPlayer)) return null;
        return fromPlayer((UniPlayer) player, clazz);
    }

    /**
     * Get the corresponding kit instance of this kit, or null if the player does not have this kit
     *
     * @noinspection unchecked
     */
    @SuppressWarnings("unchecked")
    public static <T extends AbstractKit> T fromPlayer(UniPlayer player, Class<? extends AbstractKit> clazz) {
        Map<Class<?>, Integer> kits = getPlayerKits(player);
        try{
            int level = kits.get(clazz);
            return (T) KITS.get(clazz).get(level);
        }catch(NullPointerException npe){
            return null;
        }
    }

    public static void loadFeatures(UniPlayer player, IKit[] iKit) {
        Map<Class<?>, Integer> kits = Arrays.stream(iKit)
                .filter(player.getFeatures()::has)
                .collect(Collectors.toMap(KitManager::getTypeFromKit, IKit::getLevel, (a, b) -> b, HashMap::new));
        player.getStorage().addObject(STORAGE_KEY, kits);
    }

    private static Class<? extends AbstractKit> getTypeFromKit(IKit kit) {
        return provider.getTypeFromKit(kit);
    }

    @SuppressWarnings("unchecked")
    private static Map<Class<?>, Integer> getPlayerKits(UniPlayer player) {
        return (Map<Class<?>, Integer>) player.getStorage().getObject(STORAGE_KEY, new HashMap<Class<?>, Integer>());
    }
}
