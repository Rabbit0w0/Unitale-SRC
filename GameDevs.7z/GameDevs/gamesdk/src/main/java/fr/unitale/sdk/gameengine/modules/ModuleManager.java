package fr.unitale.sdk.gameengine.modules;

import java.util.HashMap;
import java.util.Map;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;

/**
 * Manage module list, start or stop them
 */
public class ModuleManager {

    private final Map<Class<?>, Module<?>> modules;

    public ModuleManager() {
        this.modules = new HashMap<>();
    }

    /**
     * Load a module from a {@link Module} extended class
     *
     * @param moduleType {@link Module} extended class
     * @return true if the module is loaded else false
     */
    public boolean loadModule(Class<? extends Module<?>> moduleType) {
        final Module<?> module = this.modules.get(moduleType);
        if (module != null) {
            module.privateStartModule();
            return true;
        }
        return false;
    }

    /**
     * Unload a module from the corresponding {@link Module} extended class
     *
     * @param moduleType {@link Module} extended class
     * @return true if the module has been unload else either
     */
    public boolean unloadModule(Class<? extends Module<?>> moduleType) {
        final Module<?> module = this.modules.get(moduleType);
        if (module != null) {
            module.privateEndModule();
            return true;
        }
        return false;
    }

    /**
     * Add a module to the registered module
     *
     * @param module {@link Module} to add
     * @param load   boolean should we load the module
     * @return true if all is OK
     */
    public boolean addModule(Module<?> module, boolean load) {
        this.modules.put(module.getClass(), module);
        if (load) {
            module.privateStartModule();
        }
        return true;
    }

    /**
     * Add a module without loading it
     *
     * @param module {@link Module} to add
     * @return true if all is OK
     */
    public boolean addModule(Module<?> module) {
        return addModule(module, false);
    }

    /**
     * Remove a module from the registered modules
     *
     * @param moduleType {@link Module} extended class to remove
     * @param unload     boolean should we unload the module first
     * @return true if all is OK false either
     */
    @Deprecated
    public boolean removeModule(Class<?> moduleType, boolean unload) {
        final Module<?> module = this.modules.get(moduleType);
        if (module == null) {
            return false;
        }
        if (unload) {
            module.privateEndModule();
        }
        this.modules.remove(moduleType);
        return true;
    }

    /**
     * Remove a module and unload it before
     *
     * @param moduleType {@link Module} extended class to remove
     * @return true if all is OK false either
     */
    public boolean removeModule(Class<?> moduleType) {
        return (removeModule(moduleType, true));
    }

    /**
     * Check for a specific Module registered
     *
     * @param module {@link Module} extended class searched
     * @return true if found, false either
     */
    public boolean hasModule(Class<?> module) {
        return modules.containsKey(module);
    }

    /**
     * Get a {@link Module} instance from a registered {@link Module} extended class registered
     *
     * @param <T>        {@link Module} extended
     * @param moduleType {@link Module} extended class to get instance from
     * @return the module if found false either
     */
    @SuppressWarnings("unchecked")
    public <T extends Module<?>> T getModule(Class<T> moduleType) {
        final Module<?> module = this.modules.get(moduleType);
        return (T) module;
    }

    /**
     * Get the {@link TeamModule} instance if registered with a given team class
     *
     * @param <T>        extends {@link UniTeam}
     * @param moduleType {@link UniTeam} extended class
     * @return {@link TeamModule} if found else false
     */
    @SuppressWarnings("unchecked")
    public <T extends UniTeam> TeamModule<T> getTeamModule(Class<T> moduleType) {
        return getModule(TeamModule.class);
    }

    public Map<Class<?>, Module<?>> getModules() {
        return modules;
    }

    /**
     * Unload and remove every modules
     */
    public void clear() {
        for (final Module<?> m : modules.values()) {
            m.privateEndModule();
        }
        this.modules.clear();
    }
}
