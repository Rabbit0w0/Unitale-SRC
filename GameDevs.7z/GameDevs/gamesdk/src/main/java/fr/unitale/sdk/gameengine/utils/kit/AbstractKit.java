package fr.unitale.sdk.gameengine.utils.kit;

import fr.unitale.sdk.features.IKit;

public abstract class AbstractKit {
    private final IKit kit;

    public AbstractKit(IKit kit) {
        this.kit = kit;
    }

    public IKit getIKit() {
        return kit;
    }

    public int getLevel() {
        return kit.getLevel();
    }
}
