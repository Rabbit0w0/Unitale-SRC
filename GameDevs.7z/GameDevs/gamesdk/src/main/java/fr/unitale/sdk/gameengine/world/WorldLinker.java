package fr.unitale.sdk.gameengine.world;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.World.Environment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

import fr.unitale.sdk.UnitaleSDK;

/**
 * Allow to manage manually world traveling between worlds
 */
public class WorldLinker implements Listener {

    private static int netherDiffSize = 8;

    private final World overworld;
    private final World nether;
    private final World end;
    private boolean force;

    public WorldLinker(World overworld, World nether, World end, boolean force) {
        this.overworld = overworld;
        this.nether = nether;
        this.end = end;
        this.force = force;
        Bukkit.getPluginManager().registerEvents(this, UnitaleSDK.getInstance());
    }

    public WorldLinker(World overworld, World nether, World end) {
        this(overworld, nether, end, false);
    }

    public WorldLinker(World overworld, boolean force) {
        this.overworld = overworld;
        this.nether = getFirstWorld(Environment.NETHER);
        this.end = getFirstWorld(Environment.THE_END);
        this.force = force;
        Bukkit.getPluginManager().registerEvents(this, UnitaleSDK.getInstance());
    }

    public WorldLinker(World overworld) {
        this(overworld, false);
    }

    public static World getFirstWorld(Environment e) {
		return Bukkit.getWorlds().stream()
				.filter(w -> w.getEnvironment() == e)
				.findFirst()
				.orElse(null);
	}

    public World getOverworld() {
        return overworld;
    }

    public World getNether() {
        return nether;
    }

    public World getEnd() {
        return end;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void prevPortal(PlayerPortalEvent ev) {
        if (ev.getTo() == null || this.force) {
            if (ev.getCause() == TeleportCause.NETHER_PORTAL) {
                ev.setTo(ev.getPortalTravelAgent().findOrCreate(getNetherPortalLocation(ev.getFrom())));
            } else if (ev.getCause() == TeleportCause.END_PORTAL) {
                ev.setTo(this.end.getHighestBlockAt(this.end.getSpawnLocation()).getLocation());
            }

            if (!ev.useTravelAgent()) {
                ev.useTravelAgent(true);
            }
        }
    }

    private Location getNetherPortalLocation(Location from) {
        if (from.getWorld().getEnvironment() == Environment.NETHER) {
            return new Location(this.overworld, from.getX() * netherDiffSize, from.getY() * netherDiffSize,
                    from.getZ() * netherDiffSize);
        }
        return new Location(this.nether, from.getX() / netherDiffSize, from.getY() / netherDiffSize,
                from.getZ() / netherDiffSize);
    }

    public boolean isForced() {
        return force;
    }

    public void setForce(boolean force) {
        this.force = force;
    }
}
