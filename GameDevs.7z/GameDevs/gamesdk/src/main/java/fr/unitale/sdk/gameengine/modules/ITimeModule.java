package fr.unitale.sdk.gameengine.modules;

public interface ITimeModule {
    void update();

    Module<?> me();
}
