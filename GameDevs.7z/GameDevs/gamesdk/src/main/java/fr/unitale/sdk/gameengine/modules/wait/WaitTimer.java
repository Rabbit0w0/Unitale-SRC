package fr.unitale.sdk.gameengine.modules.wait;

import org.bukkit.Bukkit;

import fr.unitale.sdk.gameengine.modules.wait.events.WaitTimeChangedEvent;
import fr.unitale.sdk.utils.generic.UniTimer;

public class WaitTimer extends UniTimer {
    private final WaitingModule module;

    public WaitTimer(WaitingModule mod, String name, int m, int s) {
        super(name, m, s);
        module = mod;
    }

    @Override
    protected void userUpdate() {
        Bukkit.getPluginManager().callEvent(new WaitTimeChangedEvent(this));
        module.updateScoreboard();
    }
}
