package fr.unitale.sdk.gameengine.map.firestorm;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class House extends FirestormMap {

    public House(String name, World world) {
        super(MapType.FIRESTORM_HOUSE, name, world, new Location(world, 577, 24, -1470),
                new Location(world, 577, 41, -1477), 5);
        this.bonus.add(new Location(world, 565, 1, -1493));
        this.bonus.add(new Location(world, 580, 1, -1477));
        this.bonus.add(new Location(world, 578, 9, -1471));
        this.bonus.add(new Location(world, 586, 9, -1482));
        this.bonus.add(new Location(world, 575, 9, -1482));
        this.bonus.add(new Location(world, 567, 12, -1478));
        this.bonus.add(new Location(world, 577, 15, -1470));
        this.bonus.add(new Location(world, 573, 15, -1481));
        this.bonus.add(new Location(world, 574, 20, -1481));
        this.bonus.add(new Location(world, 589, 2, -1473));
        this.bonus.add(new Location(world, 577, 14, -1480));
    }
}
