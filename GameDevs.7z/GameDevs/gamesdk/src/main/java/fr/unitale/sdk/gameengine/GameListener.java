package fr.unitale.sdk.gameengine;

import fr.unitale.api.PlayerApi;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateOfflinePlayer;
import fr.unitale.sdk.gameengine.events.eliminate.EliminatePlayerEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerWinEvent;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.SetEndScoreboardEvent;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;
import fr.unitale.sdk.players.event.UnitalePlayerQuitEvent;
import fr.unitale.sdk.utils.data.Storage;
import fr.unitale.sdk.utils.elo.EloManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.event.weather.WeatherChangeEvent;

public class GameListener implements Listener {

//    @EventHandler
//    public void on(UnitalePreparePlayerJoinEvent ev){
//        GameStatus status = GameEngine.getInstance().getGameStatus();
//        if ((status == GameStatus.WAIT) || (status == GameStatus.GAME && GameEngine.getInstance().getOfflinePlayers().contains(ev.getPlayer().getUniqueId()))) {
//            return;
//        }
//        //if player has permission to spec at end of the game (game.specend)
//        if (ev.getPlayer().hasPermission("game.specend") && GameEngine.getInstance().getServerMode() == ServerMode.NORMAL && GameEngine.getInstance().allowSpectate) {
//            return;
//        } else {
//            ev.setCancelled(true);
//            ev.setKickReason("game full");
//        }
//    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void join(UnitalePlayerJoinEvent ev) {
        GameEngine.getInstance().playerJoin(ev.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void quit(UnitalePlayerQuitEvent ev) {
        GameEngine.getInstance().playerQuit(ev.getPlayer());
    }

    @EventHandler
    public void onSetEndScoreboard(SetEndScoreboardEvent e) {
        e.getPlayer().getStorage().addObject(GameEngine.SCOREBOARD_STORAGE, e.getPlayer().getEndScoreboard());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerJoinEvent(PlayerJoinEvent event) {
        event.setJoinMessage(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerQuitEvent(PlayerQuitEvent event) {
        event.setQuitMessage(null);
    }

    @EventHandler
    public void onEliminateOfflinePlayer(EliminateOfflinePlayer e) {
        GameEngine.getInstance().removeFromKeep(e.getUUID());
        if (GameEngine.getInstance().getServerMode() == ServerMode.RANKED) {
            Storage s = GameEngine.getInstance().getStorage(e.getUUID());
            if (s != null) {
                final String key = GameEngine.getEloKey();
                int newElo = EloManager.eloLose(s.getInteger(GameEngine.ELOKEY, 1500), GameEngine.getInstance().getGameElo());
                PlayerApi.setElo(e.getUUID(), key, newElo);
            }
        }
    }

    @EventHandler
    public void onEliminatePlayerEvent(EliminatePlayerEvent e) {
        GameEngine.getInstance().removeFromKeep(e.getPlayer().getUniqueId());
        if (GameEngine.getInstance().getServerMode() == ServerMode.RANKED) {
            final String key = GameEngine.getEloKey();
            int newElo = EloManager.eloLose(e.getPlayer().getElo(key), GameEngine.getInstance().getGameElo());
            PlayerApi.setElo(e.getPlayer().getUniqueId(), key, newElo);
            e.getPlayer().setElo(key, newElo);
        }
    }

    @EventHandler
    public void onPlayerWin(GamePlayerWinEvent e) {

        if (GameEngine.getInstance().getServerMode() == ServerMode.RANKED) {
            final String key = GameEngine.getEloKey();
            int newElo;
            for (final UniPlayer p : e.getPlayers()) {
                newElo = EloManager.eloWin(p.getElo(key), GameEngine.getInstance().getGameElo());
                PlayerApi.setElo(p.getUniqueId(), key, newElo);
                p.setElo(key, newElo);
            }
        }
    }

    @EventHandler
    public void damage(EntityDamageEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void blockBreak(BlockBreakEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void blockPlace(BlockPlaceEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerAchievementAwarded(PlayerAchievementAwardedEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void food(FoodLevelChangeEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setFoodLevel(20);
        }
    }

    @EventHandler
    public void explode(EntityExplodeEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void pickup(PlayerPickupItemEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void drop(PlayerDropItemEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void target(EntityTargetEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void onWeatherChange(WeatherChangeEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntitySpawn(EntitySpawnEvent ev) {
        if (!(ev.getEntity() instanceof Player) && GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityCombustByEntity(EntityCombustByEntityEvent ev) {
        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) {
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void regen(EntityRegainHealthEvent ev) {
        if (GameEngine.getInstance().getGameStatus() == GameStatus.GAME) {
            return;
        }
        if (ev.getEntity() instanceof Player) {
            final Player p = (Player) ev.getEntity();
            p.setHealth(p.getMaxHealth());
        }
    }

//	private boolean isNearbyPlayer(Player p, double d){
//		for (Entity e : p.getNearbyEntities(d, d, d)){
//			if (e instanceof Player)return true;
//		}
//		return false;
//	}
//	
//	private Player getNearPlayer(Player p){
//		for (UniPlayer pl : GameEngine.getInstance().getOnlinePlayers()){
//			if (!pl.getUniqueId().equals(p.getUniqueId()))return pl;
//		}
//		return p;
//	}

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        if (GameEngine.getInstance().getGameStatus() == GameStatus.WAIT) {
            GameEngine.getInstance().userWaitMove(e.getPlayer());
            return;
        }

        if (GameEngine.getInstance().getGameStatus() != GameStatus.GAME) return;

        //TODO desactivated for the moment, still usefull ? (causes strange tp)
//		Player p = e.getPlayer();
//		
//		if (GameEngine.getInstance().isEliminated(p.getUniqueId()) &&
//				p.getGameMode() == org.bukkit.GameMode.SPECTATOR &&
//				!isNearbyPlayer(p, 100)){
//			
//			p.setSpectatorTarget(getNearPlayer(p));
//		}
    }
}
