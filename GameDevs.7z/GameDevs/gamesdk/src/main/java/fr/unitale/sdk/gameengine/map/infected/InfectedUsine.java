package fr.unitale.sdk.gameengine.map.infected;

import java.util.Arrays;
import java.util.Collections;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class InfectedUsine extends InfectedMap {

    public InfectedUsine(String name, World world) {
        super(MapType.INFECTED_FACTORY, name, world,
				Collections.singletonList(
						new Location(world, 0, 64, 0)),
                Arrays.asList(
                        new Location(world, -28, 64, -37),
                        new Location(world, 28, 64, -38),
                        new Location(world, 27, 64, 25),
                        new Location(world, -17, 64, 40)));
    }
}
