package fr.unitale.sdk.gameengine.events.eliminate;

import java.util.UUID;

public class EliminateOfflinePlayer extends EliminateEvent {

    private final UUID op;

    public EliminateOfflinePlayer(UUID p) {
        this.op = p;
    }

    public UUID getUUID() {
        return op;
    }
}
