package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Chest;
import org.bukkit.inventory.ItemStack;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;

public class AngevsDemon extends FKMap {

    public AngevsDemon(String name, World world) {
        super(MapType.ANGEVSDEMON, name, new Location(FKMap.world, -7, 185, 72));

        this.addTeam(149, 76, 94, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(-166, 74, 143, UniColor.RED, "Rouge");
//		this.addTeam(437,98,13, UniColor.GREEN, "Vert");
//		this.addTeam(47,95,-281, UniColor.ORANGE, "Orange");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);
    }

    @Override
    public void populateFirstChest(Chest c) {
        super.populateFirstChest(c);
        c.getInventory().addItem(new ItemStack(Material.SUGAR_CANE, 3));
    }
}
