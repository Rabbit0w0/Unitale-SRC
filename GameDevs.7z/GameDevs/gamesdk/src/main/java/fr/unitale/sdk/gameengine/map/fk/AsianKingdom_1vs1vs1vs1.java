package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;

public class AsianKingdom_1vs1vs1vs1 extends FKMap {

    public AsianKingdom_1vs1vs1vs1(String name, World world) {
        super(MapType.ASIANKINGDOM_1VS1VS1VS1, name, new Location(FKMap.world, 0, 70, 0));

        this.addTeam(-260, 71, -2, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(232, 74, 15, UniColor.RED, "Rouge");
        this.addTeam(6, 68, -234, UniColor.GREEN, "Vert");
        this.addTeam(-1, 64, 196, UniColor.ORANGE, "Orange");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);
    }
}
