package fr.unitale.sdk.gameengine.modules.team;

import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.players.event.SetEndScoreboardEvent;

public class TeamModuleListener extends ModuleListener<TeamModule<?>> {

    public TeamModuleListener(TeamModule<?> module) {
        super(module);
    }

    @EventHandler
    public void onPlayerDamage(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof Player) {
            final Entity damager = e.getDamager();
            if (damager != null) {
                Player pDamager = null;
                if (damager instanceof Player) {
                    pDamager = (Player) damager;
                } else if (damager instanceof Projectile) {
                    final Projectile projectile = (Projectile) damager;
                    if (projectile.getShooter() instanceof Player) {
                        pDamager = (Player) projectile.getShooter();
                    }
                }

                if (pDamager != null && UniTeam.sameTeam(pDamager, (Player) e.getEntity())) {
                    e.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onEndarielPlayerJoin(GamePlayerJoinEvent e) {
        if (GameEngine.getInstance().getMode() == Mode.TEAM)
            e.getPlayer().sendMessage(ChatColor.GOLD + "Utilisez la commande /t pour parler avec votre team.");
    }

    @EventHandler
    public void onSetEndScoreboard(SetEndScoreboardEvent e) {
        this.module.createTeamBoard(e.getPlayer());
    }
}
