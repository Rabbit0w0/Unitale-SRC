package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;

import fr.unitale.sdk.gameengine.events.game.GameStartEvent;
import fr.unitale.sdk.gameengine.utils.LuckyBlock.LuckyBlockType;
import fr.unitale.sdk.utils.items.UniItemStack;
import net.minecraft.server.v1_10_R1.NBTTagCompound;

public class FKMapListener implements Listener {
    private final FKMap map;

    public FKMapListener(FKMap map) {
        this.map = map;
    }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void blockBreak(BlockBreakEvent e) {
        if (this.map.getNoBreakable().contains(e.getBlock().getType())) {
            e.setCancelled(true);
            return;
        }
        if (map.isLucky(e.getBlock())) {
            LuckyBlockType.randomExecute(e.getBlock(), e.getPlayer());
            map.removeLucky(e.getBlock().getLocation());
        } else if (map.isWool(e.getBlock()) && e.getBlock().getType() == Material.WOOL) {
            final UniItemStack c = new UniItemStack(Material.WOOL, e.getBlock().getData());
            final NBTTagCompound tag = c.getTag();
            tag.setInt("color", e.getBlock().getData());
            c.setTag(tag);
            e.getPlayer().getInventory().addItem(c);
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void explode(EntityExplodeEvent e) {
        boolean c = false;
        for (final Block b : e.blockList()) {
            if (map.isWool(b)) c = true;
        }
        e.setCancelled(c);
    }

    @EventHandler
    public void burn(BlockBurnEvent e) {
        if (map.isWool(e.getBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent e) {
        if (this.map.getNoPlace().contains(e.getBlock().getType())) {
            e.setCancelled(true);
            return;
        }
        if (map.isWool(e.getBlock())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onGameStart(GameStartEvent e) {
        map.start();
    }
}
