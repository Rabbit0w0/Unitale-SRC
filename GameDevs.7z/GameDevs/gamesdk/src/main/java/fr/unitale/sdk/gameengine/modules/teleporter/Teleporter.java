package fr.unitale.sdk.gameengine.modules.teleporter;

import org.bukkit.Location;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.area.Area;
import fr.unitale.sdk.utils.area.AreaType;

public class Teleporter extends Area {
    protected final Location center;
    protected final Location out;

    protected Teleporter(String name, Location center, Location out) {
        super(name, AreaType.CUBOID);
        this.center = center;
        this.out = out;
    }

    @Override
    public boolean contains(Location l) {
        return (this.center.getBlockX() == l.getBlockX() &&
                this.center.getBlockY() == l.getBlockY() &&
                this.center.getBlockZ() == l.getBlockZ());
    }

    @Override
    public void moveIn(UniPlayer p) {
        p.teleport(this.out);
    }

    public Location getIn() {
        return this.center;
    }

    public Location getOut() {
        return this.out;
    }

}
