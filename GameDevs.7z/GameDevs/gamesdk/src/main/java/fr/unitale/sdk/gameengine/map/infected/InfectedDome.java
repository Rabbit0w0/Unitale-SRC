package fr.unitale.sdk.gameengine.map.infected;

import fr.unitale.sdk.gameengine.map.MapType;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Arrays;
import java.util.Collections;

public class InfectedDome extends InfectedMap {

    public InfectedDome(String name, World world) {
        super(MapType.INFECTED_DOME, name, world,
				Collections.singletonList(
						new Location(world, -2, 64, -2)),
                Arrays.asList(
                        new Location(world, 0, 75, 20),
                        new Location(world, -18, 75, -26),
                        new Location(world, -38, 65, -8),
                        new Location(world, 33, 65, -2)));
    }
}
