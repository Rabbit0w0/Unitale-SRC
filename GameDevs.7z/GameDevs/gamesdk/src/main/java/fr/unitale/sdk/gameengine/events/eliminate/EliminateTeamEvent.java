package fr.unitale.sdk.gameengine.events.eliminate;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;

public class EliminateTeamEvent extends EliminateEvent {
    private final UniTeam team;
    private final int competingTeams;

    public EliminateTeamEvent(UniTeam team) {
        this.team = team;
        this.competingTeams = GameEngine.getInstance().getCompetingTeamCount();
    }

    public UniTeam getTeam() {
        return this.team;
    }

    public int getCompetingTeams() {
        return competingTeams;
    }
}
