package fr.unitale.sdk.gameengine.map.firestorm;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class LuigiCastle extends FirestormMap {

    public LuigiCastle(String name, World world) {
        super(MapType.FIRESTORM_LUIGICASTLE, name, world, new Location(world, 1, 92, 81),
                new Location(world, 1, 145, 79), 5);
        this.bonus.add(new Location(world, 27, 58, 88));
        this.bonus.add(new Location(world, -10, 52, 69));
        this.bonus.add(new Location(world, 23, 49, 97));
        this.bonus.add(new Location(world, -1, 54, 99));
        this.bonus.add(new Location(world, 22, 71, 68));
        this.bonus.add(new Location(world, 9, 80, 83));
        this.bonus.add(new Location(world, -10, 84, 75));
        this.bonus.add(new Location(world, -16, 94, 84));
        this.bonus.add(new Location(world, 0, 94, 85));
        this.bonus.add(new Location(world, 10, 94, 84));
        this.bonus.add(new Location(world, 15, 92, 69));
        this.bonus.add(new Location(world, 1, 88, 62));
        this.bonus.add(new Location(world, 6, 48, 70));
        this.bonus.add(new Location(world, 2, 77, 86));
        this.bonus.add(new Location(world, 9, 73, 89));
        this.bonus.add(new Location(world, 1, 66, 101));
        this.bonus.add(new Location(world, 2, 63, 74));
        this.bonus.add(new Location(world, 3, 52, 63));
        this.bonus.add(new Location(world, -21, 50, 93));
        this.bonus.add(new Location(world, 6, 49, 101));
        this.bonus.add(new Location(world, 28, 51, 72));
        this.bonus.add(new Location(world, 1, 66, 100));
        this.bonus.add(new Location(world, 3, 71, 72));
        this.bonus.add(new Location(world, 24, 72, 67));
        this.bonus.add(new Location(world, -17, 63, 59));
        this.bonus.add(new Location(world, 20, 64, 60));
        this.bonus.add(new Location(world, 13, 55, 61));
        this.bonus.add(new Location(world, -14, 53, 70));
        this.bonus.add(new Location(world, -15, 54, 79));
    }
}
