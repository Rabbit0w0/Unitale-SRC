package fr.unitale.sdk.gameengine.modules.team;

import org.bukkit.entity.Player;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;

public class TeamDispatcher<T extends UniTeam> {
    protected final TeamModule<T> module;

    public TeamDispatcher(TeamModule<T> module) {
        this.module = module;
    }

    public void dispatch() {
        //set a team for all players without teams
        GameEngine.getInstance().getOnlinePlayers().forEach(p -> {
            UniTeam team = UniTeam.getTeam(p);
            //if player does not have a team
            if (team == null) {
                //get the team with the least amount of players
                UniTeam smallestTeam = module.getSmallerTeam();
                if (smallestTeam != null) {
                    smallestTeam.addPlayer(p);
                } else {
                    UniLogger.warning("found null when asking for smallest team (team amount = " + module.getNbTeam() + ") ! sending player to hub !");
                    p.sendToHub();
                }
            }
        });

        //check for a single team filled with players
        int emptyTeamsCount = (int) module.getTeams().stream().filter(UniTeam::isEmpty).count();
        if (emptyTeamsCount == module.getTeams().size() - 1) {//if there's only one team filled with players
            //we balance
            UniTeam nonEmpty = module.getTeams().stream().filter(t -> !t.isEmpty()).findFirst().orElse(null);
            UniTeam newTeam = module.getFirstAvailableTeam();
            int halPlayerCount = nonEmpty.getCompetingCount() / 2;
            for (int i = 0; i < halPlayerCount; i++) {
                UniPlayer player = nonEmpty.getFirstAvailablePlayer();
                player.sendMessage(Lang.str(player, "game.team.menu.limited"));
                nonEmpty.removePlayer(player);
                newTeam.addPlayer(player);
            }
        }

        //if we have to dispatch players in every teams
        if (module.isDispatchTeam()) {
            while (module.getDistanceTeams() > 1) {
                UniTeam higher = module.getHigherTeam();
                UniTeam smaller = module.getSmallerTeam();
                Player p = higher.getOnlinePlayers().get(higher.getOnlinePlayers().size() - 1);
                p.sendMessage(Lang.str(p, "game.team.menu.limited"));

                higher.removePlayer(p);
                smaller.addPlayer(p);
            }
        }

        module.getTeams().stream().filter(UniTeam::isEmpty).forEach(UniTeam::burnAtStart);
    }
}
