package fr.unitale.sdk.gameengine.map.fk.utils;

import org.bukkit.block.Block;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.utils.generic.Unlocker;

public abstract class TeamUnlocker<T extends UniTeam> extends Unlocker {
    private Block block;
    private T team;

    public TeamUnlocker(Long timeToUnlock, T team, Block b) {
        super(timeToUnlock);
        this.team = team;
        this.block = b;
    }

    public T getTeam() {
        return team;
    }

    public void setTeam(T team) {
        this.team = team;
    }

    public Block getBlock() {
        return block;
    }
}
