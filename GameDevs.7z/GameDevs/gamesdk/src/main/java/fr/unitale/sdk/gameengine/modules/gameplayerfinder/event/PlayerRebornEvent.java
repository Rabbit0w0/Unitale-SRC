package fr.unitale.sdk.gameengine.modules.gameplayerfinder.event;

import fr.unitale.sdk.gameengine.modules.gameplayerfinder.PlayerSave;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UniPlayerEvent;

public class PlayerRebornEvent extends UniPlayerEvent {

    private final PlayerSave save;

    public PlayerRebornEvent(UniPlayer player, PlayerSave save) {
        super(player);
        this.save = save;
    }

    public PlayerSave getSave() {
        return save;
    }
}
