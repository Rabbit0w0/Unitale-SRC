package fr.unitale.sdk.gameengine.utils.kit;

import fr.unitale.sdk.features.IKit;

public interface KitProvider {

    Class<? extends AbstractKit> getTypeFromKit(IKit kit);
}
