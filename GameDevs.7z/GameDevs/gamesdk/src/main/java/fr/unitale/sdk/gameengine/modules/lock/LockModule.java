package fr.unitale.sdk.gameengine.modules.lock;

import fr.unitale.sdk.gameengine.modules.Module;

public class LockModule extends Module<LockListener> {

    public LockModule() {
        this.moduleListener = new LockListener(this);
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }
}
