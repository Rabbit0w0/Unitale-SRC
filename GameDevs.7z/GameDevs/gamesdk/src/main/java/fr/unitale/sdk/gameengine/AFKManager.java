package fr.unitale.sdk.gameengine;

import java.util.Calendar;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;

/**
 * Manage AFK
 */
public class AFKManager implements Listener {

    private static String LAST_ACTIVITY = "LAST_ACTIVITY";
    private static long afktimer = 300000L;

    public AFKManager() {
        new BukkitRunnable() {

            @Override
            public void run() {
                if (!GameEngine.getInstance().isAntiAFK()) return;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UniPlayer ep = (UniPlayer) p;
                    if (!ep.hasPermission("afk.bypass") && ep.isOnline()) {
                        long actual = Calendar.getInstance().getTimeInMillis();
                        long time = ep.getStorage().getLong(LAST_ACTIVITY, actual);
                        if (actual - time > afktimer) {
                            GameEngine.getInstance().eliminatePlayer(ep);
                            GameEngine.getInstance().broadcast("game.kick.afk", ep.getName());
                            ep.sendToHub();
                            ep.getStorage().addLong(LAST_ACTIVITY, 0l);
                        }
                    }
                }
            }
        }.runTaskTimer(UnitaleSDK.getInstance(), 0l, 20l * 5l);
    }

    @EventHandler
    public void onJoin(UnitalePlayerJoinEvent e) {
        e.getPlayer().getStorage().addLong(LAST_ACTIVITY, Calendar.getInstance().getTimeInMillis());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        ((UniPlayer) e.getPlayer()).getStorage().addLong(LAST_ACTIVITY, Calendar.getInstance().getTimeInMillis());
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        ((UniPlayer) e.getWhoClicked()).getStorage().addLong(LAST_ACTIVITY, Calendar.getInstance().getTimeInMillis());
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        //Todo gérer l'asynchrone
        ((UniPlayer) e.getPlayer()).getStorage().addLong(LAST_ACTIVITY, Calendar.getInstance().getTimeInMillis());
    }
}
