package fr.unitale.sdk.gameengine.events.game;

import fr.unitale.api.type.ServerTypes.GameStatus;

public class GameStateEvent extends GameEvent {

	private final GameStatus status;

	public GameStateEvent(GameStatus status) {
		this.status = status;
	}

	public GameStatus getStatus() {
		return status;
	}
}
