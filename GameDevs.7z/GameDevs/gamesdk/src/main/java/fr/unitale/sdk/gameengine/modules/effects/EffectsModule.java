package fr.unitale.sdk.gameengine.modules.effects;

import java.util.LinkedList;
import java.util.List;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import fr.unitale.sdk.gameengine.modules.Module;

public class EffectsModule extends Module<EffectsModuleListener> {
    private final List<PotionEffect> effects = new LinkedList<>();

    public EffectsModule() {
        this.moduleListener = new EffectsModuleListener(this);
    }

    @Override
    public void startModule() {
        for (final Object obj : getConfig("effects", new JSONArray()).toArray()) {
            final JSONObject jobj = (JSONObject) obj;

            final PotionEffectType type = PotionEffectType.getByName((String) jobj.get("type"));
            final int amplifier = Math.toIntExact((long) jobj.get("amplifier"));
            effects.add(new PotionEffect(type, Integer.MAX_VALUE, amplifier));
        }
    }

    @Override
    public void endModule() {
    }

    public void setEffects(Player... parr) {
        for (final Player p : parr) {
            p.addPotionEffects(effects);
        }
    }
}
