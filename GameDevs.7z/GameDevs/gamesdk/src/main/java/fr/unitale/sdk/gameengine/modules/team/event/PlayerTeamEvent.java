package fr.unitale.sdk.gameengine.modules.team.event;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;

public class PlayerTeamEvent extends TeamEvent {

	private final UniPlayer player;

	public PlayerTeamEvent(UniTeam team, UniPlayer player) {
		super(team);
		this.player = player;
	}

	public UniPlayer getPlayer() {
		return this.player;
	}

}
