package fr.unitale.sdk.gameengine.modules.team;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;

public class SetTeamOwnerCommand extends AbstractCommand {

    public SetTeamOwnerCommand() {
        super("teamleader");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof UniPlayer) {
            final UniPlayer ep = (UniPlayer) sender;
            UniTeam team;
            if ((team = UniTeam.getTeam(ep.getUniqueId())) != null) {
                if (team.getOwner().equals(ep.getUniqueId())) {
                    Player newLeader;
                    if ((newLeader = Bukkit.getPlayer(args[0])) != null) {
                        if (team.contains(newLeader)) {
                            team.setOwner(newLeader.getUniqueId());
                            team.broadcast("game.wait.team.leader.designedby", ep.getChatDisplayName(), args[0]);
                        } else {
                            ep.sendMessage(Lang.str(ep, "game.wait.team.player_not_in_your_team"));
                        }
                    } else {
                        ep.sendMessage(Lang.str(ep, "ui.generic.player.notfound"));
                    }
                } else {
                    ep.sendMessage(Lang.str(ep, "game.wait.team.notleader"));
                }
            } else {
                ep.sendMessage(Lang.str(ep, "game.wait.noteam"));
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }
}
