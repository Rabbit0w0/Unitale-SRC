package fr.unitale.sdk.gameengine.map.skydef;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class SkydefMushroom extends SkydefMap {

    public SkydefMushroom(String name, World world) {
        super(MapType.SKYDEF_MUSHROOM, name, world,
                new Location(world, 0, 180, 0),
                world.getHighestBlockAt(0, 0).getLocation(),
                new Location(world, 11, 180, 2),
                world.getHighestBlockAt(new Location(world, 11, 180, 2)).getLocation(),
                new Location(world, 0, 180, 6),
                16,
                new Location(world, -50, 111, -51));
    }
}
