package fr.unitale.sdk.gameengine.modules.futuremoves;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import fr.unitale.sdk.GameSDK;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.bar.BarAPI;
import fr.unitale.sdk.bar.EndBar;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.game.GameStartEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.ActionBar;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.material.UniMaterial;
import fr.unitale.sdk.utils.math.VectorUtils;
import fr.unitale.sdk.utils.sound.SoundCreator;

import java.util.Arrays;

public class FutureMovesModuleListener extends ModuleListener<FutureMovesModule> {
    private static PotionEffectType JETPACK_EFFECT = PotionEffectType.LEVITATION;
    private static String bossBar = "JETPACK_BAR";

    public FutureMovesModuleListener(FutureMovesModule module) {
        super(module);
    }

    @EventHandler
    public void onGameStart(GameStartEvent event) {
        for (Player p : GameEngine.getInstance().getOnlinePlayers()) {
            p.setAllowFlight(true);
            if (module.isJetPackEnabled()) {
                EndBar bar = UnitaleSDK.getAPI(BarAPI.class).registerNewBar(Lang.str(p, "game.futuremoves.bar"), BarColor.PURPLE, p);
                ((UniPlayer) p).getStorage().addObject(bossBar, bar);
                bar.setMaxValue(1.0D);
                bar.setValue(1.0D);
            }
        }
        new EffectThread(module).runTaskTimer(GameSDK.asJavaPlugin(), 1L, 1L);
    }

    @EventHandler
    public void onPlayerToggleFlight(PlayerToggleFlightEvent e) {
        if (e.getPlayer().getGameMode().equals(GameMode.CREATIVE) || e.getPlayer().getGameMode().equals(GameMode.SPECTATOR))
            return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        BlockFace face = haveBlockOnSide(p);
        EndBar bar = ((EndBar) ((UniPlayer) p).getStorage().getObject(bossBar));
        if (face != null && module.getCanWallJump().test((UniPlayer) e.getPlayer())) {
            Vector v = p.getVelocity();
            v.setY(0);
            if (face.getModX() != 0) {
                v.setX(v.getX() * face.getModX());
            }
            if (face.getModZ() != 0) {
                v.setZ(v.getZ() * face.getModZ());
            }
            v.multiply(3);
            v.add(new Vector(face.getModX(), 0, face.getModZ()));
            v.add(new Vector(0, 1.5, 0));
            v.multiply(0.4);
            p.setVelocity(v);
            p.setAllowFlight(false);
        } else if (module.isJetPackEnabled() && bar.getValue() >= 1D) {
            p.addPotionEffect(new PotionEffect(JETPACK_EFFECT, 20, 1));
            bar.setValue(0D);
            p.setAllowFlight(false);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.getPlayer().getGameMode().equals(GameMode.CREATIVE) || event.getPlayer().getGameMode().equals(GameMode.SPECTATOR))
            return;

        UniPlayer p = (UniPlayer) event.getPlayer();
        EndBar bar = ((EndBar) p.getStorage().getObject(bossBar));
        if (!p.hasPotionEffect(JETPACK_EFFECT)) {
            BlockFace face = haveBlockOnSide(p);
            if (face != null && module.getCanWallJump().test(p)) {
                p.setAllowFlight(true);
                ActionBar.sendActionBar(p, Lang.str(p, "game.futuremoves.walljump"));
            } else {
//				ActionBar.sendActionBar(p, "");
                if (module.isJetPackEnabled()) {
                    if (bar.getValue() < 1D) {
                        p.setAllowFlight(false);
                    }
                }
            }
        }
    }

    public BlockFace haveBlockOnSide(Player p) {
        final Location loc = p.getLocation();
        final World w = loc.getWorld();
        final double x = loc.getX();
        final double y = loc.getY();
        final double z = loc.getZ();
        final Location[] sides = new Location[]{new Location(w, x + 0.5, y, z), new Location(w, x - 0.5, y, z), new Location(w, x, y, z + 0.5), new Location(w, x, y, z - 0.5)};

        return Arrays.stream(sides)
                .filter(bl -> UniMaterial.byMaterial(bl.getBlock().getType()).isSolid())
                .findFirst()
                .map(bl -> bl.getBlock().getFace(loc.getBlock()))
                .orElse(null);
    }

    public static class EffectThread extends BukkitRunnable {

        private FutureMovesModule module;

        public EffectThread(FutureMovesModule module) {
            this.module = module;
        }

        @Override
        public void run() {
            if (!module.isJetPackEnabled()) return;
            for (Player p : GameEngine.getInstance().getOnlinePlayers()) {
                EndBar bar = ((EndBar) ((UniPlayer) p).getStorage().getObject(bossBar));
                if (p.hasPotionEffect(JETPACK_EFFECT)) {
                    SoundCreator.playSound(p.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1F, 1F, 5);

                    Location particle = p.getLocation().add(0D, 1.2D, 0D);

                    Vector vector = new Vector(-0.25, 0, 0.2);
                    vector = VectorUtils.rotateVector(vector, p.getLocation().getYaw(), p.getLocation().getPitch());
                    ParticleEffect.FLAME.display(0F, 0F, 0F, 0F, 1, particle.clone().add(vector), 100.0D);
                    ParticleEffect.SMOKE_NORMAL.display(new Vector(0D, -1, 0D), 0.1F, particle.clone().add(vector), 100.0D);

                    vector = new Vector(-0.25, 0, -0.2);
                    vector = VectorUtils.rotateVector(vector, p.getLocation().getYaw(), p.getLocation().getPitch());
                    ParticleEffect.FLAME.display(0F, 0F, 0F, 0F, 1, particle.clone().add(vector), 100.0D);
                    ParticleEffect.SMOKE_NORMAL.display(new Vector(0D, -1, 0D), 0.1F, particle.clone().add(vector), 100.0D);
                } else {
                    if (bar.getValue() < 1D) {
                        final double nXp = bar.getValue() + 0.01D;
                        if (nXp > 1D) {
                            p.setAllowFlight(true);
                            bar.setValue(1D);
                        } else {
                            bar.setValue(nXp);
                        }
                    }
                }
            }
        }
    }
}
