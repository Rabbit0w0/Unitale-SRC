package fr.unitale.sdk.gameengine.map.firestorm;

import java.util.LinkedList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;

public abstract class FirestormMap extends GameMap {
	private int radius;
    private final Location spawn;
    private final Location lava;
    protected final List<Location> bonus;

    public FirestormMap(MapType type, String name, World world, Location spawn, Location lava, int radius) {
        super(type, name, world);
        this.spawn = spawn;
        this.lava = lava;
        this.radius = radius;
        this.bonus = new LinkedList<>();
    }

    public Location getSpawn() {
        return spawn;
    }

    public Location getLava() {
        return lava;
    }

    public int getRadius() {
        return radius;
    }

    public FirestormMap setRadius(int r) {
        this.radius = r;
        return this;
    }

    public List<Location> getBonus() {
        return this.bonus;
    }
}
