package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;

public class EasterKingdoms extends FKMap {

    public EasterKingdoms(String name, World world) {
        super(MapType.EASTERKINGDOMS, name, new Location(FKMap.world, -17, 71, 5));

        this.addTeam(-316, 74, -1, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(356, 71, -24, UniColor.RED, "Rouge");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);
    }
}