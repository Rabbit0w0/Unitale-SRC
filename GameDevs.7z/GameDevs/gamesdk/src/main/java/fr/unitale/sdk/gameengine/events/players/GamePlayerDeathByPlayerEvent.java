package fr.unitale.sdk.gameengine.events.players;

import fr.unitale.sdk.players.UniPlayer;

public class GamePlayerDeathByPlayerEvent extends GamePlayerDeathEvent {
    private final UniPlayer killer;

    public GamePlayerDeathByPlayerEvent(UniPlayer player, UniPlayer killer) {
        super(player);
        this.killer = killer;
        this.isKill = true;
    }

    public UniPlayer getKiller() {
        return killer;
    }
}
