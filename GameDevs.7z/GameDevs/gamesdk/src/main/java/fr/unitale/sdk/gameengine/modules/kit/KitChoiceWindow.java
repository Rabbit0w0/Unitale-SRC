package fr.unitale.sdk.gameengine.modules.kit;

import org.bukkit.entity.Player;

import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.ui.elements.UIWindow;

public class KitChoiceWindow extends UIWindow {

    public KitChoiceWindow(Player p) {
        super(54, Lang.str(p, "game.kit.menu.select"));

        addPanel("main", new KitChoicePanel(p));

        showPanel("main");
    }
}
