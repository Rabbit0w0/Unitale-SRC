package fr.unitale.sdk.gameengine.modules.gameplayerfinder;

import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;

public class PlayerSave {
    private final UUID uuid;
    private final String name;
    private final Location location;
    private final ItemStack[] inventory;
    private final ItemStack[] stuff;
    private final UniTeam team;
    private final int level;
    private final float xp;

    public PlayerSave(UUID uuid, String name, Location location, ItemStack[] inventory, ItemStack[] stuff, UniTeam team, int level, float xp) {
        this.uuid = uuid;
        this.name = name;
        this.location = location;
        this.inventory = inventory;
        this.stuff = stuff;
        this.team = team;
        this.level = level;
        this.xp = xp;
    }

    public PlayerSave(Player p) {
        this(p.getUniqueId(), p.getName(), p.getLocation().clone(), p.getInventory().getContents(), p.getInventory().getArmorContents(), UniTeam.getTeam(p),
                p.getLevel(), p.getExp());
    }

    public void load(Player p) {
        p.teleport(this.location);
        p.getInventory().clear();
		Arrays.stream(this.inventory).filter(Objects::nonNull).forEach(itemStack -> p.getInventory().addItem(itemStack));
        p.getInventory().setArmorContents(this.stuff);
        p.setLevel(this.level);
        p.setExp(this.xp);
        if (this.team != null) this.team.addPlayer(p);
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public Location getLocation() {
        return location;
    }

    public ItemStack[] getInventory() {
        return inventory;
    }

    public ItemStack[] getStuff() {
        return stuff;
    }

    public UniTeam getTeam() {
        return team;
    }

    public int getLevel() {
        return level;
    }

    public float getXp() {
        return xp;
    }
}
