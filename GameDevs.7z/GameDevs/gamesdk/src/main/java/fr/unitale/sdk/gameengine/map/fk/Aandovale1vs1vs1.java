package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Chest;
import org.bukkit.inventory.ItemStack;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;

public class Aandovale1vs1vs1 extends FKMap {

    public Aandovale1vs1vs1(String name, World world) {
        super(MapType.AANDOVALE1VS1VS1, name, new Location(FKMap.world, -31, 169, -5));

        this.addTeam(85, 98, 21, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(-128, 100, 6, UniColor.RED, "Rouge");
        this.addTeam(-26, 96, -112, UniColor.GREEN, "Vert");
//		this.addTeam(47,95,-281, UniColor.ORANGE, "Orange");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);
    }

    @Override
    public void populateFirstChest(Chest c) {
        super.populateFirstChest(c);
        c.getInventory().addItem(new ItemStack(Material.SUGAR_CANE, 3));
    }
}
