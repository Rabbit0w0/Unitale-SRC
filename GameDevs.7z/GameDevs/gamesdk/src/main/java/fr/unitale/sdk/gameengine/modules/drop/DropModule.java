package fr.unitale.sdk.gameengine.modules.drop;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Supplier;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.utils.math.RandomUtils;

public class DropModule extends Module<DropListener> {

    private boolean populateEnchantedBooks = false;
    private Supplier<Integer> enchantAmount = () -> RandomUtils.nextInt(3) + 1;
    private Supplier<Integer> enchantLevel = () -> RandomUtils.nextInt(3) + 1;

    public DropModule() {
        moduleListener = new DropListener(this);
    }

    /**
     * @return the populateEnchantedBooks
     */
    public boolean shouldPopulateEnchantedBooks() {
        return populateEnchantedBooks;
    }

    /**
     * @param populateEnchantedBooks the populateEnchantedBooks to set
     */
    public DropModule setPopulateEnchantedBooks(boolean populateEnchantedBooks) {
        this.populateEnchantedBooks = populateEnchantedBooks;
        return this;
    }

    /**
     * @return the EnchantAmount
     */
    public Supplier<Integer> getEnchantAmount() {
        return enchantAmount;
    }

    /**
     * @return the enchantLevel
     */
    public Supplier<Integer> getEnchantLevel() {
        return enchantLevel;
    }

    /**
     * @param enchantAmount the enchantAmount to set
     */
    public void setEnchantAmount(Supplier<Integer> enchantAmount) {
        this.enchantAmount = enchantAmount;
    }

    /**
     * @param enchantLevel the enchantLevel to set
     */
    public void setEnchantLevel(Supplier<Integer> enchantLevel) {
        this.enchantLevel = enchantLevel;
    }

    private static Map<DropMaterial, ItemStack> craft = new LinkedHashMap<>();
    private static Map<DropMaterial, ItemStack> brew = new LinkedHashMap<>();
    private static Map<DropMaterial, ItemStack> drop = new LinkedHashMap<>();
    private static Map<DropMaterial, ItemStack> block = new LinkedHashMap<>();
    private static Map<DropMaterial, ItemStack> fish = new LinkedHashMap<>();

    List<ItemAdded<Material>> blockAdd = new LinkedList<>();
    List<ItemAdded<EntityType>> entityAdd = new LinkedList<>();

    Map<ItemStack, Integer> fishAdd = new LinkedHashMap<>();
    private final Map<Material, Integer> materialXp = new LinkedHashMap<>();

    static class DropMaterial {
        private final Material material;
        private final byte data;

        public DropMaterial(Material m, byte data) {
            this.material = m;
            this.data = data;
        }

        public Material getMaterial() {
            return this.material;
        }

        public byte getData() {
            return (this.data);
        }
    }

    static class ItemAdded<T> {
        int rate;
        ItemStack item;
        T type;

        public ItemAdded(int rate, ItemStack is, T type) {
            this.rate = rate;
            this.item = is;
            this.type = type;
            if (this.rate < 0) {
                this.rate = 0;
            } else if (this.rate > 100) {
                this.rate = 100;
            }
        }

        public ItemStack getItem() {
            return (this.item);
        }

        public boolean rand() {
            return (((int) (Math.random() * 100)) < this.rate);
        }

        public T getType() {
            return (this.type);
        }
    }

    public enum ConvertType {
        CRAFT(craft), BREW(brew), DROP(drop), BLOCK(block), FISH(fish);

        Map<DropMaterial, ItemStack> map;

        ConvertType(Map<DropMaterial, ItemStack> map) {
            this.map = map;
        }

        @SuppressWarnings("deprecation")
        public boolean contains(ItemStack is) {
            if (is == null) {
                return false;
            }
            return (contains(is.getType(), is.getData().getData()));
        }

        public boolean contains(Material m, byte b) {
			return map.keySet().stream()
					.anyMatch(dm -> dm.getMaterial() == m && (dm.getData() == (byte) -1 || dm.getData() == b));
        }

        public boolean containsOne(Collection<ItemStack> items) {
            for (ItemStack is : items) {
                if (contains(is)) return true;
            }
            return false;
        }
    }

    public void addMaterialXp(Material m, Integer xp) {
        this.materialXp.put(m, xp);
    }

    public Integer getMaterialXp(Material m) {
        return this.materialXp.get(m);
    }

    public void addConvertItem(ConvertType type, Material mat, Byte data, ItemStack is) {
        addConvertItem(type, new DropMaterial(mat, data), is);
    }

    public void addConvertItem(ConvertType type, Material mat, ItemStack is) {
        addConvertItem(type, new DropMaterial(mat, (byte) (-1)), is);
    }

    public void addConvertItem(ConvertType type, DropMaterial mat, ItemStack is) {
        type.map.put(mat, is);
    }

    public ItemStack getItem(ConvertType type, Material mat) {
        return (getItem(type, mat, (byte) -1, 1));
    }

    public ItemStack getItem(ConvertType type, Material mat, byte b) {
        return (getItem(type, mat, b, 1));
    }

    public ItemStack getItem(ConvertType type, Material mat, int amount) {
        return (getItem(type, mat, (byte) -1, amount));
    }

    @SuppressWarnings("deprecation")
    public ItemStack getItem(ConvertType type, Material mat, byte b, int amount) {
        ItemStack all = null;
        ItemStack value = null;
        for (final Entry<DropMaterial, ItemStack> e : type.map.entrySet()) {
            if (e.getKey().getMaterial() == mat) {
                if (e.getKey().getData() == b) {
                    value = e.getValue();
                } else if (e.getKey().getData() == -1) {
                    all = e.getValue();
                }
            }
        }
        if (value == null) {
            value = all;
        }
        ItemStack stack = ((value != null) ? new ItemStack(value.getType(), value.getAmount() * amount, value.getData().getData()) : new ItemStack(mat, amount, (b == -1) ? 0 : b));
        if (stack.getType() == Material.ENCHANTED_BOOK && shouldPopulateEnchantedBooks()) {
            int enchantAmount = getEnchantAmount().get();
            for (int i = 0; i < enchantAmount; i++) {
                int enchantLevel = getEnchantLevel().get();
                stack.addUnsafeEnchantment(Enchantment.values()[RandomUtils.nextInt(Enchantment.values().length)], enchantLevel);
            }
        }
        return stack;
    }

    @SuppressWarnings("deprecation")
    public ItemStack getItem(ConvertType type, ItemStack is) {
        return ((is != null) ? getItem(type, is.getType(), is.getData().getData(), is.getAmount()) : null);
    }

    public ItemStack getItem(ConvertType type, ItemStack is, byte b) {
        return ((is != null) ? getItem(type, is.getType(), b, is.getAmount()) : null);
    }

    public void addEntityDrop(ItemAdded<EntityType> ia) {
        this.entityAdd.add(ia);
    }

    public void addEntityDrop(EntityType e, int rate, ItemStack item) {
        addEntityDrop(new ItemAdded<>(rate, item, e));
    }

    public void addBlockDrop(ItemAdded<Material> ia) {
        this.blockAdd.add(ia);
    }

    public void addBlockDrop(Material m, int rate, ItemStack item) {
        addBlockDrop(new ItemAdded<>(rate, item, m));
    }

    public void addFish(ItemStack is, int value) {
        this.fishAdd.put(is, value);
    }

    public ItemStack getFish() {
        if (this.fishAdd.size() == 0) {
            return null;
        }
        int n = this.fishAdd.values().stream().mapToInt(v -> v).sum();
		final int r = (int) (Math.random() * n);
        n = 0;
        for (final Entry<ItemStack, Integer> e : this.fishAdd.entrySet()) {
            n += e.getValue();
            if (n >= r) {
                return (e.getKey());
            }
        }
        return (null);
    }

    public void dropEntityItems(EntityType et, Location l) {
		this.entityAdd.stream()
				.filter(ia -> ia.getType() == et && ia.rand())
				.forEach(ia -> l.getWorld().dropItem(l, ia.getItem()));
    }

    public void dropBlockItems(Material m, Location l) {
        final Location la = new Location(l.getWorld(), l.getBlockX() + 0.5, l.getBlockY(), l.getBlockY() + 0.5);
		this.blockAdd.stream()
				.filter(ia -> ia.getType() == m && ia.rand())
				.forEach(ia -> la.getWorld().dropItem(la, ia.getItem()));
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }
}
