package fr.unitale.sdk.gameengine.modules.randomtp;

import fr.unitale.api.Response;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.thread.SDKPool;
import fr.unitale.sdk.utils.block.CageCreator;
import net.minecraft.server.v1_10_R1.PacketPlayOutMapChunk;
import org.bukkit.*;
import org.bukkit.craftbukkit.v1_10_R1.CraftChunk;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.Map.Entry;

public class RandomTPModule extends Module<RandomTPModuleListener> {
    private World world;
    private Mode mode;
    private int circle;

    Map<UniTeam, Location> teamSpawn = null;
    Map<Location, UUID> soloSpawn = null;

    public RandomTPModule(World w) {
        this.moduleListener = new RandomTPModuleListener(this);
        mode = GameEngine.getInstance().getMode();
        this.world = w;
        this.circle = 3;
    }

    @Override
    public void startModule() {
        if (mode == Mode.SOLO) {
            setPlayerSpawn();
        } else {
            setTeamSpawn();
        }
    }

    public void setSpawn(int r) {
        if (mode == Mode.SOLO) {
            setPlayerSpawn(r);
        } else {
            setTeamSpawn(r);
        }
    }

    public void reloadPosition() {
        Location l;
        if (this.mode == Mode.SOLO) {
            Collection<UniPlayer> players = new LinkedList<>(GameEngine.getInstance().getOnlinePlayers());
            for (UniPlayer p : players) {
                l = setUserLocation(p);
                if (l != null) {
                    sendCircleChunk(p.getPlayer(), l, circle);
                }
            }
        } else {
            TeamModule<UniTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
            if (tm == null) {
                return;
            }
            for (UniTeam t : tm.getTeams()) {
                l = teamSpawn.get(t);
                if (l != null) {
                    for (UniPlayer p : t.getOnlinePlayers()) {
                        sendCircleChunk(p, l, circle);
                    }
                }
            }
        }
    }

    @Override
    public void endModule() {
        HandlerList.unregisterAll(moduleListener);
    }

    public void teleportAllDelayed() {
        teleportAllDelayed(null);
    }

    public void teleportAllDelayed(Response<?> r) {
        for (UniPlayer p : GameEngine.getInstance().getOnlinePlayers()) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 1200, 4));
        }
        teleportAll(false);
        new BukkitRunnable() {

            @Override
            public void run() {
                fallAll();
                removeGlass();
                if (r != null) r.success(null);
            }
        }.runTaskLater(UnitaleSDK.getInstance(), 200l);
    }

    private void fallAll() {
        Collection<UniPlayer> players = new LinkedList<>(GameEngine.getInstance().getOnlinePlayers());
        for (UniPlayer p : players) {
            p.removePotionEffect(PotionEffectType.DAMAGE_RESISTANCE);
            p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 20*30, 4));
            p.setGameMode(GameMode.SURVIVAL);
        }
    }

    public void teleportAll(boolean ground) {
        if (GameEngine.getInstance().getMode() == Mode.TEAM) {
            teleportPlayersByTeam(ground);
        } else {
            teleportPlayers(ground);
        }
    }

    public void setTeamSpawn() {
        setTeamSpawn(getConfig("radius", 750));
    }

    public void setTeamSpawn(int r) {
        TeamModule<UniTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
        if (tm == null) {
            return;
        }
        this.teamSpawn = new HashMap<>(tm.getNbTeam());
        double diff = Math.PI * 2 / tm.getNbTeam();
        double off = 0;

        Location spawnLoc;

        for (UniTeam t : tm.getTeams()) {
            spawnLoc = this.world.getHighestBlockAt(
                    (int) (Math.cos(off) * r),
                    (int) (Math.sin(off) * r)).getLocation();
            loadChunk(spawnLoc, this.circle);
            Location glass = spawnLoc.clone();
            glass.setY(150d);
            CageCreator.setCage(glass, Material.BARRIER, 3, 3, t.getColor());

            this.teamSpawn.put(t, spawnLoc.clone());

            off += diff;
        }
    }

    private Location getUserLocation(UUID uuid) {
        return this.soloSpawn.entrySet().stream()
                .filter(e -> e.getValue() != null && e.getValue().equals(uuid))
                .findFirst()
                .map(Entry::getKey)
                .orElse(null);
    }

    Location getUserLocation(Player p) {
        return (getUserLocation(p.getUniqueId()));
    }

    private Location getLocationToSet(Player p) {
        for (Entry<Location, UUID> e : soloSpawn.entrySet()) {
            if (e.getValue() != null && e.getValue().equals(p.getUniqueId())) return e.getKey();
        }

        return this.soloSpawn.entrySet().stream()
                .filter(e -> e.getValue() == null)
                .findFirst()
                .map(Entry::getKey)
                .orElse(null);
    }

    Location setUserLocation(Player p) {
        Location l = getLocationToSet(p);
        if (l != null) {
            this.soloSpawn.put(l, p.getUniqueId());
            return l;
        }
        return null;
    }

    public void setPlayerSpawn() {
        setPlayerSpawn(getConfig("radius", 750));
    }

    public void setPlayerSpawn(int r) {
        WaitingModule wm = GameEngine.getInstance().getModuleManager().getModule(WaitingModule.class);
        int size = 64;
        if (wm != null) {
            size = wm.maxPlayers;
        }
        this.soloSpawn = new HashMap<>(size);
        double diff = Math.PI * 2 / size;
        double off = 0;
        Location spawnLoc;
        for (int i = 0; i < size; i++) {
            spawnLoc = this.world.getHighestBlockAt(
                    (int) (Math.cos(off) * r),
                    (int) (Math.sin(off) * r)).getLocation();
            loadChunk(spawnLoc, this.circle);
            Location glass = spawnLoc.clone();
            glass.setY(150d);
            CageCreator.setCage(glass, Material.BARRIER, 3, 3, null);

            this.soloSpawn.put(spawnLoc.clone(), null);

            off += diff;
        }
    }

    public void removeGlass() {
        if (GameEngine.getInstance().getMode() == Mode.TEAM) {
            for (Entry<UniTeam, Location> entry : teamSpawn.entrySet()) {
                Location loc = entry.getValue().clone();
                loc.setY(150d);
                CageCreator.deleteCage(loc, 3, 3);
            }
        } else {
            for (Entry<Location, UUID> entry : soloSpawn.entrySet()) {
                Location loc = entry.getKey().clone();
                loc.setY(150d);
                CageCreator.deleteCage(loc, 3, 3);
            }
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setGameMode(GameMode.SURVIVAL);
        }
    }

    public void teleportPlayersByTeam(boolean ground) {
        TeamModule<UniTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
        if (tm == null) {
            teleportPlayers(ground);
            return;
        }
        Location spawnLoc;
        for (UniTeam t : tm.getTeams()) {
            if (t.isEliminated()) continue;
            spawnLoc = this.teamSpawn.get(t).clone();
            if (spawnLoc != null) {
                for (UniPlayer p : t.getOnlinePlayers()) {
                    if (p.isEliminated()) continue;
                    teleport(p, spawnLoc, ground);
                }
            }
        }
    }

    public void teleportPlayer(Player player, boolean ground) {
        Location spawnLoc = null;
        if (this.mode == Mode.SOLO) {
            spawnLoc = getUserLocation(player).clone();
        } else {
            TeamModule<UniTeam> tm = GameEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
            UniTeam t = UniTeam.getTeam(player);
            if (tm != null && t != null) {
                spawnLoc = this.teamSpawn.get(t).clone();
            }
        }
        if (spawnLoc != null) {
            teleport((UniPlayer) player, spawnLoc, ground);
        }
    }

    private void teleportPlayers(boolean ground) {
        Collection<UniPlayer> players = new LinkedList<>(GameEngine.getInstance().getOnlinePlayers());
        Location spawnLoc;
        for (UniPlayer p : players) {
            if (p.isEliminated()) continue;
            spawnLoc = getUserLocation(p).clone();
            if (spawnLoc != null) {
                teleport(p, spawnLoc, ground);
            }
        }
    }

    public void teleport(UniPlayer p, Location spawnLoc, boolean ground) {
        if (!ground) {
            spawnLoc.setY(152d);
            p.setGameMode(GameMode.ADVENTURE);
        } else {
            p.setGameMode(GameMode.SURVIVAL);
        }

        UnitaleTpEvent event = new UnitaleTpEvent(p, spawnLoc, ground);
        Bukkit.getPluginManager().callEvent(event);
        if (!event.isCancelled()) {
            p.teleport(event.getLocation());
        }
    }

    void sendCircleChunk(final UniPlayer p, final Location spawnLoc, final int circle) {
        loadChunk(spawnLoc, circle);
        SDKPool.execute(() -> {
            for (int x = -circle; x <= circle; x++) {
                for (int z = -circle; z <= circle; z++) {
                    Location loc = spawnLoc.clone().add(x * 16, 0, z * 16);
                    sendChunk(p, loc);
                }
            }
        });
    }

    private void loadChunk(final Location spawnLoc, final int circle) {
        for (int x = -circle; x <= circle; x++) {
            for (int z = -circle; z <= circle; z++) {
                Location loc = spawnLoc.clone().add(x * 16, 0, z * 16);
                if (!loc.getChunk().isLoaded()) {
                    loc.getChunk().load();
                }
            }
        }
    }

    private void sendChunk(UniPlayer player, Location l) {
        player.sendPacket(new PacketPlayOutMapChunk(((CraftChunk) l.getChunk()).getHandle(), 65535));
    }

    public World getWorld() {
        return world;
    }

    public void setWorld(World world) {
        this.world = world;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public int getCircle() {
        return circle;
    }

    public void setCircle(int circle) {
        this.circle = circle;
    }
}
