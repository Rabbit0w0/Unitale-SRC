package fr.unitale.sdk.gameengine.modules.teleporter;

import java.util.LinkedHashMap;
import java.util.Map;

import org.bukkit.Effect;
import org.bukkit.Location;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.utils.area.AreaAPI;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;

public class TeleporterModule extends Module<TeleporterListener> implements Updater {
    private final Map<String, Teleporter> teleporters;
    private int id;

    public TeleporterModule() {
        this.moduleListener = new TeleporterListener(this);
        this.teleporters = new LinkedHashMap<>();
        this.id = 0;
    }

    @Override
    public void startModule() {
        TimeManager.getInstance().addTimer(new UniTimer("TeleporterModule", this));
    }

    @Override
    public void endModule() {

    }

    public Map<String, Teleporter> getTeleporters() {
        return teleporters;
    }

    public Teleporter getTeleporter(String tp) {
        return this.teleporters.get(tp);
    }

    public Teleporter newTeleporter(Location in, Location out) {
        String id = "MODULE_TP_" + this.id++;
        Teleporter tp = new Teleporter(id, in, out);
        this.teleporters.put(id, tp);
        UnitaleSDK.getAPI(AreaAPI.class).addArea(tp);
        return tp;
    }

    public Teleporter newTeleporter(Teleporter tp) {
        this.teleporters.put(tp.getKey(), tp);
        UnitaleSDK.getAPI(AreaAPI.class).addArea(tp);
        return tp;
    }

    public void removeTeleporter(String key) {
        Teleporter tp = this.teleporters.get(key);
        if (tp != null) {
            this.teleporters.remove(key);
            UnitaleSDK.getAPI(AreaAPI.class).removeArea(key);
        }
    }

    public void removeTeleporter(Teleporter tp) {
        removeTeleporter(tp.getKey());
    }

    @Override
    public void start() {
    }

    @SuppressWarnings("deprecation")
    @Override
    public void update() {
        for (Teleporter t : this.teleporters.values()) {
            t.center.getWorld().playEffect(t.center.clone().add(0, 1, 0), Effect.HEART, 0);
        }
    }

    @Override
    public void end() {
    }
}
