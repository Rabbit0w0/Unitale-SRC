package fr.unitale.sdk.gameengine.events.game;

import fr.unitale.api.type.ServerTypes.GameStatus;

public class GameStartEvent extends GameStateEvent {
    int playerFromStart;

    public GameStartEvent(int player) {
        super(GameStatus.GAME);
        this.playerFromStart = player;
    }

    public int getPlayerFromStart() {
        return (this.playerFromStart);
    }
}
