package fr.unitale.sdk.gameengine.map.skydef;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class SkydefTestMap extends SkydefMap {

    public SkydefTestMap(String name, World world) {
        super(MapType.SKYDEF_TEST, name, world,
                new Location(world, 0, 160, 0),
                world.getHighestBlockAt(0, 0).getLocation(),
                new Location(world, 4, 159, 21),
                world.getHighestBlockAt(new Location(world, 4, 180, 21)).getLocation(),
                new Location(world, -7, 195, 0),
                16,
                new Location(world, -96, 100, -82));
    }
}
