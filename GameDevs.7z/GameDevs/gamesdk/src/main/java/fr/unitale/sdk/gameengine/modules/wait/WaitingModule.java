package fr.unitale.sdk.gameengine.modules.wait;

import fr.unitale.api.QueueApi;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.commands.ForcestartCommand;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.team.SetTeamNameCommand;
import fr.unitale.sdk.gameengine.modules.team.SetTeamOwnerCommand;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.wait.events.WaitTimeAbortEvent;
import fr.unitale.sdk.gameengine.modules.wait.room.AWaitingRoom;
import fr.unitale.sdk.gameengine.modules.wait.ui.TeamChoiceWindow;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.scoreboard.DisplaySlot;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

public class WaitingModule extends Module<WaitingModuleListener> {
	
    public int waitMinutes;
    public int waitSeconds;
	public int minPlayers;
    public int maxPlayers;
    public Mode mode;
    public boolean forced = false;
    public WaitTimer timer;
    public UniScoreboard board;
    public UniScoreboard voidBoard;

    public VoteStartCommand voteCommand;
    public SetTeamNameCommand teamNameCommand;
    public SetTeamOwnerCommand teamOwnerCommand;
    public ForcestartCommand forcestartCommand;

    private Listener waitPhaseListener;
    private Map<Player, TeamChoiceWindow> teamsWindows;

    private int waitTick;

    private int ID;
    private final Class<? extends Module<?>>[] moduleToLoad;

    @SuppressWarnings("unchecked")
    private Class<? extends Module<?>>[] waitModules = (Class<Module<?>>[]) new Class[0];
    private AWaitingRoom room;

    Supplier<Boolean> allowVoteStartByPlayers = () -> true;

    @SafeVarargs
    public WaitingModule(Class<? extends Module<?>>... m) {
        super();
        this.room = null;
        moduleToLoad = m;
        moduleListener = new WaitingModuleListener(this);

        voteCommand = new VoteStartCommand(this);
        teamNameCommand = new SetTeamNameCommand();
        teamOwnerCommand = new SetTeamOwnerCommand();
        forcestartCommand = new ForcestartCommand(this);

        waitTick = 0;
        this.voidBoard = new UniScoreboard();
        this.waitPhaseListener = null;
    }

    /**
     * Set the boolean supplier allowing player to make a vote to force the game to start (right clickable by a cmd block)
     * @param allowVoteStartByPlayers
     */
    public void setVoteStartByPlayers(Supplier<Boolean> allowVoteStartByPlayers) {
        this.allowVoteStartByPlayers = allowVoteStartByPlayers;
    }

    public UniScoreboard getBoard() {
        return this.board;
    }

    private void configBoard(UniScoreboard board) {
        board.createSideBoard(ChatColor.BOLD + "" + ChatColor.GOLD + getConfig("waitObjName", "Game"));
        if (GameEngine.getInstance().getMap() != null) {
            board.addScore("spacer_1", " ", 1, DisplaySlot.SIDEBAR);
            board.addScore("map", ChatColor.GREEN + "Map: " + ChatColor.RED + GameEngine.getInstance().getMap().getType().toString(), 2, DisplaySlot.SIDEBAR);
            board.addScore("spacer_2", "  ", 3, DisplaySlot.SIDEBAR);
        }
    }

    public void setAllBoard() {
        Collection<UniPlayer> ps = GameEngine.getInstance().getOnlinePlayers();
		ps.stream().filter(p -> p.getEndScoreboard() != this.board).forEach(p -> p.setScoreboard(board));
    }

    @Override
    public void startModule() {
        if (this.waitPhaseListener != null)
            Bukkit.getPluginManager().registerEvents(this.waitPhaseListener, UnitaleSDK.getInstance());

        this.board = new UniScoreboard();
        configBoard(this.board);
        configBoard(this.voidBoard);
        GameEngine.getInstance().waitGame();
        waitMinutes = getConfig("minutes", 1);
        waitSeconds = getConfig("seconds", 30);
        minPlayers = getConfig("minplayers", 16);
        maxPlayers = getConfig("maxplayers", 20);
        mode = GameEngine.getInstance().getMode();

        //register commands
        teamNameCommand.register();
        teamOwnerCommand.register();
        voteCommand.register();
        forcestartCommand.register();

        //start timer if enough players
        if (Bukkit.getOnlinePlayers().size() >= minPlayers && timer == null) {
            timer = (WaitTimer) TimeManager.getInstance().addTimer(new WaitTimer(this, "Waiting", 0, 30));
        }

        if (mode == Mode.TEAM) {
            UnitaleSDK.enableAPI(API.UI);
            final TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
            if (tm == null) {
                GameEngine.getInstance().emergencyShutdown("TEAM mode and TeamModule is not in the ModuleManager !");
            }
            teamsWindows = new HashMap<>();
        }

        for (final Player p : Bukkit.getOnlinePlayers()) {
            ((UniPlayer) p).setScoreboard(board);
            p.setGameMode(GameMode.ADVENTURE);
            p.getInventory().clear();
            p.getActivePotionEffects().clear();
            p.setHealth(p.getMaxHealth());
            if (mode == Mode.TEAM) {
                final UniItemStack star = new UniItemStack(Material.NETHER_STAR, Lang.str(p, "game.team.choose"));
                p.getInventory().addItem(star);
            }
        }

        ID = Bukkit.getScheduler().scheduleSyncRepeatingTask(GameEngine.getInstance().getPlugin(), this::checkTimer, 0, 20);

        try {
            for (final Class<? extends Module<?>> load : waitModules) {
                final Module<?> module = GameEngine.getInstance().getModuleManager().getModule(load);
                if (module != null) {
                    module.privateStartModule();
                } else {
                    GameEngine.getInstance().getModuleManager().addModule(load.newInstance(), true);
                }
            }
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }

        Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), this::reSendRequest, 20 * 10L);
    }

    /**
     * get a new teamWindow for a given {@link Player}
     *
     * @param p {@link Player} to get team windows for
     * @return {@link TeamChoiceWindow} instance
     */
    public TeamChoiceWindow getTeamWindow(Player p) {
        TeamChoiceWindow window = new TeamChoiceWindow(this, p);
        teamsWindows.put(p, window);
        return window;
    }

    /**
     * Update all teams windows
     */
    public void updateTeamWindow() {
        for (TeamChoiceWindow w : teamsWindows.values()) {
            w.update();
        }
    }

    void resetWaitTick() {
        waitTick = 0;
    }

    public void reSendRequest() {
        if (GameEngine.getInstance().getGameStatus() == GameStatus.WAIT) {
            setQueue();
            if (GameEngine.getInstance().getOnlinePlayers().size() == 0) {
                waitTick++;
            }
            if (waitTick >= 120) {
                Bukkit.getScheduler().cancelTask(ID);
                QueueApi.getInstance().endRequest(GameEngine.getInstance().getGameUuid());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "stop");
                return;
            }
        }

        Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), this::reSendRequest, 30*20L);

    }

    @SafeVarargs
    public final WaitingModule setWaitModules(final Class<? extends Module<?>>... m) {
        waitModules = m;
        return this;
    }

    public void setQueue() {
        final int slots = this.maxPlayers - GameEngine.getInstance().getOnlinePlayers().size();
        final TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
        final String mapName = (GameEngine.getInstance().getMap() != null) ? GameEngine.getInstance().getMap().getType().name() : null;
        final boolean vip = GameEngine.getInstance().isVip();
        final UUID uuid = GameEngine.getInstance().getGameUuid();
        if (tm != null) {
            if (tm.sizeRestricted()) {
                QueueApi.getInstance().request(uuid, ServerManager.type, mapName, GameEngine.getInstance().getServerMode(), mode, tm.getTeamSize(), slots, getMaxPlayers(), vip);
            } else {
                QueueApi.getInstance().request(uuid, ServerManager.type, mapName, GameEngine.getInstance().getServerMode(), mode, null, slots, getMaxPlayers(), vip);
            }
        } else {
            QueueApi.getInstance().request(uuid, ServerManager.type, mapName, GameEngine.getInstance().getServerMode(), mode, null, slots, getMaxPlayers(), vip);
        }
    }

    public void setRoom(AWaitingRoom room) {
        this.room = room;
    }

    public AWaitingRoom getRoom() {
        return (this.room);
    }

    public void checkTimer() {
        checkIfCancel();
        if (timer == null) return;

        if (timer.getMinutes() == 0 && timer.getSeconds() == 0) {
            startGame();
        }
    }

    private void checkIfCancel() {
        if (Bukkit.getOnlinePlayers().size() < minPlayers && timer != null && !forced) {
            TimeManager.getInstance().removeTimer(timer);
            timer = null;
            
            Collection<UniPlayer> ps = GameEngine.getInstance().getOnlinePlayers();
            for (final UniPlayer p : ps) {
                p.sendMessage(Lang.str(p, "game.wait.abort"));
                p.setScoreboard(voidBoard);
            }
            Bukkit.getPluginManager().callEvent(new WaitTimeAbortEvent());
        }
    }

    public void updateScoreboard() {
        if (timer == null) {
            return;
        }
        if (board.hasScore("time")) {
            board.updateScore("time", Lang.str("game.wait.time", timer.getITime()));
        } else {
            board.addScore("time", Lang.str("game.wait.time", timer.getITime()), 0, DisplaySlot.SIDEBAR);
        }
    }

    public void startGame() {
        if (this.waitPhaseListener != null) HandlerList.unregisterAll(this.waitPhaseListener);
        final TeamModule<?> teamModule = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
        
        if (teamModule != null && GameEngine.getInstance().getMode() == Mode.TEAM) {
            teamModule.dispatch();
        }
        Bukkit.getScheduler().cancelTask(ID);
        GameEngine.getInstance().getModuleManager().removeModule(this.getClass());

        for (final Class<? extends Module<?>> load : waitModules) {
            final Module<?> module = GameEngine.getInstance().getModuleManager().getModule(load);
            if (module != null) {
                GameEngine.getInstance().getModuleManager().unloadModule(load);
            }
        }

        try {
            for (final Class<? extends Module<?>> load : moduleToLoad) {
                final Module<?> module = GameEngine.getInstance().getModuleManager().getModule(load);
                if (module != null) {
                    module.privateStartModule();
                } else {
                    GameEngine.getInstance().getModuleManager().addModule(load.newInstance(), true);
                }
            }
            GameEngine.getInstance().startGame();
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void endModule() {
        voteCommand.unregister();
        teamNameCommand.unregister();
        teamOwnerCommand.unregister();
        forcestartCommand.unregister();
        Bukkit.getScheduler().cancelTask(ID);
        QueueApi.getInstance().endRequest(GameEngine.getInstance().getGameUuid());

        UniLogger.info("End of waiting module, starting the game...");
    }

    public Listener getWaitPhaseListener() {
        return waitPhaseListener;
    }

    public void setWaitPhaseListener(Listener waitPhaseListener) {
        this.waitPhaseListener = waitPhaseListener;
    }
    
    public int getMinPlayers() {
		return minPlayers;
	}

	public void setMinPlayers(double minPlayers) {
		this.minPlayers = (int) minPlayers;
	}

	public int getMaxPlayers() {
		return maxPlayers;
	}

	public void setMaxPlayers(int maxplayers) {
		this.maxPlayers = maxplayers;
	}
	
}
