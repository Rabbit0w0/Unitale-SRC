package fr.unitale.sdk.gameengine.events.players;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import fr.unitale.sdk.gameengine.events.game.GameEvent;
import fr.unitale.sdk.players.UniPlayer;

public class GamePlayerWinEvent extends GameEvent {
    private final List<UniPlayer> player;

    public GamePlayerWinEvent(UniPlayer... p) {
        this.player = new ArrayList<>();
		this.player.addAll(Arrays.asList(p));
    }

    public GamePlayerWinEvent(List<UniPlayer> p) {
        this.player = p;
    }

    public List<UniPlayer> getPlayers() {
        return player;
    }
}
