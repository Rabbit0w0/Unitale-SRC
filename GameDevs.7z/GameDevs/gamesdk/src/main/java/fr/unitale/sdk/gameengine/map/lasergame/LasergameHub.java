package fr.unitale.sdk.gameengine.map.lasergame;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class LasergameHub extends LasergameMap {

    public LasergameHub(String name, World w) {
        super(MapType.LASERGAME_HUB, name, w, new Location[]{
                new Location(w, 0, 66, 0)});
    }
}
