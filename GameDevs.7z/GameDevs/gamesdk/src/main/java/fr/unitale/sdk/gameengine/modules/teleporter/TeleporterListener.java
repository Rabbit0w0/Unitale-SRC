package fr.unitale.sdk.gameengine.modules.teleporter;

import fr.unitale.sdk.gameengine.modules.ModuleListener;

public class TeleporterListener extends ModuleListener<TeleporterModule> {

    public TeleporterListener(TeleporterModule module) {
        super(module);
    }
}
