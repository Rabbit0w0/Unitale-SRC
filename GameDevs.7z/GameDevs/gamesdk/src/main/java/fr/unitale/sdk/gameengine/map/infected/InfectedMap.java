package fr.unitale.sdk.gameengine.map.infected;

import java.util.List;
import java.util.Random;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;

public class InfectedMap extends GameMap {

    private List<Location> spawnPlayers, spawnZombies;

    public InfectedMap(MapType type, String name, World world, List<Location> spawnPlayers, List<Location> spawnZombies) {
        super(type, name, world);
        this.spawnPlayers = spawnPlayers;
        this.spawnZombies = spawnZombies;
    }

    /**
     * @param type {@link SpawnType} asked
     * @return {@link Location}
     */
    public Location getRandomSpawnLocation(SpawnType type) {
        switch (type) {
            case PLAYER:
                return spawnPlayers.get(new Random().nextInt(spawnPlayers.size()));
            case ZOMBIE:
                return spawnZombies.get(new Random().nextInt(spawnZombies.size()));
        }
        return null;
    }

    /**
     * @return the spawnPlayers
     */
    public List<Location> getSpawnPlayers() {
        return spawnPlayers;
    }

    /**
     * @return the spawnZombies
     */
    public List<Location> getSpawnZombies() {
        return spawnZombies;
    }

    public enum SpawnType {
        PLAYER, ZOMBIE;
    }
}
