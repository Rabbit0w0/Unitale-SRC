package fr.unitale.sdk.gameengine;

import java.util.UUID;

public abstract class PlayerInfo {

    UUID uuid;

    public PlayerInfo(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUUID() {
        return uuid;
    }

    public abstract void send();
}
