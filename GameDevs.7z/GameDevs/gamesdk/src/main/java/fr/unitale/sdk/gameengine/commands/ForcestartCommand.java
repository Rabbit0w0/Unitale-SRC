package fr.unitale.sdk.gameengine.commands;

import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Force starting of the game without timer
 */
public class ForcestartCommand extends AbstractCommand {

    private WaitingModule module;

    public ForcestartCommand(WaitingModule module) {
        super("forcestart", "/forcestart", "Forcer le demmarage de la partie ! (sans compteur)");
        this.module = module;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof UniPlayer) {
            UniPlayer player = (UniPlayer) sender;
            if (player.hasPermission("game.forcestart")) {
                module.startGame();
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }

}
