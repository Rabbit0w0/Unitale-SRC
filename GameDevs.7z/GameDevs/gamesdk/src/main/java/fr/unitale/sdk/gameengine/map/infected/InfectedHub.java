package fr.unitale.sdk.gameengine.map.infected;

import java.util.Collections;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class InfectedHub extends InfectedMap {

    public InfectedHub(String name, World world) {
        super(MapType.INFECTED_HUB, name, world, Collections.singletonList(new Location(world, 0, 65, 0)), Collections.emptyList());
    }
}
