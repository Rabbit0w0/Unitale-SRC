package fr.unitale.sdk.gameengine.utils;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.stat.PlayerStat;
import fr.unitale.sdk.stat.PlayerStatType;
import fr.unitale.sdk.stat.PlayerStatType.PlayerStatMode;
import fr.unitale.sdk.stat.StatManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Allow to print specific player gain from game
 */
public class EndMoneyManager {

    public static void printGain(UniPlayer p, List<PlayerStatType> stats, boolean emerald) {
        final PlayerStat s = StatManager.getInstance().getPlayerStat(p);
        Integer n;
        int gold = 0;
        int em = 0;
        boolean titleBonus = false;

        p.sendMessage(Lang.str(p, "game.engine.money.header"));
        for (PlayerStatType stat : stats) {
            n = s.getStat(stat);
            if (n > 0 && !titleBonus) {
                p.sendMessage(Lang.str(p, "game.engine.money.bonus"));
                titleBonus = true;
            }
            if (stat.getMode() == PlayerStatMode.UNIQUE && n > 0) {
                p.sendMessage(Lang.str(p, "game.engine.money.statunique", stat.getDescription(), "" + (n * stat.getMoney(MoneyType.GOLD)), "" + (n * stat.getMoney(MoneyType.EMERALDS))));
            } else if (n > 0) {
                p.sendMessage(Lang.str(p, "game.engine.money.stat", stat.getDescription(), "" + n, "" + (n * stat.getMoney(MoneyType.GOLD)), "" + (n * stat.getMoney(MoneyType.EMERALDS))));
            }
            gold += (n * stat.getMoney(MoneyType.GOLD));
            em += (n * stat.getMoney(MoneyType.EMERALDS));
        }

        final double goldBoost = p.getBoost(MoneyType.GOLD);
        final double emBoost = p.getBoost(MoneyType.EMERALDS);

        gold = (int) (gold * goldBoost);
        em = (int) (em * emBoost);

        int gb = (int) (goldBoost * 100) - 100;
        int eb = (int) (emBoost * 100) - 100;

        p.sendMessage(" ");
        p.sendMessage(Lang.str(p, "game.engine.money.gain"));
        p.sendMessage(Lang.str(p, "game.engine.money.gold", (gold + (goldBoost != 0.0 ? Lang.str(p, "game.engine.money.booster", "" + (gb < 0 ? 0 : gb)) : ""))));
        p.sendMessage(Lang.str(p, "game.engine.money.emerald", (em + (emBoost != 0.0 ? Lang.str(p, "game.engine.money.booster", "" + (eb < 0 ? 0 : eb)) : ""))));
        if (GameEngine.getInstance().getServerMode() == ServerMode.RANKED) {
            int difElo = p.getElo(GameEngine.getEloKey()) - p.getStorage().getInteger(GameEngine.ELOKEY, 1500);
            p.sendMessage(" ");
            p.sendMessage(Lang.str(p, "game.engine.money.gameelo", "" + GameEngine.getInstance().getGameElo()));
            p.sendMessage(Lang.str(p, "game.engine.money.elo", p.getElo(GameEngine.getEloKey()) + " " + ChatColor.GOLD + ((difElo < 0) ? difElo : "+" + difElo)));
        }
        p.sendMessage(Lang.str(p, "game.engine.money.footer"));
    }

    /**
     * print gain for a given player, showing the given stats
     * @param p {@link UniPlayer}
     * @param stats {@link List} of {@link UniPlayer}
     */
    private static void printGain(UniPlayer p, List<PlayerStatType> stats) {
        printGain(p, stats, true);
    }

    /**
     * print gain for a given player, showing all stats
     * @param p {@link UniPlayer}
     */
    public static void printGain(UniPlayer p) {
        printGain(p, playerStatList(p), false);
    }

    /**
     * print gain to all players
     * @param stats array of each {@link PlayerStatType} to show or empty to show all stats
     */
    public static void printGain(PlayerStatType... stats) {
        GameEngine.getInstance().getOnlinePlayers()
                .forEach(p -> EndMoneyManager.printGain(p, (stats.length == 0) ? playerStatList(p) : Arrays.asList(stats)));
    }

    private static List<PlayerStatType> playerStatList(Player p) {
		return StatManager.getInstance().getPlayerStat(p).getStatType().stream()
				.filter(pst -> pst.getMoney(MoneyType.GOLD) > 0 || pst.getMoney(MoneyType.EMERALDS) > 0)
				.collect(Collectors.toCollection(ArrayList::new));
    }
}
