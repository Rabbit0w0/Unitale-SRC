package fr.unitale.sdk.gameengine.map.skydef;

import java.io.IOException;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.teleporter.Teleporter;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import fr.unitale.sdk.utils.color.UniColor;
import net.minecraft.server.v1_10_R1.NBTCompressedStreamTools;
import net.minecraft.server.v1_10_R1.NBTTagCompound;

public class SkydefMap extends GameMap {

    protected final Location castle;
    protected final Teleporter castleTp;
    protected final Teleporter worldTp;
    protected final Location banner;
    protected final Location center;
    protected final Location schemSpawn;
    protected int teamCount;
    protected UniTeam defender;
    protected int defTeamSize;

    public SkydefMap(MapType type, String name, World world,
                     Location castle, Location inWorld,
                     Location inCastle, Location outWorld,
                     Location banner, int teamCount, Location schemSpawn) {
        super(type, name, world);

        this.castle = castle;
        this.castleTp = new SkydefTp("TP_TO_CASTLE", inWorld.clone().add(0.5, 0, 0.5), castle.clone().add(0.5, 0, 0.5), this);
        this.worldTp = new SkydefTp("TP_TO_WORLD", inCastle.clone().add(0.5, 0, 0.5), outWorld.clone().add(0.5, 0, 0.5), this);
        this.banner = banner;
        this.center = world.getHighestBlockAt(0, 0).getLocation().clone();
        this.teamCount = teamCount;
        this.team = true;
        this.defender = null;
        this.schemSpawn = schemSpawn;
        this.defTeamSize = GameEngine.getInstance().getConfig("defteamsize", 8);
    }

    public Location getCastle() {
        return castle.clone();
    }

    public Teleporter getCastleTp() {
        return castleTp;
    }

    public Teleporter getWorldTp() {
        return worldTp;
    }

    public Location getBanner() {
        return banner.clone();
    }

    public Location getCenter() {
        return center.clone();
    }

    @Override
    public void createTeam(TeamModule<?> tm) {
        if (teamCount > 16) teamCount = 16;

        UniColor c;
        for (int i = 0; i < teamCount; i++) {
            c = UniColor.getFromWoolByte((byte) i);
            if (i == 0) {
                defender = tm.addTeam(c, c.getChatColor() + "Defenseur");
                defender.setSize(this.defTeamSize);
            } else {
                tm.addTeam(c, c.getChatColor() + "Attaquant");
            }
        }
    }

    public UniTeam getDefender() {
        return defender;
    }

    public void setTeamCount(int count) {
        this.teamCount = count;
    }

    public void buildCastle(Class<?> clazz) {
        NBTTagCompound nbt;
        try {
            nbt = NBTCompressedStreamTools.a(clazz.getResourceAsStream(this.getType().getName() + ".schematic"));
            Schematic schematic = SchematicAPI.loadSchematic(nbt);
            SchematicAPI.pasteSchematic(this.schemSpawn, schematic, false);
        } catch (IOException e) {
            e.printStackTrace();
            GameEngine.getInstance().emergencyShutdown("Cant paste Castle");
        }

        this.banner.getBlock().setType(Material.STANDING_BANNER);

        buildteleporter(clazz);
    }

    public void buildteleporter(Class<?> clazz) {
        NBTTagCompound nbt;
        try {
            nbt = NBTCompressedStreamTools.a(clazz.getResourceAsStream("teleporter.schematic"));
            Schematic schematic = SchematicAPI.loadSchematic(nbt);
            SchematicAPI.pasteSchematic(this.castleTp.getIn().clone().add(-3, -2, -3), schematic, false);
        } catch (IOException e) {
            e.printStackTrace();
            //GameEngine.getInstance().emergencyShutdown("Cant paste Teleporter");
        }
    }
}
