package fr.unitale.sdk.gameengine.events.game;

import fr.unitale.api.type.ServerTypes.GameStatus;

public class GameEndEvent extends GameStateEvent {

    public GameEndEvent() {
        super(GameStatus.END);
    }
}
