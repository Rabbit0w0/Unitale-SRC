package fr.unitale.sdk;

import fr.unitale.api.QueueApi;
import fr.unitale.sdk.gameengine.GameEngine;
import org.bukkit.plugin.java.JavaPlugin;

public class GameSDK extends JavaPlugin {
    private static GameSDK instance;

    @Override
    public void onLoad() {
        instance = this;
        super.onLoad();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        QueueApi.getInstance().endRequest(GameEngine.getInstance().getGameUuid());
    }

    /**
     * @return {@link JavaPlugin} corresponding of this SDK
     */
    public static JavaPlugin asJavaPlugin() {
        return instance;
    }
}
