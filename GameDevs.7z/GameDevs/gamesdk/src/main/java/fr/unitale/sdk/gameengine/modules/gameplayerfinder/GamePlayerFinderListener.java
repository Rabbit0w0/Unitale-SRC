package fr.unitale.sdk.gameengine.modules.gameplayerfinder;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateOfflinePlayer;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateTeamEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.gameplayerfinder.event.PlayerRebornEvent;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;
import fr.unitale.sdk.players.event.UnitalePlayerQuitEvent;

public class GamePlayerFinderListener extends ModuleListener<GamePlayerFinderModule> {

    public GamePlayerFinderListener(GamePlayerFinderModule module) {
        super(module);
    }

    @EventHandler
    public void onEliminateOfflinePlayer(EliminateOfflinePlayer e) {
        this.module.lookingFor(e.getUUID());
    }

    @EventHandler
    public void quit(UnitalePlayerQuitEvent e) {
        this.module.save(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void join(UnitalePlayerJoinEvent e) {
        if (GameEngine.getInstance().getOfflinePlayers().contains(e.getPlayer().getUniqueId())) return;
        PlayerSave save = this.module.rebornPlayer(e.getPlayer());
        if (save != null) {
            Bukkit.getPluginManager().callEvent(new PlayerRebornEvent(e.getPlayer(), save));
            GameEngine.getInstance().addOfflinePlayer(e.getPlayer().getUniqueId());
        }
    }

    @EventHandler
    public void onEliminateTeam(EliminateTeamEvent e) {
        this.module.removeTeam(e.getTeam());
    }
}
