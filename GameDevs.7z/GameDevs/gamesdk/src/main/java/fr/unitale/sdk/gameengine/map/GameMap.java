package fr.unitale.sdk.gameengine.map;

import org.bukkit.World;

import fr.unitale.sdk.gameengine.modules.team.TeamModule;

/**
 * A game map abstract class
 */
public abstract class GameMap {
    protected String name;
    protected World world;
    protected boolean team;
    private final MapType type;

    public GameMap(MapType type, String name, World world) {
        this.name = name;
        this.world = world;
        this.team = false;
        this.type = type;
    }

    /**
     * @return map's name
     */
    public String getName() {
        return this.name;
    }

    /**
     * @return {@link World} instance
     */
    public World getWorld() {
        return this.world;
    }

    public boolean isTeam() {
        return this.team;
    }

    public void createTeam(TeamModule<?> tm) {
    }

    public MapType getType() {
        return type;
    }
}
