package fr.unitale.sdk.gameengine.events.players;

import fr.unitale.sdk.gameengine.events.game.GameEvent;
import fr.unitale.sdk.players.UniPlayer;

public class GamePlayerEvent extends GameEvent {

    private final UniPlayer player;

    public GamePlayerEvent(UniPlayer player) {
        this.player = player;
    }

    public UniPlayer getPlayer() {
        return player;
    }
}
