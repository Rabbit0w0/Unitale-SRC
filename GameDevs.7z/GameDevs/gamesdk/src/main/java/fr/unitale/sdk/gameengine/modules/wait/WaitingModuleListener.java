package fr.unitale.sdk.gameengine.modules.wait;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.events.PreStartWaitEvent;
import fr.unitale.sdk.gameengine.modules.wait.room.AWaitingRoom;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UnitalePlayerQuitEvent;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

import java.util.List;

public class WaitingModuleListener extends ModuleListener<WaitingModule> {

    public WaitingModuleListener(WaitingModule module) {
        super(module);
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        final AWaitingRoom room = this.module.getRoom();
        if (room != null && room.haveToMove(e.getPlayer(), e.getFrom(), e.getTo())) {
            room.result(e.getPlayer());
        }
    }

    @EventHandler
    public void onPlayerInventoryClick(InventoryClickEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void interact(PlayerInteractEvent ev) {
        final UniItemStack item = UniItemStack.fromItemStack(ev.getPlayer().getInventory().getItemInMainHand());
        if (item == null || ev.getAction().equals(Action.PHYSICAL)) {
            return;
        }

        if (item.getType() == Material.NETHER_STAR) {
            module.getTeamWindow(ev.getPlayer()).open(ev.getPlayer());
        } else if (item.getType() == Material.COMMAND_REPEATING && !item.isGlowing()) {
            Bukkit.getServer().dispatchCommand(ev.getPlayer(), "votestart");
            item.setGlowing(true);
            ev.getPlayer().getInventory().setItem(0, item);
        } else if (ev.getPlayer().getInventory().getItemInMainHand().getType() == Material.BED) {
            ((UniPlayer) ev.getPlayer()).sendToHub();
        }
        ev.setCancelled(true);
    }

    @SuppressWarnings("unchecked")
    @EventHandler(priority = EventPriority.LOWEST)
    public void join(GamePlayerJoinEvent ev) {
        final UniPlayer p = ev.getPlayer();
        if (GameEngine.getInstance().getOnlinePlayers().size() > this.module.maxPlayers) {
            p.sendMessage(Lang.str(p, "game.wait.serverfull"));
            p.sendToHub();
            return;
        }

        module.setAllBoard();
        p.getInventory().clear();
        p.setGameMode(GameMode.ADVENTURE);
        if (module.mode == Mode.TEAM) {
            final UniItemStack star = new UniItemStack(Material.NETHER_STAR, Lang.str(p, "game.team.choose"));
            p.getInventory().setItem(4, star);
        }

        if (module.allowVoteStartByPlayers.get()) {
            UniItemStack vote = new UniItemStack(Material.COMMAND_REPEATING, Lang.str(p, "game.wait.item.votestart"));
            p.getInventory().setItem(0, vote);
        }

        UniItemStack leave = new UniItemStack(Material.BED, Lang.str(p, "game.wait.item.leave"));
        p.getInventory().setItem(8, leave);

        if (GameEngine.getInstance().getOnlinePlayers().size() == module.maxPlayers) {
            if (module.timer == null) {
                module.timer = (WaitTimer) TimeManager.getInstance().addTimer(new WaitTimer(module, "Waiting", module.waitMinutes, module.waitSeconds));
            }

            PreStartWaitEvent pswe = new PreStartWaitEvent(module.timer.getMinutes(), module.timer.getSeconds());
            Bukkit.getPluginManager().callEvent(pswe);
            module.timer.setTime(pswe.getMinutes(), pswe.getSecondes());
        } else if (GameEngine.getInstance().getOnlinePlayers().size() >= module.minPlayers && module.timer == null) {
            module.timer = (WaitTimer) TimeManager.getInstance().addTimer(new WaitTimer(module, "Waiting", module.waitMinutes, module.waitSeconds));
        }

        this.module.resetWaitTick();
        this.module.setQueue();
    }

    @SuppressWarnings("unchecked")
    @EventHandler
    public void quit(UnitalePlayerQuitEvent ev) {
        final UniPlayer p = ev.getPlayer();
        p.getInventory().clear();
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        if (module.voteCommand.getVotes().contains(p)) {
            module.voteCommand.getVotes().remove(p);
        }
        if (UniTeam.getTeam(p) != null) {
            UniTeam.getTeam(p).removePlayer(p);
            module.updateTeamWindow();
        }

        if (GameEngine.getInstance().getServerMode().equals(ServerMode.GUILD)) {
            final TeamModule<UniTeam> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
            final UniTeam team = tm.getTeam(p.getGuild().getName());
            if (team != null) {
                team.removePlayer(p);
                if (team.size() == 0) {
                    tm.removeTeam(team);
                }
            }
        }
        GameEngine.getInstance().playerQuit(ev.getPlayer());

        this.module.setQueue();
    }

    @EventHandler
    public void damage(EntityDamageEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void blockBreak(BlockBreakEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void blockPlace(BlockPlaceEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void food(FoodLevelChangeEvent ev) {
        ev.setFoodLevel(20);
    }

    @EventHandler
    public void explode(EntityExplodeEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void pickup(PlayerPickupItemEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void drop(PlayerDropItemEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void target(EntityTargetEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void regen(EntityRegainHealthEvent ev) {
        if (ev.getEntity() instanceof Player) {
            final Player p = (Player) ev.getEntity();
            p.setHealth(p.getMaxHealth());
        }
    }

    public UniTeam getTeamFromID(List<UniTeam> teams, int id) {
        return teams.stream()
                .filter(team -> team.getColor().getWoolByte() == id)
                .findFirst()
                .orElse(null);
    }
}
