package fr.unitale.sdk.gameengine.map.lasergame;

import fr.unitale.api.type.ServerTypes;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.sdk.GameSDK;
import fr.unitale.sdk.gameengine.map.MapType;

public class LasergameTron extends LasergameMap implements Listener {

    public LasergameTron(String name, World world) {
        super(MapType.LASERGAME_TRON, name, world, new Location[]{
                new Location(world, -49, 54, -21, -90, 0),
                new Location(world, -22, 54, -49, -90, 0),
                new Location(world, 28, 54, -49, 0, 0),
                new Location(world, 49, 54, -18, 90, 0),
                new Location(world, -49, 54, 18, -90, 0),
                new Location(world, 49, 54, 21, 90, 0),
                new Location(world, -28, 54, 49, 180, 0),
                new Location(world, 22, 54, 49, 90, 0),
                new Location(world, 0, 54, 8, 0, 0),
                new Location(world, 0, 54, -7, 180, 0),
                new Location(world, -49, 60, 48, -90, 0),
                new Location(world, 49, 60, -47, 90, 0),
                new Location(world, 37, 54, 11, 180, 0),
                new Location(world, -36, 54, -10, 0, 0),
                new Location(world, 40, 54, 49, 180, 0),
                new Location(world, -39, 54, -48, 0, 0)
        });

        Bukkit.getPluginManager().registerEvents(this, GameSDK.asJavaPlugin());
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (event.getTo().getWorld().equals(getWorld())) {
            event.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 1, true, false));
        }
    }

    @Override
    public int getMinPlayers(ServerTypes.Mode mode) {
        return 12;
    }
}
