package fr.unitale.sdk.gameengine.map.fk.utils;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import fr.unitale.sdk.UnitaleSDK;

public class Locker implements Listener {
    private static final int FAIL_TIME = 100;

    private Map<Block, TeamUnlocker<?>> lock;

    public Locker() {
        lock = new LinkedHashMap<>();
        Bukkit.getPluginManager().registerEvents(this, UnitaleSDK.getInstance());
    }

    private long getTimeStamp() {
        return Calendar.getInstance().getTimeInMillis();
    }

    public void addLock(TeamUnlocker<?> u) {
        this.lock.put(u.getBlock(), u);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.LEFT_CLICK_BLOCK) return;
        TeamUnlocker<?> lock = this.lock.get(e.getClickedBlock());
        if (lock == null) return;
        long time = getTimeStamp();
        long last = lock.getLastTick();
        if (last != 0 && time - last > FAIL_TIME) {
            lock.fail();
		}
    }
}
