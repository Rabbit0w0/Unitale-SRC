package fr.unitale.sdk.gameengine.events.eliminate;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.players.UniPlayer;

public class EliminatePlayerEvent extends EliminateEvent {
    private final UniPlayer player;
    private final int competingPlayers;

    public EliminatePlayerEvent(UniPlayer player) {
        this.player = player;
        this.competingPlayers = GameEngine.getInstance().getCompetingPlayersCount();
    }

    public UniPlayer getPlayer() {
        return this.player;
    }

    public int getCompetingPlayers() {
        return this.competingPlayers;
    }
}
