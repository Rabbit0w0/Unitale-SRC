package fr.unitale.sdk.gameengine.map.uhc;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.bukkit.Difficulty;
import org.bukkit.Location;

import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.world.WorldData;
import net.minecraft.server.v1_10_R1.Biomes;

/**
 * An UHC game map
 */
public class UHCMap extends GameMap {
    private int teamCount; //number of team to create
    private WorldData worldData;
    private Schematic centerSchematic; //schematic to load
    private int centerX, centerZ; //map center coord

    private static final int MAX_TEAM_AMOUNT = 16, CHUNK_BLOCK_SIZE = 16, SPAWN_HEIGHT = 200;

    public UHCMap(int teamCount, Schematic centerSchematic, int centerX, int centerZ) {
        super(MapType.UHC, "UHC", null);
        this.team = true;
        this.teamCount = teamCount;
        this.centerSchematic = centerSchematic;
        worldData = new WorldData(name);

        //remove oceans and similar biomes
        try {
            setFinalStatic(Biomes.class.getDeclaredField("a"), Biomes.c); //oceans becomes plains
            setFinalStatic(Biomes.class.getDeclaredField("b"), Biomes.c); //oceans becomes plains too
            setFinalStatic(Biomes.class.getDeclaredField("p"), Biomes.K); //mushroom island becomes savanna
            setFinalStatic(Biomes.class.getDeclaredField("q"), Biomes.K); //mushroom island shore becomes savanna
            setFinalStatic(Biomes.class.getDeclaredField("z"), Biomes.c); //deep ocean becomes plains
            setFinalStatic(Biomes.class.getDeclaredField("M"), Biomes.h); //mesa becomes swamp
            setFinalStatic(Biomes.class.getDeclaredField("N"), Biomes.h); //mesa rock becomes swamp
            setFinalStatic(Biomes.class.getDeclaredField("O"), Biomes.h); //mesa clear rocks becomes swamp
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Build map
     *
     * @param borderSize int border size
     * @param run        boolean should we cancel daylightcycle
     * @param delete     boolean should we try to delete the existing map before building
     * @param pregen     boolean should we pregen the map
     */
    public void buildMap(int borderSize, boolean run, boolean delete, boolean pregen) {
        if (delete) worldData.deleteWorld();
        worldData.generateWorld((-borderSize) / CHUNK_BLOCK_SIZE, (-borderSize) / CHUNK_BLOCK_SIZE, borderSize / CHUNK_BLOCK_SIZE, borderSize / CHUNK_BLOCK_SIZE, pregen);
        worldData.setBorderCenter(0, 0);
        worldData.setBorderSize(borderSize << 1);
        worldData.setBorderWarningDistance(10);
        worldData.setBorderWarningTime(10);
        worldData.setBorderDamageAmount(1);
        worldData.setBorderDamageBuffer(2);
        if (run) {
            worldData.getWorld().setTime(1200);
            worldData.getWorld().setGameRuleValue("doDaylightCycle", "false");
        }
        worldData.getWorld().setDifficulty(Difficulty.HARD);

        world = worldData.getWorld();
        SchematicAPI.pasteSchematic(
                new Location(world,
                        centerX - (centerSchematic.getWidth() >> 1),
                        SPAWN_HEIGHT - (centerSchematic.getHeight() >> 1),
                        centerZ - (centerSchematic.getLength() >> 1)),
                centerSchematic,
                true);
    }

    public Schematic getCenterSchematic() {
        return centerSchematic;
    }

    public int getTeamCount() {
        return teamCount;
    }

    public WorldData getWorldData() {
        return worldData;
    }

    public int getCenterX() {
        return centerX;
    }

    public int getCenterY() {
        return SPAWN_HEIGHT;
    }

    public int getCenterZ() {
        return centerZ;
    }

    private static void setFinalStatic(Field field, Object newValue) throws Exception {
        field.setAccessible(true);
        // remove final modifier from field
        final Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        field.set(null, newValue);
    }

    @Override
    public void createTeam(TeamModule<?> tm) {
        if (teamCount > MAX_TEAM_AMOUNT) teamCount = MAX_TEAM_AMOUNT;
        tm.setSizeRestrict(true);
        UniColor c;
        for (int i = 0; i < teamCount; i++) {
            c = UniColor.getFromWoolByte((byte) i);
            tm.addTeam(c, c.getChatColor().name());
        }
    }
}
