package fr.unitale.sdk.gameengine.map.lasergame;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.Random;

public class LasergameMap extends GameMap {
    private final Random rand = new Random();
    private final Location[] spawns;

    public LasergameMap(MapType type, String name, World w, Location[] spawns) {
        super(type, name, w);
        this.spawns = spawns;
    }

    public void randomSpawn(Player p) {
        if (spawns.length > 0) {
            p.teleport(spawns[rand.nextInt(spawns.length)]);
        }
    }

    public void randomSpawnProtected(Player p) {
        if (spawns.length == 0) {
            return;
        }

        final GameEngine<?> instance = GameEngine.getInstance();

        Location best = null;
        double bestDist = 0;
        int minPlayers = Integer.MAX_VALUE;

        for (final Location loc : spawns) {
            double distance = 0d;
            int players = 0;
            for (final Player pl : instance.getCompetingPlayers()) {
                if (pl.getLocation().getWorld().equals(loc.getWorld())
                        && pl.getGameMode() != GameMode.SPECTATOR) {
                    double dist = pl.getLocation().distance(loc);
                    distance += dist;
                    if (dist <= 20D) {
                        players++;
                    }
                }
            }

            if (players < minPlayers || (players == minPlayers && distance > bestDist)) {
                best = loc;
                bestDist = distance;
                minPlayers = players;
            }
        }

        if (best == null) {
            best = spawns[0];
        }
        p.teleport(best);
    }

    /**
     * The player amount is based on the numbers of spawns in this map
     * @return players amount for this map
     */
    public int getMaxPlayers(){
        return spawns.length;
    }

    public int getMinPlayers(ServerTypes.Mode mode){
        return 2;
    }
}
