package fr.unitale.sdk.gameengine.modules.effects;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.sdk.GameSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.game.GameStartEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;

public class EffectsModuleListener extends ModuleListener<EffectsModule> {

    public EffectsModuleListener(EffectsModule module) {
        super(module);
    }

    @EventHandler
    public void onPlayerJoin(UnitalePlayerJoinEvent event) {
        final Player p = event.getPlayer();
        for (final PotionEffect effect : p.getActivePotionEffects()) {
            p.removePotionEffect(effect.getType());
        }
        getModule().setEffects(p);
    }

    @EventHandler
    public void onGameStart(GameStartEvent event) {
        final EffectsModule module = getModule();
        for (final Player p : GameEngine.getInstance().getOnlinePlayers()) {
            module.setEffects(p);
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        new BukkitRunnable() {

            @Override
            public void run() {
                getModule().setEffects(event.getPlayer());
            }

        }.runTaskLater(GameSDK.asJavaPlugin(), 3L);
    }
}
