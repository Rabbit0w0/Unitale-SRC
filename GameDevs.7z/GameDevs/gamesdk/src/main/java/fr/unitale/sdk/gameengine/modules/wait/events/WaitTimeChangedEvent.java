package fr.unitale.sdk.gameengine.modules.wait.events;

import fr.unitale.sdk.gameengine.modules.wait.WaitTimer;

public class WaitTimeChangedEvent extends WaitEvent {
    private final WaitTimer timer;

    public WaitTimeChangedEvent(WaitTimer timer) {
        super();
        this.timer = timer;
    }

    public WaitTimer getTimer() {
        return timer;
    }
}
