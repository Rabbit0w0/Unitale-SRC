package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;

public class Nordique extends FKMap {

    public Nordique(String name, World world) {
        super(MapType.NORDIQUE, name, new Location(FKMap.world, 106, 178, -140));

        this.addTeam(-6, 94, 59, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(182, 95, -232, UniColor.RED, "Rouge");
        this.addTeam(358, 98, 118, UniColor.GREEN, "Vert");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);
    }
}
