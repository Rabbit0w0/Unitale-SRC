package fr.unitale.sdk.gameengine.modules.kit;

import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.utils.items.UniItemStack;

public class KitChoiceListener extends ModuleListener<KitChoiceModule> {

    public KitChoiceListener(KitChoiceModule module) {
        super(module);
    }

    @EventHandler
    public void onPlayerJoin(GamePlayerJoinEvent e) {
        getModule().onKitUpdate(e.getPlayer());
        getModule().addItem(e.getPlayer());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.PHYSICAL && e.getItem() != null) {
            UniItemStack eis = UniItemStack.fromItemStack(e.getItem());
            if (eis.hasKey(KitChoiceModule.KEY)) {
                new KitChoiceWindow(e.getPlayer()).open(e.getPlayer());
            }
        }
    }
}
