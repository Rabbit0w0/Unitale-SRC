package fr.unitale.sdk.gameengine.modules.team.event;

import fr.unitale.sdk.gameengine.events.game.GameEvent;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;

public class TeamEvent extends GameEvent {

	private final UniTeam team;

	public TeamEvent(UniTeam team) {
		this.team = team;
	}

	public UniTeam getTeam() {
		return this.team;
	}
}
