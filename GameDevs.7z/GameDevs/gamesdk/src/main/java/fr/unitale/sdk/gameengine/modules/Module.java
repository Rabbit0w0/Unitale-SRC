package fr.unitale.sdk.gameengine.modules;

import org.bukkit.event.HandlerList;
import org.json.simple.JSONObject;

import fr.unitale.sdk.gameengine.GameEngine;

/**
 * an abstract Module
 *
 * @param <T> corresponding {@link ModuleListener} type
 */
public abstract class Module<T extends ModuleListener<?>> {
    protected T moduleListener;
    private boolean loaded;

    public Module() {
        this.loaded = false;
    }

    public void privateStartModule() {
        this.loaded = true;
        if (this.moduleListener != null) {
            GameEngine.getInstance().getPlugin().getServer().getPluginManager().registerEvents(this.moduleListener, GameEngine.getInstance().getPlugin());
        }
        startModule();
    }

    public void privateEndModule() {
        this.loaded = false;
        HandlerList.unregisterAll(moduleListener);
        endModule();
    }

    public boolean isLoaded() {
        return (this.loaded);
    }

    public JSONObject getConfig() {
        return GameEngine.getInstance().getConfig("module." + getClass().getSimpleName(), new JSONObject());
    }

    public <U> U getConfig(String node, U def) {
        String string = "module." + getClass().getSimpleName() +
                "." +
                node;
        return GameEngine.getInstance().getConfig(string, def);
    }

    public T getListener() {
        return this.moduleListener;
    }

    public abstract void startModule();

    public abstract void endModule();
}
