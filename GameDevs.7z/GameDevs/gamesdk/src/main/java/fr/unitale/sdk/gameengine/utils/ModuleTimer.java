package fr.unitale.sdk.gameengine.utils;

import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.sdk.GameSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.ITimeModule;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;

//TODO still used ?
public class ModuleTimer<T extends ITimeModule> extends UniTimer {

    protected T module;

    public ModuleTimer(T module, String name, int m, int s) {
        super(name, m, s);
        this.module = module;
    }

    @Override
    protected void endTimeTimer() {
        new BukkitRunnable() {

            @Override
            public void run() {
                endModuleTimer();
            }
        }.runTaskLater(GameSDK.asJavaPlugin(), 1L);
    }

    protected void endModuleTimer() {
        TimeManager.getInstance().removeTimer(getName());
        GameEngine.getInstance().getModuleManager().removeModule(module.getClass());
    }

    @Override
    protected void userUpdate() {
        this.module.update();
    }

}
