package fr.unitale.sdk.gameengine.modules.lock;

import fr.unitale.sdk.gameengine.modules.ModuleListener;

public class LockListener extends ModuleListener<LockModule> {

    public LockListener(LockModule module) {
        super(module);
    }
}
