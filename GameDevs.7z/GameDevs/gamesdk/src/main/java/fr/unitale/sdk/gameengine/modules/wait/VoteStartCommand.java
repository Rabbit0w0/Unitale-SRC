package fr.unitale.sdk.gameengine.modules.wait;

import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.TimeManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.util.LinkedList;
import java.util.List;

public class VoteStartCommand extends AbstractCommand {
    private final List<UniPlayer> votes;
    private final WaitingModule module;

    public VoteStartCommand(WaitingModule module) {
        super("votestart");
        this.module = module;
        this.votes = new LinkedList<>();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!module.allowVoteStartByPlayers.get())return true;
        if (sender instanceof UniPlayer) {
            final UniPlayer ep = (UniPlayer) sender;
            if (!votes.contains(ep)) {
                if (!module.forced) {
                    votes.add(ep);
                    ep.sendMessage(Lang.str(ep, "game.wait.vote.voted"));
                    checkVotes();
                } else {
                    ep.sendMessage(Lang.str(ep, "game.wait.vote.done"));
                }
            } else {
                ep.sendMessage(Lang.str(ep, "game.wait.vote.alreadyvoted"));
            }
        } else {
            sender.sendMessage("Not an player.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }

    private void checkVotes() {
        if (votes.size() >= GameEngine.getInstance().getOnlinePlayers().size() / 2 && votes.size() > 1
                && module.timer == null) {
            Lang.bcst("game.wait.vote.start");
            module.forced = true;
            module.timer = (WaitTimer) TimeManager.getInstance()
                    .addTimer(new WaitTimer(module, "Waiting", module.waitMinutes, module.waitSeconds));
        }
    }

    public List<UniPlayer> getVotes() {
        return votes;
    }
}
