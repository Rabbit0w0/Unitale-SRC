package fr.unitale.sdk.gameengine.modules.lock;

import java.util.Calendar;
import java.util.Locale;

public abstract class ALock {
    private static final int TIME_DISTANCE = 500;

    private long lastClick;
    private long start;
    private final long timeToUnlock;

    public ALock(long timeToUnlock) {
        this.lastClick = 0;
        this.start = 0;
        this.timeToUnlock = timeToUnlock;
    }

    private long getCurrentTime() {
        return Calendar.getInstance(Locale.FRANCE).getTimeInMillis();
    }

    public void tryUnlock() {
        long t = getCurrentTime();
        if (start == 0) {
            this.start = t;
            this.lastClick = t;
            start();
            return;
        }
        if (t - this.lastClick > TIME_DISTANCE) {
            this.start = 0;
            this.lastClick = 0;
            end();
            fail();
        } else if (t - this.start > this.timeToUnlock) {
            this.start = 0;
            this.lastClick = 0;
            end();
            success();
        } else {
            this.lastClick = t;
            unlockTick();
        }
    }

    public long getTimeValue() {
        return this.lastClick - this.start;
    }

    protected abstract void unlockTick();

    protected abstract void fail();

    protected abstract void success();

    protected abstract void start();

    protected abstract void end();
}
