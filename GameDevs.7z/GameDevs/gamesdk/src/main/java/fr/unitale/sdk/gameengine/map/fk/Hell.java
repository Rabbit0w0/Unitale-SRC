package fr.unitale.sdk.gameengine.map.fk;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;

public class Hell extends FKMap {

    public Hell(String name, World world) {
        super(MapType.HELL, name, new Location(FKMap.world, 34, 71, 63));

        this.addTeam(336, 67, 6, UniColor.LIGHT_BLUE, "Bleu");
        this.addTeam(-332, 68, 72, UniColor.RED, "Rouge");
//		this.addTeam(-198,69,316, UniColor.GREEN, "Vert");

        this.getNoBreakable().add(Material.DIAMOND_BLOCK);
        this.getNoBreakable().add(Material.GOLD_BLOCK);
        this.getNoBreakable().add(Material.IRON_BLOCK);
        this.getNoBreakable().add(Material.REDSTONE_BLOCK);
        this.getNoBreakable().add(Material.LAPIS_BLOCK);
        this.getNoBreakable().add(Material.EMERALD_BLOCK);

        this.getNoPlace().add(Material.DIAMOND_BLOCK);
        this.getNoPlace().add(Material.GOLD_BLOCK);
        this.getNoPlace().add(Material.IRON_BLOCK);
        this.getNoPlace().add(Material.REDSTONE_BLOCK);
        this.getNoPlace().add(Material.LAPIS_BLOCK);
        this.getNoPlace().add(Material.EMERALD_BLOCK);
    }
}
