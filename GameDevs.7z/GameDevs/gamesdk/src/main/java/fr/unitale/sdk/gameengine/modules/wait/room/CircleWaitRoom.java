package fr.unitale.sdk.gameengine.modules.wait.room;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public class CircleWaitRoom extends AWaitingRoom {
    private final Location spawn;
    private final double distance;

    public CircleWaitRoom(Location spawn, double distance) {
        this.spawn = spawn;
        this.distance = distance;
    }

    @Override
    public boolean haveToMove(Player p, Location from, Location to) {
        return spawn.getWorld() != to.getWorld() || to.distance(spawn) > this.distance;
    }

    public void result(Player p) {
        p.teleport(this.spawn);
    }

}
