package fr.unitale.sdk.gameengine.map.lasergame.event;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UniPlayerEvent;

public class UnitalePlayerRespawnDemandEvent extends UniPlayerEvent {

    public UnitalePlayerRespawnDemandEvent(UniPlayer player) {
        super(player);
    }
}
