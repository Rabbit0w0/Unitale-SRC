package fr.unitale.sdk.gameengine.map;

import fr.unitale.sdk.gameengine.map.firestorm.*;
import fr.unitale.sdk.gameengine.map.fk.*;
import fr.unitale.sdk.gameengine.map.infected.InfectedDome;
import fr.unitale.sdk.gameengine.map.infected.InfectedHub;
import fr.unitale.sdk.gameengine.map.infected.InfectedLabo;
import fr.unitale.sdk.gameengine.map.infected.InfectedUsine;
import fr.unitale.sdk.gameengine.map.lasergame.LasergameEnergium;
import fr.unitale.sdk.gameengine.map.lasergame.LasergameHub;
import fr.unitale.sdk.gameengine.map.lasergame.LasergameTron;
import fr.unitale.sdk.gameengine.map.skydef.SkydefIce;
import fr.unitale.sdk.gameengine.map.skydef.SkydefMushroom;
import fr.unitale.sdk.gameengine.map.skydef.SkydefSand;
import fr.unitale.sdk.gameengine.map.skydef.SkydefTestMap;
import fr.unitale.sdk.gameengine.map.uhc.UHCMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.WorldCreator;

import java.lang.reflect.Constructor;
import java.util.Arrays;

public enum MapType {

    //TODO maybe try to put this out of the game engine and inside all games plugins ?

    ICEVSFIRE("icevsfire", IceVSFire.class, ChatColor.GOLD + "Ice VS Fire"),
    //	CANDY("candy", Candy.class, ChatColor.GOLD+"Candy Kingdom"),
    FLOWEROFLAKES("flowersoflakes", FlowerOfLakes.class, ChatColor.GOLD + "Flower Of Lakes"),
    EASTERKINGDOMS("easterkingdoms", EasterKingdoms.class, ChatColor.GOLD + "Easter Kingdoms"),
    POISONPARADISE("poisonparadise", PoisonParadise.class, ChatColor.GOLD + "Poison Paradise"),
    FLOWERS("flowers", Flowers.class, ChatColor.GOLD + "Flowers"),
    HELL("hell", Hell.class, ChatColor.GOLD + "Hell"),
    CHRISTMAS("christmas", Christmas.class, ChatColor.GOLD + "Christmas"),

    ANGEVSDEMON("angevsdemon", AngevsDemon.class, ChatColor.GOLD + "Ange vs Demon"),
    AANDOVALE1VS1("aandovale1vs1", Aandovale1vs1.class, ChatColor.GOLD + "Aandovale Grove"),
    AANDOVALE1VS1VS1("aandovale1vs1vs1", Aandovale1vs1vs1.class, ChatColor.GOLD + "Aandovale Grove"),
    CANDY_1VS1VS1("candy_1vs1vs1", Candy1vs1vs1.class, ChatColor.GOLD + "Candy Kingdom"),
    CANDY_1VS1("candy_1vs1", Candy1vs1.class, ChatColor.GOLD + "Candy Kingdom"),
    ASIANKINGDOM_1VS1("asiankingdom_1vs1", AsianKingdom_1vs1.class, ChatColor.GOLD + "Asian Kingdom"),
    ASIANKINGDOM_1VS1VS1VS1("asiankingdom_1vs1vs1vs1", AsianKingdom_1vs1vs1vs1.class, ChatColor.GOLD + "Asian Kingdom"),
    NORDIQUE("nordique", Nordique.class, ChatColor.GOLD + "Nordique"),

    LASERGAME_HUB("hublaser", LasergameHub.class, ChatColor.GOLD + "Lasergame Hub"),
    LASERGAME_TRON("lasergame_tron", LasergameTron.class, ChatColor.GOLD + "The grid"),
    LASERGAME_ENERGIUM("lasergame_energium", LasergameEnergium.class, ChatColor.GOLD + "Energium"),

    UHC("uhc", UHCMap.class, ChatColor.GOLD + "UHC"),

    SKYDEF_MUSHROOM("mushroom", SkydefMushroom.class, ChatColor.GOLD + "Château champi"),
    SKYDEF_SAND("sand", SkydefSand.class, ChatColor.GOLD + "Château de sable"),
    SKYDEF_ICE("ice", SkydefIce.class, ChatColor.GOLD + "Château de glace"),

    SKYDEF_TEST("skydef", SkydefTestMap.class, ChatColor.GOLD + "Château test"),

    FIRESTORM_ENDARE("arena_endare", fr.unitale.sdk.gameengine.map.firestorm.Endare.class, ChatColor.GOLD + "Arêne d'Endare"),
    FIRESTORM_LUIGICASTLE("fire_luigicastle", LuigiCastle.class, ChatColor.GOLD + "Chateau Luigi"),
    FIRESTORM_CARROTHOUSE("fire_carrothouse", CarrotHouse.class, ChatColor.GOLD + "Maison carotte"),
    FIRESTORM_HOUSE("fire_house", House.class, ChatColor.GOLD + "Maison"),
    FIRESTORM_SIPHANO("fire_siphano", Siphano.class, ChatColor.GOLD + "Siphano"),
    FIRESTORM_FRIGIEL("fire_frigiel", Frigiel.class, ChatColor.GOLD + "Frigiel"),

    INFECTED_HUB("infected_hub", InfectedHub.class, ChatColor.GOLD + "Infected Hub"),
    INFECTED_LABO("infected_labo", InfectedLabo.class, ChatColor.GOLD + "Laboratoire"),
    INFECTED_DOME("infected_dome", InfectedDome.class, ChatColor.GOLD + "Dôme"),
    INFECTED_FACTORY("infected_factory", InfectedUsine.class, ChatColor.GOLD + "Usine");
	
	/*SKYDEF_CHAMPI("skydef", SkydefChampiMap.class, ChatColor.GOLD+"Château champi"),
	SKYDEF_ORIENT("skydef", SkydefOrientMap.class, ChatColor.GOLD+"Château oriental"),
	SKYDEF_ICE("skydef", SkydefIceMap.class, ChatColor.GOLD+"Château de glâce");*/

    /**
     * @param s {@link String} map type as a string
     * @return {@link MapType} or null if not found
     */
    public static MapType fromString(String s) {
		return Arrays.stream(MapType.values())
				.filter(m -> m.name().equalsIgnoreCase(s))
				.findFirst()
				.orElse(null);
	}

    /**
     * @param s   {@link String} map type as a string
     * @param def {@link MapType} default value if not found
     * @return {@link MapType} or default value if not found
     */
    public static MapType fromString(String s, MapType def) {
		return Arrays.stream(MapType.values())
				.filter(m -> m.name().equalsIgnoreCase(s))
				.findFirst()
				.orElse(def);
	}

    private String name;
    private Class<? extends GameMap> clazz;
    private GameMap map;
    private String publicName;

    MapType(String name, Class<? extends GameMap> clazz, String publicName) {
        this.name = name;
        this.clazz = clazz;
        this.map = null;
        this.publicName = publicName;
    }

    /**
     * load map
     *
     * @param world {@link World} to link
     */
    private void load(World world) {
        try {
            final Constructor<? extends GameMap> construct = clazz.getConstructor(String.class, World.class);
            map = construct.newInstance(name, world);
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    public GameMap getInstance() {
        if (map == null) {
            create(name);
        }
        return map;
    }

    public GameMap getInstance(World w) {
        if (map == null) {
            create(w);
        }
        return map;
    }

    public void create() {
        create(this.name);
    }

    public void create(String mapName) {
        if (loaded()) {
            return;
        }
        final World w = Bukkit.createWorld(WorldCreator.name(name));
        load(w);
    }

    public void create(World w) {
        if (loaded()) {
            return;
        }
        load(w);
    }

    public boolean loaded() {
        return this.map != null;
    }

    public void unload() {
        if (this.map != null) {
            if (Bukkit.getServer().unloadWorld(map.getWorld(), false)) {
                this.map = null;
            }
        }
    }

    @Override
    public String toString() {
        return publicName;
    }

    public String getName() {
        return this.name;
    }
}
