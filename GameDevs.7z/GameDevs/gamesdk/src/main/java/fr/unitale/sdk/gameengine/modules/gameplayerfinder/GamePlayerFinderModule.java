package fr.unitale.sdk.gameengine.modules.gameplayerfinder;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.bukkit.entity.Player;

import fr.unitale.api.QueueApi;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.chat.UniLogger;

public class GamePlayerFinderModule extends Module<GamePlayerFinderListener> {
    public static final String REBORN_TIME = "REBORN_TIME";

    private final Map<UUID, PlayerSave> playerSaved;
    private final List<PlayerSave> players;

    public GamePlayerFinderModule() {
        this.moduleListener = new GamePlayerFinderListener(this);
        this.playerSaved = new LinkedHashMap<>();
        this.players = new LinkedList<>();
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    public void save(Player p) {
        this.playerSaved.put(p.getUniqueId(), new PlayerSave(p));
    }

    public void removeSave(Player p) {
        this.playerSaved.remove(p.getUniqueId());
    }

    public void lookingFor(UUID uuid) {
        PlayerSave save = this.playerSaved.remove(uuid);

        if (save != null) {
            this.players.add(save);
            setQueue();
        }
    }

    public PlayerSave rebornPlayer(Player p) {
        if (this.players.size() == 0) {
            UniLogger.warning("trying to reborn a player when no saves are available");
            return null;
        }

        PlayerSave save = this.players.remove(0);
        save.load(p);
        ((UniPlayer) p).getStorage().addLong(REBORN_TIME, Calendar.getInstance().getTimeInMillis());
        setQueue();
        return save;
    }

    public Map<UUID, PlayerSave> getPlayerSaved() {
        return playerSaved;
    }

    public List<PlayerSave> getPlayers() {
        return players;
    }

    public void setQueue() {
    	final int maxPlayers = getConfig("maxplayers", 20);
        final int slots = maxPlayers - players.size();

        if (players.size() == 0) {
            QueueApi.getInstance().endRequest(GameEngine.getInstance().getGameUuid());
            return;
        }

        final String mapName = (GameEngine.getInstance().getMap() != null) ? GameEngine.getInstance().getMap().getType().name() : null;
        final boolean vip = GameEngine.getInstance().isVip();
        QueueApi.getInstance().request(GameEngine.getInstance().getGameUuid(), ServerManager.type, mapName, GameEngine.getInstance().getServerMode(), Mode.TEAM, null, slots, maxPlayers, vip);
    }

    private Entry<UUID, PlayerSave> playerToRemove(UniTeam t) {
		return this.playerSaved.entrySet().stream()
				.filter(e -> e.getValue().getTeam() == t)
				.findFirst()
				.orElse(null);
	}

    public void removeTeam(UniTeam t) {
        Entry<UUID, PlayerSave> playerToRemove;
        while ((playerToRemove = playerToRemove(t)) != null) {
            this.players.remove(playerToRemove.getValue());
            this.playerSaved.remove(playerToRemove.getKey());
        }
        setQueue();
    }
}
