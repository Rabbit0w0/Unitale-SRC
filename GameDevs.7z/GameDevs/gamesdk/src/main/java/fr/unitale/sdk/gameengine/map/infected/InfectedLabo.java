package fr.unitale.sdk.gameengine.map.infected;

import fr.unitale.sdk.gameengine.map.MapType;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Arrays;
import java.util.Collections;

public class InfectedLabo extends InfectedMap {

    public InfectedLabo(String name, World world) {
        super(MapType.INFECTED_LABO, name, world,
                Collections.singletonList(
                        new Location(world, 21, 58, -29)),
                Arrays.asList(
                        new Location(world, 33, 68, 19),
                        new Location(world, -13, 58, -56),
                        new Location(world, 61, 58, -41)));
    }

}
