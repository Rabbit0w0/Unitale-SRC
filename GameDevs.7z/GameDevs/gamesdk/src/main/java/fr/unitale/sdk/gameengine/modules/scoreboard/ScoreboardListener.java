package fr.unitale.sdk.gameengine.modules.scoreboard;

import org.bukkit.event.EventHandler;

import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;

public class ScoreboardListener extends ModuleListener<ScoreboardModule> {

    public ScoreboardListener(ScoreboardModule module) {
        super(module);
    }

    @EventHandler
    public void onIcePlayerJoin(UnitalePlayerJoinEvent e) {
        e.getPlayer().setScoreboard(this.module.getBoard());
    }
}
