package fr.unitale.sdk.gameengine.modules.team;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateTeamEvent;
import fr.unitale.sdk.gameengine.modules.team.event.PlayerJoinTeamEvent;
import fr.unitale.sdk.gameengine.modules.team.event.PlayerQuitTeamEvent;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.data.Storage;
import fr.unitale.sdk.utils.fancymessage.FancyMessage;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.scoreboard.Team.Option;
import org.bukkit.scoreboard.Team.OptionStatus;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class UniTeam {
    private static final String STORAGE_TEAM = "STORAGE_TEAM";
    private static Supplier<Boolean> SHOULD_TEAM_JOIN_BE_SHOUTED = () -> true;
    private static Supplier<Boolean> SHOULD_TEAM_LEADER_BE_SHOUTED = () -> true;

    public static void setShouldTeamJoinBeShouted(Supplier<Boolean> shouldTeamJoinBeShouted){
        SHOULD_TEAM_JOIN_BE_SHOUTED = shouldTeamJoinBeShouted;
    }

    public static void setShouldTeamLeaderBeShouted(Supplier<Boolean> shouldTeamLeaderBeShouted) {
        SHOULD_TEAM_LEADER_BE_SHOUTED = shouldTeamLeaderBeShouted;
    }

    private final List<UUID> players;
    protected String name;
    protected Location spawn;
    protected UniColor color;
    private boolean eliminated;
    private UUID owner = null;
    private final UUID id;
    private int size;
    private OptionStatus nameTagVisibility;

    public UniTeam(String name, UniColor color, int size) {
        this.players = new LinkedList<>();

        this.name = name;
        this.color = color;
        this.spawn = null;
        this.eliminated = false;
        this.owner = null;
        this.size = size;
        this.id = UUID.randomUUID();
        this.nameTagVisibility = OptionStatus.ALWAYS;
    }

    @SuppressWarnings("deprecation")
    private void addToAllBoard(OfflinePlayer op) {
        UniPlayer ep;
        Team t;
        for (final Player p : GameEngine.getInstance().getOnlinePlayers()) {
            ep = (UniPlayer) p;
            if (ep.getEndScoreboard() != null) {
                t = ep.getEndScoreboard().getBoard().getTeam(this.name);
                if (t != null) {
                    t.addPlayer(op);
                }
            }
        }
    }

    private boolean addPlayer(UUID p) {
        if (!contains(p)) {
            this.players.add(p);
            return true;
        }
        return false;
    }

    private void join(UniPlayer p) {
        p.getStorage().addObject(STORAGE_TEAM, this);
        Bukkit.getPluginManager().callEvent(new PlayerJoinTeamEvent(this, p));
    }

    public void addPlayer(Player p) {
        final UniTeam t = UniTeam.getTeam(p);
        if (t != null) {
            t.removePlayer(p);
        }
        if (addPlayer(p.getUniqueId())) {
            addToAllBoard(p);
            join((UniPlayer) p);
            playerJoin(p);
            if (SHOULD_TEAM_JOIN_BE_SHOUTED.get()) p.sendMessage(Lang.str(p, "game.team.join", this.color + this.name));
            if (this.owner == null) {
                this.setOwner(p.getUniqueId());
            }
        }
    }

    @SuppressWarnings("deprecation")
    private void removeToAllBoard(OfflinePlayer op) {
        UniPlayer ep;
        Team t;
        for (final Player p : GameEngine.getInstance().getOnlinePlayers()) {
            ep = (UniPlayer) p;
            if (ep.getEndScoreboard() != null) {
                t = ep.getEndScoreboard().getBoard().getTeam(this.name);
                if (t != null) {
                    t.addPlayer(op);
                }
            }
        }
    }

    private boolean removePlayer(UUID p) {
        if (contains(p)) {
            this.players.remove(p);
            return true;
        }
        return false;
    }

    private void leave(UniPlayer p) {
        p.getStorage().removeObject(STORAGE_TEAM);
        Bukkit.getPluginManager().callEvent(new PlayerQuitTeamEvent(this, p));
    }

    public void removePlayer(Player p) {
        if (removePlayer(p.getUniqueId())) {
            removeToAllBoard(p);
            leave((UniPlayer) p);
            playerQuit(p);
            if (p.getUniqueId().equals(this.getOwner())) {
                if (players.size() >= 1) {
                    this.setOwner(players.get(0));
                } else {
                    this.setOwner(null);
                }
            }
        }
    }

    public void unsafeRemovePlayer(UUID p) {
        if (contains(p)) {
            this.players.remove(p);
            if (p.equals(this.getOwner())) {
                if (players.size() >= 1) {
                    this.setOwner(players.get(0));
                } else {
                    this.setOwner(null);
                }
            }
        }
    }

    public boolean contains(Player p) {
        return (contains(p.getUniqueId()));
    }

    public boolean contains(OfflinePlayer p) {
        return (contains(p.getUniqueId()));
    }

    public boolean contains(UUID uuid) {
        return (this.players.contains(uuid));
    }

    public void playerJoin(Player p) {
    }

    public void playerQuit(Player p) {
    }

    public void update() {

    }

    public void setSpawn(Location l) {
        this.spawn = l;
    }

    // GETTER

    private boolean isEliminated(UUID uuid) {
        final Storage s = GameEngine.getInstance().getStorage(uuid);
        return ((s == null) ? true : s.getBoolean("ELIMINATE", false));
    }

    public Location getSpawn() {
        return (this.spawn);
    }

    public String getName() {
        return (this.name);
    }

    public void setName(String name) {
        this.name = name;
    }

    public UniColor getColor() {
        return (this.color);
    }

    public int size() {
        return this.players.size();
    }

    public boolean isEmpty() {
        return (this.players.size() == 0);
    }

    public List<UUID> getContent() {
        return this.players;
    }

    public List<OfflinePlayer> getOfflinePlayers() {
        return this.players.stream()
                .map(Bukkit::getOfflinePlayer)
                .collect(Collectors.toCollection(LinkedList::new));
    }

    public List<UniPlayer> getOnlinePlayers() {
        final List<UniPlayer> p = new LinkedList<>();
        Player po;
        for (final UUID uuid : this.players) {
            po = Bukkit.getPlayer(uuid);
            if (po != null) {
                p.add((UniPlayer) po);
            }
        }
        return p;
    }

    public List<OfflinePlayer> getOfflineCompetingPlayers() {
        return this.players.stream()
                .filter(uuid -> !isEliminated(uuid))
                .map(Bukkit::getOfflinePlayer)
                .collect(Collectors.toCollection(LinkedList::new));
    }

    public List<UniPlayer> getOnlineCompetingPlayers() {
        final List<UniPlayer> p = new LinkedList<>();
        Player po;
        for (final UUID uuid : this.players) {
            po = Bukkit.getPlayer(uuid);
            if (po != null && !isEliminated(po.getUniqueId())) {
                p.add((UniPlayer) po);
            }
        }
        return p;
    }

    public UniPlayer getFirstConnectedPlayer() {
        Player po;
        for (final UUID uuid : this.players) {
            po = Bukkit.getPlayer(uuid);
            if (po != null) {
                return (UniPlayer) po;
            }
        }
        return null;
    }

    public UniPlayer getFirstAvailablePlayer() {
        Player po;
        GameEngine<?> ge = GameEngine.getInstance();
        for (final UUID uuid : this.players) {
            po = Bukkit.getPlayer(uuid);
            if (po != null && !ge.isEliminated(po.getUniqueId())) {
                return (UniPlayer) po;
            }
        }
        return null;
    }

    public int getCompetingCount() {
        return ((int) this.players.stream()
                .filter(uuid -> !isEliminated(uuid))
                .count());
    }

    public boolean isEliminated() {
        if (!this.eliminated && getCompetingCount() == 0) {
            this.eliminated = true;
        }
        return this.eliminated;
    }

    public boolean haveToEliminate() {
        return (!this.eliminated && getCompetingCount() == 0);
    }

    private void eliminate(UUID p) {
        final Storage s = GameEngine.getInstance().getStorage(p);
        if (s != null) {
            s.addBoolean("ELIMINATE", true);
        }
    }

    public void burnAtStart() {
        this.eliminated = true;
    }

    public void eliminate() {
        this.eliminated = true;
        for (final UUID po : this.players) {
            eliminate(po);
        }
        Bukkit.getPluginManager().callEvent(new EliminateTeamEvent(this));
    }

    public void teleportation(Location l) {
        if (l == null) {
            return;
        }
        Player p;
        for (final UUID po : this.players) {
            p = Bukkit.getPlayer(po);
            if (p != null) {
                p.teleport(l);
            }
        }
    }

    public void teleportation() {
        teleportation(this.spawn);
    }

    public void broadcast(String msg) {
        Player p;
        for (final UUID po : this.players) {
            p = Bukkit.getPlayer(po);
            if (p != null) {
                p.sendMessage(Lang.str(p, msg));
            }
        }
    }

    public void broadcast(String msg, String... args) {
        Player p;
        for (UUID po : this.players) {
            p = Bukkit.getPlayer(po);
            if (p != null) {
                p.sendMessage(Lang.str(p, msg, args));
            }
        }
    }

    public static UniTeam getTeam(Player p) {
        final UniPlayer ep = (UniPlayer) p;
        return (UniTeam) (ep.getStorage().getObject(STORAGE_TEAM));
    }

    public static UniTeam getTeam(UUID id) {
        final Storage storage = GameEngine.getInstance().getStorage(id);
        return ((storage == null) ? null : (UniTeam) storage.getObject(STORAGE_TEAM));
    }

    public UUID getOwner() {
        return this.owner;
    }

    public void setOwner(UUID id) {
        this.owner = id;
        Player p;
        if ((p = Bukkit.getPlayer(id)) == null) {
            return;
        }

        if(SHOULD_TEAM_LEADER_BE_SHOUTED.get()){
            p.sendMessage(Lang.str(p, "game.wait.team.leader.designed"));
            new FancyMessage().text(Lang.str(p, "game.wait.command.teamname.help")).suggest("/teamname").send(p);
            new FancyMessage().text(Lang.str(p, "game.wait.command.teamleader.help")).suggest("/teamleader").send(p);
        }
    }

    public static boolean sameTeam(Player a, Player b) {
        final UniTeam ta = getTeam(a);
        final UniTeam tb = getTeam(b);
        return (ta != null && ta == tb);
    }

    public static Team createTeamBoard(Scoreboard board, UniTeam team) {
        final Team t = board.registerNewTeam(team.getName());
        t.setPrefix(team.getColor().toString());
        t.setSuffix(ChatColor.WHITE.toString());
        t.setDisplayName(team.getName());
        t.setOption(Option.NAME_TAG_VISIBILITY, team.getNameTagVisibility());
        return t;
    }

    public static Team reloadTeamBoard(Scoreboard board, UniTeam team) {
        final Team t = board.getTeam(team.getName());
        if (t != null) {
            t.unregister();
        }

        return createTeamBoard(board, team);

        /*
         * if (t == null)t = createTeamBoard(board, team); for (OfflinePlayer op
         * : t.getPlayers())t.removePlayer(op); for (OfflinePlayer op :
         * team.getOfflinePlayers()){ t.addPlayer(op);
         * System.out.println("[BOARD] Ajout du joueur " + op.getName() +
         * " dans la team " + team.getName()); } return t;
         */
    }

    public static Team getTeamBoard(Scoreboard board, UniTeam team, boolean force) {
        Team t = board.getTeam(team.getName());
        if (t == null && force) {
            t = board.registerNewTeam(team.getName());
            t.setPrefix(team.getColor().toString());
            t.setSuffix(ChatColor.WHITE.toString());
            t.setDisplayName(team.getName());
        }

        return (t);
    }

    public static Team getTeamBoard(Scoreboard board, UniTeam team) {
        return (getTeamBoard(board, team, false));
    }

    public void addPotionEffect(PotionEffect pe) {
        this.getOnlinePlayers().forEach(e -> e.addPotionEffect(pe, true));
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public UUID getId() {
        return id;
    }

    /**
     * @return the nameTagVisibility
     */
    public OptionStatus getNameTagVisibility() {
        return nameTagVisibility;
    }

    /**
     * @param nameTagVisibility the nameTagVisibility to set
     */
    public UniTeam setNameTagVisibility(OptionStatus nameTagVisibility) {
        this.nameTagVisibility = nameTagVisibility;
        return this;
    }
}
