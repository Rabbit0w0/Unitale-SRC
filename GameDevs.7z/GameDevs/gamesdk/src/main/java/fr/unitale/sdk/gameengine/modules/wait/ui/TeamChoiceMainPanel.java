package fr.unitale.sdk.gameengine.modules.wait.ui;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.bukkit.entity.Player;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIComponent;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.ui.elements.UIRobotPanel;
import fr.unitale.sdk.ui.elements.sorters.GridSortPattern;
import fr.unitale.sdk.utils.items.UniItemBanner;

public class TeamChoiceMainPanel extends UIRobotPanel implements UIFormHandler<UniTeam> {

    Module<?> module;
    TeamModule<?> tm;

    public TeamChoiceMainPanel(Module<?> m, Player p) {
        super(54, new GridSortPattern());
        module = m;
        tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);

        createDecoration(p);

        if (tm != null) {
            for (final UniTeam team : tm.getTeams()) {
                final UniItemBanner banner = new UniItemBanner();
                banner.setBaseColor(team.getColor().getDyeColor());
                banner.setName(Lang.str("game.team.menu.join", team.getColor() + team.getName()));
                this.setComponent(team.getColor().getWoolByte(), new UIButton<>(team, banner));
            }
        }

        update();
    }

    @Override
    public void update() {
        if (tm != null) {
            for (final UniTeam team : tm.getTeams()) {
                final UIComponent component = this.getComponent(team.getColor().getWoolByte());
                if (component != null) {
                    final UniItemBanner banner = (UniItemBanner) component.getRender();
                    final List<String> lores = new LinkedList<>();
                    lores.add(" ");
                    Collections.addAll(
                            lores,
                            Lang.arr(
                                    "game.team.menu.banner.lore",
                                    String.valueOf(team.getOnlinePlayers().size()),
                                    String.valueOf(team.getSize())
                            )
                    );
                    lores.add(" ");
                    team.getOnlinePlayers().forEach(p -> {
                        lores.add("§8- §7" + p.getName()
                                + (team.getOwner() != null && team.getOwner().equals(p.getUniqueId())
                                ? " - Chef d'équipe" : ""));
                    });
                    banner.setLores(lores);
                    banner.setAmount(team.size());
                    banner.setName(Lang.str("game.team.menu.join", team.getColor() + team.getName()));
                }
            }
        }
        super.update();
    }

    @Override
    public void onSubmit(Player player, UniTeam team) {
        final TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
        if (tm != null) {
            if (team.getOnlinePlayers().size() >= team.getSize()) {
                player.sendMessage(Lang.str(player, "game.team.overload"));
            } else {
                if (team.equals(UniTeam.getTeam(player))) {
                    return;
                }

                team.addPlayer(player);
                player.closeInventory();
            }
        }
        update();
    }

}
