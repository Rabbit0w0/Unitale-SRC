package fr.unitale.sdk.gameengine.map.lasergame;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.gameengine.map.MapType;
import org.bukkit.Location;
import org.bukkit.World;

public class LasergameEnergium extends LasergameMap{

    public LasergameEnergium(String name, World w) {
        super(MapType.LASERGAME_ENERGIUM, name, w, new Location[]{
                new Location(w, -51, 68, 2, -120, 0),
                new Location(w, -52, 70, 52, -135, 0),
                new Location(w, -46, 70, -52, -100, 0),
                new Location(w, 51, 68, -2, 66, 0),
                new Location(w, 46, 70, 52, 92, 0),
                new Location(w, 52, 70, -52,45, 0),
                new Location(w, 25, 68, -54, -11, 0),
                new Location(w, -25, 68, 54, 166, 0),
                new Location(w, -21, 68, -37, -90, 0),
                new Location(w, 22, 68, 38, 90, 0),
                new Location(w, -26, 65, 27, 180, 0),
                new Location(w, -28, 65, -25, 0, 0)});
    }

    @Override
    public int getMinPlayers(ServerTypes.Mode mode) {
        switch(mode){
            case SOLO:
                return 8;
            case TEAM:
                return 10;
            default:
                return 10;
        }
    }
}
