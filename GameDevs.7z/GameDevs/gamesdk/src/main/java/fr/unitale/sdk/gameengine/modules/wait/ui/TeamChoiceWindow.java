package fr.unitale.sdk.gameengine.modules.wait.ui;

import org.bukkit.entity.Player;

import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.ui.elements.UIWindow;

public class TeamChoiceWindow extends UIWindow {

    public TeamChoiceWindow(Module<?> m, Player p) {
        super(54, Lang.str("game.team.menu.select"));

        addPanel("main", new TeamChoiceMainPanel(m, p));

        showPanel("main");
    }

    public void update() {
        getPanel("main").update();
    }
}
