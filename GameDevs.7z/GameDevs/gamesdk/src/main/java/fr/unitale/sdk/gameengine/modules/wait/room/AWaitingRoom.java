package fr.unitale.sdk.gameengine.modules.wait.room;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public abstract class AWaitingRoom {
    public abstract boolean haveToMove(Player p, Location from, Location to);

    public void result(Player p) {
        p.teleport(p.getWorld().getSpawnLocation());
    }
}
