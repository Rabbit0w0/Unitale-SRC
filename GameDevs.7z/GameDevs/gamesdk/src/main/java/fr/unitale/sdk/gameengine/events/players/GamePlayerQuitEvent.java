package fr.unitale.sdk.gameengine.events.players;

import fr.unitale.sdk.players.UniPlayer;

public class GamePlayerQuitEvent extends GamePlayerEvent {

    public GamePlayerQuitEvent(UniPlayer player) {
        super(player);
    }
}
