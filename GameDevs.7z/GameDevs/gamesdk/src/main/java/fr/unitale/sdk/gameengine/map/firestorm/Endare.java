package fr.unitale.sdk.gameengine.map.firestorm;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class Endare extends FirestormMap {

    public Endare(String name, World world) {
        super(MapType.FIRESTORM_ENDARE, name, world, new Location(world, -900, 29, 196),
                new Location(world, -900, 71, 196),
                5);
    }
}
