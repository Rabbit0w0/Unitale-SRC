package fr.unitale.sdk.gameengine.modules.wait.events;

public class PreStartWaitEvent extends WaitEvent {

    private int minutes;
    private int secondes;

    public PreStartWaitEvent(int m, int s) {
        this.minutes = m;
        this.secondes = s;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public int getSecondes() {
        return secondes;
    }

    public void setSecondes(int secondes) {
        this.secondes = secondes;
    }

    public int getTime() {
        return this.minutes * 60 + this.secondes;
    }
}
