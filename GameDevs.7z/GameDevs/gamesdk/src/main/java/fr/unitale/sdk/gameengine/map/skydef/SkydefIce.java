package fr.unitale.sdk.gameengine.map.skydef;

import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class SkydefIce extends SkydefMap {

    public SkydefIce(String name, World world) {
        super(MapType.SKYDEF_ICE, name, world,
                null,
                null,
                null,
                null,
                null,
                0,
                null);
    }
}
