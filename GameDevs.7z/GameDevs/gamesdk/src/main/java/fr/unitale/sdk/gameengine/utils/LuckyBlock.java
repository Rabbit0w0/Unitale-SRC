package fr.unitale.sdk.gameengine.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import fr.unitale.sdk.guilds.GuildPubSub;
import fr.unitale.sdk.utils.annotations.Unfinished;

@Unfinished
public class LuckyBlock {

    public static enum LuckyBlockType {
        ;

        Method method;

        LuckyBlockType(String methodName) {
            try {
                this.method = GuildPubSub.class.getDeclaredMethod(methodName, Block.class, Player.class);
            } catch (NoSuchMethodException | SecurityException e) {
                try {
                    this.method = GuildPubSub.class.getDeclaredMethod("defaultMethod", Block.class);
                } catch (NoSuchMethodException | SecurityException e1) {
                    this.method = null;
                }
                e.printStackTrace();
            }
        }

        public void execute(Block lucky, Player p) {
            if (this.method == null) {
                return;
            }
            try {
                this.method.invoke(null, lucky, p);
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                e.printStackTrace();
            }
        }

        public static LuckyBlockType fromString(String s) {
            for (final LuckyBlockType c : LuckyBlockType.values()) {
                if (c.name().equalsIgnoreCase(s)) {
                    return c;
                }
            }
            return null;
        }

        public static LuckyBlockType getRandom() {
            return LuckyBlockType.values()[(int) (Math.random() * LuckyBlockType.values().length)];
        }

        public static void randomExecute(Block b, Player p) {
            getRandom().execute(b, p);
        }
    }

    static void defaultMethod(Block luky) {

    }
}
