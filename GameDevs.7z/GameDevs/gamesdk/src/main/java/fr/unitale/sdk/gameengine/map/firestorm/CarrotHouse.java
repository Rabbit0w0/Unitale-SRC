package fr.unitale.sdk.gameengine.map.firestorm;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.MapType;

public class CarrotHouse extends FirestormMap {

    public CarrotHouse(String name, World world) {
        super(MapType.FIRESTORM_CARROTHOUSE, name, world, new Location(world, 720, 118, -1118),
                new Location(world, 721, 148, -1119), 5);
        this.bonus.add(new Location(world, 724, 88, -1119));
        this.bonus.add(new Location(world, 725, 82, -1119));
        this.bonus.add(new Location(world, 715, 86, -1111));
        this.bonus.add(new Location(world, 718, 83, -1125));
        this.bonus.add(new Location(world, 711, 79, -1117));
        this.bonus.add(new Location(world, 713, 69, -1114));
        this.bonus.add(new Location(world, 721, 72, -1122));
        this.bonus.add(new Location(world, 717, 75, -1113));
        this.bonus.add(new Location(world, 717, 62, -1115));
    }
}
