package fr.unitale.sdk.gameengine.modules.team.event;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;

public class PlayerJoinTeamEvent extends PlayerTeamEvent {

	public PlayerJoinTeamEvent(UniTeam team, UniPlayer player) {
		super(team, player);
	}

}
