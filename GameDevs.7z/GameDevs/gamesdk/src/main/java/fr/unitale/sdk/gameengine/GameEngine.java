package fr.unitale.sdk.gameengine;

import fr.unitale.api.PlayerApi;
import fr.unitale.api.client.redis.Redis;
import fr.unitale.api.type.IBoostable;
import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.api.type.ServerTypes.ServerType;
import fr.unitale.sdk.gameengine.commands.AvailableCommand;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateOfflinePlayer;
import fr.unitale.sdk.gameengine.events.eliminate.EliminatePlayerEvent;
import fr.unitale.sdk.gameengine.events.game.GameEndEvent;
import fr.unitale.sdk.gameengine.events.game.GameStartEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerJoinEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerQuitEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerWinEvent;
import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.modules.ModuleManager;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.gameengine.utils.EndMoneyManager;
import fr.unitale.sdk.gameengine.utils.GameTimer;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.thread.SDKPool;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.data.Storage;
import fr.unitale.sdk.utils.elo.EloManager;
import fr.unitale.sdk.utils.firework.FireworkFactory;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import redis.clients.jedis.Jedis;

import java.io.*;
import java.lang.reflect.Constructor;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * Represent a game engine with a corresponding game map type
 *
 * @param <M> {@link GameMap} class relative to this game engine
 */
public abstract class GameEngine<M extends GameMap> {

    private static Integer offlineDeleteTime = 300;

    public static String ELOKEY = "STORAGE_ELO";

    private static GameEngine<?> __instance;
    public final static String SCOREBOARD_STORAGE = "SCOREBOARD_STORAGE";

    public static GameEngine<?> getInstance() {
        return __instance;
    }

    private final JavaPlugin plugin;
    private final ModuleManager moduleManager;
    private final GameTimer timer;
    private final UUID gameUuid;

    protected GameStatus gameStatus;
    private final Map<UUID, UniPlayer> onlinePlayers;
    private final Map<UUID, Integer> offlinePlayers;
    protected Map<UUID, Storage> playerData;
    private boolean keepOffline;
    private JSONObject config;
    protected GameListener listener;
    protected Mode mode;
    protected ServerMode serverMode;
    private double goldBoost;
    private double emeraldBoost;
    protected M gameMap;
    private int gameElo;
    protected boolean vip;
    protected boolean antiAFK;
    protected boolean allowSpectate = false;

    public GameEngine(JavaPlugin plugin, String json) {
        __instance = this;
        this.gameUuid = UUID.randomUUID();
        this.mode = Mode.SOLO;

        this.serverMode = ServerMode.NORMAL;

        this.plugin = plugin;
        this.listener = null;
        this.gameStatus = GameStatus.WAIT;
        this.moduleManager = new ModuleManager();
        this.offlinePlayers = new LinkedHashMap<>();
        this.onlinePlayers = new LinkedHashMap<>();
        this.playerData = new LinkedHashMap<>();
        this.keepOffline = false;
        this.timer = new GameTimer();
        this.goldBoost = 0;
        this.emeraldBoost = 0;
        this.gameElo = 0;
        this.gameMap = null;
        this.antiAFK = true;

        setListener();
        if (this.listener != null) {
            this.plugin.getServer().getPluginManager().registerEvents(this.listener, this.plugin);
        }

        WeatherAPI.rainDisable();
        WeatherAPI.thunderDisable();
        WeatherAPI.setTime(1200);
        WeatherAPI.disableTime();
        WeatherAPI.disableWeather();

        ServerManager.type = ServerType.GAME;

        if (!loadConfig(json)) {
            emergencyShutdown("Config cant be loaded");
        }

        this.mode = getMode(getConfig("mode", "solo"));
        this.vip = getConfig("vip", Boolean.FALSE);
        this.serverMode = ServerMode.fromString(getConfig("servermode", "NORMAL"));

        new AvailableCommand().register();
    }

    /**
     * define default ELO score for this game
     */
    public void setGameElo() {
        this.gameElo = 0;
        if (getOnlinePlayers().size() == 0) {
            return;
        }
        final String gameEloId = getEloKey();
        for (final UniPlayer e : getOnlinePlayers()) {
            this.gameElo += e.getElo(gameEloId);
        }

        this.gameElo /= getOnlinePlayers().size();
    }

    /**
     * @return game map
     */
    public M getMap() {
        return this.gameMap;
    }

    /**
     * @return gold boost for this game
     */
    public double getGoldBoost() {
        return this.goldBoost;
    }

    /**
     * @return emerald boost for this game
     */
    public double getEmeraldBoost() {
        return this.emeraldBoost;
    }

    private UUID getOfflinePlayerToDelete() {
        return this.offlinePlayers.entrySet().stream()
                .filter(entry -> entry.getValue() >= offlineDeleteTime || !this.keepOffline)
                .findFirst()
                .map(Entry::getKey)
                .orElse(null);
    }

    public UUID getGameUuid() {
        return gameUuid;
    }

    /**
     * Update the list of offline players relatively to the keep offline argument or their offline delete time
     * If they should be eliminated, then they are
     */
    public void updateOfflinePlayer() {
        this.offlinePlayers.replaceAll((k, v) -> (v == null) ? 1 : v + 1);

        UUID uuid;
        OfflinePlayer op;
        while ((uuid = getOfflinePlayerToDelete()) != null) {
            op = Bukkit.getOfflinePlayer(uuid);
            this.offlinePlayers.remove(uuid);
            Bukkit.getPluginManager().callEvent(new EliminateOfflinePlayer(uuid));
            PlayerApi.setPlayerLastServer(uuid, null);

            UUID finalUuid = uuid;
            SDKPool.execute(() -> {
                try (Jedis jedis = Redis.getConnection()) {
                    jedis.publish("PLAYER_ELIMINATED", finalUuid.toString());
                }
            });

            if (!this.isEliminated(uuid)) {
                this.eliminatePlayer(uuid);
                if (op != null)
                    this.broadcast("game.kick.afk", op.getName());
            }
        }
    }

    /**
     * @return {@link GameTimer}
     */
    public GameTimer getGameTimer() {
        return this.timer;
    }

    protected void setListener() {
        this.listener = new GameListener();
    }

    /**
     * SOLO or TEAM
     *
     * @return {@link Mode}
     */
    public Mode getMode() {
        return this.mode;
    }

    /**
     * @return {@link ModuleManager}
     */
    public ModuleManager getModuleManager() {
        return (this.moduleManager);
    }

    /**
     * WAIT, GAME or END
     *
     * @return {@link GameStatus}
     */
    public GameStatus getGameStatus() {
        return gameStatus;
    }

    /**
     * @param status {@link GameStatus} WAIT, GAME or END
     */
    public void setGameStatus(GameStatus status) {
        this.gameStatus = status;
    }

    /**
     * @return {@link UUID} set of the offline players
     */
    public Set<UUID> getOfflinePlayers() {
        return offlinePlayers.keySet();
    }

    /**
     * @return {@link UniPlayer} list of online players
     */
    public List<UniPlayer> getOnlinePlayers() {
        return new ArrayList<>(onlinePlayers.values());
    }

    /**
     * @return {@link UniPlayer} list of online players as a {@link ArrayList}
     */
    public List<UniPlayer> getSafeOnlinePlayers() {
        return new ArrayList<>(this.onlinePlayers.values());
    }

    /**
     * @return Should players be kept in the game while offline
     */
    public boolean isKeptOffline() {
        return keepOffline;
    }

    /**
     * @param keepOffline should players be kept in the game while offline
     */
    public void setKeepOffline(boolean keepOffline) {
        this.keepOffline = keepOffline;
    }

    /**
     * @return this game engine {@link JavaPlugin}
     */
    public JavaPlugin getPlugin() {
        return plugin;
    }

    protected boolean loadConfig(String json) {
        final JSONParser parser = new JSONParser();
        try {
            final Object o = parser.parse(json);
            if (o instanceof JSONObject) {
                this.config = (JSONObject) o;
                return true;
            }
        } catch (final Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Get a config value
     *
     * @param <T>  type of the argument needed, defined by the default value to return
     * @param path {@link String} path of the value to get as "path.to.my.value"
     * @param def  default value to set if not found
     * @return the needed value
     */
    @SuppressWarnings("unchecked")
    public <T> T getConfig(String path, T def) {
        if (config == null) {
            return def;
        }

        final String[] nodes = path.contains(".") ? path.split("\\.") : new String[]{path};
        JSONObject node = config;
        for (int i = 0; i < nodes.length - 1; i++) {
            final String next = nodes[i];
            final Object found = node.get(next);
            if (found instanceof JSONObject) {
                node = (JSONObject) found;
            } else {
                return def;
            }
        }
        final Object value = node.get(nodes[nodes.length - 1]);
        if (value == null) {
            return def;
        }

        if (def.getClass().isAssignableFrom(value.getClass())) {
            return (T) value;
        } else if (Number.class.isAssignableFrom(def.getClass()) && Number.class.isAssignableFrom(value.getClass())) {
            //TODO Codé de façon un peu porcine. À changer quand on aura le temps de se pencher sur ce problème
            try {
                final Constructor<?> constructor = def.getClass().getDeclaredConstructor(String.class);
                return (T) constructor.newInstance(value.toString());
            } catch (final Exception e) {
                e.printStackTrace();
            }
        }
        return def;
    }

    /**
     * @return {@link JSONObject} config root
     */
    public JSONObject getConfig() {
        return config;
    }

    private void setStorage(UniPlayer ep) {
        final Storage s = this.playerData.get(ep.getUniqueId());
        if (s != null) {
            ep.setStorage(s);
            final UniScoreboard b = (UniScoreboard) ep.getStorage().getObject(SCOREBOARD_STORAGE);
            if (b != null) {
                ep.setScoreboard(b);
            }
        } else {
            if (ep.getEndScoreboard() != null) {
                ep.getStorage().addObject(SCOREBOARD_STORAGE, ep.getEndScoreboard());
            }
            ep.getStorage().addInteger(ELOKEY, ep.getElo(GameEngine.getEloKey()));
            this.playerData.put(ep.getUniqueId(), ep.getStorage());
        }
    }

    private void waitModuleJoin(UniPlayer player) {
        WaitingModule m = this.getModuleManager().getModule(WaitingModule.class);
        if (m != null) {
            Lang.bcst("game.player.join", player.getName(), String.valueOf(this.onlinePlayers.size()), String.valueOf(m.maxPlayers));
            Map<IBoostable, Double> boosts = player.getBoosts();
            int newBoost;
            for (Entry<IBoostable, Double> boost : boosts.entrySet()) {
                if (boost.getValue() > 1) {
                    newBoost = (int) ((boost.getValue() * 100) - 100);
                    player.sendMessage(Lang.str(player, "game.player.join.boost", boost.getKey().toString(), "" + (Math.max(newBoost, 0))));
                }
            }
        }
    }

    /**
     * Define the behaviour when a player join the game
     *
     * @param player {@link UniPlayer}
     */
    public void playerJoin(UniPlayer player) {
        //if game has not started yet
        if (gameStatus == GameStatus.WAIT) {
            player.clear();
            onlinePlayers.put(player.getUniqueId(), player);
            setStorage(player);
            waitModuleJoin(player);
            Bukkit.getPluginManager().callEvent(new GamePlayerJoinEvent(player));
            userJoin(player);
        } else if (gameStatus == GameStatus.GAME && offlinePlayers.containsKey(player.getUniqueId())) {
            offlinePlayers.remove(player.getUniqueId());
            onlinePlayers.put(player.getUniqueId(), player);
            setStorage(player);
            Lang.bcst("game.player.reconnect", player.getName());
            //TODO make a reconnect event instead of a connect
            Bukkit.getPluginManager().callEvent(new GamePlayerJoinEvent(player));
            userJoin(player);
        } else {
            //if player has permission to spec at end of the game (game.specend)
            if (player.hasPermission("game.specend") && serverMode == ServerMode.NORMAL && allowSpectate) {
                setStorage(player);
                Lang.bcst("game.player.reconnect", player.getName());
                userSpectate(player);
            } else {
                player.kickPlayer(Lang.str(player, "game.kick.join.party"));
            }
        }
    }

    /**
     * Add an offline player to the offline players
     *
     * @param player {@link UUID} of the player to add
     */
    public void addOfflinePlayer(UUID player) {
        this.offlinePlayers.put(player, 0);
    }

    /**
     * Define the behaviour when a player leaves the game
     *
     * @param player {@link UniPlayer}
     */
    public void playerQuit(UniPlayer player) {
        if (!this.onlinePlayers.containsKey(player.getUniqueId())) {
            return;
        }

        this.onlinePlayers.remove(player.getUniqueId());
        if (this.keepOffline && this.gameStatus != GameStatus.WAIT) {
            this.offlinePlayers.put(player.getUniqueId(), 0);
        } else {
            this.playerData.remove(player.getUniqueId());
        }

        Bukkit.getPluginManager().callEvent(new GamePlayerQuitEvent(player));
        userQuit(player);
        if (this.gameStatus == GameStatus.GAME) {
            PlayerApi.sUniPlayerData(player, false, true, true, null);
            if (this.onlinePlayers.size() == 0) this.endGame(60);
        }
    }

    /**
     * Called when a player joins the game
     *
     * @param player {@link Player}
     */
    protected void userJoin(UniPlayer player) {
    }

    /**
     * Called when a player spectate the game
     *
     * @param player {@link Player}
     */
    protected void userSpectate(UniPlayer player) {
    }

    /**
     * Called when a player leaves the game
     *
     * @param player {@link Player}
     */
    protected void userQuit(UniPlayer player) {
    }

    /**
     * Called when the status is WAIT and the player moves
     *
     * @param player {@link Player}
     */
    protected void userWaitMove(Player player) {
    }

    /**
     * Get the storage of an offline player
     *
     * @param player {@link OfflinePlayer}
     * @return {@link Storage} of this player
     */
    public Storage getStorage(OfflinePlayer player) {
        if (!player.isOnline()) {
            return this.playerData.get(player.getUniqueId());
        }

        final UniPlayer ep = (UniPlayer) player.getPlayer();
        return ep.getStorage();
    }

    /**
     * Get a Storage from an online player's {@link UUID}
     *
     * @param uuid {@link UUID}
     * @return {@link Storage} of this player
     */
    public Storage getStorage(UUID uuid) {
        final Player p = Bukkit.getPlayer(uuid);
        return ((p == null) ? this.playerData.get(uuid) : ((UniPlayer) p).getStorage());
    }

    /**
     * @return {@link Collection} of all {@link Storage}s
     */
    public Collection<Storage> getStorages() {
        return this.playerData.values();
    }

    /**
     * @return {@link Map} of {@link UUID} and their corresponding {@link Storage}
     */
    public Map<UUID, Storage> getMapStorages() {
        return this.playerData;
    }

    // --------------------------------------- PHASE ---------------------------------------------------------

    /**
     * Set the game status to WAIT
     */
    public void waitGame() {
        this.gameStatus = GameStatus.WAIT;
    }

    /**
     * Start the game
     */
    public void startGame() {
        setGameElo();
        this.gameStatus = GameStatus.GAME;
        for (final UniPlayer p : this.onlinePlayers.values()) {
            if (p.getBoost(MoneyType.GOLD) > this.goldBoost) {
                this.goldBoost = p.getBoost(MoneyType.GOLD);
            }

            if (p.getBoost(MoneyType.EMERALDS) > this.emeraldBoost) {
                this.emeraldBoost = p.getBoost(MoneyType.EMERALDS);
            }

            if (this.keepOffline) {
                PlayerApi.setLastServerIdentity(p.getUniqueId());
            }
        }
        Bukkit.getPluginManager().callEvent(new GameStartEvent(this.onlinePlayers.size()));
        TimeManager.getInstance().addTimer(this.timer);
        this.plugin.getServer().getPluginManager().registerEvents(new AFKManager(), this.plugin);
    }

    /**
     * Try to stop the game
     *
     * @param force boolean force the game to stop
     * @param time  long delay before shutting down the server in ticks (20 = 1s)
     */
    public void endGame(boolean force, long time) {
        this.gameStatus = GameStatus.END;
        Bukkit.getPluginManager().callEvent(new GameEndEvent());
        if (force) {
            endServer(time);
        }

        EndMoneyManager.printGain();
        for (final UniPlayer p : this.onlinePlayers.values()) {
            PlayerApi.setPlayerLastServer(p.getUniqueId(), null);
        }
    }

    /**
     * Stop the game
     *
     * @param time long delay before shutting down the server in ticks (20 = 1s)
     */
    public void endGame(long time) {
        endGame(true, time);
    }

    /**
     * Stop the game NOW
     */
    public void endGame() {
        endGame(true, 0);
    }

    /**
     * Get {@link Mode} from String
     *
     * @param text {@link String}
     * @return {@link Mode}
     */
    public Mode getMode(String text) {
        if (text.equalsIgnoreCase("team")) {
            return Mode.TEAM;
        } else {
            return Mode.SOLO;
        }
    }

    /**
     * @param reason {@link String}
     */
    public void emergencyShutdown(String reason) {
        UniLogger.error("SHUTDOWN SCHEDULED DU TO: " + reason);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "stop");
    }

    /**
     * End the server NOW
     */
    public void endServer() {
        privateEndServer();
    }

    /**
     * End the server in a certain time
     *
     * @param delay long time in tick (20 = 1s)
     */
    public void endServer(long delay) {
        if (delay <= 0) {
            privateEndServer();
        } else {
            Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, this::privateEndServer, delay);
        }
    }

    private void privateEndServer() {
        PlayerApi.sUniPlayersData(GameEngine.getInstance().getOnlinePlayers(), false, true, true, res -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "stop"));
    }

    /**
     * broadcast a message
     *
     * @param msg {@link String} to send
     * @deprecated broadcasting a raw message without translation is not a good thing.
     */
    @Deprecated
    public void broadcast(String msg) {
        for (final Player po : getOnlinePlayers()) {
            po.sendMessage(msg);
        }
    }

    /**
     * broadcast a message with some given arguments if necessary
     *
     * @param msg  {@link String} key to the player's locale config
     * @param args arguments for the message to send
     */
    public void broadcast(String msg, String... args) {
        for (final Player po : getOnlinePlayers()) {
            po.sendMessage(Lang.str(po, msg, args));
        }
    }

    /**
     * broadcast a message without arguments
     *
     * @param msg {@link String} key to the player's locale config
     */
    public void broadcastLang(String msg) {
        for (final Player po : getOnlinePlayers()) {
            po.sendMessage(Lang.str(po, msg));
        }
    }

    /**
     * Spawn a random firework above player's location
     *
     * @param p {@link Player}
     */
    public void spawk(Player p) {
        FireworkFactory.spawnRandomFirework(p.getLocation(), false);
    }

    /**
     * @param p {@link Player}
     * @return players is playing in this game
     */
    public boolean isPlaying(Player p) {
        return onlinePlayers.containsKey(p.getUniqueId());
    }

    /**
     * check if a players has been eliminated
     *
     * @param id {@link UUID} to check from
     * @return false if the player is still playing else true
     */
    public boolean isEliminated(UUID id) {
        Player p = Bukkit.getPlayer(id);
        final Storage s = (p == null) ? getStorage(id) : (((UniPlayer) p).getStorage());
        return (s == null) ? true : s.getBoolean("ELIMINATE", false);
    }

    /**
     * Eliminate an offline player by {@link UUID}
     *
     * @param id {@link UUID} of the player to eliminate
     */
    public void eliminateOfflinePlayer(UUID id) {
        final Storage s = getStorage(id);
        s.addBoolean("ELIMINATE", true);
        Bukkit.getPluginManager().callEvent(new EliminateOfflinePlayer(id));
        if (this.mode == Mode.SOLO) {
            return;
        }

        final UniTeam t = UniTeam.getTeam(id);
        if (t != null && t.haveToEliminate()) {
            t.eliminate();
        }
    }

    /**
     * Eliminate a player by his {@link UUID}
     *
     * @param p {@link UUID} of the player
     */
    public void eliminatePlayer(UUID p) {
        Player player = Bukkit.getPlayer(p);
        if (player != null) eliminatePlayer((UniPlayer) player);
        else eliminateOfflinePlayer(p);
    }

    /**
     * Eliminate a player
     *
     * @param p {@link Player}
     */
    public void eliminatePlayer(Player p) {
        eliminatePlayer((UniPlayer) p);
    }

    /**
     * Eliminate a player
     *
     * @param p {@link UniPlayer}
     */
    public void eliminatePlayer(UniPlayer p) {
        p.eliminate();
        Bukkit.getPluginManager().callEvent(new EliminatePlayerEvent(p));
        if (this.mode == Mode.SOLO) {
            return;
        }

        final UniTeam t = UniTeam.getTeam(p);
        if (t != null && t.haveToEliminate()) {
            t.eliminate();
        }
    }

    /**
     * Send a {@link GamePlayerWinEvent} with the winners of this game
     *
     * @param players Players[] winners of this game
     */
    public void winPlayer(UniPlayer... players) {
        Bukkit.getPluginManager().callEvent(new GamePlayerWinEvent(players));
    }

    /**
     * @return {@link List} of {@link UniTeam}
     */
    public List<UniTeam> getOnlineTeams() {
        final TeamModule<UniTeam> tm = moduleManager.getTeamModule(UniTeam.class);
        if (tm == null) {
            return null;
        }

		return tm.getTeams().stream()
				.filter(team -> team.getFirstConnectedPlayer() != null)
				.collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     * @return online teams count
     */
    public int getOnlineTeamsCount() {
        final TeamModule<UniTeam> tm = moduleManager.getTeamModule(UniTeam.class);
        if (tm == null) {
            return 0;
        }

		return (int) tm.getTeams().stream()
				.filter(team -> team.getFirstConnectedPlayer() != null)
				.count();
    }

    /**
     * @return same as getOnlineTeams();
     */
    public List<UniTeam> getAvailableTeams() {
        final TeamModule<UniTeam> tm = moduleManager.getTeamModule(UniTeam.class);
        if (tm == null) {
            return null;
        }

		return tm.getTeams().stream()
				.filter(team -> team.getFirstAvailablePlayer() != null)
				.collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     * @return same as getOnlineTeamsCount();
     */
    public int getAvailableTeamsCount() {
        final TeamModule<UniTeam> tm = moduleManager.getTeamModule(UniTeam.class);
        if (tm == null) {
            return 0;
        }

		return (int) tm.getTeams().stream()
				.filter(team -> team.getFirstAvailablePlayer() != null)
				.count();
    }

    /**
     * @return {@link List} of {@link UniPlayer} in the game
     */
    public List<UniPlayer> getCompetingPlayers() {
        final List<UniPlayer> l = new LinkedList<>();
        UniPlayer ep;
        for (final Player p : this.onlinePlayers.values()) {
            ep = (UniPlayer) p;
            if (!ep.isEliminated()) {
                l.add(ep);
            }
        }
        return l;
    }

    /**
     * @return same as getCompetingPlayers();
     */
    public List<UniPlayer> getEndCompetingPlayers() {
        final List<UniPlayer> l = new LinkedList<>();
        UniPlayer ep;
        for (final Player p : this.onlinePlayers.values()) {
            ep = (UniPlayer) p;
            if (!ep.isEliminated()) {
                l.add(ep);
            }
        }
        return l;
    }

    /**
     * @return competing player count
     */
    public int getCompetingPlayersCount() {
        int i = 0;
        UniPlayer ep;
        for (final Player p : this.onlinePlayers.values()) {
            ep = (UniPlayer) p;
            if (!ep.isEliminated()) {
                i++;
            }
        }
        return i;
    }

    /**
     * @return {@link List} of {@link UniPlayer} containing all team still in the game
     */
    public List<UniTeam> getCompetingTeams() {
        final TeamModule<UniTeam> tm = moduleManager.getTeamModule(UniTeam.class);
        if (tm == null) {
            return null;
        }

		return tm.getTeams().stream()
				.filter(team -> !team.isEliminated())
				.collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     * @return competing teams count
     */
    public int getCompetingTeamCount() {
        final TeamModule<UniTeam> tm = moduleManager.getTeamModule(UniTeam.class);
        if (tm == null) {
            return 0;
        }

		return (int) tm.getTeams().stream()
				.filter(team -> !team.isEliminated())
				.count();
    }

    /**
     * Remove a {@link UUID} from the offline player list
     *
     * @param uuid {@link UUID} to remove
     */
    public void removeFromKeep(UUID uuid) {
        this.offlinePlayers.remove(uuid);
        PlayerApi.setPlayerLastServer(uuid, null);
    }

    /**
     * get the JSON formatted {@link String} content from a file
     *
     * @param f {@link File} to get content from
     * @return {@link String} json formatted string
     */
    public static String getJSONContent(File f) {
        FileInputStream stream = null;
        try {
            stream = new FileInputStream(f);
        } catch (final FileNotFoundException e1) {
            e1.printStackTrace();
        }
        final InputStreamReader reader = new InputStreamReader(stream);
        final JSONParser parser = new JSONParser();
        try {
            final Object o = parser.parse(reader);
            if (o instanceof JSONObject) {
                return ((JSONObject) o).toJSONString();
            }
        } catch (final Exception e) {
            e.printStackTrace();
        } finally {
            try {
                stream.close();
                reader.close();
            } catch (final IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * get the default json content from a file inside the plugin
     *
     * @param clazz {@link Class} to get resource from
     * @param name  {@link String} file name
     * @return {@link String} json formatted content
     */
    public static String getDefaultJSONContent(Class<?> clazz, String name) {
        final InputStream stream = clazz.getResourceAsStream(name);
        final InputStreamReader reader = new InputStreamReader(stream);
        final JSONParser parser = new JSONParser();
        try {
            final Object o = parser.parse(reader);
            if (o instanceof JSONObject) {
                return ((JSONObject) o).toJSONString();
            }
        } catch (final Exception e) {
            e.printStackTrace();
        } finally {
            try {
                stream.close();
                reader.close();
            } catch (final IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * @return NORMAL, GUILD or RANKED
     */
    public ServerMode getServerMode() {
        return serverMode;
    }

    /**
     * @param serverMode NORMAL, GUILD RANKED
     */
    public void setServerMode(ServerMode serverMode) {
        this.serverMode = serverMode;
    }

    /**
     * @return the allowSpectate
     */
    public boolean allowSpectate() {
        return allowSpectate;
    }

    /**
     * @param allowSpectate the allowSpectate to set
     */
    public void setAllowSpectate(boolean allowSpectate) {
        this.allowSpectate = allowSpectate;
    }

    /**
     * @param value {@link String} servermode text
     * @return NORMAL, GUILD or RANKED
     */
    public ServerMode getServerModeFromString(String value) {
        switch (value) {
			case "ranked":
                return ServerMode.RANKED;
            case "guild":
                return ServerMode.GUILD;
            default:
                return ServerMode.NORMAL;
        }
    }

    /**
     * @return elo key
     */
    public static String getEloKey() {
        if (GameEngine.getInstance().getMode() == Mode.TEAM) {
            final TeamModule<?> tm = GameEngine.getInstance().getModuleManager().getModule(TeamModule.class);
            if (tm != null && tm.sizeRestricted()) {
                return EloManager.getKey(tm.getTeamSize());
            } else {
                return EloManager.getKey(Mode.TEAM);
            }
        } else {
            return EloManager.getKey();
        }
    }

    /**
     * @return game elo
     */
    public int getGameElo() {
        return this.gameElo;
    }

    /**
     * Call an event
     *
     * @param ev {@link Event} to call
     */
    public void callEvent(Event ev) {
        Bukkit.getPluginManager().callEvent(ev);
    }

    /**
     * @return true if the config for "vip" is true
     */
    public boolean isVip() {
        return vip;
    }

    /**
     * @return get whether the anti afk is on or off
     */
    public boolean isAntiAFK() {
        return antiAFK;
    }

    /**
     * @param antiAFK activate or deactivate the anti afk system
     */
    public void setAntiAFK(boolean antiAFK) {
        this.antiAFK = antiAFK;
    }
}