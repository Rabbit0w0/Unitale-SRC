package fr.unitale.sdk.gameengine.map.skydef;

import org.bukkit.Location;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.sdk.gameengine.modules.teleporter.Teleporter;
import fr.unitale.sdk.players.UniPlayer;

public class SkydefTp extends Teleporter {

    private final SkydefMap map;

    SkydefTp(String name, Location center, Location out, SkydefMap map) {
        super(name, center, out);
        this.map = map;
    }

    @Override
    public void moveIn(UniPlayer p) {
        if (this.map.getDefender().contains(p.getUniqueId())) {
            System.out.println("Je vais tp " + p.getName() + " en " + this.out);
            p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 40, 4));
            p.teleport(this.out);
        }
    }
}
