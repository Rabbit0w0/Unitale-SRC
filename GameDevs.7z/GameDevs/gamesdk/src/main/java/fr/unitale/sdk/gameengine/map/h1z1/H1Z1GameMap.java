package fr.unitale.sdk.gameengine.map.h1z1;

import java.util.LinkedList;
import java.util.List;

import org.bukkit.Difficulty;
import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.gameengine.map.GameMap;
import fr.unitale.sdk.gameengine.map.MapType;

public class H1Z1GameMap extends GameMap {

    private final int size;
    private final List<Location> triggers;

    public H1Z1GameMap(MapType type, String name, World world, int size) {
        super(type, name, world);
        this.size = size;
        this.triggers = new LinkedList<>();
        world.getWorldBorder().setCenter(0D, 0D);
        world.getWorldBorder().setSize(size);
        world.setDifficulty(Difficulty.PEACEFUL);
    }

    public int getSize() {
        return size;
    }

    public List<Location> getTriggers() {
        return triggers;
    }
}
