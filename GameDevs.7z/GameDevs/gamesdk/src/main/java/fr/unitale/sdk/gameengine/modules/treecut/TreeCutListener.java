package fr.unitale.sdk.gameengine.modules.treecut;

import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;

import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.players.UniPlayer;

public class TreeCutListener extends ModuleListener<TreeCutModule> {

    public TreeCutListener(TreeCutModule module) {
        super(module);
    }

    @EventHandler
    public void blockBreak(BlockBreakEvent ev) {
        UniPlayer player = (UniPlayer) ev.getPlayer();
        this.module.blockBreak(player, player.getLocation().clone(), ev.getBlock());
    }
}
