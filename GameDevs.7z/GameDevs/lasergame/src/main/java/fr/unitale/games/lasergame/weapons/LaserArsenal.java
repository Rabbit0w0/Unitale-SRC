package fr.unitale.games.lasergame.weapons;

import java.util.LinkedHashMap;
import java.util.Map;

import fr.unitale.games.lasergame.weapons.effects.BodyType;
import fr.unitale.games.lasergame.weapons.effects.CanonType;
import fr.unitale.games.lasergame.weapons.effects.ExplosionType;
import fr.unitale.games.lasergame.weapons.effects.LensType;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gun.GunAPI;
import fr.unitale.sdk.gun.model.Gun;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;

public class LaserArsenal {

	private Map<UniPlayer, Integer> guns;

	public LaserArsenal() {
		guns = new LinkedHashMap<UniPlayer, Integer>();
	}
	
	public void reset(UniPlayer player) {
		if(guns.containsKey(player)) {
			GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
			int id = guns.get(player);
			api.unregister(id);
			guns.remove(player);
		}
	}
	
	public UniItemStack getItem(UniPlayer player) {
		LaserGameGun gun = (LaserGameGun)getOrCreateGun(player);
		UniItemStack stack = UniItemStack.fromItemStack(gun.getBody().getItem()).translate(player);
		gun.injectTag(stack);
		return stack;
	}
	
	public void resetAll() {
		GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
		guns.values().forEach(api::unregister);
		guns.clear();
	}
	
	public Gun getOrCreateGun(UniPlayer p) {
		GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
		if (guns.containsKey(p)) {
			return api.getInstanceFromId(guns.get(p));
		}else {
			BodyType body = BodyType.NORMAL;
			if (p.getSettings().getLasergameBody() != null) {
				body = BodyType.valueOf(p.getSettings().getLasergameBody().name());
			}
			
			ExplosionType explosion = ExplosionType.NORMAL;
			if (p.getSettings().getLasergameExplosion() != null) {
				explosion = ExplosionType.valueOf(p.getSettings().getLasergameExplosion().name());
			}
			
			CanonType canon = CanonType.NORMAL;
			if (p.getSettings().getLasergameCanon() != null) {
				canon = CanonType.valueOf(p.getSettings().getLasergameCanon().name());
			}
			
			LensType lens = LensType.NORMAL;
			if (p.getSettings().getLasergameLens() != null) {
				lens = LensType.valueOf(p.getSettings().getLasergameLens().name());
			}
			
			LaserGameGun gun = new LaserGameGun(p.getSettings().getPrimary().getColor(),
					p.getSettings().getSecondary().getColor(),
					body,
					canon,
					explosion,
					lens,
					Integer.MAX_VALUE,
					Integer.MAX_VALUE,
					Integer.MAX_VALUE,
					Integer.MAX_VALUE,
					1.0f,
					0.2f,
					40,
					0,
					body.getLoadTime(),
					0.0f,
					1);
			
			api.registerGun(gun);
			guns.put(p, gun.getId());
			return gun;
		}
	}
}
