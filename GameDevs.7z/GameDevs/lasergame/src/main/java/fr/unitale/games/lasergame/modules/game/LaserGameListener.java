package fr.unitale.games.lasergame.modules.game;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.games.lasergame.LaserGameEngine;
import fr.unitale.games.lasergame.modules.game.team.LaserTeam;
import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.games.lasergame.utils.LasergameScoreboard;
import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.lasergame.event.UnitalePlayerRespawnDemandEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.gun.GunAPI;
import fr.unitale.sdk.gun.events.GunCooldownEvent;
import fr.unitale.sdk.gun.events.GunShootEvent;
import fr.unitale.sdk.gun.model.Gun;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.morphs.MorphAPI;
import fr.unitale.sdk.morphs.model.Morph;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.data.Tuple;
import fr.unitale.sdk.utils.fancymessage.FancyMessage;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class LaserGameListener extends ModuleListener<LaserGameModule> {

    private final Random rand = new Random();
    private Map<UniPlayer, Integer> cooldowns;

    public LaserGameListener(LaserGameModule module) {
        super(module);
        cooldowns = new HashMap<>();
    }

    @EventHandler
    public void onPlayerJoin(UnitalePlayerJoinEvent e) {
        getModule().respawn(e.getPlayer(), true);
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onItemDrop(PlayerDropItemEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerSwap(PlayerSwapHandItemsEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onEntityInteract(PlayerInteractEntityEvent e) {
        if (e.getRightClicked() != null && (e.getRightClicked() instanceof ArmorStand || e.getRightClicked() instanceof ItemFrame))
            e.setCancelled(true);
    }

    @EventHandler
    public void onEntityInteract(PlayerInteractEvent ev) {
        UniPlayer player = (UniPlayer) ev.getPlayer();
        UniItemStack stack = UniItemStack.fromItemStack(ev.getItem());
        if (stack != null) {
            GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
            Gun gun = api.getInstanceFrom(stack);
            if (gun != null && gun instanceof LaserGameGun && (ev.getAction().equals(Action.LEFT_CLICK_BLOCK) || ev.getAction().equals(Action.LEFT_CLICK_AIR))) {
                if (isInCooldownFor(player, CooldownType.PUSH)) {
                    player.sendMessage(Lang.str(player, "game.lasergame.chat.cooldown"));
                } else {
                    //set velocity
                    Vector movement = (Vector) player.getStorage().getObject("movement", null);
                    if (movement == null) return;
                    movement.multiply(4);
                    movement.setY(0.3);
                    player.setVelocity(movement);
                    player.setExp(0f);
                    setCooldownFor(player, CooldownType.PUSH, true);
                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            if (player.getExp() >= 1f) {
                                setCooldownFor(player, CooldownType.PUSH, false);
                                SoundCreator.playSound(Sound.BLOCK_NOTE_SNARE, 0.5f, player);
                                cancel();
                            } else {
                                player.setExp(player.getExp() + 1.0f / 16.0f);
                            }

                        }
                    }.runTaskTimer(LaserGameEngine.getInstance().getPlugin(), 0l, 5l);
                }
            }
//            if (stack.hasKey("glowingitem")) {
//                module.setPlayersGlowing((UniPlayer) ev.getPlayer());
//                ev.getPlayer().getInventory().remove(Material.COMPASS);
//            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent ev) {
        Vector movement = ev.getTo().clone().subtract(ev.getFrom().clone()).toVector();
        UniPlayer player = (UniPlayer) ev.getPlayer();
        player.getStorage().addObject("movement", movement);
    }

    @EventHandler
    public void onPlayerSneak(PlayerToggleSneakEvent e) {
        e.setCancelled(true);
        e.getPlayer().sendMessage(Lang.str(e.getPlayer(), "game.sneak.disabled"));
    }

    @SuppressWarnings("unchecked")
    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent ev){
        //if not a player related event or the gameStatus is not game
        if (LaserGameEngine.getInstance().getGameStatus() != GameStatus.GAME ||
                !(ev.getDamager() instanceof Player) ||
                !(ev.getEntity() instanceof Player)) {
            ev.setCancelled(true);
            return;
        }

        UniPlayer ep = (UniPlayer) ev.getEntity();
        Morph morph = MorphAPI.getMorphManager().getOrCreateMorph(ep);

        //if player is invulerable, has invulnerable morph, or damage is not letal
        if (ep.isInvulnerable() ||
                morph.getType() == LaserGameModule.INVULNERABLE_MORPH ||
                ep.getHealth() >= ev.getDamage()) {
            return;
        }

        GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
        UniPlayer killer = (UniPlayer) ev.getDamager();
        UniItemStack item = killer.getMainHandItem();
        LaserGameGun gun = (LaserGameGun) api.getInstanceFrom(item);

        if (LaserGameEngine.getInstance().getMode() == Mode.TEAM) {
            LaserTeam t = (LaserTeam) UniTeam.getTeam(killer);

            Bukkit.getOnlinePlayers().stream()
                    .map(p -> (UniPlayer) p)
                    .forEach(p -> new FancyMessage(Lang.str(p, "game.lasergame.kill",
                            t.getColor() + killer.getName() + ChatColor.RESET,
                            Lang.str(p, gun.getExplosion().getDisplay()),
                            UniTeam.getTeam(ep).getColor() + ep.getName() + ChatColor.RESET)).send(p));

            //increment killer kill score
            killer.getStorage().addInteger(
                    LasergameScoreboard.PLAYER_KILLS_KEY,
                    killer.getStorage().getInteger(LasergameScoreboard.PLAYER_KILLS_KEY, 0) + 1
            );

            //check team score
            int score = t.getScore() +1;
            t.setScore(score);
            if (score >= getModule().getConfig("maxTeamScore", 60)) {
                LaserGameEngine.getInstance().endGame(t);
            }
        } else {
            Bukkit.getOnlinePlayers().stream()
                    .map(p -> (UniPlayer) p)
                    .forEach(p -> new FancyMessage(Lang.str(p, "game.lasergame.kill",
                            killer.getName(),
                            Lang.str(p, gun.getExplosion().getDisplay()),
                            ep.getName())).send(p));
            //increment player kill count
            int kills = killer.getStorage().getInteger(LasergameScoreboard.PLAYER_KILLS_KEY, 0) + 1;
            killer.getStorage().addInteger(LasergameScoreboard.PLAYER_KILLS_KEY, kills);

            //check for kill needed
            if (kills >= getModule().getConfig("maxPlayerScore", 20)) {
                LaserGameEngine.getInstance().endGame(killer, gun);
            }
        }

        //update all scoreboards
        LaserGameEngine.getInstance().getOnlinePlayers().forEach(p -> {
            LasergameScoreboard sc = (LasergameScoreboard) p.getEndScoreboard();
            sc.update();
        });

        boolean voice = false;

        // Kill chain
        killer.getStorage().addInteger("game.lasergame.killchain", killer.getStorage().getInteger("game.lasergame.killchain") + 1);
        if (killer.getStorage().getInteger("game.lasergame.killchain") == 10) {
            SoundCreator.playSound(LGSound.ANNOUNCER_TEN_KILLS, SoundMaster.VOICE, 1F);
            voice = true;
        }

        // Triple/double kill
        int i = 1;
        final Tuple<Integer, Long> last = (Tuple<Integer, Long>) killer.getStorage()
                .getObject("game.lasergame.lastkill", new Tuple<>(0, 0l));
        if (last.getB() + 3000L > Calendar.getInstance().getTimeInMillis()) {
            i = last.getA();
        }
        if (i == 2) {
            SoundCreator.playSound(LGSound.ANNOUNCER_DOUBLE_KILL, SoundMaster.VOICE, 1F, killer);
            voice = true;
        } else if (i == 3) {
            SoundCreator.playSound(LGSound.ANNOUNCER_TRIPLE_KILL, SoundMaster.VOICE, 1F, killer);
            Bukkit.getScheduler().runTaskLater(LaserGameEngine.getInstance().getPlugin(), () -> SoundCreator.playSound(LGSound.PLAYER_TRIPLE_KILL, SoundMaster.VOICE, 1F, killer), 10l);
            voice = true;
        }
        killer.getStorage().addObject("game.lasergame.lastkill",
                new Tuple<>(i + 1, Calendar.getInstance().getTimeInMillis()));

        // Kill
        if (!voice && rand.nextInt() % 2 == 0) {
            SoundCreator.playSound(LGSound.PLAYER_KILL, SoundMaster.VOICE, 1F, killer);
        }
        SoundCreator.playSound(Sound.ENTITY_ARROW_HIT_PLAYER, SoundMaster.NEUTRAL, 1F, killer);

        StatManager.getInstance().addArgStat(killer, PlayerGameStat.KILL, ep.getUniqueId().toString());
        ep.setGameMode(GameMode.SPECTATOR);

        GameEngine.getInstance().getCompetingPlayers().forEach(p -> {
            if (ep.equals(p) || ep.equals(p.getSpectatorTarget())) {
                p.setSpectatorTarget(killer);
                p.sendTitle("", killer.getName(), 20, 80, 20);
            }
        });
        ep.sendActionBar(Lang.str("game.lasergame.respawn.actionbar"));
        Bukkit.getScheduler().runTaskLater(LaserGameEngine.getInstance().getPlugin(), () -> getModule().respawn(ep, true), 20L * 4L);
    }

    @EventHandler
    public void onShoot(GunShootEvent e) {
        UniPlayer pEntity = e.getPlayer();
        if (MorphAPI.getMorphManager().getOrCreateMorph(pEntity).getType() == LaserGameModule.INVULNERABLE_MORPH ||
                pEntity.isInvulnerable() ||
                pEntity.getGameMode().equals(GameMode.SPECTATOR)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onGunCooldown(GunCooldownEvent e) {
        if (!e.isCancelled()) {
            if (e.getGun() instanceof LaserGameGun) {
                if (e.touched()) {
                    e.setTime(e.getTime() / 2);
                }
            }
        }
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.SPECTATOR) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerRespawnDemand(UnitalePlayerRespawnDemandEvent e) {
        getModule().respawn(e.getPlayer(), true);
    }


    private boolean isInCooldownFor(UniPlayer p, CooldownType type) {
        int bf = cooldowns.getOrDefault(p, 0);
        return ((bf >> type.pos) & 1) == 1;
    }

    private void setCooldownFor(UniPlayer p, CooldownType type, boolean cooldown) {
        int bf = cooldowns.getOrDefault(p, 0);
        if (cooldown) bf |= (1 << type.pos);
        else bf &= ~(1 << type.pos);
        cooldowns.put(p, bf);
    }

    private enum CooldownType {
        PUSH(0);

        int pos;

        private CooldownType(int pos) {
            this.pos = pos;
        }
    }
}
