package fr.unitale.games.lasergame.weapons.effects;

import org.bukkit.Material;

import fr.unitale.games.lasergame.weapons.effects.lens.FireballLens;
import fr.unitale.games.lasergame.weapons.effects.lens.GradientLens;
import fr.unitale.games.lasergame.weapons.effects.lens.Lens;
import fr.unitale.games.lasergame.weapons.effects.lens.NormalLens;
import fr.unitale.games.lasergame.weapons.effects.lens.SpiralLens;
import fr.unitale.games.lasergame.weapons.effects.lens.TriangleLens;
import fr.unitale.games.lasergame.weapons.effects.lens.WaveLens;
import fr.unitale.sdk.features.IFeature;
import fr.unitale.sdk.utils.items.UniItemStack;

public enum LensType implements IFeature {

	NORMAL(new UniItemStack(Material.FIREWORK).setName("sdk.feature.lasergame.lens.normal.name"), false, false, new NormalLens()),
	SPIRAL(new UniItemStack(Material.SNOW_BALL).setName("sdk.feature.lasergame.lens.spiral.name"), false, true, new SpiralLens()),
	WAVE(new UniItemStack(Material.WATER_BUCKET).setName("sdk.feature.lasergame.lens.wave.name"), false, true, new WaveLens()),
	GRADIENT(new UniItemStack(Material.BONE).setName("sdk.feature.lasergame.lens.gradient.name"), true, false, new GradientLens()),
	TRIANGLE(new UniItemStack(Material.PRISMARINE_SHARD).setName("sdk.feature.lasergame.lens.triangle.name"), true, false, new TriangleLens()),
	FIREBALL(new UniItemStack(Material.FIREBALL).setName("sdk.feature.lasergame.lens.fireball.name"), true, true, new FireballLens());

	private String key;
	private UniItemStack item;
	private boolean flick;
	private boolean trail;
	private Lens lens;

	LensType(UniItemStack item, boolean flick, boolean trail, Lens lens) {
		this.item = item;
		this.flick = flick;
		this.trail = trail;
		this.lens = lens;
		this.key = "LASERGAME:LENS";
	}

	@Override
	public UniItemStack getItem() {
		return item;
	}

	public boolean hasFlicker() {
		return flick;
	}

	public boolean hasTrail() {
		return trail;
	}

	public Lens getLens() {
		return lens;
	}

	@Override
	public String getKeyTag() {
		return key;
	}

}
