package fr.unitale.games.lasergame.modules.pregame;

import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.wait.events.WaitTimeChangedEvent;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent.Status;
import org.bukkit.scheduler.BukkitRunnable;

public class PreLaserGameModuleListener extends ModuleListener<PreLaserGameModule> {

	public PreLaserGameModuleListener(PreLaserGameModule module) {
		super(module);
	}

	@EventHandler
	public void onTimerUpdated(WaitTimeChangedEvent e) {
		final int seconds = e.getTimer().getSeconds();
		final int minutes = e.getTimer().getMinutes();
		if (minutes == 0 && seconds <= 9 && seconds >= 5) {
			SoundCreator.playVoice(LGSound.valueOf("ANNOUNCER_BEGINS_" + (seconds-4) + "S"), 1F);
		} else if (minutes == 0 && seconds == 30) {
			SoundCreator.playVoice(LGSound.ANNOUNCER_BEGINS_30S, 1F);
		} else if (minutes == 1 && seconds == 0) {
			SoundCreator.playVoice(LGSound.ANNOUNCER_BEGINS_1M, 1F);
		} else if (minutes == 0 && seconds == 3) {
			SoundCreator.playVoice(LGSound.ANNOUNCER_BEGINS, 1F);
		}
	}

	@EventHandler
	public void onPlayerJoin(UnitalePlayerJoinEvent e) {
		getModule().getSpawn().randomSpawn(e.getPlayer());
	}
	
	@EventHandler
	public void onPlayerMove(PlayerMoveEvent e) {
		if(e.getTo().getY() <= 0D) {
			getModule().getSpawn().randomSpawn(e.getPlayer());
		}
	}
	
	@EventHandler
	public void onPlayerResourcePack(PlayerResourcePackStatusEvent e) {
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(e.getStatus() == Status.SUCCESSFULLY_LOADED) {
					SoundCreator.playSound(LGSound.MUSIC_START, SoundMaster.RECORDS, 1F, e.getPlayer());
				}/* else if(e.getStatus() == Status.FAILED_DOWNLOAD) {
					e.getPlayer().kickPlayer("Echec du téléchargement.");
				} else if(e.getStatus() == Status.DECLINED) {
					e.getPlayer().kickPlayer("Vous ne pouvez pas jouer sans resource pack.");
				}*/
			}
		}.runTask(UnitaleSDK.getInstance());
	}

}
