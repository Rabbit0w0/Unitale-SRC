package fr.unitale.games.lasergame.bonus;

import org.bukkit.Material;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.sdk.utils.items.UniItemStack;

public class JumpBonus extends LGPotionEffectBonus {
	
	public JumpBonus() {
		super(new PotionEffect(PotionEffectType.JUMP, 4*20, 2));
	}

	@Override
	public UniItemStack getItem() {
		return new UniItemStack(Material.CARROT_ITEM);
	}

	@Override
	public int getChance() {
		return 5;
	}
	
	@Override
	public int getDuration() {
		return 4*20;
	}

}
