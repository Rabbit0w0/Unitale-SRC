package fr.unitale.games.lasergame.weapons.effects.explosion;

import java.util.Random;

import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.items.DropFactory;

public class DropItemExplosion extends Explosion {

	private static Random rand = new Random();

	@Override
	public void explode(LaserGameGun gun, Player player, LivingEntity entity, float power) {
		DropFactory.drop(entity.getLocation().add(1, 0, 0), new ItemStack(Material.DIAMOND_HELMET), false, true, 100);
		DropFactory.drop(entity.getLocation().add(0, 0, 1), new ItemStack(Material.BONE), false, true, 100);
		final Item[] red = DropFactory.drop(entity.getLocation().add(1, 0, 1), new ItemStack(Material.REDSTONE), 20,
				false, true, 100);
		for (final Item item : red) {
			item.setVelocity(new Vector(rand.nextInt(200) - 100, rand.nextInt(200) - 100, rand.nextInt(200) - 100)
					.multiply(0.01D));
		}
	}
}
