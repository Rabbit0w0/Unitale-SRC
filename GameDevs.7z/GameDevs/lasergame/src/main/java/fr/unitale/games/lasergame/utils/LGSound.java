package fr.unitale.games.lasergame.utils;

import java.util.Random;

import org.bukkit.Sound;

import fr.unitale.sdk.utils.sound.CustomSound;

public enum LGSound implements CustomSound {

	MUSIC_START("game.lasergame.music.start", 67l),
	MUSIC_END("game.lasergame.music.end"),
	MUSIC_BACKGROUND("game.lasergame.music.background", 134l),
	// MUSIC_KILLSTREAK("game.lasergame.music.killstreak"),

	SOUND_TELEPORT("game.lasergame.sound.teleport", Sound.ENTITY_ENDERMEN_TELEPORT),
	SOUND_SUPERNOVA("game.lasergame.sound.supernova"),
	SOUND_SHOT_NORMAL("game.lasergame.sound.shot-normal", Sound.BLOCK_LEVER_CLICK),
	
	ANNOUNCER_BEGINS_1M("game.lasergame.announcer.begins_1m"),
	ANNOUNCER_BEGINS_30S("game.lasergame.announcer.begins_30s"),

	ANNOUNCER_BEGINS("game.lasergame.announcer.begins"),
	ANNOUNCER_BEGINS_1S("game.lasergame.announcer.begins_1s"),
	ANNOUNCER_BEGINS_2S("game.lasergame.announcer.begins_2s"),
	ANNOUNCER_BEGINS_3S("game.lasergame.announcer.begins_3s"),
	ANNOUNCER_BEGINS_4S("game.lasergame.announcer.begins_4s"),
	ANNOUNCER_BEGINS_5S("game.lasergame.announcer.begins_5s"),

	ANNOUNCER_DOUBLE_KILL("game.lasergame.announcer.doublekill"),
	ANNOUNCER_TRIPLE_KILL("game.lasergame.announcer.triplekill"),
	ANNOUNCER_TEN_KILLS("game.lasergame.announcer.tenkills"),

	ANNOUNCER_TEAM_FAILED("game.lasergame.announcer.team_failed"),
	ANNOUNCER_TEAM_WON("game.lasergame.announcer.team_won"),

	PLAYER_TRIPLE_KILL("game.lasergame.player.triplekill"),

	PLAYER_KILL("game.lasergame.player.kill"),

	PLAYER_NEED_KILL("game.lasergame.player.need_kill"),

	PLAYER_RESPAWN("game.lasergame.player.respawn"),

	PLAYER_ALERT_OPPONENTS("game.lasergame.player.alert_opponents"),

	PLAYER_ALERT_OPPONENTS_WIN("game.lasergame.player.alert_opponents_win"),

	PLAYER_ALERT_TEAM("game.lasergame.player.alert_team"),

	PLAYER_ALERT_TEAM_WIN("game.lasergame.player.alert_team_win"),

	PLAYER_SUPERNOVA("game.lasergame.player.supernova");

	private String key;
	private long duration;
	private Sound alternative;

	private LGSound(String key) {
		this.key = key;
	}
	
	private LGSound(String key, long duration) {
		this.key = key;
		this.duration = duration;
	}
	
	private LGSound(String key, Sound alternative) {
		this.key = key;
		this.alternative = alternative;
	}

	@Override
	public String getKey() {
		return key;
	}
	
	@Override
	public long getDuration() {
		return duration;
	}
	
	@Override
	public Sound getAlternative() {
		return alternative;
	}

	private static Random rand = new Random();

	public static LGSound rand(LGSound[] sounds) {
		return sounds[rand.nextInt(sounds.length)];
	}

}
