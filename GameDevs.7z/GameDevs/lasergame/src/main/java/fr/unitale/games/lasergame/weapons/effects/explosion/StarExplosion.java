package fr.unitale.games.lasergame.weapons.effects.explosion;

import org.bukkit.Color;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.firework.CustomFirework;
import fr.unitale.sdk.utils.firework.CustomFireworkEffect;

public class StarExplosion extends Explosion {

	@Override
	public void explode(LaserGameGun gun, Player player, LivingEntity entity, float power) {
		final CustomFireworkEffect effect = new CustomFireworkEffect(gun.getLens().hasFlicker(),
				gun.getLens().hasTrail(), Type.STAR, new Color[] { gun.getPrimaryColor() },
				new Color[] { gun.getSecondaryColor() });
		new CustomFirework(false, effect).spawn(entity.getLocation(), true);
	}

}
