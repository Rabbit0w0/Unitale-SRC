package fr.unitale.games.lasergame.aura;

import fr.unitale.sdk.features.aura.Aura;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;
import org.bukkit.Color;
import org.bukkit.Location;

public class WinnerAura extends Aura {

	private double height = 0.0D;
	private final double multiplier = 10.0D;

	private final OrdinaryColor primary;
	private final OrdinaryColor secondary;

	public WinnerAura(UniPlayer owner, Color primary, Color secondary) {
		super(owner, 1, true);
		this.primary = new OrdinaryColor(primary);
		this.secondary = new OrdinaryColor(secondary);
	}

	@Override
	protected void update() {
		height = height < 2.0D ? height + 0.05D : 0.0D;
		final double large = Math.sin(height * 0.5 * Math.PI);

		final Location loc = owner.getLocation();
		final Location p1 = loc.clone().add(Math.sin(height * multiplier) * large, height,
				Math.cos(height * multiplier) * large);
		final Location p2 = loc.clone().add(Math.sin(height * multiplier + Math.PI) * large, height,
				Math.cos(height * multiplier + Math.PI) * large);
		ParticleEffect.REDSTONE.display(primary, p1, 100.0D);
		ParticleEffect.REDSTONE.display(secondary, p2, 100.0D);
	}

}
