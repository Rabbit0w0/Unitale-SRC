package fr.unitale.games.lasergame.bonus;

import org.bukkit.potion.PotionEffect;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.effects.EffectsModule;
import fr.unitale.sdk.players.UniPlayer;

public abstract class LGPotionEffectBonus implements LGBonus {
	
	private PotionEffect effect;
	
	public LGPotionEffectBonus(PotionEffect effect) {
		this.effect = effect;
	}
	
	@Override
	public void onUsed(UniPlayer p) {
		if(p.hasPotionEffect(effect.getType())) {
			p.removePotionEffect(effect.getType());
		}
		p.addPotionEffect(effect);
	}
	
	@Override
	public void onFinished(UniPlayer p) {
		if(p.hasPotionEffect(effect.getType())) {
			p.removePotionEffect(effect.getType());
		}
		EffectsModule effects = GameEngine.getInstance().getModuleManager().getModule(EffectsModule.class);
		if(effects != null) {
			effects.setEffects(p);
		}
	}

}
