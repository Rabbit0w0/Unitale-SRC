package fr.unitale.games.lasergame.modules.game.team;

import org.bukkit.scoreboard.Team.OptionStatus;

import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;

public class LaserTeam extends UniTeam {

	private int score = 0;

	public LaserTeam(String name, UniColor color, int size) {
		super(name, color, size);
		setNameTagVisibility(OptionStatus.NEVER);
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

}
