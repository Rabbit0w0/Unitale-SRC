package fr.unitale.games.lasergame.bonus;

import java.util.Random;

import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;

public interface LGBonus {
	
	public static String BONUS_KEY = "LASERGAME-BONUS";
	
	static LGBonus[] bonus = new LGBonus[]{
			new SpeedBonus(),
			new JumpBonus()
	};
	static Random rand = new Random();
	
	public static UniItemStack random() {
		int index = rand.nextInt(bonus.length);
		LGBonus bo = bonus[index];
		
		UniItemStack item = bo.getItem();
		item.addKeyVal(BONUS_KEY, index);
		return item;
	}

	public UniItemStack getItem();
	
	public int getChance();
	
	public int getDuration();
	
	public void onUsed(UniPlayer p);
	
	public void onFinished(UniPlayer p);
	
}
