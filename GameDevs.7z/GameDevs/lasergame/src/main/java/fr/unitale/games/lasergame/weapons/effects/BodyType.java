package fr.unitale.games.lasergame.weapons.effects;

import org.bukkit.Material;

import fr.unitale.sdk.features.IFeature;
import fr.unitale.sdk.utils.items.UniItemStack;

public enum BodyType implements IFeature {

	NORMAL(30, new UniItemStack(Material.WOOD_HOE).setName("sdk.feature.lasergame.body.normal.name").setLores("sdk.feature.lasergame.body.normal.description")),
	IRON(28, new UniItemStack(Material.IRON_HOE).setName("sdk.feature.lasergame.body.iron.name").setLores("sdk.feature.lasergame.body.iron.description")),
	GOLD(26, new UniItemStack(Material.GOLD_HOE).setName("sdk.feature.lasergame.body.gold.name").setLores("sdk.feature.lasergame.body.gold.description")),
	DIAMOND(24, new UniItemStack(Material.DIAMOND_HOE).setName("sdk.feature.lasergame.body.diamond.name").setLores("sdk.feature.lasergame.body.diamond.description"));

	private String key;
	private int loadTime;
	private UniItemStack item;

	BodyType(int loadTime, UniItemStack item) {
		this.loadTime = loadTime;
		this.item = item;
		this.key = "LASERGAME:BODY";
	}

	public int getLoadTime() {
		return loadTime;
	}

	@Override
	public UniItemStack getItem() {
		return item;
	}

	@Override
	public String getKeyTag() {
		return key;
	}

}
