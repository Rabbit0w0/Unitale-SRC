package fr.unitale.games.lasergame.weapons.effects.explosion;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;

public abstract class Explosion {

	public abstract void explode(LaserGameGun gun, Player player, LivingEntity entity, float power);

}
