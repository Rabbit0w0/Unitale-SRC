package fr.unitale.games.lasergame.weapons.effects.lens;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;

public abstract class Lens {

	public abstract void playEffect(LaserGameGun gun, Player player, Location location, float power, int distance);

}
