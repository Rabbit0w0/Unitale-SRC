package fr.unitale.games.lasergame.modules.pregame;

import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.map.lasergame.LasergameMap;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.utils.sound.SoundLooper;
import fr.unitale.sdk.utils.sound.SoundMaster;

public class PreLaserGameModule extends Module<PreLaserGameModuleListener> {

	private LasergameMap spawn;

	public PreLaserGameModule() {
		this.moduleListener = new PreLaserGameModuleListener(this);
	}

	@Override
	public void startModule() {
		spawn = (LasergameMap) MapType.LASERGAME_HUB.getInstance();
		
		SoundLooper.setSound(LGSound.MUSIC_START, SoundMaster.RECORDS, 1F);
	}

	@Override
	public void endModule() {

	}

	public LasergameMap getSpawn() {
		return spawn;
	}

}
