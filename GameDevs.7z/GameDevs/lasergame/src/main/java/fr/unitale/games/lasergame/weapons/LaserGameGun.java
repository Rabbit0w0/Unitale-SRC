package fr.unitale.games.lasergame.weapons;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.games.lasergame.LaserGameEngine;
import fr.unitale.games.lasergame.modules.game.LaserGameModule;
import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.games.lasergame.weapons.effects.BodyType;
import fr.unitale.games.lasergame.weapons.effects.CanonType;
import fr.unitale.games.lasergame.weapons.effects.ExplosionType;
import fr.unitale.games.lasergame.weapons.effects.LensType;
import fr.unitale.sdk.GameSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gun.events.GunHurtEntityEvent;
import fr.unitale.sdk.gun.model.Gun;
import fr.unitale.sdk.morphs.MorphAPI;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;
import fr.unitale.sdk.utils.math.VectorUtils;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;
import net.minecraft.server.v1_10_R1.BlockPosition;
import net.minecraft.server.v1_10_R1.PacketPlayOutBlockBreakAnimation;
import net.minecraft.server.v1_10_R1.PacketPlayOutGameStateChange;
import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LaserGameGun extends Gun {

	private static Random rand = new Random();

	private static List<PotionEffect> maxShootEffects = new ArrayList<>(3);
	static {
		maxShootEffects.add(new PotionEffect(PotionEffectType.SLOW, 60, 2, false, false));
		maxShootEffects.add(new PotionEffect(PotionEffectType.WEAKNESS, 50, 2, false, false));
		maxShootEffects.add(new PotionEffect(PotionEffectType.BLINDNESS, 30, 1, false, false));
	}

	private Color primary;
	private Color secondary;
	private BodyType body;
	private CanonType canon;
	private ExplosionType explosion;
	private LensType lens;

	public LaserGameGun(Color primary, Color secondary, BodyType body, CanonType canon, ExplosionType explosion, LensType lens,
			int bullets, int maxBullets, int charger, int chargerCapacity, float power, float penetration, int distance, int loadTime, int timeBetweenShoots, float dispersion, int shoots) {
		super(bullets, maxBullets, charger, chargerCapacity, power, penetration, distance, loadTime, timeBetweenShoots, dispersion, shoots);
		this.primary = primary;
		this.secondary = secondary;
		this.body = body;
		this.canon = canon;
		this.explosion = explosion;
		this.lens = lens;
	}
	
	@Override
	public boolean shouldPlayReloadSound() {
		return false;
	}
	
	@Override
	public void playEffect(UniPlayer player, Location location, float power, int distance) {
		lens.getLens().playEffect(this, player, location, power, distance);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public void onBlockHurt(UniPlayer player, Location block, float power) {
		PacketPlayOutBlockBreakAnimation animation = new PacketPlayOutBlockBreakAnimation(rand.nextInt(), new BlockPosition(block.getBlockX(), block.getBlockY(), block.getBlockZ()), rand.nextInt(8));
		player.sendPacket(animation);
		block.getWorld().playEffect(block, Effect.TILE_BREAK, block.getBlock().getTypeId());
		super.onBlockHurt(player, block, power);
	}

	@Override
	public void onHurt(UniPlayer damager, LivingEntity entity, float power) {
		if (LaserGameEngine.getInstance().getMode() == Mode.TEAM) {
			if (entity instanceof Player && UniTeam.sameTeam(damager, (Player) entity)) {
				return;
			}
		}
		if (entity instanceof UniPlayer) {
			UniPlayer pEntity = (UniPlayer) entity;
			if (MorphAPI.getMorphManager().getOrCreateMorph(pEntity).getType() == LaserGameModule.INVULNERABLE_MORPH || pEntity.isInvulnerable()) {
				return;
			}
			getExplosion().getExplosion().explode(this, damager, entity, power);
			entity.damage(100.0D, damager);
			
			//check for kills in chain of 3
//			int killchain = damager.getStorage().getInteger("game.lasergame.killchain", 0);
//			if(killchain%3 == 0 && killchain > 0) {
//				damager.getInventory().setItem(1, new UniItemStack(Material.COMPASS).setName(Lang.str(damager, "game.infected.compass.name")).addKey("glowingitem"));
//				SoundCreator.playSound(Sound.BLOCK_SLIME_BREAK, 1.0f, damager);
//			}
		}
	}

	@Override
	public void onShoot(UniPlayer player) {
		if (canon.isCustom()) {
			SoundCreator.playSound(player.getLocation(), canon.getCustomSound(), SoundMaster.PLAYERS, canon.getVolume(), canon.getPitch());
		} else {
			SoundCreator.playSound(player.getLocation(), canon.getSound(), SoundMaster.PLAYERS, canon.getVolume(), canon.getPitch());
		}
	}
	
	@Override
	public void onShootFailed(UniPlayer player) {
		super.onShootFailed(player);
	}

	public void maxShoot(UniPlayer player, ItemStack item) {
		new MaxShootRunnable(this, player).runTaskAsynchronously(GameSDK.asJavaPlugin());
		SoundCreator.playSound(player.getLocation(), Sound.ENTITY_GUARDIAN_ATTACK, 1F, 1F, 30F);
		final PacketPlayOutGameStateChange packetAppearance = new PacketPlayOutGameStateChange(10, 0F);

		for (UniPlayer otherPlayer : GameEngine.getInstance().getOnlinePlayers()) {
			double dist = otherPlayer.getLocation().distance(player.getLocation());
			if (dist <= 10D && player != otherPlayer) {
				GunHurtEntityEvent event = new GunHurtEntityEvent(this, player, otherPlayer, 100.0f);
				Bukkit.getPluginManager().callEvent(event);
				if (!event.isCancelled()) {
					onHurt(player, otherPlayer, 100F);
					otherPlayer.sendPacket(packetAppearance);
				}
			}
		}

		SoundCreator.playSound(player.getLocation(), LGSound.PLAYER_SUPERNOVA, SoundMaster.VOICE, 1F, 1F, 30F);
		SoundCreator.playSound(player.getLocation(), LGSound.SOUND_SUPERNOVA, SoundMaster.BLOCKS, 1F, 1F, 600F);

		player.sendPacket(packetAppearance);
		player.addPotionEffects(maxShootEffects);
	}

	public Color getPrimaryColor() {
		return primary;
	}

	public Color getSecondaryColor() {
		return secondary;
	}

	public BodyType getBody() {
		return body;
	}

	public CanonType getCanon() {
		return canon;
	}

	public ExplosionType getExplosion() {
		return explosion;
	}

	public LensType getLens() {
		return lens;
	}

	private static class MaxShootRunnable extends BukkitRunnable {

		private LaserGameGun gun;
		private UniPlayer player;

		public MaxShootRunnable(LaserGameGun gun, UniPlayer player) {
			super();
			this.gun = gun;
			this.player = player;
		}

		@Override
		public void run() {
			final Location loc = player.getLocation().add(0D, 0.2D, 0D);
			final Vector dir = new Vector(10D, 0D, 0D);
			boolean test = false;
			for (float i = 0F; i < 360F; i += 9F) {
				for (float j = 0F; j < 360F; j += 9F) {
					test = !test;
					final Vector v = VectorUtils.rotateVector(dir.clone(), i, j);
					final Location loc2 = loc.clone().add(v);
					ParticleEffect.REDSTONE.display(new OrdinaryColor(test ? gun.getPrimaryColor() : gun.getSecondaryColor()), loc2, 100.0D);
					ParticleEffect.FLAME.display(v, 0.06f, loc);
				}
			}
		}

	}

}
