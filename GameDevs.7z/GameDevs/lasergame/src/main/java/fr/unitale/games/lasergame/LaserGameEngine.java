package fr.unitale.games.lasergame;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.api.type.ServerTypes.ServerType;
import fr.unitale.games.lasergame.aura.WinnerAura;
import fr.unitale.games.lasergame.modules.game.LaserGameModule;
import fr.unitale.games.lasergame.modules.game.team.LaserTeam;
import fr.unitale.games.lasergame.modules.pregame.PreLaserGameModule;
import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.games.lasergame.utils.LasergameScoreboard;
import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.features.aura.AuraAPI;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.map.lasergame.LasergameMap;
import fr.unitale.sdk.gameengine.modules.effects.EffectsModule;
import fr.unitale.sdk.gameengine.modules.futuremoves.FutureMovesModule;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.stat.PlayerStatType;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.firework.FireworkFactory;
import fr.unitale.sdk.utils.resourcepack.ResourcePackType;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundLooper;
import fr.unitale.sdk.utils.sound.SoundMaster;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Difficulty;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class LaserGameEngine extends GameEngine<LasergameMap> {

    public static LaserGameEngine __instance;

    private final Random rand = new Random();
    private static String[] types = new String[]{"LASERGAME_ENERGIUM", "LASERGAME_TRON"};

    private LaserTeam redTeam, blueTeam;

    public LaserGameEngine(JavaPlugin plugin, String json) {
        super(plugin, json);
        __instance = this;

        this.serverMode = ServerMode.fromString(getConfig("servermode", "NORMAL"));

        setKeepOffline(false);

        ServerManager.type = ServerType.LASERGAME;

        String mapName = GameEngine.getInstance().getConfig("map", getRandomMap());
        mapName = mapName.equals("null") ? getRandomMap() : mapName;
        gameMap = (LasergameMap) MapType.fromString(mapName).getInstance();
        gameMap.getWorld().setDifficulty(Difficulty.PEACEFUL);

        WeatherAPI.setTime(TimeSet.DAY, gameMap.getWorld());
        WeatherAPI.disableTime();

        redTeam = new LaserTeam(ChatColor.RED + "Red", UniColor.RED, 100);
        blueTeam = new LaserTeam(ChatColor.BLUE + "Blue", UniColor.BLUE, 100);

        getModuleManager().clear();
        TeamModule<LaserTeam> tm = new TeamModule<>(LaserTeam.class);
        if (mode == Mode.TEAM) {
            tm.addTeam(redTeam);
            tm.addTeam(blueTeam);
        }
        getModuleManager().addModule(tm, true);
        getModuleManager().addModule(new EffectsModule(), true);
        getModuleManager().addModule(new PreLaserGameModule(), true);
        getModuleManager().addModule(new FutureMovesModule().setLevitationPower(2), false);
        getModuleManager().addModule(new LaserGameModule(), false);

        WaitingModule wm = new WaitingModule(LaserGameModule.class, FutureMovesModule.class);
        wm.setMaxPlayers(gameMap.getPlayersAmount());//max player is overriden by the map's value
        getModuleManager().addModule(wm, true);


        /*
          Victory + podium place + participation
          ex:
               1st place: 15+20 = 35 gold + 1 emerald for victory
               2nd place: 10+20 = 30 gold
               3rd place: 5+20 = 25 gold
               other places: 20 gold
         */
        PlayerGameStat.VICTORY.setMoney(MoneyType.EMERALDS, 1);
        PlayerGameStat.PLACE_1.setMoney(MoneyType.GOLD, 15);
        PlayerGameStat.PLACE_2.setMoney(MoneyType.GOLD, 10);
        PlayerGameStat.PLACE_3.setMoney(MoneyType.GOLD, 5);
        PlayerGameStat.PARTICIPATION.setMoney(MoneyType.GOLD, 20);

        //enable apis used in this game
        UnitaleSDK.enableAPI(API.FEATURE, API.GUN, API.MORPH);
    }

    public static LaserGameEngine getInstance() {
        return __instance;
    }

    /**
     *  End the game with the winning player and his gun
     */
    public void endGame(Player winner, LaserGameGun gun) {
        setGameStatus(GameStatus.END);

        //add winning aura
        UnitaleSDK.getAPI(AuraAPI.class).setPlayerAura(new WinnerAura((UniPlayer) winner, gun.getPrimaryColor(), gun.getSecondaryColor()));

        //launch firework at player position
        Bukkit.getScheduler().runTaskTimer(LaserGameEngine.getInstance().getPlugin(), () -> {
            if (winner != null && winner.isOnline()) {
                FireworkFactory.spawnRandomFirework(winner.getLocation(), false);
            }
        }, 0, 50);

        //play end sound
        SoundLooper.stop();
        SoundCreator.playSound(LGSound.MUSIC_END, SoundMaster.RECORDS, 1F);

        //compute stats
        addStats();

        //call win event or eliminate player
        LaserGameEngine.getInstance().getOnlinePlayers().forEach(p -> {
            if (p == winner) {
                GameEngine.getInstance().winPlayer(p);
            } else {
                GameEngine.getInstance().eliminatePlayer(p);
            }
        });

        //end the game in 15 seconds
        endGame(20 * 15);
    }

    /**
     * End the game with the given team winning
     */
    public void endGame(LaserTeam team) {
        setGameStatus(GameStatus.END);

        //add aura to the winning players
        team.getOnlinePlayers().forEach(p -> UnitaleSDK.getAPI(AuraAPI.class).setPlayerAura(new WinnerAura(p, team.getColor().getColor(), Color.WHITE)));

        //display the winning team
        LaserGameEngine.getInstance().getOnlinePlayers().forEach(p -> p.sendMessage(Lang.str(p, "game.lasergame.win.team", team.getName())));

        //call events where players of the team won
        GameEngine.getInstance().winPlayer(team.getOnlinePlayers().toArray(new UniPlayer[team.getOnlinePlayers().size()]));

        //play sound of victory or eliminate players
        LaserGameEngine.getInstance().getCompetingPlayers().forEach(p -> {
            if (team.equals(UniTeam.getTeam(p))) {//if player is in the winning team then play voice
                SoundCreator.playVoice(LGSound.ANNOUNCER_TEAM_WON, 1F, p);
            } else {//else eliminate player
                GameEngine.getInstance().eliminatePlayer(p);
            }
        });

        //compute stats
        addStats();

        //spawn fireworks randomly
        Bukkit.getScheduler().runTaskTimer(LaserGameEngine.getInstance().getPlugin(), () -> team.getOnlinePlayers().forEach(p -> FireworkFactory.spawnRandomFirework(p.getLocation(), false)), 0, 100);

        //play end sound
        SoundLooper.stop();
        SoundCreator.playSound(LGSound.MUSIC_END, SoundMaster.RECORDS, 1F);

        //end the game in 15 seconds
        endGame(20 * 15);
    }

    /**
     * Add the stats about player participations and places
     */
    public void addStats() {
        //get all UniPlayer sorted by their number of kills
        List<UniPlayer> competing = LaserGameEngine.getInstance().getOnlinePlayers().stream()
                .sorted(
                        Comparator.comparingInt(p -> p.getStorage().getInteger(LasergameScoreboard.PLAYER_KILLS_KEY, 0))
                )
                .collect(Collectors.toList());

        //iterate through each player and set place in game stat if necessary
        for (int i = 0; i < competing.size(); i++) {
            UniPlayer p = competing.get(i);
            PlayerStatType place = PlayerGameStat.getPlace(competing.size() - i);
            if (place != null) {
                if (place == PlayerGameStat.PLACE_1) StatManager.getInstance().addStat(p, PlayerGameStat.VICTORY);
                StatManager.getInstance().addStat(p, place);
            }
        }

        //add participation to every players
        LaserGameEngine.getInstance().getOnlinePlayers().forEach(p -> StatManager.getInstance().addStat(p, PlayerGameStat.PARTICIPATION));
    }


    @Override
    protected void userJoin(UniPlayer player) {
        Bukkit.getScheduler().runTask(getPlugin(), () -> ResourcePackType.LASERGAME.send(player));
    }

    private String getRandomMap(){
        return types[rand.nextInt(types.length)];
    }

    /**
     * @return the redTeam
     */
    public LaserTeam getRedTeam() {
        return redTeam;
    }

    /**
     * @return the blueTeam
     */
    public LaserTeam getBlueTeam() {
        return blueTeam;
    }
}
