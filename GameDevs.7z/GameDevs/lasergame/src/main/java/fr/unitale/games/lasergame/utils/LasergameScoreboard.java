package fr.unitale.games.lasergame.utils;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.lasergame.LaserGameEngine;
import fr.unitale.games.lasergame.modules.game.LaserGameModule;
import fr.unitale.games.lasergame.modules.game.team.LaserTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScore;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import org.bukkit.scoreboard.DisplaySlot;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LasergameScoreboard extends UniScoreboard {

    private static final int PLAYERS_COUNT = 10;
    public static final String PLAYER_KILLS_KEY = "lasergame_kills";
    private static final String PLAYER_KILLS_LIST = "lasergame_kills_list";

    private UniPlayer owner;
    private ServerTypes.Mode mode;
    private LaserGameModule module;

    public LasergameScoreboard(UniPlayer owner, LaserGameModule module) {
        this.owner = owner;
        this.mode = LaserGameEngine.getInstance().getMode();
        this.module = module;
    }

    public void init() {
        //create side and player list board
        createSideBoard(Lang.str(owner, "game.lasergame.board"));
        addObjective("KILLS", "dummy", DisplaySlot.PLAYER_LIST, "KILLS");

        //create list board
        LaserGameEngine.getInstance().getCompetingPlayers().forEach(p -> addScore(PLAYER_KILLS_LIST + p.getUniqueId().toString(),
                p.getName(),
                p.getStorage().getInteger(PLAYER_KILLS_KEY, 0), DisplaySlot.PLAYER_LIST));

        //ajout des scores de sidebar
        int index = 0;
        addScore("space_1", " ", index++, DisplaySlot.SIDEBAR);
        addScore("maxScore",
                Lang.str(
                        "game.lasergame.score.max",
                        module.getConfig(
                                mode == ServerTypes.Mode.SOLO ? "maxPlayerScore" : "maxTeamScore",
                                mode == ServerTypes.Mode.SOLO ? 20 : 50)),
                index++,
                DisplaySlot.SIDEBAR);
        addScore("space_2", "  ", index++, DisplaySlot.SIDEBAR);
        addScore("kills", Lang.str(owner, "game.lasergame.board.kills", owner.getStorage().getInteger(PLAYER_KILLS_KEY, 0)), index++, DisplaySlot.SIDEBAR);
        if(mode == ServerTypes.Mode.TEAM){
            LaserTeam playerteam = LaserGameEngine.getInstance().getModuleManager().getTeamModule(LaserTeam.class).getTeams().stream().filter(t -> t.contains(owner)).findFirst().orElse(null);
            addScore("team", Lang.str(owner, "game.lasergame.board.team", playerteam.getColor()+playerteam.getName()), index++, DisplaySlot.SIDEBAR);
        }
        addScore("space_3", "   ", index++, DisplaySlot.SIDEBAR);
        if(mode == ServerTypes.Mode.TEAM){
            addScore("score_0", LaserGameEngine.getInstance().getRedTeam().getName(), index++, DisplaySlot.SIDEBAR);
            addScore("score_1", LaserGameEngine.getInstance().getBlueTeam().getName(), index++, DisplaySlot.SIDEBAR);
        }else{
            for (int i = 0; i < PLAYERS_COUNT; i++) {
                addScore("score_" + i, Lang.str(owner, "game.lasergame.board.none"), index++, DisplaySlot.SIDEBAR);
            }
        }
    }

    public synchronized void update() {
        getScore("kills").setData(Lang.str(owner, "game.lasergame.board.kills", ""+owner.getStorage().getInteger(PLAYER_KILLS_KEY, 0)));

        if (mode == ServerTypes.Mode.TEAM) {
            final TeamModule<LaserTeam> tm = LaserGameEngine.getInstance().getModuleManager().getTeamModule(LaserTeam.class);
            final LaserTeam playerteam = tm.getTeams().stream().filter(t -> t.contains(owner)).findFirst().orElse(null);
            getScore("team").setData(Lang.str(owner, "game.lasergame.board.team", playerteam.getColor()+playerteam.getName()));

            final AtomicReference<Integer> i = new AtomicReference<>(0);
            Stream.of(LaserGameEngine.getInstance().getBlueTeam(), LaserGameEngine.getInstance().getRedTeam())
                    .sorted(Comparator.comparingInt(LaserTeam::getScore))
                    .forEachOrdered(t -> {
                        getScore("score_"+i.get()).setData(
                                Lang.str(
                                        owner,
                                        "game.generic.score",
                                        t.getColor() + t.getName(),
                                        Lang.space("" + t.getScore(), ' ', 3)
                                )
                        );
                        //increment ref
                        i.getAndUpdate(val -> val+1);
                    });
        } else {
            final List<UniPlayer> players = getBestPlayers(PLAYER_KILLS_KEY);
            for(int i = 0; i < PLAYERS_COUNT; i++){
                final UniScore score = getScore("score_"+i);
                try{
                    final UniPlayer player = players.get(i);
                    score.setData(Lang.str(owner, "game.generic.score", player.getName(), Lang.space("" + player.getStorage().getInteger(PLAYER_KILLS_KEY, 0), ' ', 3)));
                }catch(IndexOutOfBoundsException ex){
                    score.setData(Lang.str(owner, "game.lasergame.board.none"));
                }
            }
        }
        //update list board
        LaserGameEngine.getInstance().getOnlinePlayers()
                .forEach(p -> getScore(PLAYER_KILLS_LIST + p.getUniqueId().toString()).setValue(p.getStorage().getInteger(PLAYER_KILLS_KEY, 0)));
    }

    /**
     * Get best players with a given integer key
     *
     * @param key    {@link String} key to check
     */
    private List<UniPlayer> getBestPlayers(String key) {
        List<UniPlayer> list = LaserGameEngine.getInstance().getOnlinePlayers().stream()
                .sorted(Comparator.comparing(p -> p.getStorage().getInteger(key, 0)))
                .collect(Collectors.toList());
        Collections.reverse(list);
        return list;
    }
}
