package fr.unitale.games.lasergame;

import java.util.UUID;

import fr.unitale.sdk.gameengine.PlayerInfoScored;

public class LaserGamePlayerInfo extends PlayerInfoScored {

	public LaserGamePlayerInfo(UUID uuid) {
		super(uuid);
	}

	@Override
	public void send() {

	}

}
