package fr.unitale.games.lasergame.modules.game;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.games.lasergame.LaserGameEngine;
import fr.unitale.games.lasergame.aura.RespawnAura;
import fr.unitale.games.lasergame.bonus.BonusListener;
import fr.unitale.games.lasergame.modules.pregame.PreLaserGameModule;
import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.games.lasergame.utils.LasergameScoreboard;
import fr.unitale.games.lasergame.weapons.LaserArsenal;
import fr.unitale.sdk.GameSDK;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.features.aura.AuraAPI;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.morphs.MorphAPI;
import fr.unitale.sdk.morphs.model.Morph;
import fr.unitale.sdk.morphs.model.MorphType;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemLeatherArmor;
import fr.unitale.sdk.utils.items.UniItemLeatherArmor.CustomLeatherArmorType;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundLooper;
import fr.unitale.sdk.utils.sound.SoundMaster;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Random;

public class LaserGameModule extends Module<LaserGameListener> {

	public static MorphType INVULNERABLE_MORPH = MorphType.SKELETON;
	private Random rand = new Random();
	private LaserArsenal arsenal;

	public LaserGameModule() {
		arsenal = new LaserArsenal();
		moduleListener = new LaserGameListener(this);
	}

	@Override
	public void startModule() {
		LaserGameEngine.getInstance().getCompetingPlayers().forEach(p -> {
			//set scoreboard
            LasergameScoreboard sc = new LasergameScoreboard(p, this);
            sc.init();
			p.setScoreboard(sc);

			LaserGameEngine.getInstance().getMap().randomSpawnProtected(p);
		});
		SoundCreator.playSound(LGSound.SOUND_TELEPORT, SoundMaster.NEUTRAL, 1F);

		SoundLooper.setSound(LGSound.MUSIC_BACKGROUND, SoundMaster.RECORDS, 1F);
		LaserGameEngine.getInstance().getModuleManager().removeModule(PreLaserGameModule.class);

		LaserGameEngine.getInstance().getCompetingPlayers().forEach(p -> respawn(p, false));
		
		Bukkit.getPluginManager().registerEvents(new BonusListener(), GameSDK.asJavaPlugin());
	}

	@Override
	public void endModule() {}

	public void respawn(UniPlayer ep, boolean teleport) {
		boolean hasCompass = ep.getInventory().contains(Material.COMPASS);
		ep.setGameMode(GameMode.ADVENTURE);
		ep.sendTitle("", "");
		
		if(teleport)LaserGameEngine.getInstance().getMap().randomSpawnProtected(ep);
		
		ep.setHealth(ep.getMaxHealth());
		ep.setFoodLevel(20);
		ep.setExp(1f);
		ep.getInventory().clear();
		ep.getInventory().setHeldItemSlot(0);
		ep.getStorage().addInteger("game.lasergame.killchain", 0);

		if (rand.nextInt() % 2 == 0) {
			SoundCreator.playSound(LGSound.PLAYER_RESPAWN, SoundMaster.VOICE, 1F, ep);
		}
		Morph morph = MorphAPI.getMorphManager().getOrCreateMorph(ep);
		morph.setNameDisplayed(true);
		morph.setType(INVULNERABLE_MORPH);
		ep.setInvulnerable(true);
		ep.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 1, true, false));
		UnitaleSDK.getAPI(AuraAPI.class).setPlayerAura(new RespawnAura(ep));
		
		Bukkit.getScheduler().runTaskLater(LaserGameEngine.getInstance().getPlugin(), () ->{
			if (LaserGameEngine.getInstance().getMode() == Mode.TEAM) {
				if(LaserGameEngine.getInstance().getRedTeam().contains(ep)) {
					//player is in red team
					ep.getInventory().setHelmet(new UniItemStack(Material.IRON_HELMET));
					ep.getInventory().setChestplate(new UniItemStack(Material.IRON_CHESTPLATE));
					ep.getInventory().setLeggings(new UniItemStack(Material.IRON_LEGGINGS));
					ep.getInventory().setBoots(new UniItemStack(Material.IRON_BOOTS));
				}else {
					//player is in blue team
					ep.getInventory().setHelmet(new UniItemStack(Material.DIAMOND_HELMET));
					ep.getInventory().setChestplate(new UniItemStack(Material.DIAMOND_CHESTPLATE));
					ep.getInventory().setLeggings(new UniItemStack(Material.DIAMOND_LEGGINGS));
					ep.getInventory().setBoots(new UniItemStack(Material.DIAMOND_BOOTS));
				}
			} else {
				ItemStack[] armor = new ItemStack[4];
				for (int i = 0; i < 4; i++) {
					armor[3 - i] = new UniItemLeatherArmor(CustomLeatherArmorType.values()[i], ep.getSettings().getPrimary().getColor());
				}
				ep.getInventory().setArmorContents(armor);
			}
			arsenal.reset(ep);
			ep.getInventory().setItem(0, arsenal.getItem(ep));
			if(hasCompass) {
				ep.getInventory().setItem(1, new UniItemStack(Material.COMPASS).setName("game.infected.compass.name").addKey("glowingitem").translate(ep));
			}
			
			MorphAPI.getMorphManager().deleteMorph(ep);
			ep.setInvulnerable(false);
			UnitaleSDK.getAPI(AuraAPI.class).removeAura(ep);
			ep.removePotionEffect(PotionEffectType.INVISIBILITY);
		}, 60l);
	}
	
//	public void setPlayersGlowing(UniPlayer player) {
//		LaserGameEngine.getInstance().getCompetingPlayers().stream()
//		.filter(p -> !p.equals(player))
//		.forEach(p -> {
//            SoundCreator.playSound(Sound.ENTITY_ENDERMEN_TELEPORT, 1f, player);
//            BukkitTask task = Bukkit.getScheduler().runTaskTimer(LaserGameEngine.getInstance().getPlugin(), ()->{
//            	setGlowing(player, p, true);
//            }, 0l, 1l);
//            Bukkit.getScheduler().runTaskLater(LaserGameEngine.getInstance().getPlugin(), () ->{
//            	task.cancel();
//            	setGlowing(player, p, false);
//            	SoundCreator.playSound(Sound.ENTITY_ENDERMEN_TELEPORT, 1f, player);
//            }, 200L);
//		});
//	}

//    private static void setGlowing(UniPlayer p, LivingEntity target, boolean glowing){
//        PacketPlayOutEntityMetadata ea;
//        PacketDataSerializer dataSerializer = new PacketDataSerializer(Unpooled.buffer());
//        dataSerializer.a(new byte[] {0,0,0,0,0,0,(byte)(glowing ? 1 : 0),0});
//        DataWatcher data = ((CraftLivingEntity)target).getHandle().getDataWatcher();
//        try {
//            data.a(data.c(),dataSerializer);
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        }
//        ea = new PacketPlayOutEntityMetadata(p.getId(),data,false);
//        try {
//            ea.b(dataSerializer);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        ((CraftPlayer)p).getHandle().playerConnection.sendPacket(ea);
//    }

	/**
	 * @return the arsenal
	 */
	public LaserArsenal getArsenal() {
		return arsenal;
	}
	

}
