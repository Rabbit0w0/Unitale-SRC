package fr.unitale.games.lasergame.weapons.effects.lens;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;
import fr.unitale.sdk.utils.math.VectorUtils;

public class TriangleLens extends Lens {

	@Override
	public void playEffect(LaserGameGun gun, Player player, Location location, float power, int distance) {
		final Location eye = player.getEyeLocation();
		final Color color = distance % 2 == 0 ? gun.getPrimaryColor() : gun.getSecondaryColor();

		for (double i = 0.0D; i <= 2 * Math.PI; i += (2 * Math.PI) / 3) {
			final Location particle = location.clone();
			Vector vector = new Vector(1, 1, 0);
			vector = VectorUtils.rotateAroundAxisX(vector, i);
			vector = VectorUtils.rotateVector(vector, eye.getYaw(), eye.getPitch());
			vector.multiply(0.2D);
			particle.add(vector);
			ParticleEffect.REDSTONE.display(new OrdinaryColor(color), particle, 100.0D);
		}
	}

}
