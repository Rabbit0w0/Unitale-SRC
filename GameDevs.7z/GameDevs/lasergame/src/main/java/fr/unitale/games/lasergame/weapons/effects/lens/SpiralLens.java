package fr.unitale.games.lasergame.weapons.effects.lens;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;
import fr.unitale.sdk.utils.math.VectorUtils;

public class SpiralLens extends Lens {

	@Override
	public void playEffect(LaserGameGun gun, Player player, Location location, float power, int distance) {
		final Location eye = player.getEyeLocation();
		final Location particle = location.clone();
		Vector vector = new Vector(1, 1, 0);
		vector = VectorUtils.rotateAroundAxisX(vector, (distance) * 0.3D);
		vector = VectorUtils.rotateVector(vector, eye.getYaw(), eye.getPitch());
		vector.multiply(0.2D);
		particle.add(vector);
		ParticleEffect.REDSTONE.display(new OrdinaryColor(gun.getPrimaryColor()), particle, 100.0D);
		vector.multiply(-2);
		particle.add(vector);
		ParticleEffect.REDSTONE.display(new OrdinaryColor(gun.getSecondaryColor()), particle, 100.0D);
	}

}
