package fr.unitale.games.lasergame.weapons.effects.lens;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.generic.ParticleEffect;

public class FireballLens extends Lens {

	@Override
	public void playEffect(LaserGameGun gun, Player player, Location location, float power, int distance) {
		final Location particle = location.clone();

		ParticleEffect.FLAME.display(0.05F, 0.05F, 0.05F, 0.0F, 1, particle, 100.0D);
		ParticleEffect.SMOKE_NORMAL.display(0.05F, 0.05F, 0.05F, 0.0F, 6, particle, 100.0D);
	}

}
