package fr.unitale.games.lasergame.weapons.effects.explosion;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.generic.ParticleEffect;

public class SmokeExplosion extends Explosion {

	@Override
	public void explode(LaserGameGun gun, Player player, LivingEntity entity, float power) {
		ParticleEffect.SMOKE_NORMAL.display(0.01F, 0.01F, 0.01F, 0.1F, 80, entity.getLocation().add(0, 1.5, 0), 30.0D);
	}

}
