package fr.unitale.games.lasergame.weapons.effects.lens;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.color.ColorBlender;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;

public class GradientLens extends Lens {

	@Override
	public void playEffect(LaserGameGun gun, Player player, Location location, float power, int distance) {
		final double percent = (distance) / 100.0D;
		final Color color = ColorBlender.blend(gun.getPrimaryColor(), gun.getSecondaryColor(), percent);
		ParticleEffect.REDSTONE.display(new OrdinaryColor(color), location, 100.0D);
	}

}
