package fr.unitale.games.lasergame.aura;

import fr.unitale.sdk.features.aura.Aura;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;
import fr.unitale.sdk.utils.math.MathUtils;
import org.bukkit.Color;
import org.bukkit.Location;

public class RespawnAura extends Aura {

	private double height = 0.0D;
	private final double multiplier = 10.0D;

	private final OrdinaryColor primary;
	private final OrdinaryColor secondary;

	private static final double PIx25 = Math.PI*2.5D;

	public RespawnAura(UniPlayer owner) {
		super(owner, 1, true);
		this.primary = new OrdinaryColor(Color.WHITE);
		this.secondary = new OrdinaryColor(Color.SILVER);
	}

	@Override
	protected void update() {
		height = height < 2.0D ? height + 0.05D : 0.0D;
		final double large = 1.0d;
		final double fHeight = height * multiplier;

		final Location loc = owner.getLocation();
		final Location p1 = loc.clone().add(Math.sin(fHeight) * large, height,
				Math.cos(height * multiplier) * large);
		final Location p2 = loc.clone().add(Math.sin(fHeight + Math.PI) * large, height,
				Math.cos(height * multiplier + Math.PI) * large);
		final Location p3 = loc.clone().add(Math.sin(fHeight + MathUtils.PId2) * large, height,
				Math.cos(height * multiplier) * large);
		final Location p4 = loc.clone().add(Math.sin(fHeight + PIx25) * large, height,
				Math.cos(height * multiplier + Math.PI) * large);
		ParticleEffect.REDSTONE.display(primary, p1, 100.0D);
		ParticleEffect.REDSTONE.display(secondary, p2, 100.0D);
		ParticleEffect.REDSTONE.display(primary, p3, 100.0D);
		ParticleEffect.REDSTONE.display(secondary, p4, 100.0D);
	}

}
