package fr.unitale.games.lasergame.weapons.effects.lens;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;

public class NormalLens extends Lens {

	@Override
	public void playEffect(LaserGameGun gun, Player player, Location location, float power, int distance) {
		ParticleEffect.REDSTONE.display(new OrdinaryColor(gun.getPrimaryColor()), location, 100.0D);
	}

}
