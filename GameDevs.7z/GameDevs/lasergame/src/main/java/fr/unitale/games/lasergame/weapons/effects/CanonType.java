package fr.unitale.games.lasergame.weapons.effects;

import org.bukkit.Material;
import org.bukkit.Sound;

import fr.unitale.games.lasergame.utils.LGSound;
import fr.unitale.sdk.features.IFeature;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.CustomSound;

public enum CanonType implements IFeature {

	NORMAL(LGSound.SOUND_SHOT_NORMAL, 1.0F, 10F, new UniItemStack(Material.STICK).setName("sdk.feature.lasergame.canon.normal.name")),
	BIG(Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 4F, new UniItemStack(Material.IRON_INGOT).setName("sdk.feature.lasergame.canon.big.name")),
	CAT(Sound.ENTITY_CAT_HURT, 1.0F, 5F, new UniItemStack(Material.RABBIT_HIDE).setName("sdk.feature.lasergame.canon.cat.name")),
	LIGHTNING(Sound.ENTITY_LIGHTNING_THUNDER, 1.0F, 5F, new UniItemStack(Material.REDSTONE).setName("sdk.feature.lasergame.canon.lightning.name"));

	private String key;
	private Sound sound;
	private CustomSound customSound;
	private float volume;
	private float pitch;
	private UniItemStack item;

	CanonType(Sound sound, float volume, float pitch, UniItemStack item) {
		this.sound = sound;
		this.volume = volume;
		this.pitch = pitch;
		this.item = item;
		this.key = "LASERGAME:CANON";
	}

	CanonType(CustomSound sound, float volume, float pitch, UniItemStack item) {
		this.customSound = sound;
		this.volume = volume;
		this.pitch = pitch;
		this.item = item;
		this.key = "LASERGAME:CANON";
	}

	public Sound getSound() {
		return sound;
	}

	public CustomSound getCustomSound() {
		return customSound;
	}

	public boolean isCustom() {
		return customSound != null;
	}

	public float getVolume() {
		return volume;
	}

	public float getPitch() {
		return pitch;
	}

	@Override
	public UniItemStack getItem() {
		return item;
	}

	@Override
	public String getKeyTag() {
		return key;
	}

}
