package fr.unitale.games.lasergame.bonus;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.games.lasergame.LaserGameEngine;
import fr.unitale.sdk.utils.items.event.UnitaleDroppedItemExplodeEvent;
import net.minecraft.server.v1_10_R1.NBTTagCompound;

public class BonusListener implements Listener {
	
	@EventHandler
	public void onBonusWalk(UnitaleDroppedItemExplodeEvent e) {
		if(e.getItem().hasKey(LGBonus.BONUS_KEY)) {
			NBTTagCompound tag = e.getItem().getTag();
			LGBonus bonus = LGBonus.bonus[tag.getInt(LGBonus.BONUS_KEY)];
			bonus.onUsed(e.getPlayer());
			
			new BukkitRunnable() {
				
				@Override
				public void run() {
					bonus.onFinished(e.getPlayer());
				}
			}.runTaskLater(LaserGameEngine.getInstance().getPlugin(), bonus.getDuration());
		}
	}

}
