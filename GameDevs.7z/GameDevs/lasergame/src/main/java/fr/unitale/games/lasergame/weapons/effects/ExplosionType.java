package fr.unitale.games.lasergame.weapons.effects;

import org.bukkit.Material;

import fr.unitale.games.lasergame.weapons.effects.explosion.BurstExplosion;
import fr.unitale.games.lasergame.weapons.effects.explosion.DropItemExplosion;
import fr.unitale.games.lasergame.weapons.effects.explosion.Explosion;
import fr.unitale.games.lasergame.weapons.effects.explosion.LavaExplosion;
import fr.unitale.games.lasergame.weapons.effects.explosion.NormalExplosion;
import fr.unitale.games.lasergame.weapons.effects.explosion.SmokeExplosion;
import fr.unitale.games.lasergame.weapons.effects.explosion.StarExplosion;
import fr.unitale.sdk.features.IFeature;
import fr.unitale.sdk.utils.items.UniItemStack;

public enum ExplosionType implements IFeature {

	NORMAL(new UniItemStack(Material.SLIME_BALL).setName("sdk.feature.lasergame.explosion.normal.name"), "sdk.feature.lasergame.explosion.normal.description", new NormalExplosion()),
	BURST(new UniItemStack(Material.FEATHER).setName("sdk.feature.lasergame.explosion.burst.name"), "sdk.feature.lasergame.explosion.burst.description", new BurstExplosion()),
	STAR(new UniItemStack(Material.NETHER_STAR).setName("sdk.feature.lasergame.explosion.star.name"), "sdk.feature.lasergame.explosion.star.description", new StarExplosion()),
	LAVA(new UniItemStack(Material.REDSTONE).setName("sdk.feature.lasergame.explosion.lava.name"), "sdk.feature.lasergame.explosion.lava.description", new LavaExplosion()),
	SMOKE(new UniItemStack(Material.LEAVES).setName("sdk.feature.lasergame.explosion.smoke.name"), "sdk.feature.lasergame.explosion.smoke.description", new SmokeExplosion()),
	DROPITEM(new UniItemStack(Material.DIAMOND_HELMET).setName("sdk.feature.lasergame.explosion.dropitem.name"), "sdk.feature.lasergame.explosion.dropitem.description", new DropItemExplosion());

	private String key;
	private UniItemStack item;
	private String display;
	private Explosion explosion;

	private ExplosionType(UniItemStack item, String display, Explosion explosion) {
		this.item = item;
		this.display = display;
		this.explosion = explosion;
		this.key = "LASERGAME:EXPLOSION";
	}

	@Override
	public UniItemStack getItem() {
		return item;
	}

	public String getDisplay() {
		return display;
	}

	public Explosion getExplosion() {
		return explosion;
	}

	@Override
	public String getKeyTag() {
		return key;
	}

}
