package fr.unitale.games.lasergame.weapons.effects.explosion;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import fr.unitale.games.lasergame.weapons.LaserGameGun;
import fr.unitale.sdk.utils.generic.ParticleEffect;

public class LavaExplosion extends Explosion {

	@Override
	public void explode(LaserGameGun gun, Player player, LivingEntity entity, float power) {
		ParticleEffect.DRIP_LAVA.display(0.1F, 0.1F, 0.1F, 1.0F, 200, entity.getLocation().add(0, 1.5, 0), 100.0D);
		ParticleEffect.DRIP_LAVA.display(0.2F, 0.4F, 0.1F, 1.0F, 500, entity.getLocation().add(0, 1.1, 0), 100.0D);
	}

}
