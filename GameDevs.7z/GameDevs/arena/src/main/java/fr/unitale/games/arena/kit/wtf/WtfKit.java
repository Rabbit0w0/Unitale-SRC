package fr.unitale.games.arena.kit.wtf;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.kit.AbstractKit;
import fr.unitale.games.arena.kit.wtf.item.WtfWeaponItem;
import fr.unitale.games.arena.kit.wtf.type.WtfArmors;
import fr.unitale.games.arena.kit.wtf.type.WtfHeal;
import fr.unitale.games.arena.kit.wtf.type.WtfMisc;
import fr.unitale.games.arena.kit.wtf.type.WtfWeapons;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.apache.commons.lang3.StringUtils;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class WtfKit extends AbstractKit<WtfKit> {
    public WtfKit() {
        super(0);
    }

    @Override
    public void giveTo(UniPlayer player) {
        List<ItemStack> finalStuff = stuff.stream().map(ItemStack::clone).collect(Collectors.toList());
        ItemStack[] finalArmors = new ItemStack[armors.length];
        IntStream.range(0, armors.length)
                .filter(i -> armors[i] != null)
                .forEach(i -> finalArmors[i] = armors[i].clone());

        player.getInventory().addItem(finalStuff.toArray(new ItemStack[]{}));
        player.getInventory().setArmorContents(finalArmors);
    }

    @Override
    public WtfKit clone(ArenaInstance instance) {
        final WtfKit kit = new WtfKit();
        kit.stuff = new ArrayList<>();
        IntStream.range(0, 1).forEach(i -> kit.stuff.addAll(WtfWeapons.getRandom(instance)));
        IntStream.range(0, new Random().nextInt(3) + 1).forEach(i -> kit.stuff.add(WtfMisc.getRandom(instance)));
        IntStream.range(0, new Random().nextInt(2) + 1).forEach(i -> kit.stuff.add(WtfHeal.getRandom()));
        kit.armors = WtfArmors.getRandom(instance);
        return kit;
    }
}
