package fr.unitale.games.arena.game;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.arena.effects.EffectHandler;
import fr.unitale.games.arena.game.modules.ArenaWaitingModule;
import fr.unitale.games.arena.kit.AbstractKit;
import fr.unitale.games.arena.kit.Kit;
import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.game2.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import org.apache.commons.lang3.StringUtils;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.scoreboard.DisplaySlot;

import java.util.Arrays;
import java.util.Random;

public class ArenaInstance extends Instance<ArenaInstance> {
    private int teamSize;
    private Kit kitType;
    private AbstractKit<?> kit;
    private EffectHandler effectHandler;

    public ArenaInstance(Engine<ArenaInstance> engine, MapType mapType, int teamSize, ServerTypes.ServerMode mode) {
        super(engine, "arena.json", false);

        this.effectHandler = new EffectHandler(this);
        this.teamSize = teamSize;
        kitType = Arrays.stream(Kit.values())
                .filter(kit -> kit.name().equals(getConfig("kit", "WARRIOR")) || kit.name().equals(getConfig("kit", "WARRIOR") + "_" + mode))
                .findFirst()
                .orElse(this.kitType);
        this.kit = kitType.getKit(getGameElo()).clone(this);

        ServerManager.type = ServerTypes.ServerType.fromString("ARENA_" + getConfig("kit", "WARRIOR"));
        setServerMode(mode);
        setMode(ServerTypes.Mode.TEAM);

        setMinPlayers(teamSize * 2);
        setMaxPlayers(teamSize * 2);

        // set rewards
        PlayerGameStat STAT = new PlayerGameStat();
        // team
        if (teamSize > 1) {
            STAT.VICTORY.setMoney(MoneyType.GOLD, 8);
            STAT.DEFEAT.setMoney(MoneyType.GOLD, 6);
            if (new Random().nextInt(5) == 0) {
                STAT.VICTORY.setMoney(MoneyType.EMERALDS, 1);
            }
            // solo
        } else {
            STAT.VICTORY.setMoney(MoneyType.GOLD, 6);
            STAT.DEFEAT.setMoney(MoneyType.GOLD, 4);
            if (new Random().nextInt(6) == 0) {
                STAT.VICTORY.setMoney(MoneyType.EMERALDS, 1);
            }
        }

        setGameStat(STAT);

        // load maps
        final ArenaMap map = (ArenaMap) mapType.getInstance(this);
        setMap(map);

        // disable weather
        WeatherAPI.disableTime();
        WeatherAPI.clear();
        WeatherAPI.setTime(TimeSet.DAY);

        // team module
        final TeamModule<ArenaInstance, UniTeam> teamModule = new TeamModule<>(this);
        teamModule.setTeamSize(teamSize);
        teamModule.setSizeRestrict(true);
        register(teamModule);

        // wait module
        ArenaWaitingModule waitingModule = new ArenaWaitingModule(this) {

            @Override
            public void updateWaitingModule() { // todo
                super.updateWaitingModule();
                if (getTimer().getTime() < 4 && getTimer().getTime() > 0) {
                    getInstance().getOnlinePlayers().forEach(player -> player.sendTitle(
                            Lang.str("game.arena.title.starting_in"),
                            getTimer().getTime() + " " + Lang.str("game.arena.title.second")
                                    + (getTimer().getTime() == 1 ? "" : "s")
                    ));
                    SoundCreator.playSound(Sound.BLOCK_NOTE_BASS, 1f, getOnlinePlayers());
                } else if (getTimer().getTime() == 0) {/*
                    getInstance().getOnlinePlayers().forEach(player -> player.sendTitle(
                            "§e§lPréparez-vous au combat !",
                            "Ouverture des grilles dans 10 secondes..."
                    ));
                    SoundCreator.playSound(Sound.BLOCK_NOTE_PLING, 1f, getOnlinePlayers());*/
                }
            }
        };

        waitingModule.setBoard(getBoard());
        register(waitingModule);
        // updateBoard(waitingModule.getBoard());
    }

    @Override
    public void onJoin(UniPlayer player) {
        super.onJoin(player);

        // teleport player to map's waiting room
        player.teleport(getMap(ArenaMap.class).getSpawnLocation());
        // update online players
        getModule(ArenaWaitingModule.class).getBoard().updateScore("time", ChatColor.GREEN + Lang.str("game.arena.board.waiting", String.valueOf(getOnlinePlayers().size()), String.valueOf(getMax())));
    }

    public EffectHandler getEffectHandler() {
        return effectHandler;
    }

    public int getTeamSize() {
        return teamSize;
    }

    public Kit getKitType() {
        return kitType;
    }

    public AbstractKit<?> getKit() {
        return kit;
    }

    public void updateBoard() {
        getOnlinePlayers().stream()
                .filter(p -> p.getScoreboard() != null)
                .filter(p -> p.getScoreboard().getScores("elo_text") != null)
                .forEach(p -> p.getEndScoreboard().updateScore("elo_text", Lang.str("game.arena.board.elo_average", String.valueOf(getGameElo()))));
    }

    protected UniScoreboard getBoard() {
        final UniScoreboard b = new UniScoreboard();
        int i = 0;

        b.createLifeScore();
        b.createBelowNameLifeScore();

        String modeName = StringUtils.capitalize(ServerManager.type.name().split("_")[0].toLowerCase());
        String modeType = teamSize + "vs" + teamSize;

        b.createSideBoard(ChatColor.GOLD + modeName + " " + ChatColor.GREEN + modeType);

        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("kit_text", Lang.str("game.arena.board.kit", kitType.getName()), i++, DisplaySlot.SIDEBAR);
        b.addScore("map_text", Lang.str("game.arena.board.map", getMap().getType().toString()), i++, DisplaySlot.SIDEBAR);
        b.addScore("ranked_text", Lang.str("game.arena.board.mode", Lang.str(getServerMode().getDisplay())), i++, DisplaySlot.SIDEBAR);
        if (getServerMode().equals(ServerTypes.ServerMode.RANKED)) {
            b.addScore("elo_text", Lang.str("game.arena.board.elo_average", getGameElo()), i++, DisplaySlot.SIDEBAR);
        }

        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("time", Lang.str("game.arena.board.waiting", getOnlinePlayers().size(), getMax()), i++, DisplaySlot.SIDEBAR);
        return b;
    }
}
