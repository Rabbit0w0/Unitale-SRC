package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.entities.ArenaSnowball;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.EntityDamageByPlayerListener;
import fr.unitale.games.arena.effects.listeners.types.ProjectileHitListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_10_R1.CraftServer;
import org.bukkit.craftbukkit.v1_10_R1.entity.CraftSnowball;
import org.bukkit.entity.Snowball;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.util.Vector;

public class HammerEffect extends ArenaEffect {

    private static final float strength = 1f;

    public HammerEffect(ArenaInstance instance) {
        instance.getEffectHandler().needListener(new HammerDamageListener());
        instance.getEffectHandler().needListener(new HammerHitListener());
    }

    public static class HammerDamageListener implements ArenaEffectListener<EntityDamageByEntityEvent> {

        @Override
        public boolean check(ArenaInstance instance, EntityDamageByEntityEvent event) {
            if (!(event.getEntity() instanceof UniPlayer)) return false;
            if (fromItem(((UniPlayer) event.getDamager()).getMainHandItem(), HammerEffect.class) == null) return false;

            final UniPlayer damager = (UniPlayer) event.getDamager();
            final UniPlayer target = (UniPlayer) event.getEntity();
            final Vector velocity = damager.getLocation().getDirection().clone().multiply(strength * 1.5).setY(strength);
            target.setCollidable(false);

            final CraftSnowball snowball = new CraftSnowball(
                    (CraftServer) Bukkit.getServer(),
                    new ArenaSnowball(target.getLocation().clone().add(0, 0.9, 0))
                            .setCustomSize(0.75, 1.8, 0.75)
            );

            snowball.setPassenger(target);
            snowball.setShooter(damager);
            snowball.setBounce(true);
            snowball.setSilent(true);
            snowball.setVelocity(velocity.clone());
            return true;
        }

        @Override
        public Class<? extends AbstractListener<EntityDamageByEntityEvent>> getListener() {
            return EntityDamageByPlayerListener.class;
        }
    }

    public static class HammerHitListener implements ArenaEffectListener<ProjectileHitEvent> {

        @Override
        public boolean check(ArenaInstance instance, ProjectileHitEvent event) {
            if (!(event.getEntity() instanceof Snowball)) return false;

            final Snowball snowball = (Snowball) event.getEntity();
            if (event.getEntity().getPassenger() instanceof UniPlayer) {
                final UniPlayer target = (UniPlayer) event.getEntity().getPassenger();
                target.getStorage().addBoolean("cancel_unknown_teleport", true);
                ParticleEffect.CRIT.display(
                        0.5f,
                        1f,
                        0.5f,
                        0.3f,
                        40,
                        target.getLocation()
                );

                target.damage(4);

                final Vector velocity = snowball.getVelocity().clone();
                snowball.setPassenger(null);
                snowball.remove();

                target.setVelocity(new Vector(0, 0, 0));
                target.teleport(snowball.getLocation().subtract(velocity.multiply(1.5)));
                target.setVelocity(velocity.multiply(-1.0f));
                target.getStorage().removeBoolean("cancel_unknown_teleport");
            }
            return true;
        }

        @Override
        public Class<? extends AbstractListener<ProjectileHitEvent>> getListener() {
            return ProjectileHitListener.class;
        }
    }
}
