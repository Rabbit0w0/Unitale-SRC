package fr.unitale.games.arena.effects;

import fr.unitale.sdk.utils.items.UniItemStack;

import java.util.LinkedList;
import java.util.List;

public abstract class ArenaEffect {
    private final int id;

    private static final List<ArenaEffect> EFFECTS = new LinkedList<>(); // todo passer sur une map avec en clé l'instance
                                                                         // pour éviter les fuites de mémoire
    public ArenaEffect() {
        this.id = EFFECTS.size();
        EFFECTS.add(this);
    }

    @SuppressWarnings("unchecked")
    public static <T extends ArenaEffect> T fromId(int id, Class<T> clazz) {
        return clazz.isInstance(EFFECTS.get(id)) ? (T) EFFECTS.get(id) : null;
    }

    public static <T extends ArenaEffect> T fromItem(UniItemStack stack, Class<T> clazz) {
        if (stack == null || !stack.hasKey("effect")) return null;
        return fromId(stack.getTag().getInt("effect"), clazz);
    }

    public int getId() {
        return id;
    }
}
