package fr.unitale.games.arena.kit.wtf.item;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.kit.wtf.WtfItem;
import org.bukkit.Material;

public class WtfArmorItem<T extends ArenaEffect> extends WtfItem<T> {

    public WtfArmorItem(Material material, Class<T> effect) {
        super(material, effect);
    }

    public WtfArmorItem(Material material, int number, Class<T> effect) {
        super(material, number, effect);
    }
}
