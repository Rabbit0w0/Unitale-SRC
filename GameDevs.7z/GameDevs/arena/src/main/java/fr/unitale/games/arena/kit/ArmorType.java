package fr.unitale.games.arena.kit;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;

public enum ArmorType {
    LEATHER(Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS),
    CHAIN(Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS),
    IRON(Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS),
    GOLD(Material.GOLD_HELMET, Material.GOLD_CHESTPLATE, Material.GOLD_LEGGINGS, Material.GOLD_BOOTS),
    DIAMOND(Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS);

    private ItemStack[] items;

    ArmorType(Material helmet, Material chest, Material legging, Material boots) {
        this.items = new ItemStack[]{
                new ItemStack(helmet),
                new ItemStack(chest),
                new ItemStack(legging),
                new ItemStack(boots)
        };
    }

    public ItemStack[] getItems() {
        return items;
    }

    public ItemStack[] getItems(Enchantment enchant, int level) {
        ItemStack[] array = items.clone();
        Arrays.stream(array).forEach(item -> item.addEnchantment(enchant, level));
        return items;
    }
}
