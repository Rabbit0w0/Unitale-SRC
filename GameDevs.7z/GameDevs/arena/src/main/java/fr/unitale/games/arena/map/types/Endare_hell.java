package fr.unitale.games.arena.map.types;

import fr.unitale.games.arena.map.ArenaDoorMap;
import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.games.arena.map.ArenaDoor;
import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.games.arena.map.ArenaMapType;

public class Endare_hell extends ArenaDoorMap {
    public Endare_hell(String name, World world) {
        super(ArenaMapType.ARENA_ENDARE_HELL, name, world, new Location(world, 8, 8, 45, 180, 0), new Location(world, 41.5D, 5.0D, 8.5D, 90, 0), new Location(world, -25.5D, 5.0D, 8.5D, -90, 0), new ArenaDoor(new Location(world, 36.0D, 9.0D, 7.0D), 5, 3, ArenaDoor.DoorAxis.Z_AXIS), new ArenaDoor(new Location(world, -20.0D, 9.0D, 7.0D), 5, 3, ArenaDoor.DoorAxis.Z_AXIS));
    }

    public void openArena() {
        this.northDoor.timedOpen(10L, ArenaDoor.OpenAxis.V_AXIS, ArenaDoor.TOWARDS_POSITIVE);
        this.southDoor.timedOpen(10L, ArenaDoor.OpenAxis.V_AXIS, ArenaDoor.TOWARDS_POSITIVE);
    }
}
