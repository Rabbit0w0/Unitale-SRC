package fr.unitale.games.arena.effects.listeners.types;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;

public class InteractListener extends AbstractListener<PlayerInteractEvent> {

    public InteractListener(ArenaInstance instance) {
        super(instance);
    }

    @EventHandler
    public void on(PlayerInteractEvent event) {
        if (!check(event)) return;
        process(event);
    }
}
