package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.EntityDamageByPlayerListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.DropFactory;
import org.bukkit.Material;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Random;
import java.util.stream.IntStream;

public class ShovelEffect extends ArenaEffect {

    public ShovelEffect(ArenaInstance instance) {
        instance.getEffectHandler().needListener(new ShovelHitListener());
    }

    public static class ShovelHitListener implements ArenaEffectListener<EntityDamageByEntityEvent> {
        private static final Random random = new Random();

        @Override
        public boolean check(ArenaInstance instance, EntityDamageByEntityEvent event) {
            final ShovelEffect effect = fromItem(((UniPlayer) event.getDamager()).getMainHandItem(), ShovelEffect.class);
            if (effect == null) return false;

            IntStream.range(0, new Random().nextInt(5) + 5).forEach((i) -> DropFactory.drop(
                    event.getEntity().getLocation().add(
                            random.nextFloat() - 0.5f,
                            random.nextFloat() + 0.5f,
                            random.nextFloat() - 0.5f
                    ),
                    new ItemStack(Material.DIRT),
                    false,
                    100
            ));
            return true;
        }

        @Override
        public Class<? extends AbstractListener<EntityDamageByEntityEvent>> getListener() {
            return EntityDamageByPlayerListener.class;
        }
    }
}
