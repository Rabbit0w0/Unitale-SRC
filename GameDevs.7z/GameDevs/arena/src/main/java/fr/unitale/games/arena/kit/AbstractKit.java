package fr.unitale.games.arena.kit;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unchecked")
public abstract class AbstractKit<T extends AbstractKit<T>> implements Cloneable {
    protected int elo;
    protected List<ItemStack> stuff;
    protected ItemStack[] armors;

    protected AbstractKit(int elo) {
        this.elo = elo;
        this.stuff = new ArrayList<>();
        this.armors = new ItemStack[4];
    }

    public int getElo() {
        return elo;
    }

    public T setArmor(int slot, Material type) {
        return setArmor(slot, new ItemStack(type));
    }

    public T setArmor(int slot, ItemStack item) {
        this.armors[slot] = item;
        return (T) this;
    }

    public T setArmors(ItemStack... items) {
        this.armors = items;
        return (T) this;
    }

    public T appendStuff(Material type) {
        return appendStuff(type, 1);
    }

    public T appendStuff(Material type, int amount) {
        return appendStuff(new ItemStack(type, amount));
    }

    public T appendStuff(ItemStack item) {
        stuff.add(item);
        return (T) this;
    }

    public T clone(ArenaInstance instance) {
        try {
            return (T) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public abstract void giveTo(UniPlayer player);
}
