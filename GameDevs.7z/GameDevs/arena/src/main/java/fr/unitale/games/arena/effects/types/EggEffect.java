package fr.unitale.games.arena.effects.types;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.InteractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public abstract class EggEffect extends ArenaEffect {

    public EggEffect(ArenaInstance instance) {
        instance.getEffectHandler().needListener(new EggEffectListener());
    }

    protected void useItem(UniPlayer player) {
        final UniItemStack hand = player.getMainHandItem();
        if (hand.getAmount() == 1) {
            player.setItemInHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
            player.setItemInHand(hand);
        }
    }

    protected UniTeam getOpposedTeam(ArenaInstance instance, UniPlayer player) {
        return instance.getCompetingTeams().stream()
                .filter(all -> !all.getId().equals(instance.getModule(TeamModule.class).getTeamOf(player).getId()))
                .findFirst()
                .orElse(null);
    }

    protected abstract void spawn(ArenaInstance instance, UniPlayer player, Location location);

    public static class EggEffectListener implements ArenaEffectListener<PlayerInteractEvent> {

        @Override
        public boolean check(ArenaInstance instance, PlayerInteractEvent event) {
            if (!event.getHand().equals(EquipmentSlot.HAND)
                    || !event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) return false;

            final UniPlayer player = (UniPlayer) event.getPlayer();
            final UniItemStack hand = player.getMainHandItem();
            if (hand == null || !hand.getType().equals(Material.MONSTER_EGG)) return false;

            final EggEffect effect = fromItem(hand, EggEffect.class);
            if (effect == null) return false;
            effect.spawn(instance, player, event.getClickedBlock().getRelative(event.getBlockFace()).getLocation());
            event.setCancelled(true);
            return true;
        }

        @Override
        public Class<? extends AbstractListener<PlayerInteractEvent>> getListener() {
            return InteractListener.class;
        }
    }
}
