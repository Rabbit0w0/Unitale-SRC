package fr.unitale.games.arena.map.types;

import fr.unitale.games.arena.map.ArenaDoor;
import fr.unitale.games.arena.map.ArenaDoorMap;
import fr.unitale.games.arena.map.ArenaMapType;
import org.bukkit.Location;
import org.bukkit.World;

public class Wow extends ArenaDoorMap {

    public Wow(String name, World world) {
        super(ArenaMapType.ARENA_WOW, name, world, new Location(world, 1, 60, 60, 180, 0), new Location(world, -20.5D, 54.0D, 34.5D, -90, 0), new Location(world, 20.5D, 54.0D, 34.5D, 90, 0), new ArenaDoor(new Location(world, -18.0D, 58.0D, 32.0D), 5, 4, ArenaDoor.DoorAxis.Z_AXIS), new ArenaDoor(new Location(world, 18.0D, 58.0D, 32.0D), 5, 4, ArenaDoor.DoorAxis.Z_AXIS));
    }

    @Override
    public void openArena() {
        this.northDoor.timedOpen(10L, ArenaDoor.OpenAxis.V_AXIS, ArenaDoor.TOWARDS_POSITIVE);
        this.southDoor.timedOpen(10L, ArenaDoor.OpenAxis.V_AXIS, ArenaDoor.TOWARDS_POSITIVE);
    }
}
