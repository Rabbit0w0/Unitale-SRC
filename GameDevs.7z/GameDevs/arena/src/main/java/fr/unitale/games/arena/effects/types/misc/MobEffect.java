package fr.unitale.games.arena.effects.types.misc;

import fr.unitale.games.arena.effects.types.EggEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Location;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Spider;
import org.bukkit.entity.Zombie;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Random;

public class MobEffect extends EggEffect {
    @SuppressWarnings("unchecked")
    private static final Class<? extends Monster>[] MONSTERS = (Class<? extends Monster>[]) new Class<?>[]{
            Skeleton.class,
            Spider.class,
            Zombie.class
    };

    public MobEffect(ArenaInstance instance) {
        super(instance);
    }

    protected void spawn(ArenaInstance instance, UniPlayer player, Location location) {
        useItem(player);

        UniTeam opposed = getOpposedTeam(instance, player);
        final Monster monster = player.getWorld().spawn(location, MONSTERS[new Random().nextInt(MONSTERS.length)]);
        monster.setCustomNameVisible(false);
        monster.setTarget(opposed.getOnlineCompetingPlayers().get(new Random().nextInt(opposed.getOnlineCompetingPlayers().size())));
        monster.setMetadata("attack_only", new FixedMetadataValue(UnitaleSDK.getInstance(), opposed.getName()));
    }
}
