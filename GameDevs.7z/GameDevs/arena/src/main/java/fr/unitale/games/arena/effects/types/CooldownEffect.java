package fr.unitale.games.arena.effects.types;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public abstract class CooldownEffect extends ArenaEffect {
    protected long lastUse;
    protected final int delay;

    public CooldownEffect(int delay) {
        this.lastUse = 0;
        this.delay = delay;
    }

    public boolean canUse() {
        return System.currentTimeMillis() > lastUse + delay;
    }

    @SuppressWarnings("deprecation")
    public void use(UniPlayer player) {
        UniLogger.info("starting cooldown effect");
        lastUse = System.currentTimeMillis();
        new BukkitRunnable() {
            int c = 0;
            int max = delay / 50;
            ItemStack stack = player.getItemInHand();

            @Override
            public void run() {
                if (c <= max) {
                    short i = (short) (stack.getType().getMaxDurability() - stack.getType().getMaxDurability() * c / max);
                    UniLogger.info("new durability: " + i);
                    stack.setDurability(i);
                    c++;
                } else {
                    this.cancel();
                }
            }
        }.runTaskTimer(UnitaleSDK.getInstance(), 0, 1);
    }
}
