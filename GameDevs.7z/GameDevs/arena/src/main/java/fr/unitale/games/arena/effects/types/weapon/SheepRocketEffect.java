package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.InteractListener;
import fr.unitale.games.arena.effects.listeners.types.ProjectileHitListener;
import fr.unitale.games.arena.effects.types.CooldownEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.sound.SoundCreator;
import org.bukkit.DyeColor;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Snowball;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;


public class SheepRocketEffect extends CooldownEffect {

    public SheepRocketEffect(ArenaInstance instance) {
        super(3000);
        instance.getEffectHandler().needListener(new SheepLauncherEffect());
        instance.getEffectHandler().needListener(new SheepExplosionEffect());
    }

    protected void launch(ArenaInstance instance, UniPlayer player) {
        if (!canUse()) {
            SoundCreator.playSound(Sound.BLOCK_NOTE_PLING, 1f, player);
            return;
        }

        final Vector velocity = player.getEyeLocation().clone()
                .getDirection()
                .normalize()
                .multiply(2);

        final Snowball snowball = player.getWorld().spawn(player.getEyeLocation(), Snowball.class);
        snowball.setSilent(true);
        snowball.setShooter(player);

        final Sheep sheep = (Sheep) player.getWorld().spawnEntity(player.getEyeLocation(), EntityType.SHEEP);
        sheep.setAI(false);
        sheep.setCollidable(false);
        sheep.setInvulnerable(true);
        sheep.setColor(DyeColor.RED);

        snowball.setVelocity(velocity);
        sheep.setVelocity(velocity);

        snowball.setPassenger(sheep);
        SoundCreator.playSound(Sound.ENTITY_SHEEP_HURT, 1f, instance.getOnlinePlayers());
        use(player);
    }

    private static class SheepLauncherEffect implements ArenaEffectListener<PlayerInteractEvent> {

        @Override
        public boolean check(ArenaInstance instance, PlayerInteractEvent event) {
            if (!event.getAction().equals(Action.RIGHT_CLICK_AIR)
                    && !event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) return false;
            final UniPlayer player = (UniPlayer) event.getPlayer();
            final SheepRocketEffect effect = fromItem(player.getMainHandItem(), SheepRocketEffect.class);
            if (effect == null) return false;
            effect.launch(instance, player);

            return true;
        }

        @Override
        public Class<? extends AbstractListener<PlayerInteractEvent>> getListener() {
            return InteractListener.class;
        }
    }

    private static class SheepExplosionEffect implements ArenaEffectListener<ProjectileHitEvent> {

        @Override
        public boolean check(ArenaInstance instance, ProjectileHitEvent event) {
            if (!(event.getEntity() instanceof Snowball)) return false;

            final Snowball snowball = (Snowball) event.getEntity();
            if (event.getEntity().getPassenger() instanceof Sheep) {
                final Sheep sheep = (Sheep) snowball.getPassenger();

                sheep.getWorld().createExplosion(
                        sheep.getLocation().getBlockX(),
                        sheep.getLocation().getBlockY(),
                        sheep.getLocation().getBlockZ(),
                        3,
                        false,
                        false
                );

                ParticleEffect.FLAME.display(1.6f, 1.6f, 1.6f, 0.02f, 140, sheep.getLocation());
                ParticleEffect.SMOKE_NORMAL.display(2.9f, 2.9f, 2.9f, 0.04f, 200, sheep.getLocation());
                sheep.remove();
                snowball.remove();
            }
            return false;
        }

        @Override
        public Class<? extends AbstractListener<ProjectileHitEvent>> getListener() {
            return ProjectileHitListener.class;
        }
    }
}
