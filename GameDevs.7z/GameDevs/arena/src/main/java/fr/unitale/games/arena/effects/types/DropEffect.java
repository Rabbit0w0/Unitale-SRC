package fr.unitale.games.arena.effects.types;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.InteractListener;
import fr.unitale.games.arena.effects.listeners.types.PickupItemListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.items.UniItemStack;
import net.minecraft.server.v1_10_R1.NBTTagCompound;
import org.bukkit.Bukkit;
import org.bukkit.entity.Item;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;
import java.util.function.Consumer;

public abstract class DropEffect extends ArenaEffect {
    protected double damages;
    protected ParticleEffect effect;
    protected Consumer<UniItemStack> dropReplace;

    public DropEffect(ArenaInstance instance, double damages, ParticleEffect effect) {
        this(instance, damages, effect, (item) -> {
        });
    }

    public DropEffect(ArenaInstance instance, double damages, ParticleEffect effect, Consumer<UniItemStack> dropReplace) {
        this.damages = damages;
        this.effect = effect;
        this.dropReplace = dropReplace;
        instance.getEffectHandler().needListener(new DropLaunchEffect());
        instance.getEffectHandler().needListener(new DropPickupEffect());
    }

    protected void launch(ArenaInstance instance, UniPlayer player, UniItemStack hand) {
        if (hand.getAmount() == 1) {
            player.setItemInHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
            player.setItemInHand(hand);
        }

        final UniItemStack drop = hand.clone();
        drop.setAmount(1);
        drop.addKeyVal("anti_merge", UUID.randomUUID().toString()); // todo à revoir
        drop.addKeyVal("no_pickup", true);
        drop.addKeyVal("damages", damages);
        drop.addKeyVal("team", instance.getTeamModule(UniTeam.class).getTeamOf(player).getId().toString());

        final Item item = player.getWorld().dropItem(player.getEyeLocation(), drop);
        item.setVelocity(player.getEyeLocation().getDirection().normalize().multiply(1.5));
        item.setPickupDelay(0);

        Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), () -> {
            UniItemStack stack = UniItemStack.fromItemStack(item.getItemStack());
            NBTTagCompound tag = stack.getTag();
            tag.remove("no_pickup");
            stack.setTag(tag);
            item.setItemStack(stack);
        }, 20);

        // remove damages after 4 seconds
        new BukkitRunnable() {

            @Override
            public void run() {
                effect.display(
                        0.02f,
                        0.02f,
                        0.02f,
                        0.01f,
                        2,
                        item.getLocation()
                );
                if (item.isDead() || !item.isValid()) {
                    this.cancel();
                } else if (Math.abs(item.getVelocity().getX()) < 0.08
                        && Math.abs(item.getVelocity().getZ()) < 0.08
                        && Math.abs(item.getVelocity().getZ()) < 0.08) {
                    this.cancel();

                    UniItemStack stack = UniItemStack.fromItemStack(item.getItemStack());
                    if (stack == null) return;

                    NBTTagCompound tag = stack.getTag();
                    tag.setInt("damages", 0);
                    stack.setTag(tag);
                    item.setItemStack(stack);
                }
            }
        }.runTaskTimer(UnitaleSDK.getInstance(), 0, 1);
    }

    protected void pickup(ArenaInstance instance, PlayerPickupItemEvent event, UniItemStack itemStack) {
        if (!itemStack.hasKey("damages") || !itemStack.hasKey("team")) return;

        final UniPlayer player = (UniPlayer) event.getPlayer();
        boolean sameTeam = instance.getModule(TeamModule.class).getTeamOf(player).getId().toString().equals(itemStack.getTag().getString("team"));
        if (sameTeam && itemStack.hasKey("no_pickup")) {
            event.setCancelled(true);
            return;
        }

        event.setCancelled(true);
        event.getItem().remove();

        // remove old tags
        final UniItemStack drop = itemStack.clone();
        final NBTTagCompound compound = drop.getTag();
        compound.remove("team");
        compound.remove("no_pickup");
        compound.remove("anti_merge");
        drop.setTag(compound);

        dropReplace.accept(drop);

        int damages = itemStack.getTag().getInt("damages");
        if (!sameTeam && damages > 0) {
            player.damage(damages);
            player.getWorld().dropItem(player.getLocation(), drop);
        } else {
            player.getInventory().addItem(drop);
        }
    }

    public static class DropLaunchEffect implements ArenaEffectListener<PlayerInteractEvent> {

        @Override
        public boolean check(ArenaInstance instance, PlayerInteractEvent event) {
            if (!event.getHand().equals(EquipmentSlot.HAND)) return false;

            final UniPlayer player = (UniPlayer) event.getPlayer();
            final UniItemStack hand = player.getMainHandItem();
            final DropEffect effect = fromItem(hand, DropEffect.class);
            if (effect == null) return false;

            effect.launch(instance, player, hand);
            event.setCancelled(true);

            return false;
        }

        @Override
        public Class<? extends AbstractListener<PlayerInteractEvent>> getListener() {
            return InteractListener.class;
        }
    }

    public static class DropPickupEffect implements ArenaEffectListener<PlayerPickupItemEvent> {

        @Override
        public boolean check(ArenaInstance instance, PlayerPickupItemEvent event) {
            final UniItemStack itemStack = UniItemStack.fromItemStack(event.getItem().getItemStack());
            final DropEffect effect = fromItem(itemStack, DropEffect.class);
            if (effect == null) return false;

            effect.pickup(instance, event, itemStack);
            return true;
        }

        @Override
        public Class<? extends AbstractListener<PlayerPickupItemEvent>> getListener() {
            return PickupItemListener.class;
        }
    }
}
