package fr.unitale.games.arena.effects.types.misc;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.InteractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Bukkit;
import org.bukkit.entity.Item;
import org.bukkit.entity.Wither;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Random;
import java.util.UUID;

public class PokeballEffect extends ArenaEffect {

    public PokeballEffect(ArenaInstance instance) {
        instance.getEffectHandler().needListener(new PokeballListener());
    }

    public static class PokeballListener implements ArenaEffectListener<PlayerInteractEvent> {

        @Override
        public boolean check(ArenaInstance instance, PlayerInteractEvent event) {
            final UniPlayer player = (UniPlayer) event.getPlayer();
            final UniItemStack hand = player.getMainHandItem();
            if (fromItem(hand, PokeballEffect.class) == null) return false;

            if (hand.getAmount() == 1) {
                player.setItemInHand(null);
            } else {
                hand.setAmount(hand.getAmount() - 1);
                player.setItemInHand(hand);
            }

            final UniItemStack drop = hand.clone();
            drop.setAmount(1);
            drop.addKeyVal("anti_merge", UUID.randomUUID().toString());

            final Item item = player.getWorld().dropItem(player.getEyeLocation(), drop);
            item.setVelocity(player.getEyeLocation().getDirection().normalize().multiply(1.5));
            item.setPickupDelay(10_000);

            final UniTeam opposed = instance.getCompetingTeams().stream()
                    .filter(all -> !all.getId().equals(instance.getModule(TeamModule.class).getTeamOf(player).getId()))
                    .findFirst()
                    .orElse(null);

            Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), () -> {
                item.remove();

                final Wither wither = player.getWorld().spawn(item.getLocation(), Wither.class);
                wither.setTarget(opposed.getOnlineCompetingPlayers().get(new Random().nextInt(opposed.getOnlineCompetingPlayers().size())));
                wither.setMetadata("attack_only", new FixedMetadataValue(UnitaleSDK.getInstance(), opposed.getName()));
            }, 20 * 2);
            return true;
        }

        @Override
        public Class<? extends AbstractListener<PlayerInteractEvent>> getListener() {
            return InteractListener.class;
        }
    }
}
