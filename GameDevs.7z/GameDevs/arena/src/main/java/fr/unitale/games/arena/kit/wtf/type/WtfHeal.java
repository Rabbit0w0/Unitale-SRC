package fr.unitale.games.arena.kit.wtf.type;

import fr.unitale.sdk.utils.items.UniItemPotion;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.Random;

public enum WtfHeal {
    GOLDEN_APPLE(
            new UniItemStack(
                    Material.GOLDEN_APPLE
            )
    ),
    HEAL_POTION(
            new UniItemPotion(true)
                    .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                    .setData(new PotionData(PotionType.INSTANT_HEAL))
    ),
    REGEN_POTION(
            new UniItemPotion(true)
                    .addEffect(new PotionEffect(PotionEffectType.REGENERATION, 20 * 45, 0))
                    .setData(new PotionData(PotionType.REGEN))
    );

    private final UniItemStack item;

    WtfHeal(UniItemStack item) {
        this.item = item;
    }

    public UniItemStack getItem() {
        UniItemStack stack = item.clone();
        if (this.equals(WtfHeal.GOLDEN_APPLE)) {
            stack.setAmount(new Random().nextInt(3) + 1);
        } else if (this.equals(WtfHeal.HEAL_POTION)) {
            stack.setAmount(new Random().nextInt(3) + 1);
        }
        return stack;
    }

    public static ItemStack getRandom() {
        return values()[new Random().nextInt(values().length)].getItem();
    }
}
