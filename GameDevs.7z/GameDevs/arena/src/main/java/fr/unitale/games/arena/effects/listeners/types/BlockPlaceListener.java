package fr.unitale.games.arena.effects.listeners.types;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockPlaceEvent;

public class BlockPlaceListener extends AbstractListener<BlockPlaceEvent> {

    public BlockPlaceListener(ArenaInstance instance) {
        super(instance);
    }

    @EventHandler
    public void on(BlockPlaceEvent event) {
        if (!check(event.getPlayer())) return;

        process(event);
    }
}
