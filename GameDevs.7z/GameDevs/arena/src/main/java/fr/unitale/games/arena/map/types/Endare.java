package fr.unitale.games.arena.map.types;

import fr.unitale.games.arena.map.ArenaDoorMap;
import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.games.arena.map.ArenaDoor;
import fr.unitale.games.arena.map.ArenaMapType;

public class Endare extends ArenaDoorMap {
    public Endare(String name, World world) {
        super(ArenaMapType.ARENA_ENDARE, name, world, new Location(world, -900, 32, 232, 180, 0), new Location(world, -931.5D, 29.0D, 196.5D, -90, 0), new Location(world, -869.5D, 29.0D, 196.5D, 90, 0), new ArenaDoor(new Location(world, -928.0D, 33.0D, 195.0D), 5, 3, ArenaDoor.DoorAxis.Z_AXIS), new ArenaDoor(new Location(world, -872.0D, 33.0D, 195.0D), 5, 3, ArenaDoor.DoorAxis.Z_AXIS));
    }

    public void openArena() {
        this.northDoor.timedOpen(10L, ArenaDoor.OpenAxis.V_AXIS, ArenaDoor.TOWARDS_POSITIVE);
        this.southDoor.timedOpen(10L, ArenaDoor.OpenAxis.V_AXIS, ArenaDoor.TOWARDS_POSITIVE);
    }
}
