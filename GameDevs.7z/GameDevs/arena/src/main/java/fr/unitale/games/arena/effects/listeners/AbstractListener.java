package fr.unitale.games.arena.effects.listeners;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.event.Event;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractListener<T extends Event> extends Module<ArenaInstance> {
    private List<ArenaEffectListener<T>> checks;

    public AbstractListener(ArenaInstance instance) {
        super(instance);
        this.checks = new ArrayList<>();
    }

    protected void process(T event) {
        UniLogger.info("processing " + checks.size() + " checks for listener " + getClass().getName());
        for (ArenaEffectListener<T> check : checks) {
            if (check.check(getInstance(), event)) return;
        }
    }

    @SuppressWarnings("unchecked")
    public void appendCheck(ArenaEffectListener<?> check) {
        checks.add((ArenaEffectListener<T>) check);
    }
}
