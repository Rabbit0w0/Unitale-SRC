package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.types.DropEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.utils.generic.ParticleEffect;

public class DuckEffect extends DropEffect {

    public DuckEffect(ArenaInstance instance) {
        super(instance, 5, ParticleEffect.WATER_SPLASH);
    }
}
