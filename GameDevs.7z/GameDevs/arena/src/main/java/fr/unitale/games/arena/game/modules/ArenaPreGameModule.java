package fr.unitale.games.arena.game.modules;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.map.ArenaDoorMap;
import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.sdk.game2.event.instance.PlayerQuitInstanceEvent;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.firework.FireworkFactory;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

import java.util.List;

public class ArenaPreGameModule extends Module<ArenaInstance> {
    private UniTimer arenaTimer;

    private static final int WAITING_TIME = 10;

    protected ArenaPreGameModule(ArenaInstance instance) {
        super(instance, instance.getKitType().getNewModule(instance));
    }

    @Override
    protected void onRegistered() {
        for (UniPlayer p : instance.getOnlinePlayers()) {
            p.getInventory().clear();
            instance.getKit().giveTo(p);
            p.setGameMode(GameMode.ADVENTURE);
            UniLogger.info("init player " + p.getName() + " done !");
        }

        instance.getMap(ArenaMap.class).spawnTeams();

        this.arenaTimer = TimeManager._instance.addTimer(new UniTimer("ARENA_PRE_GAME_TIMER_" + getInstance().getUniqueId(), new Updater() {
            public void start() {
            }

            public void update() {
                if (ArenaPreGameModule.this.arenaTimer.getSeconds() >= WAITING_TIME) {
                    if (instance.getMap() instanceof ArenaDoorMap) {
                        instance.getMap(ArenaDoorMap.class).openArena();
                    }

                    ArenaPreGameModule.this.arenaTimer.setTime(0, 0);
                    setTimerBoard(ChatColor.GOLD + Lang.str("game.arena.door_opening"));
                    TimeManager._instance.removeTimer(arenaTimer);
                    instance.unregister(ArenaPreGameModule.this);
                } else {
                    setTimerBoard(ChatColor.AQUA + Lang.str("game.arena.door_opening.in", WAITING_TIME - ArenaPreGameModule.this.arenaTimer.getSeconds()));
                }
            }

            public void end() {
            }
        }));
    }

    private void setTimerBoard(String s) {
        for (UniPlayer p : instance.getOnlinePlayers()) {
            p.getEndScoreboard().updateScore("time", s);
        }
    }

    /*
     * LISTENERS
     */

    @EventHandler
    public void on(PlayerMoveEvent event) {
        if (instance.getMap() instanceof ArenaDoorMap) return;
        if (!check(event)) return;

        UniTeam team = UniTeam.getTeam(getInstance(), event.getPlayer().getUniqueId());
        if (event.getPlayer().getLocation().distance(team.getSpawn()) > 2) {
            event.getPlayer().teleport(team.getSpawn());
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitInstanceEvent event) {
        if (!check(event)) return;

        final List<UniTeam> win = instance.getAvailableTeams();
        if (win.size() == 1) {
            win(win.get(0));
            instance.endGame(200);
            instance.unregister(this);
        }
    }

    @EventHandler
    public void on(PlayerInteractEvent event) {
        if (!check(event)) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW)
    public void on(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof UniPlayer) || !check((UniPlayer) event.getEntity())) return;
        event.setCancelled(true);
    }

    @EventHandler
    public void on(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof UniPlayer) || !check((UniPlayer) event.getEntity())) return;
        event.setCancelled(true);
    }

    @EventHandler
    public void on(PlayerPickupItemEvent event) {
        if (!check(event)) return;
        event.setCancelled(true);
    }

    @EventHandler
    public void on(PlayerBucketEmptyEvent event) {
        if (!(check(event))) return;
        event.setCancelled(true);
    }

    private void win(UniTeam team) {
        if (instance.getTeamSize() > 1) {
            instance.broadcast("game.uhc.win.team", team.getColor() + team.getName());
        } else {
            instance.broadcast("game.uhc.win.solo", team.getFirstAvailablePlayer().getName());
        }
        for (final UniPlayer p : instance.getOnlinePlayers()) {
            if (team.contains(p)) {
                FireworkFactory.spawnRandomFirework(p.getLocation(), true);
                instance.victoryPlayer(p);
            } else {
                instance.defeatPlayer(p);
            }
        }
    }
}
