package fr.unitale.games.arena.effects.types.armor;

import fr.unitale.games.arena.effects.ArenaEffect;

public class Glasses extends ArenaEffect {
}
