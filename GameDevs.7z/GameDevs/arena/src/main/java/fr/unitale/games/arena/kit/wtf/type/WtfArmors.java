package fr.unitale.games.arena.kit.wtf.type;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.kit.wtf.item.WtfArmorItem;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.items.*;
import org.bukkit.Color;
import org.bukkit.inventory.ItemStack;

import java.util.Random;
import java.util.stream.IntStream;

public class WtfArmors {
    private final UniItemStack[] items;

    public static final WtfArmors LEATHER = new WtfArmors(
            new UniItemStack[]{
                    new UniItemLeatherArmor(UniItemLeatherArmor.CustomLeatherArmorType.HELMET),
                    new UniItemLeatherArmor(UniItemLeatherArmor.CustomLeatherArmorType.CHESTPLATE),
                    new UniItemLeatherArmor(UniItemLeatherArmor.CustomLeatherArmorType.LEGGINGS),
                    new UniItemLeatherArmor(UniItemLeatherArmor.CustomLeatherArmorType.BOOTS)
            }
    );
    public static final WtfArmors GOLD = new WtfArmors(
            new UniItemStack[]{
                    new UniItemArmor(UniArmor.HELMET, ArmorMaterial.GOLD),
                    new UniItemArmor(UniArmor.CHESTPLATE, ArmorMaterial.GOLD),
                    new UniItemArmor(UniArmor.LEGGINGS, ArmorMaterial.GOLD),
                    new UniItemArmor(UniArmor.BOOTS, ArmorMaterial.GOLD)
            }
    );
    public static final WtfArmors CHAIN = new WtfArmors(
            new UniItemStack[]{
                    new UniItemArmor(UniArmor.HELMET, ArmorMaterial.CHAINMAIL),
                    new UniItemArmor(UniArmor.CHESTPLATE, ArmorMaterial.CHAINMAIL),
                    new UniItemArmor(UniArmor.LEGGINGS, ArmorMaterial.CHAINMAIL),
                    new UniItemArmor(UniArmor.BOOTS, ArmorMaterial.CHAINMAIL)
            }
    );

    public WtfArmors(UniItemStack[] items) {
        this.items = items;
    }

    public static WtfArmors[] values() {
        return new WtfArmors[]{
                LEATHER,
                GOLD,
                CHAIN
        };
    }

    public UniItemStack[] getItems(ArenaInstance instance) {
        UniItemStack[] stacks = new UniItemStack[items.length];
        IntStream.range(0, items.length).forEach(i -> {
            if (items[i] instanceof WtfArmorItem) {
                stacks[i] = ((WtfArmorItem<?>) items[i]).clone(instance);
            } else {
                stacks[i] = items[i].clone();
            }
        });
        return stacks;
    }

    public static ItemStack[] getRandom(ArenaInstance instance) {
        Color color = UniColor.random().getColor();
        ItemStack[] items = new ItemStack[4];
        ItemStack[] armors = values()[new Random().nextInt(values().length)].getItems(instance);
        IntStream.range(0, 4).forEach(i -> {
            if (new Random().nextBoolean()) {
                ItemStack part = armors[i];
                if (part instanceof UniItemLeatherArmor) {
                    ((UniItemLeatherArmor) part).setColor(color);
                }

                items[3 - i] = part;
            }
        });

        return items;
    }
}
