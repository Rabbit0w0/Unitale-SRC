package fr.unitale.games.arena.map;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;
import org.bukkit.Difficulty;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;

public abstract class ArenaMap extends GameMap<TeamModule<ArenaInstance, UniTeam>> {
    protected UniTeam north;
    protected UniTeam south;
    private final Location spawnLocation;
    private final Location northLocation;
    private final Location southLocation;

    public ArenaMap(MapType type, String name, World world, Location spawn, Location n, Location s) {
        super(type, name, world);
        this.team = true;
        this.spawnLocation = spawn;
        this.northLocation = n;
        this.southLocation = s;
        this.world.setDifficulty(Difficulty.EASY);

        // update gameRules
        world.setGameRuleValue("doMobSpawning", "false");
        world.setGameRuleValue("doFireTick", "false");
        world.getEntities().stream()
                .filter(entity -> entity instanceof Creature)
                .forEach(Entity::remove);
    }

    public void createTeam(TeamModule<ArenaInstance, UniTeam> tm) {
        this.north = tm.addTeam(UniColor.ORANGE, "Nord");
        this.south = tm.addTeam(UniColor.LIME, "Sud");
        north.setSpawn(getNorthLocation());
        south.setSpawn(getSouthLocation());
    }

    public Location getSpawnLocation() {
        return spawnLocation;
    }

    public Location getNorthLocation() {
        return this.northLocation;
    }

    public Location getSouthLocation() {
        return this.southLocation;
    }

    public void spawnTeams() {
        this.north.teleportation(this.northLocation);
        this.south.teleportation(this.southLocation);
    }

    public UniTeam getSouthTeam() {
        return this.south;
    }

    public UniTeam getNorthTeam() {
        return this.north;
    }
}