package fr.unitale.games.arena.kit.wtf.item;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.kit.wtf.WtfItem;
import fr.unitale.sdk.utils.items.CustomMaterial;
import org.bukkit.Material;

public class WtfMiscItem<T extends ArenaEffect> extends WtfItem<T> {

    public WtfMiscItem(Material material, Class<T> effect) {
        super(material, effect);
    }

    public WtfMiscItem(Material material, short data, Class<T> effect) {
        super(material, data, effect);
    }

    public WtfMiscItem(Material material, int amount, short data, Class<T> effect) {
        super(material, amount, data, effect);
    }

    public WtfMiscItem(CustomMaterial material, Class<T> effect) {
        super(material, effect);
    }

    public WtfMiscItem(CustomMaterial material, short data, Class<T> effect) {
        super(material, data, effect);
    }

    public WtfMiscItem(CustomMaterial material, int amount, short data, Class<T> effect) {
        super(material, amount, data, effect);
    }
}
