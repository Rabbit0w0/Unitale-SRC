package fr.unitale.games.arena.effects.types.misc;

import fr.unitale.games.arena.effects.types.EggEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Location;
import org.bukkit.entity.Creeper;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.Random;

public class CreeperEffect extends EggEffect {

    public CreeperEffect(ArenaInstance instance) {
        super(instance);
    }

    protected void spawn(ArenaInstance instance, UniPlayer player, Location location) {
        useItem(player);

        UniTeam opposed = getOpposedTeam(instance, player);
        final Creeper monster = player.getWorld().spawn(location, Creeper.class);
        monster.setCustomNameVisible(false);
        monster.setTarget(opposed.getOnlineCompetingPlayers().get(new Random().nextInt(opposed.getOnlineCompetingPlayers().size())));
        monster.setMetadata("attack_only", new FixedMetadataValue(UnitaleSDK.getInstance(), opposed.getName()));
    }
}
