package fr.unitale.games.arena.game.modules;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.event.eliminate.EliminateTeamEvent;
import fr.unitale.sdk.game2.event.instance.PlayerQuitInstanceEvent;
import fr.unitale.sdk.game2.event.player.GamePlayerWinEvent;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.firework.FireworkFactory;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.SoundCreator;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;

public class ArenaGameModule extends Module<ArenaInstance> {
    private UniTimer arenaTimer;

    protected final int maxY;

    public ArenaGameModule(ArenaInstance instance) {
        super(instance, new ArenaEndModule(instance));
        this.maxY = instance.getMap(ArenaMap.class).getNorthLocation().getBlockY() + 15;
    }

    @Override
    protected void onRegistered() {
        for (UniPlayer p : instance.getOnlinePlayers()) {
            p.setGameMode(GameMode.SURVIVAL);
        }
        getInstance().getEffectHandler().registerAll();
        this.arenaTimer = TimeManager._instance.addTimer(new UniTimer("ARENA_GAME_TIMER_" + getInstance().getUniqueId(), new Updater() {
            public void start() {
            }

            public void update() {
                updateArena();
            }

            public void end() {
            }
        }));
    }

    @Override
    protected void onUnregistered() {
        super.onUnregistered();
        getInstance().getEffectHandler().unregisterAll();
    }

    private void updateArena() {
        setTimerBoard(ChatColor.AQUA + "Fight: " + ChatColor.YELLOW + this.arenaTimer.getITime());
    }

    private void setTimerBoard(String s) {
        for (UniPlayer p : instance.getOnlinePlayers()) {
            p.getEndScoreboard().updateScore("time", s);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!check(event.getEntity())) return;

        event.setDeathMessage(null);
        event.setKeepInventory(true);
        SoundCreator.playSound(Sound.ENTITY_WITHER_SPAWN, 1f, instance.getOnlinePlayers());
        final Player deadPlayer = event.getEntity();
        deadPlayer.getInventory().clear();

        getInstance().eliminatePlayer(deadPlayer.getUniqueId());
        deadPlayer.setHealth(20);
        deadPlayer.setAllowFlight(true);
        deadPlayer.setFlying(true);
        deadPlayer.setCollidable(false);
        deadPlayer.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1, false, false));
    }

    @EventHandler
    public void onEliminatePlayer(EliminateTeamEvent event) {
        if (!check(event)) return;
        UniLogger.info("Elimination de " + event.getTeam().getName());
        if (instance.getStatus() == ServerTypes.GameStatus.END) return;

        if (instance.getCompetingTeamCount() == 0) {
            instance.endGame(200L);
            UniLogger.info("no player left");
        } else if (instance.getCompetingTeamCount() == 1) {
            // clear entities
            instance.getMap().getWorld().getEntities().stream()
                    .filter(entity -> entity instanceof Creature)
                    .forEach(Entity::remove);

            final TeamModule<ArenaInstance, UniTeam> teamModule = instance.getTeamModule(UniTeam.class);
            for (final UniTeam team : teamModule.getTeams()) {
                if (!team.isEliminated()) {
                    Bukkit.getPluginManager().callEvent(new GamePlayerWinEvent(instance, team.getOnlineCompetingPlayers()));
                    win(team);
                    instance.endGame(200L);
                    instance.unregister(this);
                    UniLogger.info("unregistered listener");
                    TimeManager._instance.removeTimer(arenaTimer);
                    return;
                }
            }
        }
    }

    private void win(UniTeam team) {
        if (instance.getTeamSize() > 1) {
            instance.broadcast("game.uhc.win.team", team.getColor() + team.getName());
        } else {
            instance.broadcast("game.uhc.win.solo", team.getFirstAvailablePlayer().getName());
        }
        for (final UniPlayer p : instance.getOnlinePlayers()) {
            if (team.contains(p)) {
                FireworkFactory.spawnRandomFirework(p.getLocation(), true);
                instance.victoryPlayer(p);
            } else {
                instance.defeatPlayer(p);
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitInstanceEvent event) {
        if (!check(event)) return;
        if (instance.getStatus() == ServerTypes.GameStatus.END) return;

        final List<UniTeam> win = instance.getAvailableTeams();
        if (win.size() == 1) {
            win(win.get(0));
            instance.endGame(200);
            instance.unregister(this);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void on(EntityDamageByEntityEvent event) {
        // prevent damages by eliminated players
        if (instance.isEliminated(event.getDamager().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void on(EntityDamageEvent event) {
        if (getInstance().isEliminated(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void on(EntityCombustByEntityEvent event) {
        if (!(event.getCombuster() instanceof Player) || !(event.getEntity() instanceof Player)) return;

        if (UniTeam.sameTeam(getInstance(), (Player) event.getCombuster(), (Player) event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void on(PlayerInteractEvent event) {
        if (!check(event)) return;
        if (instance.isEliminated(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void on(PlayerPickupItemEvent event) {
        if (!check(event)) return;
        if (instance.isEliminated(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void on(PlayerItemConsumeEvent event) {
        final UniPlayer player = (UniPlayer) event.getPlayer();
        if (!check(player)) return;

        Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), () -> {
            player.getInventory().remove(Material.GLASS_BOTTLE);
        }, 1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void on(BlockPlaceEvent event) {
        if (!check(event.getPlayer())) return;
        final UniItemStack item = UniItemStack.fromItemStack(event.getItemInHand());
        if (event.getBlock().getLocation().getBlockY() < maxY && item.hasKey("can_be_placed")) {
            event.setCancelled(false);
            if (item.hasKey("can_be_broken")) {
                event.getBlock().setMetadata("can_be_broken", new FixedMetadataValue(UnitaleSDK.getInstance(), true));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void on(BlockBreakEvent event) {
        if (!check(event.getPlayer())) return;
        if (event.getBlock().hasMetadata("can_be_broken")) {
            event.setCancelled(false);
        }
    }
}
