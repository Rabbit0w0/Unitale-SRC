package fr.unitale.games.arena.effects.listeners.types;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.entity.Arrow;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityShootBowEvent;

public class BowShootListener extends AbstractListener<EntityShootBowEvent> {

    public BowShootListener(ArenaInstance instance) {
        super(instance);
    }

    @EventHandler
    public void on(EntityShootBowEvent event) {
        if (!check(event.getEntity().getUniqueId()) || !(event.getProjectile() instanceof Arrow)) return;
        process(event);
    }
}
