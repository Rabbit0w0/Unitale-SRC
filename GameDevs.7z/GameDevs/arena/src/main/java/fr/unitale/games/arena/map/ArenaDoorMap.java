package fr.unitale.games.arena.map;

import fr.unitale.sdk.game2.map.MapType;
import org.bukkit.Location;
import org.bukkit.World;

public abstract class ArenaDoorMap extends ArenaMap {
    protected final ArenaDoor northDoor;
    protected final ArenaDoor southDoor;

    public ArenaDoorMap(MapType type, String name, World world, Location spawnLocation, Location n, Location s, ArenaDoor northDoor, ArenaDoor southDoor) {
        super(type, name, world, spawnLocation, n, s);
        this.northDoor = northDoor;
        this.southDoor = southDoor;
    }

    public abstract void openArena();
}
