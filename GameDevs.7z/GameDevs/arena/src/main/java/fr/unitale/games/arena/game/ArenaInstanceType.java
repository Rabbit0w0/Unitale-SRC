package fr.unitale.games.arena.game;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.games.arena.map.ArenaMapType;
import fr.unitale.sdk.game2.instance.InstanceType;
import fr.unitale.sdk.game2.map.MapType;

import java.util.Objects;

public class ArenaInstanceType implements InstanceType {
    private ArenaMapType map;
    private ServerTypes.ServerMode mode;
    private int size;

    public ArenaInstanceType() {
    }

    public ArenaInstanceType(ArenaInstance instance) {
        this.map = (ArenaMapType) instance.getMap().getType();
        this.mode = instance.getServerMode();
        this.size = instance.getTeamSize();
    }

    public ArenaInstanceType(ArenaMapType map, int size, ServerTypes.ServerMode mode) {
        this.map = map;
        this.mode = mode;
        this.size = size;
    }

    public ArenaMapType getMap() {
        return map;
    }

    public ServerTypes.ServerMode getMode() {
        return mode;
    }

    public int getSize() {
        return size;
    }

    @Override
    public InstanceType fromJson(String json) {
        final JsonObject object = new JsonParser().parse(json).getAsJsonObject();
        return new ArenaInstanceType(
                MapType.fromString(ArenaMapType.values(), object.get("map").getAsString()),
                object.get("teamSize").getAsInt(),
                ServerTypes.ServerMode.fromString(object.get("serverMode").getAsString())
        );
        /* pour les tests en local
        return new ArenaInstanceType(
                ArenaMapType.ARENA_ENDARE_HELL,
                1,
                ServerTypes.ServerMode.NORMAL
        );
         */
    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof ArenaInstanceType) {
            ArenaInstanceType other = (ArenaInstanceType) object;
            return other.getMap().getName().equals(map.getName()) && other.getMode().equals(mode) && other.getSize() == size;
        } else if (object instanceof ArenaInstance) {
            ArenaInstance other = (ArenaInstance) object;
            return other.getMap().getType().getName().equals(map.getName()) && other.getServerMode().equals(mode) && other.getTeamSize() == size;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(map, mode, size);
    }

    @Override
    public String toString() {
        return "ArenaInstanceType [" + map.getName() + ", " + mode.toString() + ", " + size + "]";
    }
}
