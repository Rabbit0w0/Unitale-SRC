package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.InteractListener;
import fr.unitale.games.arena.effects.types.CooldownEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.material.UniMaterial;
import fr.unitale.sdk.utils.sound.SoundCreator;
import net.minecraft.server.v1_10_R1.AxisAlignedBB;
import net.minecraft.server.v1_10_R1.Vec3D;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_10_R1.entity.CraftEntity;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MagicWandEffect extends CooldownEffect {

    public MagicWandEffect(ArenaInstance instance) {
        super(1500);
        instance.getEffectHandler().needListener(new MagicWandEffectListener());
    }

    @SuppressWarnings("ConstantConditions")
    protected void playEffect(ArenaInstance instance, UniPlayer player) {
        if (!canUse()) {
            SoundCreator.playSound(Sound.BLOCK_NOTE_PLING, 1f, player);
            return;
        }

        final Location location = player.getEyeLocation().clone();
        final Vector direction = location.getDirection().divide(new Vector(4, 4, 4));
        final List<UUID> touched = new ArrayList<>();
        final List<UniPlayer> players = instance.getCompetingTeams().stream()
                .filter(all -> !all.getId().equals(instance.getModule(TeamModule.class).getTeamOf(player).getId()))
                .findFirst()
                .orElse(null)
                .getOnlineCompetingPlayers();

        int lastDistance = 0;
        do {
            location.add(direction);

            ParticleEffect.REDSTONE.display(
                    new ParticleEffect.OrdinaryColor(255, 0, 0),
                    location,
                    20f
            );
            for (UniPlayer entity : players) {
                if (touched.contains(entity.getUniqueId()) || entity.isDead()) {
                    continue;
                }

                AxisAlignedBB box = ((CraftEntity) entity).getHandle().getBoundingBox().grow(1, 1, 1);
                if (box.a(new Vec3D(location.getX(), location.getY(), location.getZ()))) {
                    entity.damage(6);
                    touched.add(entity.getUniqueId());
                }
            }
        } while (lastDistance++ < 200 && !UniMaterial.byMaterial(location.getBlock().getType()).isSolid());

        if (touched.size() > 0) {
            SoundCreator.playSound(Sound.BLOCK_NOTE_PLING, 1f, players);
        }

        use(player);
    }

    public static class MagicWandEffectListener implements ArenaEffectListener<PlayerInteractEvent> {

        @Override
        public boolean check(ArenaInstance instance, PlayerInteractEvent event) {
            final UniPlayer player = (UniPlayer) event.getPlayer();
            final MagicWandEffect effect = fromItem(player.getMainHandItem(), MagicWandEffect.class);
            if (effect == null) return false;
            effect.playEffect(instance, player);

            return true;
        }

        @Override
        public Class<? extends AbstractListener<PlayerInteractEvent>> getListener() {
            return InteractListener.class;
        }
    }
}
