package fr.unitale.games.arena.kit;

import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ArenaKit extends AbstractKit<ArenaKit> implements Comparable<ArenaKit> {

    protected ArenaKit(int elo) {
        super(elo);
    }

    public void giveTo(UniPlayer player) {
        List<ItemStack> finalStuff = stuff.stream().map(ItemStack::clone).collect(Collectors.toList());
        player.getInventory().addItem(finalStuff.toArray(new ItemStack[]{}));

        ItemStack[] finalArmors = new ItemStack[armors.length];
        IntStream.range(0, armors.length)
                .filter(i -> armors[i] != null)
                .forEach(i -> finalArmors[i] = armors[i].clone());

        if (finalArmors.length > 0 && finalArmors[0] != null) player.getInventory().setHelmet(finalArmors[0]);
        if (finalArmors.length > 1 && finalArmors[1] != null) player.getInventory().setChestplate(finalArmors[1]);
        if (finalArmors.length > 2 && finalArmors[2] != null) player.getInventory().setLeggings(finalArmors[2]);
        if (finalArmors.length > 3 && finalArmors[3] != null) player.getInventory().setBoots(finalArmors[3]);
    }

    @Override
    public int compareTo(ArenaKit o) {
        return Integer.compare(this.elo, o.elo);
    }
}
