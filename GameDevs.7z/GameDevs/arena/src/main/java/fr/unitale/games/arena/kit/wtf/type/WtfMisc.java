package fr.unitale.games.arena.kit.wtf.type;

import fr.unitale.games.arena.effects.types.misc.CreeperEffect;
import fr.unitale.games.arena.effects.types.misc.MobEffect;
import fr.unitale.games.arena.effects.types.misc.PokeballEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.kit.wtf.item.WtfMiscItem;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.utils.items.CustomMaterial;
import fr.unitale.sdk.utils.items.UniItemPotion;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.Random;

public enum WtfMisc {
    MINI_CREEPER(
            new WtfMiscItem<>(
                    Material.MONSTER_EGG,
                    CreeperEffect.class
            ).setName("Mini Creeper").setEggType("Creeper")
    ),
    MONSTER_EGG(
            new WtfMiscItem<>(
                    Material.MONSTER_EGG,
                    MobEffect.class
            ).setName("Oeuf de monstre").setEggType("Skeleton")
    ),
    ENDER_PEARL(
            new UniItemStack(Material.ENDER_PEARL)
    ),
    FLINT_AND_STEEL(
            new UniItemStack(Material.FLINT_AND_STEEL)
    ),
    LAVA_BUCKET(
            new UniItemStack(Material.LAVA_BUCKET)
    ),
    WATER_BUCKET(
            new UniItemStack(Material.WATER_BUCKET)
    ),
    SNOWBALL(
            new UniItemStack(Material.SNOW_BALL, 16)
    ),
    POKEBALL(
            new WtfMiscItem<>(
                    CustomMaterial.POKEBALL,
                    PokeballEffect.class
            ).setName(Lang.str("game.arena.item.pokeball.name"))
    ),
    POISON_POTION(
            new UniItemPotion(3, true)
                    .addEffect(new PotionEffect(PotionEffectType.POISON, 20 * 8, 1))
                    .setData(new PotionData(PotionType.POISON))
    ),
    DAMAGES_POTION(
            new UniItemPotion(3, true)
                    .addEffect(new PotionEffect(PotionEffectType.HARM, 20, 1))
                    .setData(new PotionData(PotionType.INSTANT_DAMAGE))
    ),
    SPEED_POTION(
            new UniItemPotion(1, false)
                    .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 15, 1))
                    .setData(new PotionData(PotionType.SPEED))
    ),
    INVISIBILITY_POTION(
            new UniItemPotion(1, false)
                    .addEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 60 * 3, 0))
                    .setData(new PotionData(PotionType.INVISIBILITY))
    ),
    SLOWNESS_POTION(
            new UniItemPotion(3, true)
                    .addEffect(new PotionEffect(PotionEffectType.SLOW, 20 * 15, 3))
                    .setData(new PotionData(PotionType.SLOWNESS))
    );

    private final UniItemStack item;

    WtfMisc(UniItemStack item) {
        this.item = item;
    }

    public UniItemStack getItem(ArenaInstance instance) {
        UniItemStack stack;
        if (item instanceof WtfMiscItem) {
            stack = ((WtfMiscItem<?>) item).clone(instance);
        } else {
            stack = item.clone();
        }

        if (this.equals(WtfMisc.MONSTER_EGG)) {
            stack.setAmount(new Random().nextInt(3) + 3);
        } else if (this.equals(WtfMisc.ENDER_PEARL)) {
            stack.setAmount(new Random().nextInt(3) + 1);
        }
        return stack;
    }

    public static ItemStack getRandom(ArenaInstance instance) {
        return values()[new Random().nextInt(values().length)].getItem(instance);
    }
}
