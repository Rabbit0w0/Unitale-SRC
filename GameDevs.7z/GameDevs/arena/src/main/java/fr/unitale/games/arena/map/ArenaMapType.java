package fr.unitale.games.arena.map;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.map.types.*;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.lang.Lang;

public class ArenaMapType extends MapType {

    public static final ArenaMapType ARENA_ENDARE = new ArenaMapType("ARENA_ENDARE", "arena_endare", Endare.class, Lang.str("game.arena.map.endare.name"));
    public static final ArenaMapType ARENA_ENDARE_HELL = new ArenaMapType("ARENA_ENDARE_HELL", "arena_endare_hell", Endare_hell.class, Lang.str("game.arena.map.endare_hell.name"));
    public static final ArenaMapType ARENA_WOW = new ArenaMapType("ARENA_WOW", "arena_wow", Wow.class, Lang.str("game.arena.map.wow.name"));
    public static final ArenaMapType ARENA_MASTERBALL = new ArenaMapType("ARENA_MASTERBALL", "arena_masterball", Masterball.class, Lang.str("game.arena.map.masterball.name"));
    public static final ArenaMapType ARENA_VOLCAN = new ArenaMapType("ARENA_VOLCAN", "arena_mustafar", Volcan.class, Lang.str("game.arena.map.volcan.name"));

    protected ArenaMapType(String key, String name, Class<? extends GameMap<TeamModule<ArenaInstance, UniTeam>>> clazz, String publicName) {
        super(key, name, clazz, publicName);
    }

    public static ArenaMapType[] values() {
        return new ArenaMapType[]{
                ARENA_ENDARE,
                ARENA_ENDARE_HELL,
                ARENA_WOW,
                ARENA_MASTERBALL,
                ARENA_VOLCAN
        };
    }

    @Override
    public boolean shouldDeleteMapWhenUnloading() {
        return true;
    }
}
