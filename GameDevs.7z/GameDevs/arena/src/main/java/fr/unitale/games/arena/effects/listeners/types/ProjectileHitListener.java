package fr.unitale.games.arena.effects.listeners.types;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ProjectileHitEvent;


public class ProjectileHitListener extends AbstractListener<ProjectileHitEvent> {

    public ProjectileHitListener(ArenaInstance instance) {
        super(instance);
    }

    @EventHandler
    public void on(ProjectileHitEvent event) {
        if (!(event.getEntity().getShooter() instanceof Player) || !check((UniPlayer) event.getEntity().getShooter()))
            return;
        process(event);
    }
}
