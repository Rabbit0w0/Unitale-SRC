package fr.unitale.games.arena.effects.listeners;

import fr.unitale.games.arena.game.ArenaInstance;
import org.bukkit.event.Event;

public interface ArenaEffectListener<T extends Event> {

    boolean check(ArenaInstance instance, T event);

    Class<? extends AbstractListener<T>> getListener();
}
