package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.InteractListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.items.UniItemStack;
import net.minecraft.server.v1_10_R1.AxisAlignedBB;
import net.minecraft.server.v1_10_R1.Vec3D;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_10_R1.entity.CraftEntity;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.Random;

public class FlameThrowerEffect extends ArenaEffect {
    private final BukkitScheduler scheduler;
    private long last = 0;
    private BukkitTask releaseTask;
    private BukkitTask task;
    private final Random random;

    public FlameThrowerEffect(ArenaInstance instance) {
        this.scheduler = UnitaleSDK.getInstance().getServer().getScheduler();
        this.random = new Random();
        instance.getEffectHandler().needListener(new FlameThrowerListener());
    }

    protected void playEffect(ArenaInstance instance, UniPlayer player) {
        final UniTeam opposed = instance.getCompetingTeams().stream()
                .filter(all -> !all.getId().equals(instance.getModule(TeamModule.class).getTeamOf(player).getId()))
                .findFirst()
                .orElse(null);

        if (opposed == null) return;

        if ((System.currentTimeMillis() - last) <= 250) {
            if (task == null) {
                task = scheduler.runTaskTimer(UnitaleSDK.getInstance(), () -> {
                    // loop effect
                    final Location eyes = player.getEyeLocation().clone();
                    for (int i = 0; i < 50; i++) {
                        ParticleEffect.FLAME.display(
                                eyes.getDirection().add(new Vector(randFloat(-0.3f, 0.3f), randFloat(-0.3f, 0.3f), randFloat(-0.3f, 0.3f))),
                                randFloat(0.225f, 0.4f), eyes, 40);
                    }

                    final Vector direction = eyes.getDirection().divide(new Vector(4, 4, 4));
                    new BukkitRunnable() {
                        int distance = 0;

                        @Override
                        public void run() {
                            eyes.add(direction);
                            for (UniPlayer all : opposed.getOnlineCompetingPlayers()) {
                                final AxisAlignedBB box = ((CraftEntity) all).getHandle().getBoundingBox();
                                if (box.grow(0.5, 0.5, 0.5).a(new Vec3D(eyes.getX(), eyes.getY(), eyes.getZ()))) {
                                    all.damage(1.5);
                                    all.setFireTicks(40);
                                }
                            }
                            if (distance++ > 25) {
                                this.cancel();
                            }
                        }
                    }.runTaskTimer(UnitaleSDK.getInstance(), 0, 1);
                }, 0, 1);
            }
            if (releaseTask != null && scheduler.isQueued(releaseTask.getTaskId())) {
                scheduler.cancelTask(releaseTask.getTaskId());
            }
            releaseTask = scheduler.runTaskLater(UnitaleSDK.getInstance(), () -> {
                // cancelled
                if (task != null) {
                    task.cancel();
                    task = null;
                }
            }, 6);
        }

        last = System.currentTimeMillis();
    }

    private float randFloat(float min, float max) {
        return min + random.nextFloat() * (max - min);
    }

    public static class FlameThrowerListener implements ArenaEffectListener<PlayerInteractEvent> {
        @Override
        public boolean check(ArenaInstance instance, PlayerInteractEvent event) {
            if (!event.getAction().equals(Action.RIGHT_CLICK_AIR)
                    && !event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) return false;

            final UniPlayer player = (UniPlayer) event.getPlayer();
            final FlameThrowerEffect effect = fromItem(player.getMainHandItem(), FlameThrowerEffect.class);
            if (effect == null) return false;
            effect.playEffect(instance, player);

            return true;
        }

        @Override
        public Class<? extends AbstractListener<PlayerInteractEvent>> getListener() {
            return InteractListener.class;
        }
    }
}
