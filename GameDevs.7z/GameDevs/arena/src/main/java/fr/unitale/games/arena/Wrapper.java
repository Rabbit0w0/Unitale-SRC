package fr.unitale.games.arena;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.game.ArenaInstanceType;
import fr.unitale.games.arena.game.modules.ArenaGlobalListeners;
import fr.unitale.games.arena.map.ArenaMapType;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.instance.InstanceType;
import fr.unitale.sdk.game2.room.PassingRoom;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Wrapper extends JavaPlugin {

    @Override
    public void onEnable() {
        UniLogger.info("Arena Wrapper launched !");

        // set gameplay
        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);

        // register global listeners
        GameSDK2.register(new ArenaGlobalListeners());

        // init instance factories

        Engine<ArenaInstance> engine = new Engine<ArenaInstance>(this, new ArenaInstanceType(), new PassingRoom()) {

            @Override
            public List<Instance<ArenaInstance>> getInstances(InstanceType instanceType) {
                ArenaInstanceType type = (ArenaInstanceType) instanceType;
                return getInstances().stream() // c'est pas très jouly mais temporairement ça marche
                        .filter(instance -> type.getMode() == instance.getServerMode() && ((ArenaInstance) instance).getTeamSize() == type.getSize())
                        .collect(Collectors.toList());
            }
        };

        /* pour les tests en local
        engine.addFactory(new ArenaInstanceType(
                ArenaMapType.ARENA_ENDARE_HELL,
                1,
                ServerTypes.ServerMode.NORMAL
        ), f -> new ArenaInstance(
                engine,
                ArenaMapType.ARENA_ENDARE_HELL,
                1,
                ServerTypes.ServerMode.NORMAL
        ));
        */

        Arrays.stream(ArenaMapType.values()).forEach(type -> IntStream.range(1, 4).forEach(i -> {
            engine.addFactory(new ArenaInstanceType(type, i, ServerTypes.ServerMode.NORMAL), f -> new ArenaInstance(engine, type, i, ServerTypes.ServerMode.NORMAL));
            // engine.addFactory(new ArenaInstanceType(type, i, ServerTypes.ServerMode.RANKED), f -> new ArenaInstance(engine, type, i, ServerTypes.ServerMode.RANKED));
        }));

        GameSDK2.startEngine(engine);
    }
}
