package fr.unitale.games.arena.game.modules;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.sdk.game2.event.instance.PlayerJoinInstanceEvent;
import fr.unitale.sdk.players.UniPlayer;

public class ArenaWaitingModule extends WaitingModule<ArenaInstance> { // todo cleanup code

    public ArenaWaitingModule(ArenaInstance instance) {
        super(instance, new ArenaPreGameModule(instance));
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent e) {
        if (e.getEntity().getType() != EntityType.PLAYER) return;
        if (getInstance().getStatus() != ServerTypes.GameStatus.GAME && getInstance().contains((UniPlayer) e.getEntity()))
            e.setCancelled(true);
    }

    @EventHandler
    protected void userJoin(PlayerJoinInstanceEvent event) {
        if (getInstance().getUniqueId().equals(event.getInstance().getUniqueId())) {
            getInstance().setGameElo();
            getInstance().updateBoard();
        }
    }
}
