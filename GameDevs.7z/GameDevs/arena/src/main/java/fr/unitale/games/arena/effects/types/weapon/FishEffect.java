package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.types.DropEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.kit.wtf.type.WtfWeapons;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.items.CustomMaterial;

public class FishEffect extends DropEffect {

    public FishEffect(ArenaInstance instance) {
        super(instance, 5, ParticleEffect.WATER_DROP, (drop) -> {
            CustomMaterial fish = WtfWeapons.getRandomFish();
            drop.setType(fish);
        });
    }
}
