package fr.unitale.games.arena.kit.wtf.type;

import fr.unitale.games.arena.effects.types.weapon.*;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.kit.wtf.item.WtfWeaponItem;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.utils.items.CustomMaterial;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public enum WtfWeapons {
    PLASTIC_DUCK(
            new WtfWeaponItem<>(
                    CustomMaterial.DUCK,
                    5,
                    DuckEffect.class
            ).setName(Lang.str("game.arena.item.duck.name"))
    ),
    FISH(
            new WtfWeaponItem<>(
                    getRandomFish(),
                    5,
                    FishEffect.class
            ).setName(Lang.str("game.arena.item.fish.name"))
    ),
    ROCKET_LAUNCHER(
            new WtfWeaponItem<>(
                    CustomMaterial.ROQUETTE_MOUTON,
                    SheepRocketEffect.class
            ).setName(Lang.str("game.arena.item.sheep_launcher.name"))
    ),
    SWORD_OF_DESTINY(
            new UniItemStack(CustomMaterial.EXORDIUM)
                    .setName(Lang.str("game.arena.item.sword_of_destiny.name"))
                    .addItemFlags(ItemFlag.HIDE_ENCHANTS)
                    .addLore(Lang.str("game.arena.item.sword_of_destiny.desc"))
                    .addLore(" ")
                    .addLore("§7Sharpness C [100]")
                    .addNewUnsafeEnchantment(Enchantment.DAMAGE_ALL, 100)
    ),
    CUPIDS_BOW(
            new WtfWeaponItem<>(
                    Material.BOW,
                    CupidEffect.class
            ).setName(Lang.str("game.arena.item.cupids_bow.name"))
                    .addNewUnsafeEnchantment(Enchantment.ARROW_INFINITE, 1)
                    .addLore(Lang.str("game.arena.item.cupids_bow.desc"))
                    .addItemFlags(ItemFlag.HIDE_ENCHANTS),
            new UniItemStack(Material.ARROW)
    ),
    SMASH_HAMMER(
            new WtfWeaponItem<>(
                    CustomMaterial.SMASH_HAMMER,
                    HammerEffect.class
            ).setName(Lang.str("game.arena.item.smash_hammer.name"))
                    .addKeyVal("damages", 2)
    ),
    MAGIC_WAND(
            new WtfWeaponItem<>(
                    CustomMaterial.JUNGLE_WAND,
                    MagicWandEffect.class
            ).setName(Lang.str("game.arena.item.magic_wand.name"))
    ),
    TOILET_BRUSH(
            new WtfWeaponItem<>(
                    CustomMaterial.BROSSE,
                    ToiletBrushEffect.class
            ).setName(Lang.str("game.arena.item.toilet_brush.name"))
                    .addLore(Lang.str("game.arena.item.toilet_brush.desc"))
                    .addKeyVal("damages", 5)
    ),
    LIGHT_SABER(
            new UniItemStack(getRandomSaber())
                    .setName(Lang.str("game.arena.item.laser_sword.name"))
                    .addLore(Lang.str("game.arena.item.laser_sword.desc"))
                    .addKeyVal("damages", 7)
    ),
    EXCALIBUR(
            new UniItemStack(CustomMaterial.EXCALIBUR)
                    .setName(Lang.str("game.arena.item.excalibur.name"))
                    .addLore(Lang.str("game.arena.item.excalibur.desc"))
    ),
    IRON_SHOVEL(
            new WtfWeaponItem<>(
                    Material.IRON_SPADE,
                    ShovelEffect.class
            ).setName(Lang.str("game.arena.item.iron_shovel.name"))
                    .addLore(Lang.str("game.arena.item.iron_shovel.desc"))
    ),
    SIGN(
            new UniItemStack(Material.SIGN)
                    .setName(Lang.str("game.arena.item.sign.name"))
                    .addLore(Lang.str("game.arena.item.sign.desc"))
                    .addNewUnsafeEnchantment(Enchantment.DAMAGE_ALL, 3)
                    .addNewUnsafeEnchantment(Enchantment.FIRE_ASPECT, 1)
                    .addNewUnsafeEnchantment(Enchantment.KNOCKBACK, 1)
    ),
    FLAME_THROWER(
            new WtfWeaponItem<>(
                    Material.DIAMOND_HOE,
                    FlameThrowerEffect.class
            ).setName(Lang.str("game.arena.item.flame_thrower.name"))
                    .addLore(Lang.str("game.arena.item.flame_thrower.desc"))
    );

    private final ItemStack[] items;

    WtfWeapons(ItemStack... items) {
        this.items = items;
    }

    public ItemStack[] getItems(ArenaInstance instance) {
        ItemStack[] stacks = new ItemStack[items.length];
        IntStream.range(0, items.length).forEach(i -> {
            if (items[i] instanceof WtfWeaponItem) {
                stacks[i] = ((WtfWeaponItem<?>) items[i]).clone(instance);
            } else {
                stacks[i] = items[i].clone();
            }
        });
        return stacks;
    }

    public static List<ItemStack> getRandom(ArenaInstance instance) {
        return Arrays.stream(values()[new Random().nextInt(values().length)].getItems(instance))
                .collect(Collectors.toList());
    }

    public static CustomMaterial getRandomFish() {
        final CustomMaterial[] FISHES = new CustomMaterial[]{
                CustomMaterial.ROTTEN_FISH,
                CustomMaterial.ROTTEN_CLOWNFISH,
                CustomMaterial.ROTTEN_PUFFERFISH,
                CustomMaterial.ROTTEN_SALMON
        };
        return FISHES[new Random().nextInt(FISHES.length)];
    }

    public static CustomMaterial getRandomSaber() {
        final CustomMaterial[] SABERS = new CustomMaterial[]{
                CustomMaterial.BLUE_LIGHTSABER,
                CustomMaterial.LIME_LIGHTSABER,
                CustomMaterial.CYAN_LIGHTSABER,
                CustomMaterial.ORANGE_LIGHTSABER,
                CustomMaterial.PURPLE_LIGHTSABER,
                CustomMaterial.WHITE_LIGHTSABER,
                CustomMaterial.GREEN_LIGHTSABER,
                CustomMaterial.RED_LIGHTSABER
        };
        return SABERS[new Random().nextInt(SABERS.length)];
    }

/*
    public static List<ItemStack> getRandom() {
        List<ItemStack> items = new ArrayList<>();
        for (WtfWeapons wtfWeapons : values()) {
            for (ItemStack stack : wtfWeapons.items) {
                items.add(stack.clone());
            }
        }
        return items;
    }
    */
}
