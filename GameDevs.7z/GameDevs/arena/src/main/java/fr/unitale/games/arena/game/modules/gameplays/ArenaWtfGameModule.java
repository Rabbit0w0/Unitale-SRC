package fr.unitale.games.arena.game.modules.gameplays;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.game.modules.ArenaGameModule;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.potion.PotionEffect;

import java.util.List;
import java.util.Random;

public class ArenaWtfGameModule extends ArenaGameModule {

    public ArenaWtfGameModule(ArenaInstance instance) {
        super(instance);
    }

    @EventHandler(ignoreCancelled = true)
    public void on(EntityDamageByEntityEvent event) {
        final UniPlayer damager = event.getDamager() instanceof UniPlayer
                ? (UniPlayer) event.getDamager()
                : event.getDamager() instanceof Arrow && ((Arrow) event.getDamager()).getShooter() instanceof UniPlayer
                ? (UniPlayer) ((Arrow) event.getDamager()).getShooter()
                : null;
        if (damager == null || !check(damager)) return;

        // prevent damages by eliminated players
        if (instance.isEliminated(damager.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        if (event.getDamager() instanceof UniPlayer) {
            UniItemStack hand = damager.getMainHandItem();
            if (hand == null) return;

            if (!hand.hasKey("damages")) return;
            event.setDamage(hand.getTag().getInt("damages"));
            UniLogger.info("Custom damages: " + hand.getTag().getInt("damages"));
        } else if (event.getDamager() instanceof Arrow
                && event.getDamager().hasMetadata("potion_effect")
                && event.getEntity() instanceof LivingEntity) {
            final List<MetadataValue> values = event.getDamager().getMetadata("potion_effect");
            final PotionEffect effect = (PotionEffect) values.get(0).value();
            ((LivingEntity) event.getEntity()).addPotionEffect(effect, true);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!check(event.getEntity())) return;

        super.onPlayerDeath(event);

        getInstance().getMap().getWorld().getLivingEntities().stream()
                .filter(entity -> entity instanceof Creature)
                .filter(entity -> ((Creature) entity).getTarget().getUniqueId().equals(event.getEntity().getUniqueId()))
                .forEach(entity -> ((Creature) entity).setTarget(findTarget(entity)));
    }

    @EventHandler
    public void on(EntityTargetEvent event) {
        UniLogger.info("target event");
        if (!event.getEntity().hasMetadata("attack_only")) return;
        event.setTarget(findTarget(event.getEntity()));
    }

    private Player findTarget(Entity entity) {
        UniLogger.info("looking for a target...");
        final List<MetadataValue> values = entity.getMetadata("attack_only");
        final UniTeam team = instance.getModule(TeamModule.class).getTeam(values.get(0).asString());
        if (team.getOnlineCompetingPlayers().size() == 0) return null;
        return team.getOnlineCompetingPlayers().get(new Random().nextInt(team.getOnlineCompetingPlayers().size()));
    }

    @EventHandler
    public void on(EntityExplodeEvent event) {
        event.blockList().clear();
        if (event.getEntity() instanceof WitherSkull || event.getEntity() instanceof Creeper) { // :shrug:
            event.setCancelled(true);
        }
    }

    // en test
    @EventHandler
    public void on(PlayerTeleportEvent event) {
        if (event.getCause().equals(PlayerTeleportEvent.TeleportCause.UNKNOWN)
                && ((UniPlayer) event.getPlayer()).getStorage().getBoolean("cancel_unknown_teleport", false)) {
            event.setCancelled(true);
            event.getPlayer().teleport(event.getFrom());
        }
    }
}
