package fr.unitale.games.arena.map.types;

import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.games.arena.map.ArenaMapType;
import org.bukkit.Location;
import org.bukkit.World;

public class Masterball extends ArenaMap {

    public Masterball(String name, World world) {
        super(ArenaMapType.ARENA_MASTERBALL, name, world, new Location(world, 129, 59, 68, 90, 0), new Location(world, 66.5, 39, 41.5, 0, 0), new Location(world, 66.5, 39, 95.5, 180, 0));
    }
}
