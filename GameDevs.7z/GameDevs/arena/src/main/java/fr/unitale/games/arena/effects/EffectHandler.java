package fr.unitale.games.arena.effects;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.Map;

public class EffectHandler {
    private ArenaInstance instance;
    private Map<Class<? extends ArenaEffectListener<?>>, ArenaEffectListener<?>> checks;
    private Map<Class<? extends AbstractListener<?>>, AbstractListener<?>> listeners;
    private boolean autoRegister = false;

    public EffectHandler(ArenaInstance instance) {
        this.instance = instance;
        this.checks = new LinkedHashMap<>();
        this.listeners = new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    public <T extends ArenaEffectListener<?>> void needListener(T check) {
        checks.put((Class<? extends ArenaEffectListener<?>>) check.getClass(), check);
        if (autoRegister) {
            register(check);
        }
    }

    public void registerAll() {
        for (ArenaEffectListener<?> check : checks.values()) {
            register(check);
        }
        this.autoRegister = true;
    }

    @SuppressWarnings("ConstantConditions")
    private void register(ArenaEffectListener<?> check) {
        listeners.compute(check.getListener(), (k, v) -> {
            if (v == null) {
                try {
                    v = check.getListener().getConstructor(ArenaInstance.class).newInstance(instance);
                } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                    e.printStackTrace();
                }
                Bukkit.getPluginManager().registerEvents(v, GameSDK2.getInstance());
                UniLogger.info("registered new listener for instance: " + v.getClass().getName());
            }
            UniLogger.info("added new check to instance, on listener " + v.getClass().getName() + " of type " + check.getClass().getName());
            v.appendCheck(check);
            return v;
        });
    }

    public void unregisterAll() {
        for (AbstractListener<?> listener : listeners.values()) {
            HandlerList.unregisterAll(listener);
        }
        this.autoRegister = false;
    }
}
