package fr.unitale.games.arena.game.modules;

import fr.unitale.sdk.game2.GlobalListener;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

public class ArenaGlobalListeners extends GlobalListener {

    @EventHandler
    public void onRegen(EntityRegainHealthEvent ev) {
        if (ev.getEntity() instanceof Player) {
            if (ev.getRegainReason() == EntityRegainHealthEvent.RegainReason.EATING || ev.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED || ev.getRegainReason() == EntityRegainHealthEvent.RegainReason.REGEN) {
                ev.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void on(BlockPlaceEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void on(BlockBreakEvent event) {
        event.setCancelled(true);
    }

    @EventHandler
    public void on(PlayerItemDamageEvent event) {
        if (!UniItemStack.fromItemStack(event.getItem()).hasKey("allow_breaking")) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void on(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.HOT_FLOOR) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void on(EntityCombustEvent event) {
        if (event.getEntity() instanceof Skeleton || event.getEntity() instanceof Zombie) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void on(EntityDeathEvent event) {
        event.getDrops().clear();
        event.setDroppedExp(0);
    }

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void onInventoryMoveItem(InventoryMoveItemEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent ev) {
        ev.setCancelled(true);
    }
}
