package fr.unitale.games.arena.kit;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collections;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.game.modules.ArenaGameModule;
import fr.unitale.games.arena.game.modules.gameplays.ArenaWtfGameModule;
import fr.unitale.games.arena.kit.wtf.WtfKit;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.instance.Module;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import fr.unitale.sdk.utils.items.UniItemPotion;
import fr.unitale.sdk.utils.items.UniItemStack;

/**
 * @noinspection unused
 */
public enum Kit {
    WARRIOR_NORMAL("Guerrier",
            ArenaGameModule.class,
            new ArenaKit(0)
                    .appendStuff(new UniItemStack(Material.DIAMOND_SWORD)
                            .addNewEnchantment(Enchantment.DAMAGE_ALL, 1))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(new UniItemPotion(6, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.GOLDEN_APPLE, 5)
                    .appendStuff(Material.ARROW, 9)
                    .setArmors(ArmorType.DIAMOND.getItems(Enchantment.PROTECTION_ENVIRONMENTAL, 1))
    ),
    WARRIOR_RANKED("Guerrier",
            ArenaGameModule.class,
            new ArenaKit(0)
                    .appendStuff(Material.STONE_SWORD)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .setArmors(ArmorType.IRON.getItems()),
            new ArenaKit(1400)
                    .appendStuff(Material.IRON_SWORD)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .setArmors(ArmorType.IRON.getItems()),
            new ArenaKit(1500)
                    .appendStuff(Material.IRON_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .setArmors(ArmorType.IRON.getItems()),
            new ArenaKit(1600)
                    .appendStuff(Material.IRON_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.GOLDEN_APPLE)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(1, Material.DIAMOND_CHESTPLATE),
            new ArenaKit(1700)
                    .appendStuff(Material.IRON_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.GOLDEN_APPLE, 2)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(1, Material.DIAMOND_CHESTPLATE)
                    .setArmor(2, Material.DIAMOND_LEGGINGS),
            new ArenaKit(1800)
                    .appendStuff(Material.IRON_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(4, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.GOLDEN_APPLE, 2)
                    .setArmors(ArmorType.DIAMOND.getItems())
                    .setArmor(3, Material.IRON_BOOTS),
            new ArenaKit(1900)
                    .appendStuff(Material.IRON_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(4, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(Material.GOLDEN_APPLE, 3)
                    .setArmors(ArmorType.DIAMOND.getItems()),
            new ArenaKit(2000)
                    .appendStuff(Material.DIAMOND_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(4, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.GOLDEN_APPLE, 3)
                    .setArmors(ArmorType.DIAMOND.getItems()),
            new ArenaKit(2100)
                    .appendStuff(Material.DIAMOND_SWORD)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(5, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.GOLDEN_APPLE, 3)
                    .setArmors(ArmorType.DIAMOND.getItems()),
            new ArenaKit(2200)
                    .appendStuff(Material.DIAMOND_SWORD)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(new UniItemPotion(5, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.GOLDEN_APPLE, 4)
                    .appendStuff(Material.ARROW, 3)
                    .setArmors(ArmorType.DIAMOND.getItems(Enchantment.PROTECTION_ENVIRONMENTAL, 1)),
            new ArenaKit(2300)
                    .appendStuff(new UniItemStack(Material.DIAMOND_SWORD).addNewEnchantment(Enchantment.DAMAGE_ALL, 1))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(new UniItemPotion(6, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.GOLDEN_APPLE, 4)
                    .appendStuff(Material.ARROW, 6)
                    .setArmors(ArmorType.DIAMOND.getItems(Enchantment.PROTECTION_ENVIRONMENTAL, 1)),
            new ArenaKit(2400)
                    .appendStuff(new UniItemStack(Material.DIAMOND_SWORD)
                            .addNewEnchantment(Enchantment.DAMAGE_ALL, 1))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(Material.FISHING_ROD)
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(new UniItemPotion(6, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.LAVA_BUCKET)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.GOLDEN_APPLE, 5)
                    .appendStuff(Material.ARROW, 9)
                    .setArmors(ArmorType.DIAMOND.getItems(Enchantment.PROTECTION_ENVIRONMENTAL, 1))
    ),
    HUNTER_NORMAL("Archer",
            ArenaGameModule.class,
            new ArenaKit(0)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 4))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_FIRE, 1)
                            .addKey("allow_breaking")
                            .durability((short) 382))
                    .appendStuff(Material.STONE_SWORD)
                    .appendStuff(Material.GOLDEN_APPLE, 3)
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemPotion(4, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.DIAMOND.getItems())
    ),
    HUNTER_RANKED("Archer",
            ArenaGameModule.class,
            new ArenaKit(0)
                    .appendStuff(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_INFINITE, 1))
                    .appendStuff(new UniItemPotion(1, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.LEATHER.getItems()),
            new ArenaKit(1400)
                    .appendStuff(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_INFINITE, 1))
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(2, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.LEATHER.getItems()),
            new ArenaKit(1500)
                    .appendStuff(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_INFINITE, 1))
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.LEATHER.getItems()),
            new ArenaKit(1600)
                    .appendStuff(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_INFINITE, 1))
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.LEATHER.getItems())
                    .setArmor(1, Material.IRON_CHESTPLATE),
            new ArenaKit(1700)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 1))
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.IRON.getItems()),
            new ArenaKit(1800)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 1))
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(3, Material.DIAMOND_BOOTS),
            new ArenaKit(1900)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 1))
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(1, Material.DIAMOND_CHESTPLATE)
                    .setArmor(2, Material.DIAMOND_BOOTS),
            new ArenaKit(2000)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(1, Material.DIAMOND_CHESTPLATE)
                    .setArmor(2, Material.DIAMOND_BOOTS),
            new ArenaKit(2100)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(1, Material.DIAMOND_CHESTPLATE)
                    .setArmor(2, Material.DIAMOND_BOOTS),
            new ArenaKit(2200)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 2))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_FIRE, 1)
                            .addKey("allow_breaking")
                            .durability((short) 382))
                    .appendStuff(Material.STONE_SWORD)
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemPotion(3, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 30, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.IRON.getItems())
                    .setArmor(1, Material.DIAMOND_CHESTPLATE)
                    .setArmor(2, Material.DIAMOND_BOOTS),
            new ArenaKit(2300)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 3))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_FIRE, 1)
                            .addKey("allow_breaking")
                            .durability((short) 382))
                    .appendStuff(Material.STONE_SWORD)
                    .appendStuff(Material.GOLDEN_APPLE, 1)
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemPotion(4, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.DIAMOND.getItems()),
            new ArenaKit(2400)
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_DAMAGE, 4))
                    .appendStuff(new UniItemStack(Material.BOW)
                            .addNewEnchantment(Enchantment.ARROW_INFINITE, 1)
                            .addNewEnchantment(Enchantment.ARROW_FIRE, 1)
                            .addKey("allow_breaking")
                            .durability((short) 382))
                    .appendStuff(Material.STONE_SWORD)
                    .appendStuff(Material.GOLDEN_APPLE, 3)
                    .appendStuff(Material.ENDER_PEARL, 2)
                    .appendStuff(Material.WATER_BUCKET)
                    .appendStuff(new UniItemPotion(4, true)
                            .addEffect(new PotionEffect(PotionEffectType.HEAL, 1, 1))
                            .setData(new PotionData(PotionType.INSTANT_HEAL)))
                    .appendStuff(new UniItemPotion()
                            .addEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60, 0))
                            .setData(new PotionData(PotionType.SPEED)))
                    .appendStuff(new UniItemStack(Material.STAINED_GLASS, 32).addKey("can_be_broken").addKey("can_be_placed"))
                    .appendStuff(Material.ARROW)
                    .setArmors(ArmorType.DIAMOND.getItems())
    ),
    WTF("WTF",
            ArenaWtfGameModule.class,
            new WtfKit()
    );

    private final String name;
    private final Class<? extends Module<ArenaInstance>> gameModule;
    private AbstractKit<?>[] kit;

    Kit(String name, Class<? extends Module<ArenaInstance>> gameModule, AbstractKit<?>... kit) {
        this.name = name;
        this.gameModule = gameModule;
        this.kit = kit;
        Arrays.sort(this.kit, Collections.reverseOrder());
    }

    public String getName() {
        return name;
    }

    public AbstractKit<?> getKit(int elo) {
        return Arrays.stream(kit)
                .filter(kit -> elo >= kit.getElo())
                .findFirst()
                .orElse(null);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module<ArenaInstance>> T getNewModule(ArenaInstance instance) {
        try {
            return (T) gameModule.getConstructor(ArenaInstance.class).newInstance(instance);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }
}
