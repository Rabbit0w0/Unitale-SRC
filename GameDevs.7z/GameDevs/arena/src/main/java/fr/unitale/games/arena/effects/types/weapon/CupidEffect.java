package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.BowShootListener;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.items.UniItemStack;
import io.netty.util.internal.ConcurrentSet;
import org.bukkit.Bukkit;
import org.bukkit.entity.Arrow;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Set;

public class CupidEffect extends ArenaEffect {
    private static final Set<Arrow> ARROWS = new ConcurrentSet<>();

    static { // todo maybe run one task per arrow instead
        Bukkit.getScheduler().runTaskTimer(UnitaleSDK.getInstance(), () -> {
            for (Arrow arrow : ARROWS) {
                if (arrow.isOnGround() || arrow.isDead()) {
                    ARROWS.remove(arrow);
                } else {
                    ParticleEffect.HEART.display(
                            0.01f,
                            0.01f,
                            0.01f,
                            0.01f,
                            1,
                            arrow.getLocation()
                    );
                }
            }
        }, 0, 1);
    }

    public CupidEffect(ArenaInstance instance) {
        instance.getEffectHandler().needListener(new CupidEffectListener());
    }

    public static class CupidEffectListener implements ArenaEffectListener<EntityShootBowEvent> {

        @Override
        public boolean check(ArenaInstance instance, EntityShootBowEvent event) {
            final UniPlayer shooter = (UniPlayer) event.getEntity();
            final UniItemStack hand = shooter.getMainHandItem();

            if (fromItem(hand, CupidEffect.class) == null) return false;

            final Arrow arrow = (Arrow) event.getProjectile();
            arrow.setMetadata("potion_effect", new FixedMetadataValue(UnitaleSDK.getInstance(), new PotionEffect(
                    PotionEffectType.CONFUSION,
                    20 * 8,
                    2
            )));
            ARROWS.add(arrow);

            return true;
        }

        @Override
        public Class<? extends AbstractListener<EntityShootBowEvent>> getListener() {
            return BowShootListener.class;
        }
    }
}
