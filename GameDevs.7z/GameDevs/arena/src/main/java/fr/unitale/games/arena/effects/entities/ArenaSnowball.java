package fr.unitale.games.arena.effects.entities;

import net.minecraft.server.v1_10_R1.*;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_10_R1.CraftWorld;
import org.bukkit.craftbukkit.v1_10_R1.event.CraftEventFactory;

import java.util.List;

public class ArenaSnowball extends EntitySnowball {
    private int ax;
    private int av;

    private int blockX;
    private int blockY;
    private int blockZ;
    private Block inBlockId;

    private double xDiff;
    private double yDiff;
    private double zDiff;

    public ArenaSnowball(Location location) {
        super(((CraftWorld) location.getWorld()).getHandle());
        setLocation(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        world.addEntity(this);
        setCustomSize(motX, motY, motZ);
    }

    public ArenaSnowball setCustomSize(double x, double y, double z) {
        this.xDiff = x;
        this.yDiff = y;
        this.zDiff = z;
        return this;
    }

    @Override
    public void shoot(double d0, double d1, double d2, float f, float f1) {
        float f2 = MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= f2;
        d1 /= f2;
        d2 /= f2;
        d0 += this.random.nextGaussian() * 0.007499999832361937D * (double) f1;
        d1 += this.random.nextGaussian() * 0.007499999832361937D * (double) f1;
        d2 += this.random.nextGaussian() * 0.007499999832361937D * (double) f1;
        d0 *= f;
        d1 *= f;
        d2 *= f;
        this.motX = d0;
        this.motY = d1;
        this.motZ = d2;
        float f3 = MathHelper.sqrt(d0 * d0 + d2 * d2);
        this.yaw = (float) (MathHelper.b(d0, d2) * 57.2957763671875D);
        this.pitch = (float) (MathHelper.b(d1, f3) * 57.2957763671875D);
        this.lastYaw = this.yaw;
        this.lastPitch = this.pitch;
        this.av = 0;
    }

    @Override
    public void m() {
        this.M = this.locX;
        this.N = this.locY;
        this.O = this.locZ;
        if (this.shake > 0) {
            --this.shake;
        }

        if (this.inGround) {
            if (this.world.getType(new BlockPosition(this.blockX, this.blockY, this.blockZ)).getBlock() == this.inBlockId) {
                ++this.av;
                if (this.av == 1200) {
                    this.die();
                }

                return;
            }

            this.inGround = false;
            this.av = 0;
        }

        double bX = this.locX - this.xDiff / 2;
        double bY = this.locY - this.yDiff / 2;
        double bZ = this.locZ - this.zDiff / 2;

        Vec3D vec3d = new Vec3D(bX, bY, bZ);
        Vec3D vec3d1 = new Vec3D(bX + this.xDiff, bY + this.yDiff, bZ + this.zDiff);
        MovingObjectPosition movingobjectposition = this.world.rayTrace(vec3d, vec3d1);
        vec3d = new Vec3D(bX, bY, bZ);
        vec3d1 = new Vec3D(bX + this.xDiff, bY + this.yDiff, bZ + this.zDiff);
        if (movingobjectposition != null) {
            vec3d1 = new Vec3D(movingobjectposition.pos.x, movingobjectposition.pos.y, movingobjectposition.pos.z);
        }

        Entity entity = null;
        List<?> list = this.world.getEntities(this, this.getBoundingBox().a(this.xDiff, this.yDiff, this.zDiff).g(1.0D));
        double d0 = 0.0D;
        boolean flag = false;

        for (Object o : list) {
            Entity entity1 = (Entity) o;
            if (entity1.isInteractable()) {
                if (entity1 == this.c) {
                    flag = true;
                } else if (this.ticksLived < 2 && this.c == null) {
                    this.c = entity1;
                    flag = true;
                } else {
                    flag = false;
                    AxisAlignedBB axisalignedbb = entity1.getBoundingBox().g(0.30000001192092896D);
                    MovingObjectPosition movingobjectposition1 = axisalignedbb.b(vec3d, vec3d1);
                    if (movingobjectposition1 != null) {
                        double d1 = vec3d.distanceSquared(movingobjectposition1.pos);
                        if (d1 < d0 || d0 == 0.0D) {
                            entity = entity1;
                            d0 = d1;
                        }
                    }
                }
            }
        }

        if (this.c != null) {
            if (flag) {
                this.ax = 2;
            } else if (this.ax-- <= 0) {
                this.c = null;
            }
        }

        if (entity != null) {
            movingobjectposition = new MovingObjectPosition(entity);
        }

        if (movingobjectposition != null) {
            if (movingobjectposition.type == MovingObjectPosition.EnumMovingObjectType.BLOCK && this.world.getType(movingobjectposition.a()).getBlock() == Blocks.PORTAL) {
                this.e(movingobjectposition.a());
            } else {
                this.a(movingobjectposition);
                if (this.dead) {
                    CraftEventFactory.callProjectileHitEvent(this);
                }
            }
        }

        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        float f = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float) (MathHelper.b(this.motX, this.motZ) * 57.2957763671875D);

        this.pitch = (float) (MathHelper.b(this.yDiff, f) * 57.2957763671875D);
        while (this.pitch - this.lastPitch < -180.0F) {
            this.lastPitch -= 360.0F;
        }

        while (this.pitch - this.lastPitch >= 180.0F) {
            this.lastPitch += 360.0F;
        }

        while (this.yaw - this.lastYaw < -180.0F) {
            this.lastYaw -= 360.0F;
        }

        while (this.yaw - this.lastYaw >= 180.0F) {
            this.lastYaw += 360.0F;
        }

        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
        float f1 = 0.99F;

        this.motX *= f1;
        this.motY *= f1;
        this.motZ *= f1;
        this.motY -= this.j();

        this.setPosition(this.locX, this.locY, this.locZ);
    }

    @Override
    public void b(NBTTagCompound nbttagcompound) {
        nbttagcompound.setInt("xTile", this.blockX);
        nbttagcompound.setInt("yTile", this.blockY);
        nbttagcompound.setInt("zTile", this.blockZ);
        MinecraftKey minecraftkey = Block.REGISTRY.b(this.inBlockId);
        nbttagcompound.setString("inTile", minecraftkey.toString());
        nbttagcompound.setByte("shake", (byte) this.shake);
        nbttagcompound.setByte("inGround", (byte) (this.inGround ? 1 : 0));
        if ((this.shooterName == null || this.shooterName.isEmpty()) && this.shooter instanceof EntityHuman) {
            this.shooterName = this.shooter.getName();
        }

        nbttagcompound.setString("ownerName", this.shooterName == null ? "" : this.shooterName);
    }

    @Override
    public void a(NBTTagCompound nbttagcompound) {
        this.blockX = nbttagcompound.getInt("xTile");
        this.blockY = nbttagcompound.getInt("yTile");
        this.blockZ = nbttagcompound.getInt("zTile");
        if (nbttagcompound.hasKeyOfType("inTile", 8)) {
            this.inBlockId = Block.getByName(nbttagcompound.getString("inTile"));
        } else {
            this.inBlockId = Block.getById(nbttagcompound.getByte("inTile") & 255);
        }

        this.shake = nbttagcompound.getByte("shake") & 255;
        this.inGround = nbttagcompound.getByte("inGround") == 1;
        this.shooter = null;
        this.shooterName = nbttagcompound.getString("ownerName");
        if (this.shooterName != null && this.shooterName.isEmpty()) {
            this.shooterName = null;
        }

        this.shooter = this.getShooter();
    }
}
