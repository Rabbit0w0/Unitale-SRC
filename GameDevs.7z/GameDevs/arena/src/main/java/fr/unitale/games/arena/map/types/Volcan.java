package fr.unitale.games.arena.map.types;

import fr.unitale.games.arena.map.ArenaMap;
import fr.unitale.games.arena.map.ArenaMapType;
import org.bukkit.Location;
import org.bukkit.World;

public class Volcan extends ArenaMap {

    public Volcan(String name, World world) {
        super(ArenaMapType.ARENA_VOLCAN, name, world, new Location(world, -29, 39, -36, -60, 0), new Location(world, 5.5, 42, -45.5, 0, 0), new Location(world, 5.5, 42, 3.5, 180, 0));
    }
}
