package fr.unitale.games.arena.map;

import fr.unitale.sdk.UnitaleSDK;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.stream.IntStream;

public class ArenaDoor {
    public enum DoorAxis {
        X_AXIS(1, 0, 0),
        Y_AXIS(0, 1, 0),
        Z_AXIS(0, 0, 1);

        public int x;
        public int y;
        public int z;

        DoorAxis(int x, int y, int z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public enum OpenAxis {
        H_AXIS(1, 0),
        V_AXIS(0, 1);

        public int h;
        public int v;

        OpenAxis(int h, int v) {
            this.h = h;
            this.v = v;
        }
    }

    public static final int TOWARDS_POSITIVE = 1;
    public static final int TOWARDS_NEGATIVE = -1;

    private final Location startPoint;
    private final int height;
    private final int length;
    private final DoorAxis axis;

    public ArenaDoor(Location start, int height, int length, DoorAxis axis) {
        this.startPoint = start;
        this.height = height;
        this.length = length;
        this.axis = axis;
    }

    public Location getStartPoint() {
        return this.startPoint;
    }

    public void build(Material m) {
        Location l = this.startPoint.clone();

        IntStream.range(0, this.height).forEach(i -> {
            IntStream.range(0, this.length).forEach(j -> {
                l.getBlock().setType(m);
                l.add(this.axis.x, 0.0D, this.axis.z);
            });
            l.add(0.0D, -1.0D, 0.0D);
        });
    }

    public void build() {
    }

    public void open() {
        build(Material.AIR);
    }

    @SuppressWarnings("deprecation")
	private void changeBlock(Block from, Block to) {
        from.setType(to.getType());
        from.setData(to.getData());
    }

    private void move(Location start, int len, OpenAxis axis, int towards) {
        World w = start.getWorld();
        if (axis == OpenAxis.H_AXIS) {
            for (int i = 0; i < len; i++) {
                for (int j = 0; j < this.height; j++) {
                    changeBlock(w.getBlockAt(start.getBlockX() + i * this.axis.x * towards, start.getBlockY() + (j + 1) * -towards, start.getBlockZ() + i * this.axis.z * towards), w
                            .getBlockAt(start.getBlockX() + this.axis.x * (i * towards + towards), start.getBlockY() + (j + 1) * -towards, start.getBlockZ() + this.axis.z * (i * towards + towards)));
                }
            }
            IntStream.range(0, this.height).forEach(j -> w.getBlockAt(start.getBlockX() + len * this.axis.x * towards, start.getBlockY() + j * -towards, start.getBlockZ() + len * this.axis.z * towards).setType(Material.AIR));
        } else {
            for (int i = 0; i < len; i++) {
                for (int j = 0; j < this.length; j++) {
                    changeBlock(w.getBlockAt(start.getBlockX() + this.axis.x * j, start.getBlockY() + i * -towards, start.getBlockZ() + this.axis.z * j), w
                            .getBlockAt(start.getBlockX() + this.axis.x * j, start.getBlockY() + i * -towards - towards, start.getBlockZ() + this.axis.z * j));
                }
            }
            IntStream.range(0, this.length).forEach(j -> w.getBlockAt(start.getBlockX() + this.axis.x * j, start.getBlockY() + len * -towards, start.getBlockZ() + this.axis.z * j).setType(Material.AIR));
        }
    }

    private void tickOpen(final Location start, final long tickByStep, final int len, final int tick, final OpenAxis axis, final int towards) {
        move(start, len - tick - 1, axis, towards);
        if (tick >= len) return;

        Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), () -> {
            ArenaDoor.this.tickOpen(start, tickByStep, len, tick + 1, axis, towards);
        }, tickByStep);
    }

    public void timedOpen(long tickByStep, OpenAxis axis, int towards) {
        Location l = this.startPoint.clone();

        if (towards == TOWARDS_NEGATIVE) {
            l.add((this.axis.x * this.length), (this.axis.y * this.height), (this.axis.z * this.length));
        }

        tickOpen(l, tickByStep, (axis == OpenAxis.H_AXIS) ? this.length : this.height, 0, axis, towards);
    }
}