package fr.unitale.games.arena.effects.types.weapon;

import fr.unitale.games.arena.effects.listeners.AbstractListener;
import fr.unitale.games.arena.effects.listeners.ArenaEffectListener;
import fr.unitale.games.arena.effects.listeners.types.EntityDamageByPlayerListener;
import fr.unitale.games.arena.effects.types.CooldownEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.sound.SoundCreator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class ToiletBrushEffect extends CooldownEffect {

    public ToiletBrushEffect(ArenaInstance instance) {
        super(4000);
        instance.getEffectHandler().needListener(new ToiletBrushListener());
    }

    private void playEffect(UniPlayer player, Entity target) {
        if (!canUse()) {
            SoundCreator.playSound(Sound.BLOCK_ANVIL_PLACE, 1f, player);
            return;
        }

        Location location = target.getLocation().clone();
        location.getBlock().setType(Material.WATER);
        ParticleEffect.DRIP_WATER.display(1.0f, 1.0f, 1.0f, 0.02f, 40, location);
        Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), () -> {
            location.getBlock().setType(Material.AIR);
        }, 5);
    }

    public static class ToiletBrushListener implements ArenaEffectListener<EntityDamageByEntityEvent> {

        @Override
        public boolean check(ArenaInstance instance, EntityDamageByEntityEvent event) {
            final UniPlayer player = (UniPlayer) event.getDamager();
            final ToiletBrushEffect effect = fromItem(player.getMainHandItem(), ToiletBrushEffect.class);
            if (effect == null) return false;
            effect.playEffect(player, event.getEntity());

            return false;
        }

        @Override
        public Class<? extends AbstractListener<EntityDamageByEntityEvent>> getListener() {
            return EntityDamageByPlayerListener.class;
        }
    }
}
