package fr.unitale.games.arena.kit.wtf.item;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.kit.wtf.WtfItem;
import fr.unitale.sdk.utils.items.CustomMaterial;
import org.bukkit.Material;

public class WtfWeaponItem<T extends ArenaEffect> extends WtfItem<T> {

    public WtfWeaponItem(Material material, Class<T> effect) {
        super(material, effect);
    }

    public WtfWeaponItem(Material material, int amount, Class<T> effect) {
        super(material, amount, effect);
    }

    public WtfWeaponItem(CustomMaterial material, Class<T> effect) {
        super(material, effect);
    }

    public WtfWeaponItem(CustomMaterial material, int amount, Class<T> effect) {
        super(material, amount, effect);
    }
}
