package fr.unitale.games.arena.kit.wtf;

import fr.unitale.games.arena.effects.ArenaEffect;
import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.sdk.utils.items.CustomMaterial;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;

import java.lang.reflect.InvocationTargetException;

public class WtfItem<T extends ArenaEffect> extends UniItemStack {
    private Class<T> effect;
    private ArenaInstance instance;

    public WtfItem(Material material, Class<T> effect) {
        super(material);
        this.effect = effect;
    }

    public WtfItem(Material material, short data, Class<T> effect) {
        super(material, data);
        this.effect = effect;
    }

    public WtfItem(Material material, int amount, Class<T> effect) {
        super(material, amount);
        this.effect = effect;
    }

    public WtfItem(Material material, int amount, short data, Class<T> effect) {
        super(material, amount, data);
        this.effect = effect;
    }

    public WtfItem(CustomMaterial material, Class<T> effect) {
        super(material);
        this.effect = effect;
    }

    public WtfItem(CustomMaterial material, short data, Class<T> effect) {
        super(material, data);
        this.effect = effect;
    }

    public WtfItem(CustomMaterial material, int amount, Class<T> effect) {
        super(material, amount);
        this.effect = effect;
    }

    public WtfItem(CustomMaterial material, int amount, short data, Class<T> effect) {
        super(material, amount, data);
        this.effect = effect;
    }

    public WtfItem<T> clone(ArenaInstance instance) {
        final WtfItem<T> item = new WtfItem<>(getType(), getAmount(), getDurability(), effect);
        item.setItemMeta(getItemMeta());
        item.setGlowing(isGlowing());
        item.instance = instance;
        return item;
    }

    @Override
    public UniItemStack clone() {
        final UniItemStack item = clone(instance);
        T effect;
        try {
            if (this.effect.getConstructor(ArenaInstance.class) != null) {
                effect = this.effect.getConstructor(ArenaInstance.class).newInstance(instance);
            } else {
                effect = this.effect.getConstructor().newInstance();
            }
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            e.printStackTrace();
            return null;
        }

        item.addKeyVal("effect", effect.getId());
        return item;
    }
}
