package fr.unitale.games.arena.game.modules;

import fr.unitale.games.arena.game.ArenaInstance;
import fr.unitale.games.arena.game.ArenaInstanceType;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import fr.unitale.sdk.utils.items.CustomMaterial;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.UUID;

public class ArenaEndModule extends Module<ArenaInstance> {

    public ArenaEndModule(ArenaInstance instance) {
        super(instance);
    }

    @Override
    protected void onRegistered() {
        for (UniPlayer player : getInstance().getOnlinePlayers()) {
            player.clear();
            player.setGameMode(GameMode.ADVENTURE);
            UniItemStack leave = new UniItemStack(Material.BED, Lang.str(player, "game.wait.item.leave"));
            player.getInventory().setItem(8, leave);
            UniItemStack playAgain = new UniItemStack(CustomMaterial.REPLAY, Lang.str(player, "game.wait.item.play_again"));
            player.getInventory().setItem(0, playAgain);
        }
    }

    @EventHandler
    public void on(EntityDamageEvent event) {
        if (!check(event.getEntity().getUniqueId())) return;

        event.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent ev) {
        if (!check(ev.getPlayer())) return;

        final UniItemStack item = UniItemStack.fromItemStack(ev.getPlayer().getInventory().getItemInMainHand());
        if (item == null || !(ev.getAction().equals(Action.RIGHT_CLICK_BLOCK) || ev.getAction().equals(Action.RIGHT_CLICK_AIR))) {
            return;
        }

        final UniPlayer player = (UniPlayer) ev.getPlayer();
        if (player.getInventory().getItemInMainHand().getType() == Material.BED) {
            player.sendToHub();
        } else if (player.getInventory().getItemInMainHand().getType() == CustomMaterial.REPLAY.getMaterial()) {
            if (player.getParty().getOwner().equals(player.getUniqueId())) {
                for (UUID playerUuid : player.getParty().getMembers()) {
                    if (Bukkit.getPlayer(playerUuid) != null) {
                        playAgain((UniPlayer) Bukkit.getPlayer(playerUuid));
                    }
                }
            } else {
                playAgain(player);
            }
        }

        ev.setCancelled(true);
    }

    private void playAgain(UniPlayer player) {
        instance.onQuit(player);

        PlayerCollector.doForEach(p -> {
            p.hidePlayer(player);
            player.hidePlayer(p);
        });
        player.setCollidable(true);
        player.setAllowFlight(false);
        player.getInventory().clear();
        player.setGameMode(GameMode.ADVENTURE);

        ArenaInstanceType type = new ArenaInstanceType(instance);
        GameSDK2.getEngine().getRoom().onJoin(player, type);
    }
}
