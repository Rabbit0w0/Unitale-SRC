package fr.unitale.games.poxor.map;

import fr.unitale.games.poxor.map.type.Ling;
import fr.unitale.games.poxor.map.type.Naring;
import fr.unitale.games.poxor.map.type.Toxon;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;

public class PxMapType extends MapType {
	
	public static final PxMapType PX_TOXON = new PxMapType("PX_TOXON", "toxon", Toxon.class, "game.px.map.toxon");
	public static final PxMapType PX_NARING = new PxMapType("PX_NARING", "naring", Naring.class, "game.px.map.naring");
	public static final PxMapType PX_LING = new PxMapType("PX_LING", "ling", Ling.class, "game.px.map.ling");
	
	protected PxMapType(String key, String name, Class<? extends GameMap> class1, String publicName) {
		super(key, name, class1, publicName);
	}

	public static PxMapType[] values() {
		return new PxMapType[] {
				PX_TOXON,
				PX_NARING,
				PX_LING,
		};
	}

    @Override
    public boolean shouldDeleteMapWhenUnloading() {
        return false;
    }
}
