package fr.unitale.games.poxor.game.listeners;

import java.util.UUID;

import org.bukkit.event.EventHandler;

import fr.unitale.sdk.game2.event.instance.InstanceListenerUnregisteredEvent;
import fr.unitale.sdk.game2.instance.InstanceListener;
import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;

public class PxGameListener extends InstanceListener implements Updater {
	
	private UniTimer timer;
	
	@EventHandler
    public void onStart(InstanceListenerUnregisteredEvent ev) {
		if (!check(ev)) return;
        if (!(ev.getListener() instanceof WaitingModule)) return;

        timer = new UniTimer("poxor-game-timer-" + UUID.randomUUID().toString(), this);

        //Spawn player here

        TimeManager.getInstance().addTimer(timer);
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
