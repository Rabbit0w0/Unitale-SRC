package fr.unitale.games.poxor.utils;

import java.util.Random;

import org.bukkit.Sound;

import fr.unitale.sdk.utils.sound.CustomSound;

public enum PxSound implements CustomSound {
	
	MUSIC_START("game.poxor.music.start", 67l),
	MUSIC_END("game.poxor.music.end"),
	MUSIC_BACKGROUND("game.poxor.music.background", 134l);
	
	private String key;
	private long duration;
	private Sound alternative;

	private PxSound(String key) {
		this.key = key;
	}
	
	private PxSound(String key, long duration) {
		this.key = key;
		this.duration = duration;
	}
	
	private PxSound(String key, Sound alternative) {
		this.key = key;
		this.alternative = alternative;
	}

	@Override
	public String getKey() {
		return key;
	}
	
	@Override
	public long getDuration() {
		return duration;
	}
	
	@Override
	public Sound getAlternative() {
		return alternative;
	}

	private static Random rand = new Random();

	public static PxSound rand(PxSound[] sounds) {
		return sounds[rand.nextInt(sounds.length)];
	}

}
