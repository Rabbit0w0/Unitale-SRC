package fr.unitale.games.poxor.map.type;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.games.poxor.map.PxMap;
import fr.unitale.games.poxor.map.PxMapType;

public class Naring extends PxMap {
	
	 public Naring(String name, World world) {
	        super(PxMapType.PX_TOXON, name, world,
	                new Location(world, 0, 0, 0),
	                new Location(world, 0, 0, 0),
	                new Location(world, 0, 0, 0));
	    }
}
