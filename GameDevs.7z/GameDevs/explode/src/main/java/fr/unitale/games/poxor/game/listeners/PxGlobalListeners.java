package fr.unitale.games.poxor.game.listeners;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.poxor.map.PxMap;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.GlobalListener;
import fr.unitale.sdk.game2.event.instance.PlayerJoinInstanceEvent;

public class PxGlobalListeners extends GlobalListener {

    /*
     * Cancel damages in waiting room
     */
    @EventHandler
    public void on(EntityDamageEvent event) {
        if (event.getEntity().getType() != EntityType.PLAYER) return;
        if (GameSDK2.getInstance((Player) event.getEntity()).getStatus().equals(ServerTypes.GameStatus.WAIT)) {
            event.setCancelled(true);
        }
    }

    /*
     * Teleport player to spawn at joining
     */
    @EventHandler
    protected void userJoin(PlayerJoinInstanceEvent event) {
        if (GameSDK2.getInstance(event.getPlayer()).getUniqueId().equals(event.getInstance().getUniqueId())) return;
        event.getPlayer().teleport(event.getInstance().getMap(PxMap.class).getWaitingRoomLocation());
    } 
    
}
