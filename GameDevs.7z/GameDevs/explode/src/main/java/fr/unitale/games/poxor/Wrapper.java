package fr.unitale.games.poxor;

import org.bukkit.plugin.java.JavaPlugin;

import fr.unitale.games.poxor.game.PxInstance;
import fr.unitale.games.poxor.game.PxInstanceType;
import fr.unitale.games.poxor.map.PxMapType;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.room.PassingRoom;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.utils.chat.UniLogger;

public class Wrapper extends JavaPlugin {

    @Override
    public void onEnable() {
        UniLogger.info("FK Wrapper launched !");

        // set gameplay
        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);
        
        // init instance factory
        Engine engine = new Engine(this, new PxInstanceType(), new PassingRoom());
        
        // pour les tests en local
        engine.addFactory(new PxInstanceType(PxMapType.PX_TOXON), f -> new PxInstance(engine, PxMapType.PX_TOXON));
        
        // start the engine
        GameSDK2.startEngine(engine);
    }

    @Override
    public void onDisable() {

    }
}
