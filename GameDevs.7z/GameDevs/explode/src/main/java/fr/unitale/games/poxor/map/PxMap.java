package fr.unitale.games.poxor.map;

import java.util.Arrays;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.World;

import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;

public abstract class PxMap extends GameMap {
	
	private List<Location> spawns;
    private final Location waitingRoom;
    
    public PxMap(MapType type, String name, World world, Location waitingRoom, Location... spawns) {
    	super(type, name, world);
        this.waitingRoom = waitingRoom;
        this.spawns = Arrays.asList(spawns);
	}
    
    public List<Location> getSpawns() {
        return spawns;
    }

    public Location getWaitingRoomLocation() {
        return waitingRoom;
    }
}
