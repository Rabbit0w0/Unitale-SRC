package fr.unitale.games.poxor.game;

import org.apache.commons.lang3.StringUtils;
import org.bukkit.ChatColor;
import org.bukkit.scoreboard.DisplaySlot;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.poxor.game.listeners.PxGameListener;
import fr.unitale.games.poxor.map.PxMapType;
import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.event.instance.InstanceListenerUnregisteredEvent;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import fr.unitale.sdk.game2.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;

public class PxInstance extends Instance {
	
	public PxInstance(Engine engine, PxMapType mapType) {
		super(engine, "poxor.json", false);
		
		ServerManager.type = ServerTypes.ServerType.GAME;
		setMode(ServerTypes.Mode.SOLO);
		
		// set rewards
		PlayerGameStat STAT = new PlayerGameStat();
        STAT.VICTORY.setMoney(MoneyType.GOLD, 15);
        STAT.DEFEAT.setMoney(MoneyType.GOLD, 5);
        
        STAT.PLACE_1.setMoney(MoneyType.GOLD, 15);
        STAT.PLACE_1.setMoney(MoneyType.EMERALDS, 2);        
        STAT.PLACE_2.setMoney(MoneyType.GOLD, 10);
        STAT.PLACE_3.setMoney(MoneyType.GOLD, 5);
        
        STAT.PARTICIPATION.setMoney(MoneyType.GOLD, 20);
        setGameStat(STAT);
        UnitaleSDK.enableAPI(API.FEATURE, API.GUN);
        
        // manage weather
        WeatherAPI.disableTime();
        WeatherAPI.clear();
        WeatherAPI.setTime(TimeSet.DAY);
        
        // waiting module
        WaitingModule waitingModule = new WaitingModule(this, new PxGameListener() {
            
            @Override
            public void onStart(InstanceListenerUnregisteredEvent ev) {
            	
            }
            
        });
        waitingModule.setBoard(getBoard());
        register(waitingModule);
    }
	
	protected UniScoreboard getBoard() {
        final UniScoreboard b = new UniScoreboard();
        int i = 0;

        b.createSideBoard(ChatColor.GOLD + "Poxor");
        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("map_text", Lang.str("game.px.board.map", getMap().getType().toString()), i++, DisplaySlot.SIDEBAR);
        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("time", Lang.str("game.px.board.waiting", String.valueOf(getOnlinePlayers().size()), String.valueOf(getMax())), i++, DisplaySlot.SIDEBAR);
        return b;
    }
	
}
