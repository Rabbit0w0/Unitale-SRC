package fr.unitale.games.poxor.game;

import java.util.Objects;

import fr.unitale.games.poxor.map.PxMapType;
import fr.unitale.sdk.game2.instance.InstanceType;

public class PxInstanceType implements InstanceType {
	private PxMapType map;
	
	public PxInstanceType() {
		
	}
	
	public PxInstanceType(PxMapType map) {
		this.map = map;
	}
	
	@Override
	public InstanceType fromJson(String s) {
		return new PxInstanceType(
                PxMapType.PX_TOXON
        );
	}
	
	public PxMapType getMap() {
		return map;
	}
	
	@Override
    public boolean equals(Object object) {
        if (object instanceof PxInstanceType) {
        	PxInstanceType other = (PxInstanceType) object;
            return other.getMap().getName().equals(map.getName());
        } else if (object instanceof PxInstance) {
        	PxInstance other = (PxInstance) object;
            return other.getMap().getName().equals(map.getName());
        } else {
            return false;
        }
    }
	
	@Override
    public int hashCode() {
        return Objects.hash(map);
    }

    @Override
    public String toString() {
        return "PxInstanceType [" + map.getName() + "]";
    }
}
