package fr.unitale.games.infected.weapons;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gun.GunAPI;
import fr.unitale.sdk.gun.model.Gun;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;

import java.util.HashMap;
import java.util.Map;

public class InfectedArsenal {

    private UniItemStack gunItem = new UniItemStack(Material.IRON_HOE).setName("game.infected.item.gun.name").setLores("game.infected.item.gun.desc");
    private UniItemStack shotgunItem = new UniItemStack(Material.DIAMOND_HOE).setName("game.infected.item.shotgun.name").setLores("game.infected.item.shotgun.desc");

    private Map<UniPlayer, Integer> guns;
    private Map<UniPlayer, Integer> shotguns;

    public InfectedArsenal() {
        guns = new HashMap<>();
        shotguns = new HashMap<>();
    }

    public void resetAll() {
        GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
        guns.values().forEach(api::unregister);
        guns.clear();
        shotguns.values().forEach(api::unregister);
        shotguns.clear();
    }

    public UniItemStack getNewGunItem(UniPlayer player) {
        UniItemStack stack = UniItemStack.fromItemStack(gunItem);
        final Gun gun = getOrCreateGun(player);
        gun.injectTag(stack);
        stack.setAmount(gun.getCharger());
        return stack;
    }

    public UniItemStack getNewShotGunItem(UniPlayer player) {
        UniItemStack stack = UniItemStack.fromItemStack(shotgunItem);
        final Gun gun = getOrCreateShotGun(player);
        gun.injectTag(stack);
        stack.setAmount(gun.getCharger());
        return stack;
    }

    public void reset(UniPlayer player) {
        resetGun(player);
        resetShotGun(player);
    }

    public void resetGun(UniPlayer player) {
        if (guns.containsKey(player)) {
            GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
            int id = guns.get(player);
            api.unregister(id);
            guns.remove(player);
        }
    }

    public void resetShotGun(UniPlayer player) {
        if (shotguns.containsKey(player)) {
            GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
            int id = shotguns.get(player);
            api.unregister(id);
            shotguns.remove(player);
        }
    }

    public Gun getOrCreateGun(UniPlayer player) {
        GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
        if (!guns.containsKey(player)) {
            Gun g = new InfectedGun();
            api.registerGun(g);
            guns.put(player, g.getId());
            return g;
        } else {
            return api.getInstanceFromId(guns.get(player));
        }
    }

    public Gun getOrCreateShotGun(UniPlayer player) {
        GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
        if (!shotguns.containsKey(player)) {
            Gun g = new InfectedShotGun();
            api.registerGun(g);
            shotguns.put(player, g.getId());
            return g;
        } else {
            return api.getInstanceFromId(shotguns.get(player));
        }
    }
}
