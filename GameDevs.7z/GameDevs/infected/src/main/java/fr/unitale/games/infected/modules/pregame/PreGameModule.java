package fr.unitale.games.infected.modules.pregame;

import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.map.infected.InfectedMap;
import fr.unitale.sdk.gameengine.modules.Module;

public class PreGameModule extends Module<PreGameModuleListener> {

    private InfectedMap hubMap;

    public PreGameModule() {
        moduleListener = new PreGameModuleListener(this);
    }

    @Override
    public void startModule() {
        hubMap = (InfectedMap) MapType.INFECTED_HUB.getInstance();
    }

    @Override
    public void endModule() {
    }

    public InfectedMap getHubMap() {
        return hubMap;
    }

}
