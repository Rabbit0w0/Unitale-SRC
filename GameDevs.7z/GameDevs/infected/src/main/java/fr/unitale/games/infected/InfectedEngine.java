package fr.unitale.games.infected;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.api.type.ServerTypes.ServerType;
import fr.unitale.games.infected.modules.phase.PhaseModule;
import fr.unitale.games.infected.modules.pregame.PreGameModule;
import fr.unitale.games.infected.team.InfectedTeam;
import fr.unitale.games.infected.weapons.InfectedArsenal;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.MapType;
import fr.unitale.sdk.gameengine.map.infected.InfectedMap;
import fr.unitale.sdk.gameengine.map.infected.InfectedMap.SpawnType;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.gameplay.Gameplay;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.gameplay.modules.NoCollisionModule;
import fr.unitale.sdk.gun.GunAPI;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.resourcepack.ResourcePackType;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.Material;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Team.OptionStatus;

import java.util.Random;

public class InfectedEngine extends GameEngine<InfectedMap> {

    private static InfectedEngine __instance;
    private static String[] types = new String[]{"INFECTED_LABO", "INFECTED_FACTORY", "INFECTED_DOME"};
    public static String ZOMBIE_WEAPON_KEY = "infected_weapon_key", ZOMBIE_TRACKER_KEY = "infected_tracker_key";

    private InfectedArsenal arsenal;
    private InfectedTeam marinesTeam, zombiesTeam;
    private UniItemStack zombieWeapon, zombieTracker;
    private PhaseModule phaseModule;

    public InfectedEngine(JavaPlugin plugin, String json) {
        super(plugin, json);

        __instance = this;

        UnitaleSDK.getAPI(GunAPI.class).setManuallyManaged(true);

        zombieWeapon = new UniItemStack(Material.BLAZE_ROD).addKey(ZOMBIE_WEAPON_KEY).setName("game.infected.item.zombieweapon.name").setLores("game.infected.item.zombieweapon.description");
        zombieTracker = new UniItemStack(Material.NETHER_STAR).addKey(ZOMBIE_TRACKER_KEY).setName("game.infected.item.zombietracker.name").setLores("game.infected.item.zombietracker.description");

        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(new Gameplay(new NoCollisionModule()));
        arsenal = new InfectedArsenal();

        ServerManager.type = ServerType.INFECTED;
        setServerMode(ServerMode.fromString(getConfig("servermode", "NORMAL")));
        setGameStatus(GameStatus.WAIT);
        mode = Mode.SOLO;
        setKeepOffline(false);

        String mapName = GameEngine.getInstance().getConfig("map", getRandomMap());
        mapName = mapName.equals("null") ? getRandomMap() : mapName;
        gameMap = (InfectedMap) MapType.fromString(mapName).getInstance();
        gameMap.getWorld().setDifficulty(Difficulty.PEACEFUL);

        WeatherAPI.setTime(TimeSet.DAY, gameMap.getWorld());
        gameMap.getWorld().setGameRuleValue("doDayLightCycle", "false");

        marinesTeam = (InfectedTeam) new InfectedTeam("marines", UniColor.CYAN, 100).setType(SpawnType.PLAYER).setNameTagVisibility(OptionStatus.FOR_OWN_TEAM);
        zombiesTeam = (InfectedTeam) new InfectedTeam("zombies", UniColor.PURPLE, 100).setType(SpawnType.ZOMBIE).setNameTagVisibility(OptionStatus.FOR_OWN_TEAM);

        getModuleManager().clear();
        UniTeam.setShouldTeamJoinBeShouted(() -> false);
        UniTeam.setShouldTeamLeaderBeShouted(() -> false);
        TeamModule<InfectedTeam> tm = new TeamModule<>(InfectedTeam.class);
        tm.addTeam(marinesTeam);
        tm.addTeam(zombiesTeam);
        getModuleManager().addModule(tm, true);
        getModuleManager().addModule(new PreGameModule(), true);

        PhaseModule phaseModule = new PhaseModule(1);
        getModuleManager().addModule(phaseModule);
        setPhaseModule(phaseModule);

        WaitingModule wm = new WaitingModule(PhaseModule.class);
        wm.setMinPlayers(8);
        wm.setVoteStartByPlayers(() -> false);
        getModuleManager().addModule(wm, true);

        PlayerGameStat.PARTICIPATION.setMoney(MoneyType.GOLD, 20);
        PlayerGameStat.VICTORY.setMoney(MoneyType.EMERALDS, 1);
        PlayerGameStat.PLACE_1.setMoney(MoneyType.GOLD, 15);
        PlayerGameStat.PLACE_2.setMoney(MoneyType.GOLD, 10);
        PlayerGameStat.PLACE_3.setMoney(MoneyType.GOLD, 5);
    }

    public static InfectedEngine getInstance() {
        return __instance;
    }

    /**
     * @return the marinesTeam
     */
    public InfectedTeam getMarinesTeam() {
        return marinesTeam;
    }

    /**
     * @return the zombiesTeam
     */
    public InfectedTeam getZombiesTeam() {
        return zombiesTeam;
    }

    /**
     * @return the zombieWeapon
     */
    public UniItemStack getZombieWeapon() {
        return zombieWeapon;
    }

    /**
     * @return the zombieTracker
     */
    public UniItemStack getZombieTracker() {
        return zombieTracker;
    }

    /**
     * @return the arsenal
     */
    public InfectedArsenal getArsenal() {
        return arsenal;
    }

    /**
     * @return the phaseModule
     */
    public PhaseModule getPhaseModule() {
        return phaseModule;
    }

    /**
     * @param phaseModule the phaseModule to set
     */
    public void setPhaseModule(PhaseModule phaseModule) {
        this.phaseModule = phaseModule;
    }

    private String getRandomMap() {
        return types[new Random().nextInt(types.length)];
    }

    @Override
    protected void userJoin(UniPlayer player) {
        Bukkit.getScheduler().runTask(getPlugin(), () -> ResourcePackType.INFECTED.send(player));
    }

    @Override
    protected void userQuit(UniPlayer player) {
        player.resetMaxHealth();
        player.setMaxHealth(20);
        player.setHealth(20);
    }

}
