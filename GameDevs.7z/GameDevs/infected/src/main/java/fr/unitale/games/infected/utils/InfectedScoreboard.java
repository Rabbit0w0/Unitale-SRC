package fr.unitale.games.infected.utils;

import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.games.infected.modules.phase.PhaseModule;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.utils.generic.TimeManager;
import org.bukkit.ChatColor;
import org.bukkit.scoreboard.DisplaySlot;

import java.util.List;
import java.util.stream.IntStream;

public class InfectedScoreboard extends UniScoreboard {

    private static final String PLAYERS_POINTS_LIST = "infected-points:";
    private UniPlayer player;

    public InfectedScoreboard(UniPlayer player) {
        this.player = player;
        init();
    }

    private void init() {
        int i = 0;
        createSideBoard(ChatColor.DARK_RED + "Infected");
        addScore("delimiter_up", ChatColor.GREEN + "-------", i++, DisplaySlot.SIDEBAR);
        addScore("phase", i++, DisplaySlot.SIDEBAR);
        addScore("space_1", " ", i++, DisplaySlot.SIDEBAR);
        addScore("playercount", i++, DisplaySlot.SIDEBAR);
        addScore("zombiecount", i++, DisplaySlot.SIDEBAR);
        addScore("space_2", "  ", i++, DisplaySlot.SIDEBAR);
        addScore("points", Lang.str(player, "game.infected.scoreboard.points", "" + player.getStorage().getInteger(PhaseModule.POINTS_KEY, 0)), i++, DisplaySlot.SIDEBAR);
        addScore("space_3", "   ", i++, DisplaySlot.SIDEBAR);
        addScore("topplayers", Lang.str(player, "game.infected.scoreboard.topplayers"), i++, DisplaySlot.SIDEBAR);
        addScore("topplayer_1", i++, DisplaySlot.SIDEBAR);
        addScore("topplayer_2", i++, DisplaySlot.SIDEBAR);
        addScore("topplayer_3", i++, DisplaySlot.SIDEBAR);
        addScore("space_4", "    ", i++, DisplaySlot.SIDEBAR);
        addScore("killed", i++, DisplaySlot.SIDEBAR);
        addScore("delimiter_down", ChatColor.GREEN + "------", i++, DisplaySlot.SIDEBAR);

        //create list board
        addObjective("POINTS", "dummy", DisplaySlot.PLAYER_LIST, "POINTS");
        InfectedEngine.getInstance().getCompetingPlayers().forEach(p -> {
            addScore(PLAYERS_POINTS_LIST + p.getUniqueId().toString(),
                    p.getName(),
                    p.getStorage().getInteger(PhaseModule.POINTS_KEY, 0), DisplaySlot.PLAYER_LIST);
        });
    }

    public void update(PhaseModule module) {
        setObjectiveTitle(Lang.str(player, "game.infected.scoreboard.title", TimeManager.stringOf(module.getTimer().getMinutes()), TimeManager.stringOf(module.getTimer().getSeconds())), DisplaySlot.SIDEBAR);
        updateScore("phase", Lang.str(player, "game.infected.scoreboard.phase", "" + module.getPhaseNumber()));
        updateScore("playercount", Lang.str(player, "game.infected.scoreboard.playercount", "" + InfectedEngine.getInstance().getMarinesTeam().getCompetingCount()));
        updateScore("zombiecount", Lang.str(player, "game.infected.scoreboard.zombiecount", "" + InfectedEngine.getInstance().getZombiesTeam().getCompetingCount()));
        updateScore("points", Lang.str(player, "game.infected.scoreboard.points", "" + player.getStorage().getInteger(PhaseModule.POINTS_KEY, 0)));

        List<UniPlayer> bestPlayers = module.getBestPlayers(PhaseModule.POINTS_KEY);
        IntStream.range(0, 3).forEach(i -> {
            try {
                UniPlayer p = bestPlayers.get(i);
                updateScore("topplayer_" + (i + 1), Lang.str(player, "game.infected.scoreboard.topplayer", "" + (i + 1), p.getName()));
            } catch (IndexOutOfBoundsException e) {
                updateScore("topplayer_" + (i + 1), Lang.str(player, "game.infected.scoreboard.none", "" + (i + 1)) + (i == 0 ? "" : i == 1 ? " " : "  "));
            }
        });

        updateScore("killed", Lang.str(player, "game.infected.scoreboard.killed", "" + player.getStorage().getInteger(PhaseModule.KILL_COUNT_STORAGE_KEY, 0)));

        //update list board
        InfectedEngine.getInstance().getOnlinePlayers()
                .forEach(p -> getScore(PLAYERS_POINTS_LIST + p.getUniqueId().toString()).setValue(p.getStorage().getInteger(PhaseModule.POINTS_KEY, 0)));
    }
}
