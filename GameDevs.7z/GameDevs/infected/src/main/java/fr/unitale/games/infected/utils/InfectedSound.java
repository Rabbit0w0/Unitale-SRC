package fr.unitale.games.infected.utils;

import fr.unitale.sdk.utils.sound.CustomSound;
import org.bukkit.Sound;

public enum InfectedSound implements CustomSound{
	ANNOUNCER_BEGIN_1S("game.infected.announcer.begin.1", null),
	ANNOUNCER_BEGIN_2S("game.infected.announcer.begin.2", null),
	ANNOUNCER_BEGIN_3S("game.infected.announcer.begin.3", null),
	ANNOUNCER_BEGIN_4S("game.infected.announcer.begin.4", null),
	ANNOUNCER_BEGIN_5S("game.infected.announcer.begin.5", null),

	AMBIENT_DOME("game.infected.ambient.dome", null),
	AMBIENT_FACTORY("game.infected.ambient.factory", null),
	AMBIENT_LABO("game.infected.ambient.labo", null),

    KILLS_2("game.infected.kills.2", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_3("game.infected.kills.3", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_4("game.infected.kills.4", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_5("game.infected.kills.5", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_6("game.infected.kills.6", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_7("game.infected.kills.7", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_8("game.infected.kills.8", Sound.ENTITY_PLAYER_ATTACK_CRIT),
    KILLS_9("game.infected.kills.9", Sound.ENTITY_PLAYER_ATTACK_CRIT),

    SKILL_JUMP("game.infected.skills.jump", Sound.BLOCK_PISTON_EXTEND),
    SKILL_RECOIL("game.infected.skills.recoil", null),

    MAGNUM_FAR("game.infected.weapons.gun.magnum.far", null),
    MAGNUM_RELOAD("game.infected.weapons.gun.magnum.reload", Sound.ENTITY_ITEM_PICKUP),
    MAGNUM_SHOT("game.infected.weapons.gun.magnum.shot", Sound.ENTITY_GENERIC_EXPLODE),

    SHOTGUN_FAR("game.infected.weapons.gun.shotgun.far", null),
    SHOTGUN_RELOAD("game.infected.weapons.gun.shotgun.reload", Sound.ENTITY_ITEM_PICKUP),
    SHOTGUN_SHOT("game.infected.weapons.gun.shotgun.shot", Sound.ENTITY_GENERIC_EXPLODE),

    SWORD_HIT("game.infected.weapons.sword.hit", Sound.BLOCK_REDSTONE_TORCH_BURNOUT),
    SWORD_MELEE("game.infected.weapons.sword.melee", null);

	private String key;
	private long duration;
	private Sound alternative;
	
	InfectedSound(String key, Sound alternative) {
		this(key, 0l, alternative);
	}
	
	InfectedSound(String key, long duration, Sound alternative) {
		this.key = key;
		this.duration = duration;
		this.alternative = alternative;
	}
	
	@Override
	public String getKey() {
		return key;
	}
	
	@Override
	public long getDuration() {
		return duration;
	}

    @Override
    public Sound getAlternative() {
        return alternative;
    }
}
