package fr.unitale.games.infected.modules.pregame;

import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import fr.unitale.games.infected.utils.InfectedSound;
import fr.unitale.sdk.gameengine.map.infected.InfectedMap.SpawnType;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.wait.events.WaitTimeChangedEvent;
import fr.unitale.sdk.players.event.UnitalePlayerJoinEvent;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;

public class PreGameModuleListener extends ModuleListener<PreGameModule> {

    public PreGameModuleListener(PreGameModule module) {
        super(module);
    }

    @EventHandler
    public void onTimerUpdated(WaitTimeChangedEvent e) {
        final int seconds = e.getTimer().getSeconds();
        final int minutes = e.getTimer().getMinutes();
        if (minutes == 0 && seconds <= 5 && seconds > 0) {
            SoundCreator.playSound(InfectedSound.valueOf("ANNOUNCER_BEGIN_" + seconds + "S"), SoundMaster.VOICE, 1.0f);
        }
    }

    @EventHandler
    public void onPlayerJoin(UnitalePlayerJoinEvent e) {
        e.getPlayer().teleport(getModule().getHubMap().getRandomSpawnLocation(SpawnType.PLAYER));
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        if (e.getTo().getY() <= 0D) {
            e.getPlayer().teleport(getModule().getHubMap().getRandomSpawnLocation(SpawnType.PLAYER));
        }
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onItemDrop(PlayerDropItemEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerSwap(PlayerSwapHandItemsEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerSneak(PlayerToggleSneakEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent ev) {
        ev.setCancelled(true);
    }
}
