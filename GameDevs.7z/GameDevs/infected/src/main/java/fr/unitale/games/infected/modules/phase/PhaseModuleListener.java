package fr.unitale.games.infected.modules.phase;

import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.games.infected.utils.InfectedScoreboard;
import fr.unitale.games.infected.utils.InfectedSound;
import fr.unitale.games.infected.utils.RespawnAura;
import fr.unitale.games.infected.weapons.InfectedShotGun;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.features.aura.AuraAPI;
import fr.unitale.sdk.gameengine.map.infected.InfectedMap.SpawnType;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gun.GunAPI;
import fr.unitale.sdk.gun.model.Gun;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.morphs.MorphAPI;
import fr.unitale.sdk.morphs.model.Morph;
import fr.unitale.sdk.morphs.model.MorphType;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.players.event.UnitalePlayerQuitEvent;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.items.DropFactory;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class PhaseModuleListener extends ModuleListener<PhaseModule> {

    //map of each players's cooldown for weapons
    //bitfield represents cooldown enabled for 1->ZombieWeaponPush 2->tracker 3->gun 4->ZombieWeaponDamage
    private Map<UniPlayer, Integer> cooldowns;

    public PhaseModuleListener(PhaseModule module) {
        super(module);
        cooldowns = new HashMap<>(Bukkit.getOnlinePlayers().size());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void damage(EntityDamageByEntityEvent ev) {
        if (!module.phaseStarted) {
            ev.setCancelled(true);
            return;
        }
        if (!(ev.getDamager() instanceof Player) || !(ev.getEntity() instanceof Player)) {
            ev.setCancelled(true);
            return;
        }

        UniPlayer victim = (UniPlayer) ev.getEntity();
        UniPlayer killer = (UniPlayer) ev.getDamager();
        UniItemStack item = killer.getMainHandItem();

        //if item is null
        if (item == null) {
            ev.setCancelled(true);
            return;
        }

        //if same team (Team damage)
        if ((InfectedEngine.getInstance().getMarinesTeam().contains(victim) && InfectedEngine.getInstance().getMarinesTeam().contains(killer))
                ||
                (InfectedEngine.getInstance().getZombiesTeam().contains(victim) && InfectedEngine.getInstance().getZombiesTeam().contains(killer))) {
            ev.setCancelled(true);
            return;
        }

        if (item.getTag().hasKey(InfectedEngine.ZOMBIE_WEAPON_KEY)) {
            if (isInCooldownFor(killer, CooldownType.ZOMBIE_WEAPON)) {
                killer.sendMessage(Lang.str(killer, "game.infected.item.cooldown"));
                ev.setCancelled(true);
                return;
            }

            //force damage to be one shot
            ev.setDamage(20);

            //set cooldown
            setCooldownFor(killer, CooldownType.ZOMBIE_WEAPON, true);
            Bukkit.getScheduler().runTaskLater(InfectedEngine.getInstance().getPlugin(), () -> setCooldownFor(killer, CooldownType.ZOMBIE_WEAPON, false), 20L);
        }

        if (victim.getHealth() <= ev.getDamage()) {
            ev.setCancelled(true);
            if (InfectedEngine.getInstance().getMarinesTeam().contains(victim) && InfectedEngine.getInstance().getZombiesTeam().contains(killer)) {
                //a zombie has killed a marines
                Lang.bcst("game.infected.kill", victim.getName(), killer.getName());

                module.setLastMarine(victim);

                InfectedEngine.getInstance().getMarinesTeam().removePlayer(victim);
                InfectedEngine.getInstance().getZombiesTeam().addPlayer(victim);

                SoundCreator.playSound(InfectedSound.SWORD_HIT, SoundMaster.PLAYERS,1f, victim);
                SoundCreator.playSound(victim.getLocation(), InfectedSound.SWORD_HIT, SoundMaster.PLAYERS, 1f, 1f, 16);

                final Location particleSpawnLoc = victim.getLocation().clone();
                particleSpawnLoc.add(0, 1.3, 0);
                ParticleEffect.BLOCK_CRACK.display(new ParticleEffect.BlockData(Material.REDSTONE_WIRE, (byte) 0), 0.2f, 0.2f, 0.2f, 2, 50, particleSpawnLoc);
                DropFactory.drop(particleSpawnLoc, new UniItemStack(Material.BONE),5, false, false, 100);

                //add points for infection
                killer.getStorage().addInteger(PhaseModule.POINTS_KEY, killer.getStorage().getInteger(PhaseModule.POINTS_KEY, 0) + 30);
                killer.sendMessage(Lang.str(killer, "game.infected.points", ""+30));

                registerInfection(killer);
                registerDeath(victim);
                registerKill(killer);
                respawn(victim, true, true);

                PlayerCollector.doForEach(p -> ((InfectedScoreboard)p.getEndScoreboard()).update(module));

                checkPhaseEnd();
            }
        }
    }

    @EventHandler
    public void interact(PlayerInteractEvent ev) {
        if (!module.phaseStarted) {
            ev.setCancelled(true);
            return;
        }
        if (ev.hasItem()) {
            UniPlayer player = (UniPlayer) ev.getPlayer();
            UniItemStack item = UniItemStack.fromItemStack(ev.getItem());
            if (ev.getAction().equals(Action.RIGHT_CLICK_AIR) || ev.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {//right click
                if (item.hasKey(InfectedEngine.ZOMBIE_WEAPON_KEY)) {//if should propulse
                    if (isInCooldownFor(player, CooldownType.ZOMBIE_PUSH)) {
                        player.sendMessage(Lang.str(player, "game.infected.item.cooldown"));
                    } else {//can propulse
                        Vector dir = player.getLocation().getDirection().clone();
                        dir.normalize().multiply(1.5);
                        dir.setY(6.0 / 7.0);
                        player.setVelocity(dir);
                        SoundCreator.playSound(player.getLocation(), InfectedSound.SKILL_JUMP, SoundMaster.PLAYERS, 1f, 1f, 16);
                        //add cooldown tag
                        setCooldownFor(player, CooldownType.ZOMBIE_PUSH, true);
                        player.setExp(0);
                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                if (player.getExp() >= 1) {
                                    //remove cooldown tag
                                    setCooldownFor(player, CooldownType.ZOMBIE_PUSH, false);
                                    //cancel this task
                                    Bukkit.getScheduler().cancelTask(getTaskId());
                                } else {
                                    player.setExp(player.getExp() + 1.0f / 16.0f);
                                }
                            }
                        }.runTaskTimer(InfectedEngine.getInstance().getPlugin(), 0L, 5L);
                    }
                }

                if (item.hasKey(InfectedEngine.ZOMBIE_TRACKER_KEY)) {
                    if (isInCooldownFor(player, CooldownType.TRACKER)) {
                        player.sendMessage(Lang.str(player, "game.infected.item.cooldown"));
                    } else {
                        Location zombieLoc = player.getEyeLocation();
                        UniPlayer nearestPlayer = InfectedEngine.getInstance().getMarinesTeam().getOnlineCompetingPlayers().stream()
                                .min(Comparator.comparing(p -> zombieLoc.distance(p.getEyeLocation())))
                                .orElse(null);
                        if (nearestPlayer == null) return;
                        Bukkit.getScheduler().runTaskAsynchronously(InfectedEngine.getInstance().getPlugin(), () -> {
                            Vector dist = new Vector(nearestPlayer.getEyeLocation().getX() - zombieLoc.getX(),
                                    nearestPlayer.getEyeLocation().getY() - zombieLoc.getY(),
                                    nearestPlayer.getEyeLocation().getZ() - zombieLoc.getZ()).multiply(1.0 / 30.0);
                            for (double i = 0; i < 30; i++) {
                                Location particleLoc = zombieLoc.add(dist);
                                Random r = new Random();
                                for (int x = 0; x < 5; x++) {
                                    Vector randomPropagation = new Vector(r.nextFloat(), r.nextFloat(), r.nextFloat());
                                    randomPropagation.multiply(0.3);
                                    ParticleEffect.REDSTONE.display(new ParticleEffect.OrdinaryColor(255, 0, 0), particleLoc.clone().add(randomPropagation));
                                }
                            }
                        });
                        //add cooldown
                        setCooldownFor(player, CooldownType.TRACKER, true);
                        Bukkit.getScheduler().runTaskLater(InfectedEngine.getInstance().getPlugin(), () -> {
                            setCooldownFor(player, CooldownType.TRACKER, false);
                        }, 100L);
                    }
                }

                GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
                Gun gun = api.getInstanceFrom(item);
                if (gun != null) {
                    gun.shoot(player);
                }
            } else if (ev.getAction().equals(Action.LEFT_CLICK_AIR) || ev.getAction().equals(Action.LEFT_CLICK_BLOCK)) {
                if (item.hasKey(InfectedEngine.ZOMBIE_WEAPON_KEY)){
                    SoundCreator.playSound(player.getLocation(), InfectedSound.SWORD_MELEE,SoundMaster.PLAYERS, 1f, 1f, 16);
                }
                GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
                Gun gun = api.getInstanceFrom(item);
                if (gun instanceof InfectedShotGun) {
                    if (isInCooldownFor(player, CooldownType.GUN)) {
                        player.sendMessage(Lang.str(player, "game.infected.item.cooldown"));
                    } else {
                        Vector dir = player.getLocation().getDirection().clone();
                        dir.multiply(-1.5f);
                        dir.setY(6.0 / 7.0);
                        player.setVelocity(dir);
                        SoundCreator.playSound(player.getLocation(), InfectedSound.SKILL_JUMP, SoundMaster.PLAYERS,1f, 1f, 16);
                        //add cooldown
                        setCooldownFor(player, CooldownType.GUN, true);
                        player.setExp(0);
                        //schedule end of cooldown
                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                if (player.getExp() >= 1) {
                                    //remove cooldown
                                    setCooldownFor(player, CooldownType.GUN, false);
                                    //cancel this task
                                    Bukkit.getScheduler().cancelTask(getTaskId());
                                } else {
                                    player.setExp(player.getExp() + 1.0f / 16.0f);
                                }
                            }
                        }.runTaskTimer(InfectedEngine.getInstance().getPlugin(), 0l, 5l);
                    }
                }
            }
        }
    }

    @EventHandler
    public void entityDamage(EntityDamageEvent ev) {
        //cancel if the phase is not started
        if (!module.phaseStarted) {
            ev.setCancelled(true);
            return;
        }

        if(ev.getCause() == EntityDamageEvent.DamageCause.LAVA){
            if(ev.getEntity() instanceof UniPlayer){
                UniPlayer player = (UniPlayer) ev.getEntity();
                if(player.getHealth() <= ev.getFinalDamage()){
                    //if player should die, then we respawn it
                    ev.setCancelled(true);
                    respawn(player, true, InfectedEngine.getInstance().getMarinesTeam().contains(player));
                }
            }
            //check for damage other than custom (which means gun)
        }else if(ev.getCause() != EntityDamageEvent.DamageCause.CUSTOM){
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void decay(BlockFadeEvent ev){
        ev.setCancelled(true);
    }

    @EventHandler
    public void decayLeaves(LeavesDecayEvent ev){
        ev.setCancelled(true);
    }

    @EventHandler
    public void playerMove(PlayerMoveEvent ev) {
        if (!module.phaseStarted) {
            return;
        }
        UniPlayer player = (UniPlayer) ev.getPlayer();

        long now = Calendar.getInstance().getTimeInMillis();
        long lastmove = player.getStorage().getLong(PhaseModule.LAST_MOVE_STORAGE_KEY, now);
        player.getStorage().addLong(PhaseModule.CAMPING_TIME_STORAGE_KEY,
                Math.max(
                        now - lastmove,
                        player.getStorage().getInteger(PhaseModule.CAMPING_TIME_STORAGE_KEY, 0)));
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent ev) {
        ev.setCancelled(true);
        UniPlayer player = (UniPlayer) ev.getPlayer();
        GunAPI api = UnitaleSDK.getAPI(GunAPI.class);
        UniItemStack stack = UniItemStack.fromItemStack(ev.getItemDrop().getItemStack());
        Gun gun = api.getInstanceFrom(stack);
        if (gun != null) {
            gun.reload(player);
        }
    }

    @EventHandler
    public void onHealthRegain(EntityRegainHealthEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerSwap(PlayerSwapHandItemsEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onPlayerSneak(PlayerToggleSneakEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent ev) {
        ev.setCancelled(true);
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent ev) {
        ev.setCancelled(true);
    }

    //When a player left the game, we check whether the game should be stopped
    @EventHandler
    public void on(UnitalePlayerQuitEvent ev){
        checkPhaseEnd();
    }

    public void registerKillAtOnce(UniPlayer player, int count) {
        player.getStorage().addInteger(PhaseModule.DOUBLE_KILL_KEY, Math.max(player.getStorage().getInteger(PhaseModule.DOUBLE_KILL_KEY, 0), count));
    }

    //register a new infection
    private void registerInfection(UniPlayer player) {
        //increment infection count
        player.getStorage().addInteger(PhaseModule.INFECTION_COUNT_STORAGE_KEY, player.getStorage().getInteger(PhaseModule.INFECTION_COUNT_STORAGE_KEY, 0) + 1);
    }

    //register a new death
    public void registerDeath(UniPlayer player) {
        //increment death count
        player.getStorage().addInteger(PhaseModule.DEATH_COUNT_STORAGE_KEY, player.getStorage().getInteger(PhaseModule.DEATH_COUNT_STORAGE_KEY, 0) + 1);
        //check max kill streak count
        player.getStorage().addInteger(PhaseModule.MAX_KILL_STREAK_COUNT_STORAGE_KEY,
                Math.max(
                        player.getStorage().getInteger(PhaseModule.KILL_STREAK_COUNT_STORAGE_KEY, 0),
                        player.getStorage().getInteger(PhaseModule.MAX_KILL_STREAK_COUNT_STORAGE_KEY, 0)));
        //reset kill streak count
        player.getStorage().addInteger(PhaseModule.KILL_STREAK_COUNT_STORAGE_KEY, 0);
    }

    //register a new kill and kill streaks
    public void registerKill(UniPlayer player) {
        //increment kill count
        player.getStorage().addInteger(PhaseModule.KILL_COUNT_STORAGE_KEY, player.getStorage().getInteger(PhaseModule.KILL_COUNT_STORAGE_KEY, 0) + 1);
        //increment kill count per game
        player.getStorage().addInteger(PhaseModule.KILL_COUNT_PER_PHASE_STORAGE_KEY, player.getStorage().getInteger(PhaseModule.KILL_COUNT_PER_PHASE_STORAGE_KEY, 0) + 1);
        //increment kill streak
        player.getStorage().addInteger(PhaseModule.KILL_STREAK_COUNT_STORAGE_KEY, player.getStorage().getInteger(PhaseModule.KILL_STREAK_COUNT_STORAGE_KEY, 0) + 1);
        //check for max kill streak
        player.getStorage().addInteger(PhaseModule.MAX_KILL_STREAK_COUNT_STORAGE_KEY,
                Math.max(
                        player.getStorage().getInteger(PhaseModule.KILL_STREAK_COUNT_STORAGE_KEY, 0),
                        player.getStorage().getInteger(PhaseModule.MAX_KILL_STREAK_COUNT_STORAGE_KEY, 0)));
    }

    //respawn player at random location
    public void respawn(UniPlayer player, boolean teleport, boolean cooldown) {
        player.setFireTicks(0);
        player.setMaxHealth(20);
        player.setHealth(20);
        player.setExp(1);
        player.getInventory().clear();
        player.setGameMode(GameMode.SURVIVAL);
        player.removePotionEffect(PotionEffectType.SPEED);
        if (InfectedEngine.getInstance().getMarinesTeam().contains(player)) {
            //player is a marines
            MorphAPI.getMorphManager().deleteMorph(player);
            InfectedEngine.getInstance().getArsenal().reset(player);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30000, 1));
            player.getInventory().setItem(0, InfectedEngine.getInstance().getArsenal().getNewGunItem(player).translate(player));
            player.getInventory().setItem(1, InfectedEngine.getInstance().getArsenal().getNewShotGunItem(player).translate(player));
            player.getInventory().setHelmet(new UniItemStack(Material.DIAMOND_HELMET).setName("game.infected.armor.helmet.name").setLores("game.infected.armor.helmet.desc").translate(player));
            player.getInventory().setChestplate(new UniItemStack(Material.DIAMOND_CHESTPLATE).setName("game.infected.armor.chestplate.name").setLores("game.infected.armor.chestplate.desc").translate(player));
            player.getInventory().setLeggings(new UniItemStack(Material.DIAMOND_LEGGINGS).setName("game.infected.armor.leggings.name").setLores("game.infected.armor.leggings.desc").translate(player));
            player.getInventory().setBoots(new UniItemStack(Material.DIAMOND_BOOTS).setName("game.infected.armor.boots.name").setLores("game.infected.armor.boots.desc").translate(player));
            if (teleport)
                player.teleport(InfectedEngine.getInstance().getMap().getRandomSpawnLocation(SpawnType.PLAYER));
        } else {
            //player is a zombie
            if (teleport)
                player.teleport(InfectedEngine.getInstance().getMap().getRandomSpawnLocation(SpawnType.ZOMBIE));
            player.sendMessage(Lang.str(player, "game.infected.respawn"));
            Morph morph = MorphAPI.getMorphManager().getOrCreateMorph(player);
            if (cooldown) {
                morph.setType(MorphType.SKELETON);
                morph.setNameDisplayed(true);
                player.setInvulnerable(true);
                UnitaleSDK.getAPI(AuraAPI.class).setPlayerAura(new RespawnAura(player));
                Bukkit.getScheduler().runTaskLater(InfectedEngine.getInstance().getPlugin(), () -> {
                    //if timer is already more than 1 minute and the zombie is still alone
                    if (module.getTimer().getMinutes() < 4 && InfectedEngine.getInstance().getZombiesTeam().getCompetingCount() == 1) {
                        player.sendMessage(Lang.str(player, "game.infected.zombie.boosted"));
                        player.setMaxHealth(40);
                        player.setHealth(40);
                    }
                    player.getInventory().setItem(0, InfectedEngine.getInstance().getZombieWeapon().translate(player));
                    player.getInventory().setItem(1, InfectedEngine.getInstance().getZombieTracker().translate(player));
                    player.setInvulnerable(false);
                    morph.setType(MorphType.ZOMBIE);
                    morph.setNameDisplayed(true);
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30000, 0));
                    UnitaleSDK.getAPI(AuraAPI.class).removeAura(player);
                }, 60L);
            } else {
                //if timer is already more than 1 minute and the zombie is still alone
                if (module.getTimer().getMinutes() < 4 && InfectedEngine.getInstance().getZombiesTeam().getCompetingCount() == 1) {
                    player.sendMessage(Lang.str(player, "game.infected.zombie.boosted"));
                    player.setMaxHealth(40);
                    player.setHealth(40);
                }
                player.getInventory().setItem(0, InfectedEngine.getInstance().getZombieWeapon().translate(player));
                player.getInventory().setItem(1, InfectedEngine.getInstance().getZombieTracker().translate(player));
                morph.setType(MorphType.ZOMBIE);
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30000, 0));
                morph.setNameDisplayed(true);
            }
        }
    }

    //check for the end of the phase
    private void checkPhaseEnd() {
        if (InfectedEngine.getInstance().getMarinesTeam().getOnlineCompetingPlayers().size() == 0) module.end();
    }

    private boolean isInCooldownFor(UniPlayer p, CooldownType type) {
        int bf = cooldowns.getOrDefault(p, 0);
        return ((bf >> type.pos) & 1) == 1;
    }

    private void setCooldownFor(UniPlayer p, CooldownType type, boolean cooldown) {
        int bf = cooldowns.getOrDefault(p, 0);
        if (cooldown) bf |= (1 << type.pos);
        else bf &= ~(1 << type.pos);
        cooldowns.put(p, bf);
    }

    private enum CooldownType {
        ZOMBIE_PUSH(3),
        TRACKER(2),
        GUN(1),
        ZOMBIE_WEAPON(0);

        int pos;

        CooldownType(int pos) {
            this.pos = pos;
        }
    }
}
