package fr.unitale.games.infected.team;

import org.bukkit.Location;

import fr.unitale.sdk.gameengine.map.infected.InfectedMap;
import fr.unitale.sdk.gameengine.map.infected.InfectedMap.SpawnType;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.utils.color.UniColor;

public class InfectedTeam extends UniTeam {

    private SpawnType type;

    public InfectedTeam(String name, UniColor color, int size) {
        super(name, color, size);
    }

    /**
     * @return the type
     */
    public SpawnType getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public InfectedTeam setType(SpawnType type) {
        this.type = type;
        return this;
    }

    public void teleportRandom(InfectedMap map) {
        getOnlineCompetingPlayers().forEach(p -> {
            p.teleport(map.getRandomSpawnLocation(type));
        });
    }

    public void teleportAt(Location loc) {
        getOnlineCompetingPlayers().forEach(p -> p.teleport(loc));
    }

}
