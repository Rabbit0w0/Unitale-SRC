package fr.unitale.games.infected.modules.phase;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.games.infected.modules.pregame.PreGameModule;
import fr.unitale.games.infected.utils.InfectedScoreboard;
import fr.unitale.games.infected.utils.InfectedSound;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.Title;
import fr.unitale.sdk.utils.collect.PlayerCollector;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;
import fr.unitale.sdk.utils.math.RandomUtils;
import fr.unitale.sdk.utils.sound.SoundCreator;
import net.minecraft.server.v1_10_R1.EntityLightning;
import net.minecraft.server.v1_10_R1.PacketPlayOutSpawnEntityWeather;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_10_R1.entity.CraftPlayer;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.stream.Collectors;

public class PhaseModule extends Module<PhaseModuleListener> implements Updater {

    public static final String KILL_COUNT_STORAGE_KEY = "infected_kill_storage_key";//kill count
    public static final String KILL_COUNT_PER_PHASE_STORAGE_KEY = "infected_kill_per_game_storage_key";//kill count per game
    public static final String KILL_STREAK_COUNT_STORAGE_KEY = "infected_kill_streak_storage_key";//kill streak
    public static final String MAX_KILL_STREAK_COUNT_STORAGE_KEY = "infected_max_kill_streak_storage_key";//max kill streak
    public static final String INFECTION_COUNT_STORAGE_KEY = "infected_infection_storage_key";//infected count
    public static final String DEATH_COUNT_STORAGE_KEY = "infected_death_storage_key";//death count
    public static final String LAST_MOVE_STORAGE_KEY = "infected_last_move_storage_key";//last move
    public static final String CAMPING_TIME_STORAGE_KEY = "infected_camping_storage_key";//camping count
    public static final String KILL_AT_ONCE_COUNT = "infected_kill_at_once_count_storage_key";//double/triple kill...
    public static final String DOUBLE_KILL_KEY = "doublekill-check-key";
    public static final String POINTS_KEY = "infected-points-key";//amount of points

    private int phaseNumber;
    private UniTimer timer;
    protected boolean phaseStarted;
    private UniPlayer lastMarine;
    private BukkitTask pointIncrementer;
    final Set<UniPlayer> lastInfected = new LinkedHashSet<>();

    public PhaseModule(int phaseNumber) {
        this.phaseNumber = phaseNumber;
        this.timer = new UniTimer("INFECTED_TIMER_PHASE_" + phaseNumber, this, 5, 0);
        this.moduleListener = new PhaseModuleListener(this);
    }

    @Override
    public void startModule() {
        InfectedEngine.getInstance().getModuleManager().removeModule(PreGameModule.class);
        InfectedEngine.getInstance().setGameStatus(GameStatus.GAME);

        InfectedEngine.getInstance().setPhaseModule(this);
        InfectedEngine.getInstance().getArsenal().resetAll();

        //set new scoreboard, reset kill count and spawn all players
        //set all players to marines
        Bukkit.getOnlinePlayers().stream()
                .map(p -> (UniPlayer) p)
                .forEach(p -> {
                    InfectedEngine.getInstance().getMarinesTeam().addPlayer(p);
                    p.setScoreboard(new InfectedScoreboard(p));
                    p.getStorage().addInteger(KILL_COUNT_PER_PHASE_STORAGE_KEY, 0);
                    p.getStorage().addInteger(KILL_STREAK_COUNT_STORAGE_KEY, 0);
                    p.getStorage().addLong(LAST_MOVE_STORAGE_KEY, Calendar.getInstance().getTimeInMillis());
                    if (phaseNumber == 1) {
                        //reset stats
                        p.getStorage().addLong(CAMPING_TIME_STORAGE_KEY, 0L);
                        p.getStorage().addInteger(DEATH_COUNT_STORAGE_KEY, 0);
                        p.getStorage().addInteger(INFECTION_COUNT_STORAGE_KEY, 0);
                        p.getStorage().addInteger(KILL_COUNT_STORAGE_KEY, 0);
                        p.getStorage().addInteger(MAX_KILL_STREAK_COUNT_STORAGE_KEY, 0);
                        p.getStorage().addInteger(KILL_AT_ONCE_COUNT, 0);
                        p.getStorage().addInteger(POINTS_KEY, 0);
                    }
                    moduleListener.respawn(p, true, true);
                });

        //if it's first phase the play ambient sound
        if(phaseNumber == 1){
            switch(InfectedEngine.getInstance().getMap().getType()){
                case INFECTED_LABO:
                    SoundCreator.playSound(InfectedSound.AMBIENT_LABO, 1f);
                    break;
                case INFECTED_DOME:
                    SoundCreator.playSound(InfectedSound.AMBIENT_DOME, 1f);
                    break;
                case INFECTED_FACTORY:
                    SoundCreator.playSound(InfectedSound.AMBIENT_FACTORY, 1f);
                    break;
                default:
                    break;
            }
        }

        new BukkitRunnable() {
            int count = 10;

            @Override
            public void run() {
                if (count == 0) {
                    //get infected count
                    int infectedCount = 1;
                    if (Bukkit.getOnlinePlayers().size() >= 10) {
                        infectedCount++;
                    }
                    Lang.bcst("game.infected.infection.start");

                    //get a pool of player from which we can pick players to get infected
                    final List<UniPlayer> playerPool = InfectedEngine.getInstance().getOnlinePlayers();
                    //if not all players have been infected at least one time, get only the those players, else reset the lastInfected list
                    if(!lastInfected.containsAll(playerPool)){
                        playerPool.removeAll(lastInfected);
                    }else{
                        lastInfected.clear();
                    }
                    if(playerPool.size() == 1 && infectedCount == 2){
                        final UniPlayer randomPlayer = (UniPlayer) Bukkit.getOnlinePlayers().stream().filter(p -> !playerPool.contains(p)).findAny().orElse(null);
                        playerPool.add(randomPlayer);
                    }

                    new Random().ints(infectedCount, 0, playerPool.size())
                            .mapToObj(playerPool::get)
                            .forEach(p -> {
                                lastInfected.add(p);

                                PacketPlayOutSpawnEntityWeather thunderPacket = new PacketPlayOutSpawnEntityWeather(
                                        new EntityLightning(((CraftPlayer) p).getHandle().getWorld(),
                                                p.getLocation().getX(),
                                                p.getLocation().getY(),
                                                p.getLocation().getZ(),
                                                false,
                                                false));
                                Bukkit.getOnlinePlayers().stream().map(pl -> (UniPlayer) pl).forEach(pl -> pl.sendPacket(thunderPacket));

                                Lang.bcst("game.infected.infection.start.player", p.getDisplayName());
                                InfectedEngine.getInstance().getMarinesTeam().removePlayer(p);
                                InfectedEngine.getInstance().getZombiesTeam().addPlayer(p);

                                moduleListener.respawn(p, true, false);
                            });
                    SoundCreator.playSound(Sound.ENTITY_LIGHTNING_THUNDER, 1f);
                    cancel();
                } else {
                    Lang.bcst("game.infected.infection.start.timer", "" + count);
                    count--;
                }
            }
        }.runTaskTimer(InfectedEngine.getInstance().getPlugin(), 0, 20L);

        //create point incrementer incrementing player score per
        pointIncrementer = Bukkit.getScheduler().runTaskTimer(InfectedEngine.getInstance().getPlugin(), () -> {
            InfectedEngine.getInstance().getOnlinePlayers()
                    .stream()
                    .filter(p -> InfectedEngine.getInstance().getMarinesTeam().contains(p))
                    .forEach(p -> p.getStorage().addInteger(POINTS_KEY, p.getStorage().getInteger(POINTS_KEY, 0)+2));
        }, 0L, 20L);

        //start timer
        TimeManager.getInstance().addTimer(timer);

        phaseStarted = true;
    }

    @Override
    public void endModule() {
        //go to next phase
        InfectedEngine.getInstance().getModuleManager().addModule(new Phase2Module(lastInfected), true);
    }

    @Override
    public void end() {
        phaseStarted = false;
        pointIncrementer.cancel();
        displayEndPhase();
        TimeManager.getInstance().removeTimer(getTimer());

        //add 100 points for every marines alive at the end
        InfectedEngine.getInstance().getOnlinePlayers().stream()
                .filter(p -> InfectedEngine.getInstance().getMarinesTeam().contains(p))
                .forEach(p -> {
                    p.sendMessage(Lang.str(p, "game.infected.points", ""+100));
                    p.getStorage().addInteger(POINTS_KEY, p.getStorage().getInteger(POINTS_KEY, 0) + 100);
                });

        //end this module in 10s
        Bukkit.getScheduler().scheduleSyncDelayedTask(InfectedEngine.getInstance().getPlugin(), () -> InfectedEngine.getInstance().getModuleManager().removeModule(PhaseModule.class), 200L);
    }

    @Override
    public void start() {
    }

    @Override
    public void update() {
        PlayerCollector.doForEach(p -> {
            InfectedScoreboard sb = (InfectedScoreboard) p.getEndScoreboard();
            sb.update(this);

            if (p.getMaxHealth() > 20) {
                for (int i = 0; i < 10; i++) {
                    final double x = RandomUtils.nextDouble(-1, 1);
                    final double y = RandomUtils.nextDouble(-1, 1);
                    final double z = RandomUtils.nextDouble(-1, 1);
                    ParticleEffect.VILLAGER_HAPPY.display(new Vector(0, 1, 0), 1, p.getLocation().add(x, y + 1, z), 100);
                }
            }
        });
    }

    /**
     * @return the phaseNumber
     */
    public int getPhaseNumber() {
        return phaseNumber;
    }

    /**
     * @return the timer
     */
    public UniTimer getTimer() {
        return timer;
    }

    public BukkitTask getPointIncrementer() {
        return pointIncrementer;
    }

    /**
     * @return the phaseStarted
     */
    public boolean isPhaseStarted() {
        return phaseStarted;
    }

    /**
     * Get best players with a given integer key
     *
     * @param key    {@link String} key to check
     */
    public List<UniPlayer> getBestPlayers(String key) {
        List<UniPlayer> list = InfectedEngine.getInstance().getOnlinePlayers().stream()
                .sorted(Comparator.comparing(p -> p.getStorage().getInteger(key, 0)))
                .collect(Collectors.toList());
        Collections.reverse(list);
        return list;
    }

    /**
     * @return the lastMarine
     */
    public UniPlayer getLastMarine() {
        return lastMarine;
    }

    /**
     * @param lastMarine the lastMarine to set
     */
    public void setLastMarine(UniPlayer lastMarine) {
        this.lastMarine = lastMarine;
    }

    //display information about end of the game
    protected void displayEndPhase() {
        displayBestPlayers();
        final List<UniPlayer> orderedPointsPlayers = getBestPlayers(POINTS_KEY);
        final List<UniPlayer> orderedKillsPlayers = getBestPlayers(KILL_COUNT_STORAGE_KEY);
        PlayerCollector.doForEach(p -> {
            if (phaseNumber < 3) {
                final Title t = new Title(Lang.str(p, "game.infected.phase.ended"));
                t.setSubtitle(Lang.str(p, "game.infected.phase.ended.bestplayer", orderedKillsPlayers.get(0).getName()));
                t.send(p);
                p.sendMessage(Lang.str(p, "game.infected.phase.next.time"));
            } else {
                final Title t = new Title(Lang.str(p, "game.infected.game.end"));
                final int place = orderedPointsPlayers.indexOf(p);
                final String placeKey = "game.infected.position." + (place == 0 ? "1" : place == 1 ? "2" : "other");
                t.setSubtitle(Lang.str(p, "game.infected.position", Lang.str(p, placeKey, place+1), p.getStorage().getInteger(POINTS_KEY, 0)));
                t.send(p);
            }
        });
    }

    //display best camper, best kill...
    private void displayBestPlayers() {
        Lang.bcst("game.infected.chat.delimiter");

        UniPlayer bestInfecter = getBestPlayers(INFECTION_COUNT_STORAGE_KEY).get(0);
        Lang.bcst("game.infected.chat.best.infecter", bestInfecter.getDisplayName(), "" + bestInfecter.getStorage().getInteger(INFECTION_COUNT_STORAGE_KEY, 0));
        UniPlayer bestKiller = getBestPlayers(KILL_COUNT_STORAGE_KEY).get(0);
        Lang.bcst("game.infected.chat.best.kill", bestKiller.getDisplayName(), "" + bestKiller.getStorage().getInteger(KILL_COUNT_STORAGE_KEY, 0));
        UniPlayer bestKillStreak = getBestPlayers(MAX_KILL_STREAK_COUNT_STORAGE_KEY).get(0);
        Lang.bcst("game.infected.chat.best.killstreak", bestKillStreak.getDisplayName(), "" + bestKillStreak.getStorage().getInteger(MAX_KILL_STREAK_COUNT_STORAGE_KEY, 0));
        UniPlayer bestKillAtOnce = getBestPlayers(KILL_AT_ONCE_COUNT).get(0);
        Lang.bcst("game.infected.chat.best.killatonce", bestKillAtOnce.getDisplayName(), "" + bestKillAtOnce.getStorage().getInteger(KILL_AT_ONCE_COUNT, 0));
        UniPlayer bestDeath = getBestPlayers(DEATH_COUNT_STORAGE_KEY).get(0);
        Lang.bcst("game.infected.chat.best.death", bestDeath.getDisplayName(), "" + bestDeath.getStorage().getInteger(DEATH_COUNT_STORAGE_KEY, 0));
        UniPlayer bestCamper = getBestPlayers(CAMPING_TIME_STORAGE_KEY).get(0);
        Lang.bcst("game.infected.chat.best.camping", bestCamper.getDisplayName(), "" + bestCamper.getStorage().getInteger(CAMPING_TIME_STORAGE_KEY, 0));
        UniPlayer lastMarine = getLastMarine();
        if (lastMarine != null) Lang.bcst("game.infected.chat.best.marines", lastMarine.getDisplayName());

        Lang.bcst("game.infected.chat.delimiter");
    }
}
