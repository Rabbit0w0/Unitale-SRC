package fr.unitale.games.infected.modules.phase;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.stat.PlayerStatType;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.generic.TimeManager;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Phase3Module extends PhaseModule {

    public Phase3Module(Collection<UniPlayer> lastInfected) {
        super(3);
        this.lastInfected.addAll(lastInfected);
    }

    @Override
    public void endModule() {
        //end game
        InfectedEngine.getInstance().setGameStatus(GameStatus.END);
        InfectedEngine.getInstance().endGame(TimeManager.second * 10);
    }

    @Override
    public void end() {
        phaseStarted = false;
        getPointIncrementer().cancel();

        //add 100 points for every marines alive at the end
        InfectedEngine.getInstance().getOnlinePlayers().stream()
                .filter(p -> InfectedEngine.getInstance().getMarinesTeam().contains(p))
                .forEach(p -> {
                    p.sendMessage(Lang.str(p, "game.infected.points", "" + 100));
                    p.getStorage().addInteger(POINTS_KEY, p.getStorage().getInteger(POINTS_KEY, 0) + 100);
                });

        displayEndPhase();

        //compute stats from player points
        computeStats();

        TimeManager.getInstance().removeTimer(getTimer());
        InfectedEngine.getInstance().getModuleManager().removeModule(Phase3Module.class);
    }

    /**
     * Add the stats about player participations and places
     */
    private void computeStats() {
        //get all UniPlayer sorted by their points
        List<UniPlayer> players = InfectedEngine.getInstance().getOnlinePlayers()
                .stream()
                .sorted(Comparator.comparingInt(p -> p.getStorage().getInteger(POINTS_KEY, 0)))
                .collect(Collectors.toList());

        //iterate through each player and set place in game stat if necessary
        for (int i = 0; i < players.size(); i++) {
            UniPlayer player = players.get(i);
            PlayerStatType place = PlayerGameStat.getPlace(players.size() - i);
            if (place != null) {
                if (place == PlayerGameStat.PLACE_1) StatManager.getInstance().addStat(player, PlayerGameStat.VICTORY);
                StatManager.getInstance().addStat(player, place);
            }
        }

        //add participation to every players
        InfectedEngine.getInstance().getOnlinePlayers().forEach(p -> StatManager.getInstance().addStat(p, PlayerGameStat.PARTICIPATION));
    }

}
