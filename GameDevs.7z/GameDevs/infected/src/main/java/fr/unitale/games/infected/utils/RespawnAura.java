package fr.unitale.games.infected.utils;

import fr.unitale.sdk.features.aura.Aura;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.OrdinaryColor;
import org.bukkit.Color;
import org.bukkit.Location;

public class RespawnAura extends Aura {

	private double height = 0.0D;
	private final double multiplier = 10.0D;

	private final OrdinaryColor primary;
	private final OrdinaryColor secondary;

	public RespawnAura(UniPlayer owner) {
		super(owner, 1, true);
		this.primary = new OrdinaryColor(Color.WHITE);
		this.secondary = new OrdinaryColor(Color.SILVER);
	}

	@Override
	protected void update() {
		height = height < 2.0D ? height + 0.05D : 0.0D;
		final double large = 1.0d;

		final Location loc = owner.getLocation();
		final Location p1 = loc.clone().add(Math.sin(height * multiplier) * large, height,
				Math.cos(height * multiplier) * large);
		final Location p2 = loc.clone().add(Math.sin(height * multiplier + Math.PI) * large, height,
				Math.cos(height * multiplier + Math.PI) * large);
		final Location p3 = loc.clone().add(Math.sin(height * multiplier + Math.PI/2) * large, height,
				Math.cos(height * multiplier) * large);
		final Location p4 = loc.clone().add(Math.sin(height * multiplier + Math.PI*2.5D) * large, height,
				Math.cos(height * multiplier + Math.PI) * large);
		ParticleEffect.REDSTONE.display(primary, p1, 100.0D);
		ParticleEffect.REDSTONE.display(secondary, p2, 100.0D);
		ParticleEffect.REDSTONE.display(primary, p3, 100.0D);
		ParticleEffect.REDSTONE.display(secondary, p4, 100.0D);
	}

}
