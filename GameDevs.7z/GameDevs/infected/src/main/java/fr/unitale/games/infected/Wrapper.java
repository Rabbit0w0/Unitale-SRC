package fr.unitale.games.infected;

import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.utils.chat.UniLogger;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

/**
 * JavaPlugin entry point for Infected
 *
 * @author Axicer
 */
public class Wrapper extends JavaPlugin {

    public static final String CONFIG_NAME = "infected.json"; //config name for this gameengine

    @Override
    public void onLoad() {
        UnitaleSDK.loadAPI(API.MORPH, API.GUN);
    }

    @Override
    public void onEnable() {
        super.onEnable();

        UniLogger.info("Infected Wrapper launched !");
        final File file = new File("plugins", CONFIG_NAME); //path is ./plugins/{CONFIG_NAME}
        if (file.exists()) {
            new InfectedEngine(this, GameEngine.getJSONContent(file));
        } else {
            //load from default configuration
            new InfectedEngine(this, GameEngine.getDefaultJSONContent(Wrapper.class, CONFIG_NAME));
        }
    }
}
