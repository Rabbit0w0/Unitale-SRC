package fr.unitale.games.infected.weapons;

import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.games.infected.modules.phase.PhaseModule;
import fr.unitale.games.infected.utils.InfectedSound;
import fr.unitale.sdk.gun.model.Shotgun;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.ActionBar;
import fr.unitale.sdk.utils.data.Tuple;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;

import java.util.Calendar;

public class InfectedShotGun extends Shotgun {

    private int count = 0;//numbers of shots within 1s with this gun

    public InfectedShotGun() {
        super(Integer.MAX_VALUE, 5, 10.0F, 0.2F, 15, 150, 16, 0.01F, 5);
    }

    @Override
    public void onShoot(UniPlayer player) {
        Bukkit.getOnlinePlayers().forEach(p -> {
            if(p.getLocation().distance(player.getLocation()) > 20){
                SoundCreator.playSound(InfectedSound.SHOTGUN_FAR, SoundMaster.PLAYERS,1f, p);
            }else{
                SoundCreator.playSound(player.getLocation(), InfectedSound.SHOTGUN_SHOT, SoundMaster.PLAYERS, 1f, 1f, 16, p);
                SoundCreator.playSound(player.getLocation(), InfectedSound.SKILL_RECOIL, SoundMaster.PLAYERS, 1f, 1f, 16, p);
            }
        });
        if(getCharger() == 0){
            reload(player);
        }else{
            final ItemStack stack = player.getInventory().getItem(1);
            if(stack != null){
                stack.setAmount(getCharger());
                player.getInventory().setItem(1, stack);
            }
        }
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
    }

    @Override
    public void onShootFailed(UniPlayer player) {
        super.onShootFailed(player);
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
    }

    @Override
    public void onReload(UniPlayer player) {
        SoundCreator.playSound(player.getLocation(), InfectedSound.SHOTGUN_RELOAD, SoundMaster.PLAYERS, 1f, 1f, 16);
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
        final ItemStack stack = player.getInventory().getItem(1);
        if(stack != null){
            stack.setAmount(getCharger());
            player.getInventory().setItem(1, stack);
        }
    }

    @Override
    public void onReloadFailed(UniPlayer player) {
        super.onReloadFailed(player);
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
    }

    @Override
    public void onHurt(UniPlayer player, LivingEntity entity, float power) {
        PhaseModule module = InfectedEngine.getInstance().getPhaseModule();
        if (!module.isPhaseStarted()) return;
        if (!(entity instanceof UniPlayer)) return;

        final UniPlayer victim = (UniPlayer) entity;

        //check for the good configuration of shots
        if (!InfectedEngine.getInstance().getMarinesTeam().contains(player) || !InfectedEngine.getInstance().getZombiesTeam().contains(victim)) return;
        if(victim.isInvulnerable())return;

        //incrementing the count of shots
        count++;
        double dist = player.getLocation().distance(entity.getLocation());
        //if 75% of the shots are touching the entity and the shot distance is less than 4.5 blocks
        if ((float) count / getShoots() > 0.75f && dist < 5.5) {
            //should die
            kill(module, player, victim);
        } else {//make a single damage and clear count within 1s
            Bukkit.getScheduler().runTaskLater(InfectedEngine.getInstance().getPlugin(), () -> count = 0, 20L);
            if (entity.getHealth() <= power) {
                kill(module, player, victim);
            } else {
                super.onHurt(player, entity, power);
            }
        }
    }

    private void kill(PhaseModule module, UniPlayer killer, UniPlayer victim) {
        //should die
        //a marines has killed a zombie
        Lang.bcst("game.infected.kill", victim.getName(), killer.getName());

        //add points to player for kill
        killer.getStorage().addInteger(PhaseModule.POINTS_KEY, killer.getStorage().getInteger(PhaseModule.POINTS_KEY, 0) + 5);
        killer.sendMessage(Lang.str(killer, "game.infected.points", ""+5));

        module.getListener().registerDeath(victim);
        module.getListener().registerKill(killer);
        module.getListener().respawn(victim, true, true);

        // Triple/double kill
        int i = 1;
        @SuppressWarnings("unchecked")
        Tuple<Integer, Long> last = (Tuple<Integer, Long>) killer.getStorage().getObject(PhaseModule.DOUBLE_KILL_KEY, new Tuple<>(0, 0L));
        if (last.getB() + 3000L > Calendar.getInstance().getTimeInMillis()) {
            i = last.getA();
        }
        switch (i) {
            case 2:
                Lang.bcst("game.infected.kill.double", killer.getDisplayName());
                SoundCreator.playSound(InfectedSound.KILLS_2, SoundMaster.PLAYERS, 1f, killer);
                break;
            case 3:
                Lang.bcst("game.infected.kill.triple", killer.getDisplayName());
                SoundCreator.playSound(InfectedSound.KILLS_3, SoundMaster.PLAYERS, 1f, killer);
                break;
            case 4:
                Lang.bcst("game.infected.kill.quadruple", killer.getDisplayName());
                SoundCreator.playSound(InfectedSound.KILLS_4, SoundMaster.PLAYERS,1f, killer);
                break;
            case 5:
                Lang.bcst("game.infected.kill.quintuple", killer.getDisplayName());
                SoundCreator.playSound(InfectedSound.KILLS_5,  1f, killer);
                break;
            default:
                break;
        }
        module.getListener().registerKillAtOnce(killer, i);
        killer.getStorage().addObject(PhaseModule.DOUBLE_KILL_KEY, new Tuple<Integer, Long>(i + 1, Calendar.getInstance().getTimeInMillis()));
    }
}
