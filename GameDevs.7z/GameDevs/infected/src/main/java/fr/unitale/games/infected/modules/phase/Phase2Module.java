package fr.unitale.games.infected.modules.phase;

import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.generic.TimeManager;
import org.bukkit.Bukkit;

import java.util.Collection;

public class Phase2Module extends PhaseModule {

    public Phase2Module(Collection<UniPlayer> lastInfected) {
        super(2);
        this.lastInfected.addAll(lastInfected);
    }

    @Override
    public void endModule() {
        InfectedEngine.getInstance().getModuleManager().addModule(new Phase3Module(lastInfected), true);
    }

    @Override
    public void end() {
        phaseStarted = false;
        getPointIncrementer().cancel();
        displayEndPhase();
        TimeManager.getInstance().removeTimer(getTimer());

        //add 100 points for every marines alive at the end
        InfectedEngine.getInstance().getOnlinePlayers().stream()
                .filter(p -> InfectedEngine.getInstance().getMarinesTeam().contains(p))
                .forEach(p -> {
                    p.sendMessage(Lang.str(p, "game.infected.points", ""+100));
                    p.getStorage().addInteger(POINTS_KEY, p.getStorage().getInteger(POINTS_KEY, 0) + 100);
                });

        //end this module in 10s
        Bukkit.getScheduler().scheduleSyncDelayedTask(InfectedEngine.getInstance().getPlugin(), () -> InfectedEngine.getInstance().getModuleManager().removeModule(Phase2Module.class), 200L);
    }

}
