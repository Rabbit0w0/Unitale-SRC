package fr.unitale.games.infected.weapons;

import fr.unitale.games.infected.InfectedEngine;
import fr.unitale.games.infected.modules.phase.PhaseModule;
import fr.unitale.games.infected.utils.InfectedSound;
import fr.unitale.sdk.gun.model.Gun;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.ActionBar;
import fr.unitale.sdk.utils.data.Tuple;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.sound.SoundMaster;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;

import java.util.Calendar;

public class InfectedGun extends Gun {

    public InfectedGun() {
        super(Integer.MAX_VALUE, Integer.MAX_VALUE, 10, 10, 10.0F, 0.0F, 30, 100, 6, 0F, 1);
    }

    @Override
    public void onShoot(UniPlayer player) {
        Bukkit.getOnlinePlayers().forEach(p -> {
            if(p.getLocation().distance(player.getLocation()) > 20){
                SoundCreator.playSound(InfectedSound.MAGNUM_FAR, SoundMaster.PLAYERS,1f, p);
            }else{
                SoundCreator.playSound(player.getLocation(), InfectedSound.MAGNUM_SHOT,SoundMaster.PLAYERS, 1f, 1f, 16, p);
            }
        });
        if(getCharger() == 0){
            reload(player);
        }else{
            final ItemStack stack = player.getInventory().getItem(0);
            if(stack != null){
                stack.setAmount(getCharger());
                player.getInventory().setItem(0, stack);
            }
        }
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
    }

    @Override
    public void onShootFailed(UniPlayer player) {
        super.onShootFailed(player);
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
    }

    @Override
    public void onReload(UniPlayer player) {
        SoundCreator.playSound(player.getLocation(), InfectedSound.MAGNUM_RELOAD, SoundMaster.PLAYERS, 1f, 1f, 16);
        ActionBar.sendActionBar(player, Lang.str(player, "game.infected.item.gun.stats", "" + getCharger()));
        final ItemStack stack = player.getInventory().getItem(0);
        if(stack != null){
            stack.setAmount(getCharger());
            player.getInventory().setItem(0, stack);
        }
    }

    @Override
    public void onHurt(UniPlayer player, LivingEntity entity, float power) {
        PhaseModule module = InfectedEngine.getInstance().getPhaseModule();
        if (!module.isPhaseStarted()) return;
        if (!(entity instanceof UniPlayer)) return;

        UniPlayer victim = (UniPlayer) entity;

        if (!InfectedEngine.getInstance().getMarinesTeam().contains(player) || !InfectedEngine.getInstance().getZombiesTeam().contains(victim)) return;
        if(victim.isInvulnerable())return;

        if (victim.getHealth() <= power) {
            //a marines has killed a zombie
            Lang.bcst("game.infected.kill", victim.getName(), player.getName());

            //add points to player for kill
            player.getStorage().addInteger(PhaseModule.POINTS_KEY, player.getStorage().getInteger(PhaseModule.POINTS_KEY, 0) + 5);
            player.sendMessage(Lang.str(player, "game.infected.points", ""+5));

            module.getListener().registerDeath(victim);
            module.getListener().registerKill(player);
            module.getListener().respawn(victim, true, true);

            // Triple/double kill
            int i = 1;
            @SuppressWarnings("unchecked")
            Tuple<Integer, Long> last = (Tuple<Integer, Long>) player.getStorage().getObject(PhaseModule.DOUBLE_KILL_KEY, new Tuple<Integer, Long>(0, 0l));
            if (last.getB() + 3000L > Calendar.getInstance().getTimeInMillis()) {
                i = last.getA();
            }
            switch (i) {
                case 2:
                    Lang.bcst("game.infected.kill.double", player.getDisplayName());
                    break;
                case 3:
                    Lang.bcst("game.infected.kill.triple", player.getDisplayName());
                    break;
                case 4:
                    Lang.bcst("game.infected.kill.quadruple", player.getDisplayName());
                    break;
                case 5:
                    Lang.bcst("game.infected.kill.quintuple", player.getDisplayName());
                    break;
                default:
                    break;
            }
            module.getListener().registerKillAtOnce(player, i);
            player.getStorage().addObject(PhaseModule.DOUBLE_KILL_KEY, new Tuple<>(i + 1, Calendar.getInstance().getTimeInMillis()));
        } else {
            super.onHurt(player, entity, power);
        }
    }

}
