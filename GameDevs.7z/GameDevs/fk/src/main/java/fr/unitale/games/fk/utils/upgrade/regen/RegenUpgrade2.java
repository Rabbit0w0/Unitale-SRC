package fr.unitale.games.fk.utils.upgrade.regen;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class RegenUpgrade2 extends RegenUpgrade {

    public RegenUpgrade2(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 2;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeRegen(player, 3);
    }
}
