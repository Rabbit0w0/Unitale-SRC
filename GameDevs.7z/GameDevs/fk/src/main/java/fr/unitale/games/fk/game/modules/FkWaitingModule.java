package fr.unitale.games.fk.game.modules;

import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.game.listeners.FkGameInstance;
import fr.unitale.sdk.players.UniPlayer;

public class FkWaitingModule extends WaitingModule<FkInstance> {

    public FkWaitingModule(FkInstance instance) {
        super(instance, new FkGameInstance(instance));
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent e) {
        if (e.getEntity().getType() != EntityType.PLAYER) return;
        if (getInstance().getStatus() != ServerTypes.GameStatus.GAME && getInstance().contains((UniPlayer) e.getEntity()))
            e.setCancelled(true);
    }
}
