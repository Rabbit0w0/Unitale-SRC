package fr.unitale.games.fk.kit;

import fr.unitale.games.fk.kit.types.ArcherKit;
import fr.unitale.games.fk.kit.types.EnchanterKit;
import fr.unitale.games.fk.kit.types.GuerrierKit;
import fr.unitale.games.fk.kit.types.MinerKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.game2.kit.AbstractKit;
import fr.unitale.sdk.game2.kit.KitManager;
import fr.unitale.sdk.players.UniPlayer;

import java.util.Arrays;

public abstract class StartKit extends AbstractKit{

    public StartKit(IKit kit) {
        super(kit);
    }

    public abstract void onGameStart(UniPlayer player);

    public static void check(UniPlayer player) {
        Arrays.asList(
                ArcherKit.class,
                EnchanterKit.class,
                GuerrierKit.class,
                MinerKit.class
        ).forEach(kitType -> {
            StartKit kit = KitManager.fromPlayer(player, kitType);
            if (kit != null) {
                kit.onGameStart(player);
            }
        });
    }
}
