package fr.unitale.games.fk.game.modules;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.game.FkInstanceType;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class FkEndModule extends Module<FkInstance> {

    public FkEndModule(FkInstance instance) {
        super(instance);
    }

    @Override
    protected void onRegistered() {
        for (UniPlayer player : getInstance().getOnlinePlayers()) {
            player.clear();
            UniItemStack leave = new UniItemStack(Material.BED, Lang.str(player, "game.wait.item.leave"));
            player.getInventory().setItem(8, leave);
            UniItemStack playAgain = new UniItemStack(Material.WOOD_BUTTON, Lang.str(player, "game.wait.item.play_again"));
            player.getInventory().setItem(0, playAgain);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent ev) {
        if (!check(ev.getPlayer())) return;

        final UniItemStack item = UniItemStack.fromItemStack(ev.getPlayer().getInventory().getItemInMainHand());
        if (item == null || !(ev.getAction().equals(Action.RIGHT_CLICK_BLOCK) || ev.getAction().equals(Action.RIGHT_CLICK_AIR))) {
            return;
        }

        if (ev.getPlayer().getInventory().getItemInMainHand().getType() == Material.BED) {
            ((UniPlayer) ev.getPlayer()).sendToHub();
        } else if (ev.getPlayer().getInventory().getItemInMainHand().getType() == Material.WOOD_BUTTON) {
            instance.onQuit((UniPlayer) ev.getPlayer());
            FkInstanceType type = new FkInstanceType(instance);
            GameSDK2.getEngine().getRoom().onJoin((UniPlayer) ev.getPlayer(), type);
        }

        ev.setCancelled(true);
    }
}
