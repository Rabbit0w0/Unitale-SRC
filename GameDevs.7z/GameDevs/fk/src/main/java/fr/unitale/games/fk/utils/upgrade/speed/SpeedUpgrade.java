package fr.unitale.games.fk.utils.upgrade.speed;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.players.UniPlayer;

public abstract class SpeedUpgrade implements IUpgrade {

    FkTeam team;

    public SpeedUpgrade(FkTeam team){
        this.team = team;
    }

    public boolean upgradeSpeed(UniPlayer player, int thickness){
		return false;    	
    }
}
