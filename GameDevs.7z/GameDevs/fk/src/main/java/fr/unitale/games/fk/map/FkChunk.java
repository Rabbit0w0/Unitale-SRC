package fr.unitale.games.fk.map;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import fr.unitale.games.fk.map.generator.GeneratorOres;
import fr.unitale.sdk.utils.chat.UniLogger;
import net.md_5.bungee.api.ChatColor;

public class FkChunk {
    private Location loc1, loc2, locfinale;
    
    public FkChunk(World w) {
    	
    	UniLogger.info(ChatColor.DARK_RED + "[R2-D2] :" + ChatColor.BLUE  +"J'ai fais mon taff putain !");
        this.loc1 = new Location(w, -300, 0, -450);
        this.loc2 = new Location(w, 450, 255, 300);

        try {
            setBlock(loc1, loc2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setBlock(Location pos1, Location pos2) throws Exception {
		if (pos1.getWorld() != pos2.getWorld())
			throw new Exception("Le monde n'est pas le même entre les deux points");
		if (pos1.getBlockX() > pos2.getBlockX()) {
			Location tmp = pos1;
			pos1 = pos2;
			pos2 = tmp;
		}
		if (pos1.getBlockZ() > pos2.getBlockZ()) {
			Location tmp = pos1;
			pos1 = pos2;
			pos2 = tmp;
		}
		for (int x = pos1.getBlockX(); x <= pos2.getBlockX(); x++) {
			for (int z = pos1.getBlockZ(); z <= pos2.getBlockZ(); z++) {
				for (int y = pos1.getBlockY(); y <= pos2.getBlockY(); y++) {
					Block b = pos1.getWorld().getBlockAt(x, y, z);
					if (b.getType().equals(Material.AIR)) {
						Chunk c = pos1.getWorld().getChunkAt(b);
						boolean need = false;
						if (!c.isLoaded()) {
							c.load();
							need = true;
						}
						this.locfinale = b.getLocation();
						new GeneratorOres(this.locfinale);
						if (need)
							c.unload();
					}
				}
			}
		}
    }
}