package fr.unitale.games.fk.utils.upgrade.heal;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.players.UniPlayer;

public abstract class HealUpgrade implements IUpgrade {

    FkTeam team;

    public HealUpgrade(FkTeam team){
        this.team = team;
    }

    public boolean upgradeHeal(UniPlayer player, int thickness){
		return false;    	
    }
}
