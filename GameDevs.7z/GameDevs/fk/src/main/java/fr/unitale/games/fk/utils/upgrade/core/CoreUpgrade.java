package fr.unitale.games.fk.utils.upgrade.core;

import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.map.FKMap;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import fr.unitale.sdk.utils.data.Triple;
import net.minecraft.server.v1_10_R1.NBTCompressedStreamTools;
import net.minecraft.server.v1_10_R1.NBTTagCompound;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class CoreUpgrade implements IUpgrade {

	FkTeam team;

	public CoreUpgrade(FkTeam team) {
		this.team = team;
	}

	public boolean upgradeCore(UniPlayer player, int level) {
		if (team.isUpgradingCore()) {
			player.sendMessage(Lang.str(player, "game.fk.upgrade.core.already"));
			return false;
		}

		team.setUpgradingCore(true);

		FKMap map = (FKMap) GameSDK2.getInstance(player).getMap();
		Schematic schematic = getCurrentSchematic(map, level);

		destroySchematic(team.getBase().getCenter(),schematic);

		team.setTaskCore(Bukkit.getScheduler().scheduleAsyncRepeatingTask(GameSDK2.getInstance(),
				new SetBlockThread(team, schematic), 0l, 4l));

		return true;
	}

	private Schematic getCurrentSchematic(FKMap map, int level) {
		String path;
		if (map.getType().equals(FKMapType.FK_ANGEL_VS_DEMON)) {// special case for this map
			String variant;
			if (team.getName().equals(map.defaultNameFromId(0))) {// is first team
				variant = "1";
			} else {// is second team
				variant = "2";
			}
			path = "schematic/angelvsdemon/" + variant + "/core_" + String.valueOf(level) + ".schematic";
		} else {
			path = "schematic/" + ((FKMapType) map.getType()).getSchematicName() + "/core_" + String.valueOf(level)
					+ ".schematic";
		}

		try {
			NBTTagCompound compound = NBTCompressedStreamTools.a(Wrapper.class.getResourceAsStream(path));
			return SchematicAPI.loadSchematic(compound);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void destroySchematic(Location center, Schematic s) {
		for (int x = (center.getBlockX() - s.getWidth() / 2); x <= center.getBlockX() + s.getWidth() / 2; x++) {
			for (int y = (center.getBlockY()) - 1; y <= center.getBlockY() + s.getHeight()
					- 2; y++) {
				for (int z = (center.getBlockZ() - s.getLength() / 2); z <= center.getBlockZ()
						+ s.getLength() / 2; z++) {
					Location l = center.clone();
					l.setX(x);
					l.setY(y);
					l.setZ(z);
					l.getBlock().setType(Material.AIR);
				}
			}
		}
	}

	private class SetBlockThread extends BukkitRunnable {

		private FkTeam team;
		private List<Triple<Block, Integer, Byte>> queue;
		private Schematic schematic;
		private Iterator<Triple<Block, Integer, Byte>> queueIterator;

		public SetBlockThread(FkTeam team, Schematic schematic) {
			this.team = team;
			this.schematic = schematic;
			this.queue = new ArrayList<>();
			computeListAndCleanWalls();
		}

		/**
		 * Compute the list of blocks to update Cleans walls replacing by air
		 */
		private void computeListAndCleanWalls() {
			byte[] blocks = schematic.getBlocks();
			byte[] blockData = schematic.getData();
			short length = schematic.getLength();
			short width = schematic.getWidth();
			short height = schematic.getHeight();

			for (int x = 0; x < width; ++x) {
				for (int y = 0; y < height; ++y) {
					for (int z = 0; z < length; ++z) {
						final int index = y * width * length + z * width + x;
						final Block block = team.getBase().getCenter().clone().add(x-3, y-2, z-3).getBlock();
						if (index >= blocks.length || index >= blockData.length) {
							continue;
						}

						int materialInt = (blocks[index] & 0xFF);
						byte materialData = blockData[index];
						if (Material.AIR.getId() != materialInt) {
							queue.add(new Triple<>(block, materialInt, materialData));
						}
					}
				}
			}
			queueIterator = queue.listIterator();
		}

		@SuppressWarnings("deprecation")
		@Override
		public void run() {
			// if queue is at end
			if (!queueIterator.hasNext()) {
				team.setUpgradingCore(false);
				// cancel task
				Bukkit.getScheduler().cancelTask(team.getTaskCore());
				return;
			}
			// get the current entry
			Triple<Block, Integer, Byte> entry = queueIterator.next();

			// apply entry synchronously
			Block block = entry.getA();
			Location loc = block.getLocation().add(0, 1, 0);
			Bukkit.getScheduler().runTask(GameSDK2.getInstance(), () -> {
				loc.getBlock().setTypeId(entry.getB());
				loc.getBlock().setData(entry.getC());
			});
		}
	}

}
