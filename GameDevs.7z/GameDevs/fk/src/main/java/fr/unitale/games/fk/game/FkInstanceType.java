package fr.unitale.games.fk.game;

import java.util.Objects;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.sdk.game2.instance.InstanceType;

public class FkInstanceType implements InstanceType {
    private FKMapType map;
    private ServerTypes.ServerMode mode;
    private int size;
    
    public FkInstanceType() {}

    public FkInstanceType(FkInstance instance) {
    	this.map = (FKMapType) instance.getMap().getType();
    	this.mode = instance.getServerMode();
        this.size = instance.getTeamSize();
    }

    public FkInstanceType(FKMapType map, int size, ServerTypes.ServerMode mode) {
        this.map = map;
        this.mode = mode;
        this.size = size;
    }

    @Override
    public InstanceType fromJson(String s) {
        /*final JsonObject object = new JsonParser().parse(s).getAsJsonObject();
        return new FkInstanceType(
                MapType.fromString(FKMapType.values(), object.get("map").getAsString())
        );*/

        // pour les tests en local
        return new FkInstanceType(
                FKMapType.FK_NORDIQUE, 
                1, 
                ServerTypes.ServerMode.NORMAL
        );

    }

    public FKMapType getMap() {
        return map;
    }
    
    public ServerTypes.ServerMode getMode() {
        return mode;
    }
    
    public int getSize() {
        return size;
    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof FkInstanceType) {
            FkInstanceType other = (FkInstanceType) object;
            return other.getMap().getName().equals(map.getName()) && other.getMode().equals(mode) && other.getSize() == size;
        } else if (object instanceof FkInstance) {
            FkInstance other = (FkInstance) object;
            return other.getMap().getType().getName().equals(map.getName()) && other.getServerMode().equals(mode) && other.getTeamSize() == size;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(map, mode, size);
    }

    @Override
    public String toString() {
        return "FKInstanceType [" + map.getName() + ", " + mode.toString() + ", " + size +"]";
    }
}
