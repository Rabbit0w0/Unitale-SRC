package fr.unitale.games.fk.map.types;

import fr.unitale.games.fk.map.FKMap;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.sdk.utils.color.UniColor;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Arrays;

public class Nordique extends FKMap {

    public Nordique(String name, World world) {
        super(FKMapType.FK_NORDIQUE, name, world, 5, 2,
                new Location(world, 0, 200, 0),
                new Location(world, -6, 94, 59),
                new Location(world, 182, 95, -232),
                new Location(world, 358, 98, 118));
    }

    @Override
    public String defaultNameFromId(int id) {
        return Arrays.asList("Rouge", "Bleu").get(id);
    }

    @Override
    public UniColor defaultColorFromId(int id) {
        return Arrays.asList(UniColor.RED, UniColor.BLUE).get(id);
    }
}
