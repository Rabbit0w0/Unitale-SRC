package fr.unitale.games.fk.kit.types;

import fr.unitale.games.fk.kit.StartKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;

public class EnchanterKit extends StartKit {

    public EnchanterKit(IKit kit) {
        super(kit);
    }

    @Override
    public void onGameStart(UniPlayer player) {
        switch(getLevel()){
            case 1:
                player.getInventory().addItem(new UniItemStack(Material.EXP_BOTTLE, 16));
                player.getInventory().addItem(new UniItemStack(Material.INK_SACK, (byte) 4).setNumber(8));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK).addNewUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1));
                break;
            case 2:
                player.getInventory().addItem(new UniItemStack(Material.EXP_BOTTLE, 24));
                player.getInventory().addItem(new UniItemStack(Material.INK_SACK, (byte) 4).setNumber(10));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK).addNewUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK).addNewUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1));
                break;
            case 3:
                player.getInventory().addItem(new UniItemStack(Material.EXP_BOTTLE, 32));
                player.getInventory().addItem(new UniItemStack(Material.INK_SACK, (byte) 4).setNumber(16));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK, 2).addNewUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK).addNewUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1));
                break;
            case 4:
                player.getInventory().addItem(new UniItemStack(Material.EXP_BOTTLE, 45));
                player.getInventory().addItem(new UniItemStack(Material.INK_SACK, (byte) 4).setNumber(24));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK, 2).addNewUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK, 2).addNewUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK).addNewUnsafeEnchantment(Enchantment.KNOCKBACK, 2));
                break;
            case 5:
                player.getInventory().addItem(new UniItemStack(Material.EXP_BOTTLE, 64));
                player.getInventory().addItem(new UniItemStack(Material.INK_SACK, (byte) 4).setNumber(32));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK, 2).addNewUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK, 2).addNewUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK, 2).addNewUnsafeEnchantment(Enchantment.THORNS, 1));
                player.getInventory().addItem(new UniItemStack(Material.ENCHANTED_BOOK).addNewUnsafeEnchantment(Enchantment.KNOCKBACK, 2));
                break;
        }
    }
}
