package fr.unitale.games.fk.utils.upgrade;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.Hat;
import fr.unitale.games.fk.utils.upgrade.core.*;
import fr.unitale.games.fk.utils.upgrade.enchant.*;
import fr.unitale.games.fk.utils.upgrade.fall.*;
import fr.unitale.games.fk.utils.upgrade.regen.*;
import fr.unitale.games.fk.utils.upgrade.farm.*;
import fr.unitale.games.fk.utils.upgrade.heal.*;
import fr.unitale.games.fk.utils.upgrade.wall.*;
import fr.unitale.games.fk.utils.upgrade.protect.*;
import fr.unitale.games.fk.utils.upgrade.speed.*;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;

import java.lang.reflect.InvocationTargetException;

public enum Upgrades {
    WALL_1(WallUpgrade1.class, 200, new UniItemStack(Material.STAINED_CLAY)),
    WALL_2(WallUpgrade2.class, 500, new UniItemStack(Material.STAINED_CLAY)),
    WALL_3(WallUpgrade3.class, 1000, new UniItemStack(Material.ENDER_STONE)),
    WALL_4(WallUpgrade4.class, 2500, new UniItemStack(Material.ENDER_STONE)),

    FALL_1(FallUpgrade1.class, 300, new UniItemStack(Material.GLASS)),
    FALL_2(FallUpgrade2.class, 750, new UniItemStack(Material.WATER_BUCKET)),
    FALL_3(FallUpgrade3.class, 1500, new UniItemStack(Material.LAVA_BUCKET)),

    ENCHANT_1(EnchantUpgrade1.class, 300, Hat.ENCHANT_V1.getItemStack()),
    ENCHANT_2(EnchantUpgrade2.class, 750, Hat.ENCHANT_V2.getItemStack()),
    ENCHANT_3(EnchantUpgrade3.class, 1500, Hat.ENCHANT_V3.getItemStack()),

    CORE_1(CoreUpgrade1.class, 500, Hat.CORE_V1.getItemStack()),
    CORE_2(CoreUpgrade2.class, 1500, Hat.CORE_V2.getItemStack()),
    CORE_3(CoreUpgrade3.class, 3000, Hat.CORE_V3.getItemStack()),

    FARM(FarmUpgrade.class, 300, Hat.FARM_V1.getItemStack()),
	
	HEADMAX_1(RegenUpgrade1.class, 200, Hat.HEAL.getItemStack()),
	HEADMAX_2(RegenUpgrade2.class, 250, Hat.HEAL.getItemStack()),
	HEADMAX_3(RegenUpgrade3.class, 300, Hat.HEAL.getItemStack()),
	
	REGEN(HealUpgrade1.class, 200, Hat.HEAL.getItemStack()),
	
	PROTECTED_1(ProtectedUpgrade1.class, 300, Hat.POTION_REGENE.getItemStack()),
	PROTECTED_2(ProtectedUpgrade2.class, 750, Hat.POTION_REGENE.getItemStack()),
	PROTECTED_3(ProtectedUpgrade3.class, 1500, Hat.POTION_REGENE.getItemStack()),
	
	SPEED_1(SpeedUpgrade1.class, 300, Hat.POTION_SPEED.getItemStack()),
	SPEED_2(SpeedUpgrade2.class, 750, Hat.POTION_SPEED.getItemStack()),
	SPEED_3(SpeedUpgrade3.class, 1500, Hat.POTION_SPEED.getItemStack());

    private Class<? extends IUpgrade> clazz;
    private int price;
    private UniItemStack stack;

    Upgrades(Class<? extends IUpgrade> clazz, int price, UniItemStack stack) {
        this.clazz = clazz;
        this.price = price;
        this.stack = stack;
        this.stack.setName("game.fk.upgrade.item."+name().toLowerCase()+".name");
        this.stack.setLores("game.fk.upgrade.item."+name().toLowerCase()+".desc");
    }

    public IUpgrade createInstance(FkTeam team) {
        try {
            return clazz.getConstructor(FkTeam.class).newInstance(team);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean has(FkTeam team){
        return team.getAcquiredUpgrades().contains(this);
    }

    public UniItemStack getStack(UniPlayer player) {
        return stack.translate(player).addLore(Lang.str(player, "game.fk.upgrade.item.price", ""+price));
    }

    public int getPrice() {
        return price;
    }
}
