package fr.unitale.games.fk.utils.upgrade.speed;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class SpeedUpgrade3 extends SpeedUpgrade {

    public SpeedUpgrade3(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeSpeed(player, 3);
    }
}
