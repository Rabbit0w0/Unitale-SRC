package fr.unitale.games.fk.utils.upgrade;

import fr.unitale.sdk.players.UniPlayer;

public interface IUpgrade {

    /**
     * Get the upgrade's level
     */
    int getLevel();

    /**
     * apply the upgrade
     * @param player The player upgrading
     */
    boolean upgrade(UniPlayer player);
}
