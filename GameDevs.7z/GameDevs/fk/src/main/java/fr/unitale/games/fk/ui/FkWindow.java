package fr.unitale.games.fk.ui;

import fr.unitale.games.fk.ui.panel.UpgradePanel;
import fr.unitale.games.fk.ui.panel.ForgePanel;
import fr.unitale.games.fk.ui.panel.VendorPanel;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIPanel;
import fr.unitale.sdk.ui.elements.UIWindow;

public class FkWindow extends UIWindow {

    private UniPlayer player;

    public FkWindow(FkPanelType panel, UniPlayer player) {
        super(54, "-_-_-_-_-_-_-_-");
        this.player = player;

        addPanel(FkPanelType.BUILDER, new UpgradePanel(player));
        addPanel(FkPanelType.FORGE, new ForgePanel(player));
        addPanel(FkPanelType.VENDOR, new VendorPanel(player));

        showPanel(panel.name());
    }

    private void addPanel(FkPanelType type, UIPanel panel){
        addPanel(type.name(), panel);
    }

    public UniPlayer getPlayer() {
        return player;
    }
}
