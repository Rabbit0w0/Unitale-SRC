package fr.unitale.games.fk.game.modules;

import java.util.List;

import org.bukkit.event.EventHandler;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.event.instance.PlayerQuitInstanceEvent;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.firework.FireworkFactory;

public class FkPreGameModule extends Module<FkInstance> {

    public FkPreGameModule(FkInstance instance) {
        super(instance);
    }
    
    @EventHandler
    public void on(PlayerQuitInstanceEvent ev) {
    	UniTeam t = UniTeam.getTeam(instance, ev.getPlayer().getUniqueId());
    	final List<UniTeam> win = instance.getAvailableTeams();
    	
    	if (!check(ev)) return;
        if (instance.getStatus() == ServerTypes.GameStatus.END) return;
        
        if (!t.isEliminated())t.eliminate();
        
        if(t.getOnlineCompetingPlayers().size() == 0) {
        	UniLogger.info("Game Null");
        	instance.endGame(200);
            instance.unregister(this);
        }
        
        if (win.size() == 1) {
            win(win.get(0));
            instance.endGame(200);
            instance.unregister(this);
        }
    }
    
    private void win(UniTeam team) {
        if (instance.getTeamSize() > 1) {
            instance.broadcast("game.fk.win.team", team.getColor() + team.getName());        
        }
        for (final UniPlayer p : instance.getOnlinePlayers()) {
            if (team.contains(p)) {
                FireworkFactory.spawnRandomFirework(p.getLocation(), true);   
                GameSDK2.getInstance(p ).broadcast("game.fk.win", team.getColor() + team.getName());
                instance.victoryPlayer(p);
            } else {
                instance.defeatPlayer(p);
            }            
        }
    }
}