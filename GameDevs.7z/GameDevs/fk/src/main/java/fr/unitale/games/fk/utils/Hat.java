package fr.unitale.games.fk.utils;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import fr.unitale.sdk.utils.items.UniItemSkull;

public enum Hat {

    FARM_V1(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMmQ0Mjk2YjMzM2QyNTMxOWFmM2YzMzA1MTc5N2Y5ZTZkODIxY2QxOWEwMTRmYjcxMzdiZWI4NmE0ZTllOTYifX19","FARM_V1")),

    HEAL(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDFhNmE0MTFiODAyYjIyZTUzMjQ3OTVjZTM0ZTNjYWU0YTgzNzk2YTE4ZDkyMzMyNjY2Y2JmMjE0ODhjMCJ9fX0=","HEAL")),

    CORE_V1(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZTQ5ZDIxMmJmYzBhMzRhNzA3NjNlMmE2OGRlNGZhOTI3MGNjZjJkODA3MWIxY2M4MzgxM2U0MTA2YjlkMWRmZSJ9fX0=", "CORE_V1")),
    CORE_V2(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjMyZjBhNjM4NjI0NjE0YzcxOWU1Y2EyZGU0YTM2MjVhZmFlMTU3MmE1MDQzZGUyZWE2NGFiZWQ0MzkifX19", "CORE_V2")),
    CORE_V3(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTY2MzZiYTY5ODhjZTliNDBkZGM3NDlhMDljZTBmYjkzOWFmNTI2MDA1OTk1YzE4ZDMyM2FjOTY2MjVmMGQ2ZCJ9fX0=", "CORE_V3")),

    ENCHANT_V1(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWMwMzBjYzM1ZmRlMDIxOGRlZDViYTVkNTU3Y2NhOWUwM2RjYmM4NGY5ZTY3MjkxMWRhNTRmZTA3YzVmZGJiYiJ9fX0=", "ENCHANTEMENT_V1")),
    ENCHANT_V2(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMzY1MDViMWJlZmJhMjQyMTcwYTQ2ZTg5NDdiNTJhZWE1NGE1OTA2MGYzZTFjMzZmMjFjZWJiNDQ2OTBmOGIwYyJ9fX0=", "ENCHANTEMENT_V2")),
    ENCHANT_V3(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTNhNjljM2NhYTMxMzA0ZTk5NTIzMjhjNzJjZWUwYjU3YjJhMmJkNDZjZTljNWNiODhjMDdkMTI2NjI3N2Q2YSJ9fX0=", "ENCHANTEMENT_3")),
    
    POTION_SPEED(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2RmNzc4ZWNiYWIzNDBjODEyNGE2Mzg4ZGYzNTAzNDFiOGZmNGI5NzEyOWY1NjYxYWVjYjA1Yzc3OGIzZjJkNSJ9fX0=", "Potion_Speed")),
    POTION_FORCE(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTFlN2ViMmU0NjFlOTZlNjMxY2JhMGMwY2RhYTU0NDg4MDYzMDJlZGFlOTFiNjFkYWZjMjgxYWU1ODRkOCJ9fX0=", "Potion_force")),
    POTION_REGENE(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGI2M2IyZGM2YmM1MWNmYzIzODNlZTQ0ZTMzNjFhZmRlNTRlZmVjN2RhNDIzODVlNmZiZTk1MjA4MWFmOTk0MSJ9fX0=", "Potion_Regen")),
        
    BRIDGE_V1(createSkullValue("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOGMxMTY5MWJhN2M0ZGNiYWYzNDdiOWFkZWJmZTkzM2NlMzAxNjcxN2I1NjUzZTQxMjJhMTJiMDI2YjM3ZmExOCJ9fX0=", "BRIDGE_V1"));
 
    private UniItemSkull itemStack;

    Hat(UniItemSkull itemStack) {
        this.itemStack = itemStack;
    }

    /**
     * Gets the Hat {@link fr.unitale.sdk.utils.items.UniItemStack}.
     * @return the Hat ItemStack.
     */
    public UniItemSkull getItemStack() {
        return itemStack;
    }

    private static UniItemSkull createSkullValue(String url, String name) {
        try {
            UniItemSkull item = new UniItemSkull();
            final GameProfile profile = item.getProfile();
            profile.getProperties().put("textures", new Property("textures", url));
            item.setOwner(profile);
            return item;
        } catch (Exception e) {
            UniItemSkull item = new UniItemSkull();
            return item;
        }
    }
}