package fr.unitale.games.fk.utils.upgrade.regen;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.players.UniPlayer;

public abstract class RegenUpgrade implements IUpgrade {

    FkTeam team;

    public RegenUpgrade(FkTeam team){
        this.team = team;
    }

    public boolean upgradeRegen(UniPlayer player, int thickness){
		return false;    	
    }
}
