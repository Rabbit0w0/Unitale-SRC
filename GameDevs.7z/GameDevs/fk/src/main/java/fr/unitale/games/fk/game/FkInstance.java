package fr.unitale.games.fk.game;

import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.DisplaySlot;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.game.cinematic.FkCinematicPoint;
import fr.unitale.games.fk.game.modules.FkWaitingModule;
import fr.unitale.games.fk.kit.StartKit;
import fr.unitale.games.fk.map.FKMap;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.sdk.API;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.game2.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.resourcepack.ResourcePackType;
import fr.unitale.sdk.utils.sound.SoundCreator;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;

public class FkInstance extends Instance<FkInstance> {

    public static final String PLAYER_MONEY_KEY = "fk-money";
    //private static final String SCHEMATIC_SPAWN = "schematic/spawn.schematic";
    private int teamSize;
    
    public ArrayList<Location> locs = new ArrayList<>();
	public ArrayList<String> title = new ArrayList<>();
	public ArrayList<String> subtitle = new ArrayList<>();

    public FkInstance(Engine<FkInstance> engine, FKMapType mapType, int teamSize, ServerTypes.ServerMode mode) {
        super(engine, "fk.json", false);
        
        this.teamSize = teamSize;

        ServerManager.type = ServerTypes.ServerType.FALLENKINGDOM;
        setServerMode(mode);
        setMode(ServerTypes.Mode.TEAM);
        
        setMinPlayers(teamSize * 2);
        setMaxPlayers(teamSize * 15);

        // set rewards
        PlayerGameStat STAT = new PlayerGameStat();
        STAT.VICTORY.setMoney(MoneyType.GOLD, 50);
        STAT.DEFEAT.setMoney(MoneyType.GOLD, 25);
        setGameStat(STAT);
        
        //remove chat API
        UnitaleSDK.unloadAPI(API.CHAT);

        //register team module
        final TeamModule<FkInstance, UniTeam> tm = new TeamModule<>(this);
        tm.setTeamSize(teamSize);
        tm.setDispatchTeam(true);
        register(tm);

        // load map
        final FKMap map = (FKMap) mapType.getInstance(this);
        map.getWorld().setTime(1200);        
        //test for loading chunk and generate ores
        //new FkChunk(map.getWorld());
        setMap(map);        
        
        //generate teams from map
        map.generateTeams(this);

        // manage weather
        WeatherAPI.disableTime();
        WeatherAPI.clear();
        WeatherAPI.setTime(TimeSet.DAY);

        // waiting module
        FkWaitingModule waitingModule = new FkWaitingModule(this) {
        	@Override
            public void updateWaitingModule() {
        		super.updateWaitingModule();
                if (getTimer().getTime() < 4 && getTimer().getTime() > 0) {
                    getInstance().getOnlinePlayers().forEach(player -> player.sendTitle(
                            Lang.str("game.fk.title.starting_in"),
                            getTimer().getTime() + " " + Lang.str("game.fk.title.second")
                                    + (getTimer().getTime() == 1 ? "" : "s")
                    ));
                    SoundCreator.playSound(Sound.BLOCK_NOTE_BASS, 1f, getOnlinePlayers());
                }
        	}
        };
        waitingModule.setBoard(getBoard());
        register(waitingModule);
    }

    @Override
    public void onJoin(UniPlayer player) {
        super.onJoin(player);
        //schedule resourcepack sending if map is ANGELVSDEMON
        Bukkit.getScheduler().runTask(GameSDK2.getInstance(), () -> {
            if (gameMap.getType().equals(FKMapType.FK_ANGEL_VS_DEMON)) {
                ResourcePackType.FALLENKINGDOM_ANGE.send(player);
            }
        });
    }
    
    @Override
    public int getMin() {
        return teamSize * 2;
    }

    @Override
    public int getMax() {
        return teamSize * 15;
    }
    
    public int getTeamSize() {
        return teamSize;
    }
    
    //manage cinematic
    public void cinematic(UniPlayer player) {
    	FkCinematicPoint trav = new FkCinematicPoint() {

            @Override
            public void runTask(Runnable task, Long time) {
                Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), task, 380);
            }
        };
        
        trav.addTitle("game.fk.travel.title.one");
		trav.addTitle("game.fk.travel.title.two");
		trav.addTitle("game.fk.travel.title.three");
		trav.addTitle("game.fk.travel.title.four");
		
		trav.addSubTitle("game.fk.travel.subtitle.one");
		trav.addSubTitle("game.fk.travel.subtitle.two");
		trav.addSubTitle("game.fk.travel.subtitle.three");
		trav.addSubTitle("game.fk.travel.subtitle.four");

		if(getMap().getType().equals(FKMapType.FK_ANGEL_VS_DEMON)) {		
			locs.add(new Location((player.getWorld()), 123.3, 106, 71.7, (float) -40.9, (float) 48.0));
			locs.add(new Location((player.getWorld()), 152, 78, 91, (float) 156.6, (float) 28.5));
			locs.add(new Location((player.getWorld()), 154, 78, 104, (float) 133.2, (float) 26.2));
			locs.add(new Location((player.getWorld()), -142, 89, 122, (float) 48.5, (float) 28.0));
			locs.add(new Location((player.getWorld()), -142, 89, 122, (float) 48.5, (float) 28.0));
			trav.addSubTitle("game.fk.travel.title.map.angevsdemon");
			trav.addSubTitle("game.fk.travel.subtitle.map.angevsdemon");
		} else if (getMap().getType().equals(FKMapType.FK_CANDY_1VS1VS1VS1)) {		
			locs.add(new Location((player.getWorld()), 169, 87, -8, (float) 144.0, (float) 44.9));
			locs.add(new Location((player.getWorld()), 158, 78, -27, (float) 155.6, (float) 26.4));
			locs.add(new Location((player.getWorld()), 160, 76, -14, (float) 132.8, (float) 25.5));
			locs.add(new Location((player.getWorld()), -123, 84, -30, (float) 53.9, (float) 28.0));
			locs.add(new Location((player.getWorld()), -123, 84, -30, (float) 53.9, (float) 28.0));
			trav.addSubTitle("game.fk.travel.title.map.candy_anderval");
			trav.addSubTitle("game.fk.travel.subtitle.map.candy_anderval");
		} else if (getMap().getType().equals(FKMapType.FK_NORDIQUE)) {		
			locs.add(new Location((player.getWorld()), 73, 197, -142, (float) -97.9, (float) 38.1));
			locs.add(new Location((player.getWorld()), 13, 117, 40, (float) 47.3, (float) 39.6));
			locs.add(new Location((player.getWorld()), 207, 121, -214, (float) -36.2, (float) 38.6));
			locs.add(new Location((player.getWorld()), 378, 123, 101, (float) 51.0, (float) 43.9));
			locs.add(new Location((player.getWorld()), 188, 90, -71, (float) 38.7, (float) 47.3));
			trav.addSubTitle("game.fk.travel.title.map.nordique");
			trav.addSubTitle("game.fk.travel.subtitle.map.nordique");
		} else if (getMap().getType().equals(FKMapType.FK_AANDOVALE_1VS1VS1)) {		
			locs.add(new Location((player.getWorld()), 100, 107, 36, (float) 138.6, (float) 28.2));
			locs.add(new Location((player.getWorld()), 90, 99, 19, (float) 148.7, (float) 13.9));
			locs.add(new Location((player.getWorld()), 92, 99, 32, (float) 135.3, (float) 14.4));
			locs.add(new Location((player.getWorld()), -110, 110, 22, (float) 135.0, (float) 25.0));
			locs.add(new Location((player.getWorld()), -46.5, 103, 13, (float) -123.6, (float) 43.0));
			trav.addSubTitle("game.fk.travel.title.map.candy_anderval");
			trav.addSubTitle("game.fk.travel.subtitle.map.candy_anderval");
		}
        trav.addPoints(locs.get(0));
        trav.addPoints(locs.get(1));
        trav.addPoints(locs.get(2));
        trav.addPoints(locs.get(3));
        trav.addPoints(locs.get(4));        
        trav.runTask();
    }
    
    
    // only use this for first spawn in game /!\ (Used in FkTeam.class)
    public void firstspawn(UniPlayer player, Location spawnLocation) { 
    	for(UniPlayer pls : this.getOnlinePlayers()) {
    		pls.hidePlayer(player);
    		pls.setGameMode(GameMode.SPECTATOR);
    	}
    	cinematic(player); 
    	
    	Bukkit.getScheduler().runTaskLater(UnitaleSDK.getInstance(), new Runnable() {
			@Override
			public void run() {								
				//reset player stat
		        player.setGameMode(GameMode.SURVIVAL);
		        player.getInventory().clear();
		        player.setHealth(20);
		        player.setMaxHealth(20);		        
		        player.setFoodLevel(40);
		        player.setSaturation(20);
		        player.getActivePotionEffects().clear();
		        player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 100, 4));
		        
		        //check for kit
		        StartKit.check(player);

		        //add some foods to the player at respawn
		        player.getInventory().addItem(new UniItemStack(Material.WOOD_SWORD));
		        player.getInventory().addItem(new UniItemStack(Material.WOOD_PICKAXE));
		        player.getInventory().addItem(new UniItemStack(Material.COOKED_BEEF, 32));

		        //teleport players to the base center
		        player.teleport(spawnLocation);	

		        for(UniPlayer pls : getOnlinePlayers()) {
		    		pls.showPlayer(player);		    		
		    	}
		        UniLogger.info("init player " + player.getName() + " done !");
			}    		
    	}, 420);       
    }

    protected UniScoreboard getBoard() {
        final UniScoreboard b = new UniScoreboard();
        int i = 0;

        b.createSideBoard(ChatColor.GOLD + "FallenKingdom");

        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("map_text", Lang.str("game.fk.board.map", getMap().getType().toString()), i++, DisplaySlot.SIDEBAR);
        b.addScore("space_" + i, StringUtils.repeat(" ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("time", Lang.str("game.fk.board.waiting", getOnlinePlayers().size(), getMax()), i++, DisplaySlot.SIDEBAR);
        b.addScore("space_" + i, StringUtils.repeat("  ", i), i++, DisplaySlot.SIDEBAR);
        b.addScore("play_unitale", (ChatColor.YELLOW + "‣ play.unitale.fr"), i++, DisplaySlot.SIDEBAR);
        return b;
    }
}
