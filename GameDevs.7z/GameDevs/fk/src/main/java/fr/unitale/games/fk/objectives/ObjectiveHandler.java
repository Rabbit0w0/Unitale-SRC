package fr.unitale.games.fk.objectives;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;

import org.bukkit.entity.Player;

public class ObjectiveHandler {

    private Objective currentObjective;

    /**
     * {
     * "objectives":[
     * {
     * ...
     * },
     * {
     * ...
     * }
     * ]
     * }
     */
    public ObjectiveHandler(FkTeam team, JsonArray array) {
        Objective last = null;
        for (JsonElement element : array) {
            if (!(element instanceof JsonObject)) continue;

            JsonObject object = (JsonObject) element;
            ObjectiveType type = ObjectiveType.valueOf(object.get("type").getAsString());
            Objective objective = new Objective(
                    type,
                    object.get("needed").getAsInt(),
                    type.getObject(object.get("object").getAsString()),
                    last,
                    null
            );

            if (last != null) {
                last.setNext(objective);
            }

            last = objective;
        }
    }

    public void checkForCompletion() {
        Objective _current = currentObjective;
        while (_current != null && _current.isComplete()) {
            _current = _current.getNext();
        }
        currentObjective = _current;
    }

    public void increment(ObjectiveType type, Object object, int amount) {
        Objective _current = currentObjective;
        while (_current != null) {
            if (!_current.isComplete() && _current.getType().equals(type) && _current.getObject().equals(object)) { // gros doute sur le obj equals
                _current.increment(amount);
                break;
            }

            _current = _current.getNext();
        }
        checkForCompletion();
    }

    public static void check(FkInstance instance, Player player, ObjectiveType type, Object object) {
        check(instance, player, type, object, 1);
    }

    public static void check(FkInstance instance, Player player, ObjectiveType type, Object object, int amount) {
        final TeamModule<FkInstance, UniTeam> tm = new TeamModule<>(instance);
        FkTeam team = (FkTeam) tm.getTeamOf(player);
        team.getObjectiveHandler().increment(type, object, amount);
    }

    public Objective getCurrentObjective() {
        return currentObjective;
    }
}
