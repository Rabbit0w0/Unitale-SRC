package fr.unitale.games.fk.team;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Cow;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.util.Vector;

import com.google.gson.JsonArray;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.game.listeners.FkGameInstance;
import fr.unitale.games.fk.objectives.ObjectiveHandler;
import fr.unitale.games.fk.ui.FkPanelType;
import fr.unitale.games.fk.ui.FkWindow;
import fr.unitale.games.fk.utils.upgrade.Upgrades;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.bar.BarAPI;
import fr.unitale.sdk.bar.EndBar;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.npcs.NPCAPI;
import fr.unitale.sdk.npcs.NPCData;
import fr.unitale.sdk.npcs.NPCDataFactory;
import fr.unitale.sdk.npcs.NPCInteraction;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.area.AreaAPI;
import fr.unitale.sdk.utils.color.UniColor;

public class FkTeam extends UniTeam {

    private FkTeamBase base;
    private EnderCrystal heartCrystal;
    private int heartCrystalLife = 2000, heartCrystalMaxLife = 2000;
    private ObjectiveHandler handler;
    private List<Upgrades> acquiredUpgrades;
    private boolean upgradingWalls = false, upgradingFalls = false, upgradingEnchant = false, upgradingCore = false;
    private int taskWall, taskCore, taskFall;
    private final FkInstance fki;
    private final EndBar captureBar;

    public FkTeam(Instance<FkInstance> instance, String name, UniColor color, int size, Location baseCenter) {
        		super(instance, name, color, size);
        base = new FkTeamBase(this, baseCenter, new Vector(15, 15, 15));
        UnitaleSDK.getAPI(AreaAPI.class).addArea(base);
        handler = new ObjectiveHandler(this, (JsonArray) instance.getConfig("objectives", new JsonArray()));
        acquiredUpgrades = new ArrayList<>();
        this.fki = (FkInstance) instance;
        this.captureBar = BarAPI.generateDefaultBar(getHeartCrystalLife() + "", BarColor.BLUE);
    }

    public FkTeamBase getBase() {
        return base;
    }

    /**
     * Teleport, clear and reset all players in the base
     */
    public void spawn() {
        getOnlineCompetingPlayers().forEach(this::spawn);
    }

    /**
     * teleport clear and reset a player in the base
     *
     * @param player
     */
    public void spawn(UniPlayer player) {
    	fki.firstspawn(player, getBase().getCenter());
    }
    
    public void title(String title) {
        title(title);
    }
    
    /*
     * manage BarAPI
     */
    
    public void iniFailedBar(String s) {
        this.captureBar.valueConfig(1, 1);
        this.captureBar.setColor(BarColor.RED);
        this.captureBar.setTitle(s);
    }

    public void iniFailedBar() {
        iniFailedBar(ChatColor.RED + "/!\\ Team incomplete /!\\");
    }
    
    public void iniBar(String s) {
        this.captureBar.setTitle(s);
    }
    
    public void unlinkBar() {
    	for (final UniPlayer pls : this.getOnlinePlayers())unlinkBar(pls);
    }
    
    public void unlinkBar(UniPlayer p) {
        this.captureBar.quitBar(p);
    }
    
    public EndBar getCaptureBar() {
        return captureBar;
    }
    
    public void linkBar() {
        for (final UniPlayer pls : this.getOnlinePlayers())linkBar(pls);
    }
    
    public void linkBar(UniPlayer p) {
        this.captureBar.joinBar(p);
    }
    
    public void updateBar(int value) {
        final int max = 100;
        this.captureBar.setValue(max - value + value);
        if (value <= (max / 4)) {
            this.captureBar.setColor(BarColor.RED);
        } else if (value <= (max / 2)) {
            this.captureBar.setColor(BarColor.YELLOW);
        } else {
            this.captureBar.setColor(BarColor.GREEN);
        }
    }    
    
    /*
     * manage EnderCrystal
     */
    public UniColor getHealth(int heals, int healmax) {
        double heal = (heals / healmax) * heals;
        if (heal <= healmax) {
            return UniColor.GREEN;
        } else if (heal != healmax && heal > healmax / 2) {
            return UniColor.ORANGE;
        } else if (heal >= healmax / 2) {
            return UniColor.RED;
        } else {
            return UniColor.BROWN;
        }
    }
    

    public EnderCrystal getHeartCrystal() {
        return heartCrystal;
    }

    public void damageCore(int damage){
        //if team should be eliminated
        if(getHeartCrystalLife() <= damage){
            eliminate();
            Lang.bcst("game.fk.team.eliminated", getColor().getChatColor()+getName());
            getOnlineCompetingPlayers().forEach(p -> {
                p.setGameMode(GameMode.SPECTATOR);
                p.getInventory().clear();
            });
            return;
        }

        heartCrystalLife -= damage;
        heartCrystal.setCustomName(String.valueOf(heartCrystalLife));
    }

    public int getHeartCrystalLife() {
        return heartCrystalLife;
    }

    public int getHeartCrystalMaxLife() {
        return heartCrystalMaxLife;
    }

    public ObjectiveHandler getObjectiveHandler() {
        return handler;
    }
    
    public boolean objectiveCompled() {
		return this.handler.getCurrentObjective().isComplete();
    }
    
    /*
     * Spawn animal
     */
    private void spawnAnimal(Location center, Class<? extends Entity> c, int off) {
		final double x = Math.cos(off);
		final double z = Math.sin(off);
		center.getWorld().spawn(new Location(center.getWorld(), center.getX() + x * 3.5D + 0.5D, center.getY(),
				center.getZ() + z * 3.5D + 0.5D), c);
	}
    
    public void spawnAnimal() {
    	Location l = getBase().getCenter();
		l.setY(l.getY() + 1);
		int off = 0;
		for (int i = 0; i < 3; i++) {
			spawnAnimal(l, Sheep.class, off++);
			spawnAnimal(l, Cow.class, off++);
			spawnAnimal(l, Chicken.class, off++);
			spawnAnimal(l, Pig.class, off++);
		}
	}

    /**
     * Spawn the Heart crystal
     */
    public void spawnCrystal() {
        //first spawn the platform
        getBase().spawnPlatform();

        //then spawn the crystal
        Location crystalLoc = getBase().getCenter().clone();
        crystalLoc.add(0.5, 0.5, 0.5);
        heartCrystal = (EnderCrystal) getBase().getCenter().getWorld().spawnEntity(crystalLoc, EntityType.ENDER_CRYSTAL);
        heartCrystal.setCustomNameVisible(false);
        heartCrystal.setCustomName(String.valueOf(heartCrystalLife));
        heartCrystal.setGlowing(true);
        heartCrystal.setShowingBottom(false);
    }

    public void spawnNPCs() {
        Location spawnLocation = getBase().getCenter().clone();
        spawnLocation.add(5,5,0);
        NPCData vendorData = new NPCDataFactory()
                .setInvulnerable(true)
                .lookAtPlayers()
                .spawnLocation(spawnLocation.clone())
                .interaction(new NPCInteraction() {
                    @Override
                    public String getName() {
                        return "fk-npc-interaction-vendor-"+ UUID.randomUUID();
                    }                    
					@Override
					public void onInteractLeft(Player player, net.minecraft.server.v1_10_R1.Entity npc) {
						new FkWindow(FkPanelType.VENDOR, (UniPlayer)player).open(player);
						
					}
					@Override
					public void onInteractRight(Player player, net.minecraft.server.v1_10_R1.Entity npc) {
						new FkWindow(FkPanelType.VENDOR, (UniPlayer)player).open(player);
						
					}
                })
                .create();
        spawnLocation.add(0,5,2);
        NPCData builderData = new NPCDataFactory()
                .setInvulnerable(true)
                .lookAtPlayers()
                .spawnLocation(spawnLocation.clone())
                .interaction(new NPCInteraction() {
                    @Override
                    public String getName() {
                        return "fk-npc-interaction-builder-"+ UUID.randomUUID();
                    }                   
					@Override
					public void onInteractLeft(Player player, net.minecraft.server.v1_10_R1.Entity npc) {
						new FkWindow(FkPanelType.BUILDER, (UniPlayer)player).open(player);
						
					}
					@Override
					public void onInteractRight(Player player, net.minecraft.server.v1_10_R1.Entity npc) {
						new FkWindow(FkPanelType.BUILDER, (UniPlayer)player).open(player);
						
					}
                })
                .create();
        spawnLocation.add(0,5,-4);
        NPCData forgeData = new NPCDataFactory()
                .setInvulnerable(true)
                .lookAtPlayers()
                .spawnLocation(spawnLocation.clone())
                .interaction(new NPCInteraction() {
                    @Override
                    public String getName() {
                        return "fk-npc-interaction-forge"+ UUID.randomUUID();
                    }
                    @Override
                    public void onInteractLeft(Player player, net.minecraft.server.v1_10_R1.Entity npc) {
                        new FkWindow(FkPanelType.FORGE, (UniPlayer)player).open(player);
                    }
                    @Override
                    public void onInteractRight(Player player, net.minecraft.server.v1_10_R1.Entity npc) {
                        new FkWindow(FkPanelType.FORGE, (UniPlayer)player).open(player);
                    }
                })
                .create();

        NPCAPI api = UnitaleSDK.getAPI(NPCAPI.class);
        api.spawn(vendorData);
        api.spawn(builderData);
        api.spawn(forgeData);
    }

    public boolean canAssault(FkGameInstance module) {
        return getObjectiveHandler().getCurrentObjective() == null && module.getCurrentDay() >= 2;
    }

    public boolean isUpgradingWalls() {
        return upgradingWalls;
    }

    public void setUpgradingWalls(boolean upgradingWalls) {
        this.upgradingWalls = upgradingWalls;
    }

    public boolean isUpgradingFalls() {
        return upgradingFalls;
    }

    public void setUpgradingFalls(boolean upgradingFalls) {
        this.upgradingFalls = upgradingFalls;
    }

    public boolean isUpgradingEnchant() {
        return upgradingEnchant;
    }

    public void setUpgradingEnchant(boolean upgradingEnchant) {
        this.upgradingEnchant = upgradingEnchant;
    }

    public boolean isUpgradingCore() {
        return upgradingCore;
    }

    public void setUpgradingCore(boolean upgradingCore) {
        this.upgradingCore = upgradingCore;
    }

    public List<Upgrades> getAcquiredUpgrades() {
        return acquiredUpgrades;
    }
    
    /**
	 * @return the taskWall
	 */
	public int getTaskWall() {
		return taskWall;
	}

	/**
	 * @return the taskCore
	 */
	public int getTaskCore() {
		return taskCore;
	}

	/**
	 * @return the taskFall
	 */
	public int getTaskFall() {
		return taskFall;
	}

	/**
	 * @param taskWall the taskWall to set
	 */
	public void setTaskWall(int taskWall) {
		this.taskWall = taskWall;
	}

	/**
	 * @param taskCore the taskCore to set
	 */
	public void setTaskCore(int taskCore) {
		this.taskCore = taskCore;
	}

	/**
	 * @param taskFall the taskFall to set
	 */
	public void setTaskFall(int taskFall) {
		this.taskFall = taskFall;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FkTeam fkTeam = (FkTeam) o;
        return fkTeam.getName().equals(getName());
    }
}