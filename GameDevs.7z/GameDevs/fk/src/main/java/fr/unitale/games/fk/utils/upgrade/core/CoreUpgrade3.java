package fr.unitale.games.fk.utils.upgrade.core;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class CoreUpgrade3 extends CoreUpgrade{

    public CoreUpgrade3(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeCore(player, 3);
    }
}
