package fr.unitale.games.fk.game.cinematic;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.utils.chat.Title;

public abstract class FkCinematicPoint {

	private List<Location> pointsList = new ArrayList<>();
	private final List<String> titleList = new ArrayList<>();
	private final List<String> subtitleList = new ArrayList<>();
	private Runnable run;
	private BukkitTask task;
	private boolean endtask = true;

	public FkCinematicPoint() {
	}

	/**
	 * @start task
	 * @param player, locations, time
	 */
	public void runFunction(Player player, List<Location> locations, int time) {
		task = Bukkit.getScheduler().runTaskTimer(UnitaleSDK.getInstance(), new Runnable() {
			private int ticks = 0;

			@Override
			public void run() {
				try {
					Title.sendTitle(Lang.str(player, titleList.get(this.ticks)), Lang.str(player, subtitleList.get(this.ticks)));
					player.teleport(locations.get(this.ticks));
					this.ticks += 1;
				} catch (Exception e) {
					if (run != null && endtask) {
						endtask = false;
						run.run();
						task.cancel();
					}

				}

			}

		}, 0, 60L);
	}

	/**
	 * @add pointList
	 * @param loc
	 */
	public void addPoints(Location loc) {
		this.pointsList.add(loc);
	}

	/**
	 * @return the pointsList
	 */
	public List<Location> getPointsList() {
		return pointsList;
	}

	/**
	 * @param pointsList the pointsList to set
	 */
	public void setPointsList(List<Location> pointsList) {
		this.pointsList = pointsList;
	}

	/**
	 * Get amount of points
	 * 
	 * @return amount of points
	 */
	public int countPoints() {
		return this.pointsList.size();
	}

	/**
	 * Remove a point
	 * 
	 * @param pointNumber
	 */
	public void removePoint(int pointNumber) {
		this.pointsList.remove(pointNumber - 1);
	}

	/**
	 * Clear all points
	 */
	public void clearPoints() {
		this.pointsList.clear();
	}

	/**
	 * Run
	 */
	public void runTask() {
		for (Player player : Bukkit.getOnlinePlayers()) {
			player.getInventory().clear();
			runFunction(player, getPointsList(), 550);
		}
	}

	public abstract void runTask(Runnable task, Long time);

	/**
	 * Set task final
	 * 
	 * @param run
	 */

	public void setActionAtEnd(Runnable run) {
		this.run = run;
	}

	/**
	 * @add pointList
	 * @param title
	 */
	public void addTitle(String title) {
		this.titleList.add(title);
	}

	/**
	 * @add pointList
	 * @param subtitle
	 */
	public void addSubTitle(String subtitle) {
		this.subtitleList.add(subtitle);
	}

}