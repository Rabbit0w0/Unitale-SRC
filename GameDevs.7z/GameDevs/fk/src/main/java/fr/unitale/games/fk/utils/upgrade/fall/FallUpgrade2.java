package fr.unitale.games.fk.utils.upgrade.fall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class FallUpgrade2 extends FallUpgrade {

    public FallUpgrade2(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 2;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeFall(player, 4);
    }
}
