package fr.unitale.games.fk.utils.upgrade.wall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.ui.panel.FkPanel;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Material;

public class WallUpgrade3 extends WallUpgrade{

    public WallUpgrade3(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeWall(player, 12, 1, Material.STAINED_CLAY);
    }
}
