package fr.unitale.games.fk.utils.upgrade.farm;

import fr.unitale.games.fk.Wrapper;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import net.minecraft.server.v1_10_R1.NBTCompressedStreamTools;
import net.minecraft.server.v1_10_R1.NBTTagCompound;
import org.bukkit.Location;

import java.io.IOException;

public class FarmUpgrade implements IUpgrade{

    FkTeam team;

    public FarmUpgrade(FkTeam team){
        this.team = team;
    }

    @Override
    public int getLevel() {
        return 1;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        try {
            NBTTagCompound compound = NBTCompressedStreamTools.a(Wrapper.class.getResourceAsStream("schematic/model/farm.schematic"));
            Schematic schematic = SchematicAPI.loadSchematic(compound);

            Location spawn = team.getBase().getCenter().clone();
            spawn.add(5,-1,5);
            SchematicAPI.pasteSchematic(spawn, schematic, true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return true;
    }
}
