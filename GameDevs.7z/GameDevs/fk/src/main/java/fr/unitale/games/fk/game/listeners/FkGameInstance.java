package fr.unitale.games.fk.game.listeners;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Creature;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.EnchantingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.Dye;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.game.modules.FkEndModule;
import fr.unitale.games.fk.objectives.ObjectiveHandler;
import fr.unitale.games.fk.objectives.ObjectiveType;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.team.FkTeamBase;
import fr.unitale.games.fk.ui.panel.ForgePanel.ForgeEntry;
import fr.unitale.games.fk.ui.panel.VendorPanel.VendorEntry;
import fr.unitale.games.fk.utils.FkScoreboard;
import fr.unitale.games.fk.utils.upgrade.Upgrades;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.event.eliminate.EliminateTeamEvent;
import fr.unitale.sdk.game2.event.instance.InstanceEvent;
import fr.unitale.sdk.game2.event.instance.InstanceListenerUnregisteredEvent;
import fr.unitale.sdk.game2.event.player.GamePlayerWinEvent;
import fr.unitale.sdk.game2.instance.Module;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.game2.module.waiting.WaitingModule;
import fr.unitale.sdk.game2.stat.PlayerGameStat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.area.AreaJoinEvent;
import fr.unitale.sdk.utils.area.AreaLeaveEvent;
import fr.unitale.sdk.utils.area.AreaMoveEvent;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.firework.FireworkFactory;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;

public class FkGameInstance extends Module<FkInstance> implements Updater {
	private static final List<Material> farm = Arrays.asList(Material.POTATO, Material.CARROT, Material.WHEAT);
    private static final List<Material> canPlace = Arrays.asList(Material.TNT, Material.LAVA, Material.WATER, Material.STATIONARY_LAVA, Material.STATIONARY_WATER,
            Material.REDSTONE_TORCH_ON, Material.REDSTONE_TORCH_OFF, Material.FIRE, Material.WALL_SIGN, Material.SIGN_POST);
    private static final List<Material> canBreakOther = Arrays.asList(Material.TNT, Material.LAVA, Material.WATER, Material.STATIONARY_WATER, Material.STATIONARY_LAVA, Material.FIRE);
    private static final int MINUTES_PER_DAY = 10;
    private static final HashMap<UUID, Long> tempnomoney = new HashMap<>();    

    private UniTimer timer;
    public ArrayList<Material> materials;
    
    public FkGameInstance(FkInstance instance) {
    	super(instance, new FkEndModule(instance));
    	this.materials = new ArrayList<Material>();	
    }

    @EventHandler
    public void onStart(InstanceListenerUnregisteredEvent ev) {
        if (!check(ev)) return;
        if (!(ev.getListener() instanceof WaitingModule)) return;

        timer = new UniTimer("fk-game-timer-" + UUID.randomUUID().toString(), this);

        //spawn players
        getInstance().getTeamModule(FkTeam.class).getTeams().forEach(t -> {
            t.spawnCrystal();
            t.spawnNPCs();
            t.spawn(); 
            t.spawnAnimal();
            t.getOnlineCompetingPlayers().forEach(p -> p.setScoreboard(new FkScoreboard(p)));
        });

        TimeManager.getInstance().addTimer(timer);
    }

    @EventHandler
    public void on(BlockPlaceEvent ev) {
        if (!check(ev.getPlayer())) return;

        //get player and get team
        UniPlayer player = (UniPlayer) ev.getPlayer();
        FkTeam team = getInstance().getTeamModule(FkTeam.class).getTeamOf(player);
        Block block = ev.getBlock();

        //get whether the placed block is inside an enemy base
        boolean inEnemyBase = getInstance().getTeamModule(FkTeam.class).getTeams().stream().anyMatch(t -> t.getBase().contains(block.getLocation()));

        //default case with TNT
        switch (ev.getBlock().getType()) {
            case TNT:
                if (!team.canAssault(this)) {
                    ev.setCancelled(true);
                    player.sendMessage(Lang.str(player, "game.fk.tnt.noassault"));
                    return;
                } else if (block.getRelative(BlockFace.DOWN).getType().equals(Material.TNT)) {
                    ev.setCancelled(true);
                    player.sendMessage(Lang.str(player, "game.fk.tnt.no"));
                }                
            case REDSTONE_TORCH_OFF:
                if (!team.canAssault(this)) {
                    ev.setCancelled(true);
                    player.sendMessage(Lang.str(player, "game.fk.tnt.noassault"));
                    return;
                }                 
            case REDSTONE_TORCH_ON:
                if (!team.canAssault(this)) {
                    ev.setCancelled(true);
                    player.sendMessage(Lang.str(player, "game.fk.tnt.noassault"));
                    return;
                } 		
            default:
			break;
        }

        //if the block is outside of the team's base
        if (!team.getBase().contains(block.getLocation())) {
            if (inEnemyBase) {//in an enemy base
                if (!canPlace.contains(block.getType())) {
                    ev.setCancelled(true);
                    return;
                }
            } else {//in the world
                if (block.getType() != Material.WORKBENCH) {
                    ev.setCancelled(true);
                    return;
                } else if (block.getRelative(BlockFace.DOWN).getType() == Material.WORKBENCH) {
                    ev.setCancelled(true);
                    return;
                }
            }
        } else {//in player's base
            double dist = team.getBase().getCenter().distance(block.getLocation());
            if (dist < 5) {
                ev.setCancelled(true);
                player.sendMessage(Lang.str(player, "game.fk.place.no"));
                return;
            }
        }
    }    

    /**
     * manage block breaking
     */
    @EventHandler
    public void on(BlockBreakEvent ev) {
        String message, cap;
        final UniPlayer p = (UniPlayer) ev.getPlayer();

        //get player and get team
        UniPlayer player = (UniPlayer) ev.getPlayer();
        FkTeam team = getInstance().getTeamModule(FkTeam.class).getTeamOf(player);
        Block block = ev.getBlock();        
       
        if (farm.contains(ev.getBlock().getType())) {
			Location loc = ev.getBlock().getLocation();
			Bukkit.getServer().getScheduler().scheduleSyncDelayedTask(UnitaleSDK.getInstance(), () -> {
				loc.getWorld().getBlockAt(loc).setType(farm.get(new Random().nextInt(2)));
				byte data = loc.getWorld().getBlockAt(loc).getData();
				byte newData = (byte) (data + 1);
				if (newData > 7) {
					newData = (byte) 7;
				}
				loc.getWorld().getBlockAt(loc).setData(newData);
			}, 5);
		}
        
        if (ev.getBlock().getType().equals(Material.SOIL))ev.setCancelled(true);
        for (ItemStack item : ev.getBlock().getDrops()) {
			if (ev.getBlock().getType().equals(Material.SKULL))return;
			if (item.getType() == Material.LOG) {

				ev.getBlock().setType(Material.AIR);
				ItemMeta itemm = item.getItemMeta();
				message = VendorEntry.valueOf("LOG").getStack(p).toString().toLowerCase();
				cap = message.substring(0, 1);
				cap = cap.toUpperCase();

				message = message.substring(1);
				itemm.setDisplayName(UniColor.ORANGE + cap + message);
				itemm.setLore(Collections.singletonList(
						Lang.str(ev.getPlayer(), "game.fk.item.price", VendorEntry.valueOf("LOG").getStack(p).toString())));
				item.setItemMeta(itemm);

				ev.getBlock().getDrops().clear();
				ev.getPlayer().getInventory().addItem(item);
				break;
			}
			if (getMaterials().contains(item.getType())) {
				ev.getBlock().setType(Material.AIR);
				ItemMeta itemm = item.getItemMeta();
				message = item.toString().toLowerCase();
				cap = message.substring(0, 1);
				cap = cap.toUpperCase();

				message = message.substring(1);
				itemm.setDisplayName(UniColor.ORANGE + cap + message);
				itemm.setLore(Collections.singletonList(Lang.str(ev.getPlayer(), "game.fk.item.price",VendorEntry.valueOf(item.getType().name()).getStack(p).toString())));
				item.setItemMeta(itemm);
				ev.getBlock().getDrops().clear();
				ev.getPlayer().getInventory().addItem(item);
			}
        }			
        //get whether the placed block is inside an enemy base
        boolean inEnemyBase = getInstance().getTeamModule(FkTeam.class).getTeams().stream()
                .filter(t -> !t.equals(team))
                .anyMatch(t -> t.getBase().contains(block.getLocation()));

        if (inEnemyBase) {//in enemy base
            if (!canBreakOther.contains(block.getType())) {
                ev.setCancelled(true);
                return;
            }
        } else if (team.getBase().contains(block.getLocation())) {//in base
            double dist = team.getBase().getCenter().distance(block.getLocation());
            if (dist < 3) {
                ev.setCancelled(true);
                player.sendMessage(Lang.str(player, "game.fk.place.no"));
                return;
            }
        }
    }

    /**
     *  manage objectives
     */
    @EventHandler
    public void on(EntityDeathEvent ev) {
    	if (ev.getEntityType() != EntityType.PLAYER && ev.getEntity().getKiller() instanceof Player) {
    		final Player killer = ev.getEntity().getKiller(); 
    		final UniPlayer p = (UniPlayer) ev.getEntity().getKiller();
			String message, cap;
			Iterator<ItemStack> it = ev.getDrops().iterator();
			while (it.hasNext()) {
				ItemStack item = it.next();
				if (getMaterials().contains(item.getType())) {
					ItemMeta itemm = item.getItemMeta();
					message = item.getType().name().toLowerCase();

					cap = message.substring(0, 1);
					cap = cap.toUpperCase();

					message = message.substring(1);
					itemm.setDisplayName(UniColor.ORANGE + cap + message);
					itemm.setLore(Collections.singletonList(Lang.str(killer, "game.fk.item.price", VendorEntry.valueOf(item.getType().name()).getStack(p).toString())));
					item.setItemMeta(itemm);

					it.remove();
					ev.getDrops().clear();
					ev.getEntity().getWorld().dropItemNaturally(ev.getEntity().getLocation(), item);
				}
				
				if (item.getType() == Material.ARROW) {
					ItemMeta itemm = item.getItemMeta();
					itemm.setDisplayName(Lang.str(killer, ForgeEntry.valueOf("ARROW").getStack(p).toString(), 1 + ""));
					item.setItemMeta(itemm);
					it.remove();
					ev.getDrops().clear();
					ev.getEntity().getWorld().dropItemNaturally(ev.getEntity().getLocation(), item);
				}
			}
    	}
        ObjectiveHandler.check((FkInstance) getInstance(), ev.getEntity().getKiller(), ObjectiveType.KILL, ev.getEntityType());
    }
    
    /*
     * manage death player in fight
     */
    @EventHandler
    public void on(PlayerDeathEvent ev) {
      ev.setDeathMessage(null);
      if (!check(ev.getEntity())) return;
      FkTeam t = (FkTeam) UniTeam.getTeam(instance, ev.getEntity().getUniqueId());
      final UniPlayer deadPlayer = (UniPlayer)ev.getEntity();
      final UniPlayer killerPlayer = (UniPlayer)getKiller(ev.getEntity());
      PlayerGameStat s = new PlayerGameStat();
      if (killerPlayer == null) {
        if (ev.getEntity() != null && t != null)
	        GameSDK2.getInstance(deadPlayer).broadcast("game.fk.killed", Objects.requireNonNull(ev.getEntity()).getName());
	  		}else {
	  			UniTeam tk = UniTeam.getTeam(instance, killerPlayer.getUniqueId());
	  			GameSDK2.getInstance(deadPlayer).broadcast("game.fk.kill", t.getColor()+ev.getEntity().getName(), tk.getColor()+killerPlayer.getName());
	  			long nowtemp = (System.currentTimeMillis() / 1000 / 60) + 1;

	  			if(tempnomoney.containsKey(deadPlayer.getUniqueId())) {  					
	  					killerPlayer.sendMessage(Lang.str(killerPlayer, "game.fk.death.money"));	  				
	  			}else {
  					killerPlayer.sendMessage(Lang.str(killerPlayer, "game.fk.death.money"));
  					killerPlayer.getStorage().addInteger("fk-money", Integer.valueOf(100));
  					new BukkitRunnable() {
  						@Override
  						public void run() {
  							tempnomoney.remove(deadPlayer.getUniqueId());	
  							killerPlayer.getStorage().addInteger("fk-money", Integer.valueOf(100));
  						}
  					}.runTaskLater(UnitaleSDK.getInstance(), 270L);    
  					tempnomoney.put(deadPlayer.getUniqueId(), nowtemp);  					
	  			}
	  			StatManager.getInstance().addStat((Player)deadPlayer, s.DEATH);
	  			StatManager.getInstance().addStat((Player)killerPlayer, s.KILL);
	  		}           
      
	      	for (ItemStack i : ev.getDrops()) {
				if (i.equals(new ItemStack(Material.WOOD_SWORD)) || i.equals(new ItemStack(Material.WOOD_PICKAXE))) {
					i.setType(Material.AIR);
					}
	      		}
		      	deadPlayer.setHealth(deadPlayer.getMaxHealth());
				deadPlayer.setFoodLevel(20);	
				deadPlayer.getPlayer().setGameMode(GameMode.SPECTATOR);
				deadPlayer.getPlayer().sendTitle(Lang.str(deadPlayer, "game.fk.respawn.title"), Lang.str(deadPlayer, "game.fk.respawn.subtitle"));
		      
				new BukkitRunnable() {
					@Override
					public void run() {
						t.spawn(deadPlayer);						
					}
				}.runTaskLater(UnitaleSDK.getInstance(), 90L);    
    	}

    /**
     * manage objectives
     */
    @EventHandler
    public void on(CraftItemEvent event) {
        if (!check((InstanceEvent) event.getWhoClicked())) return;

        ObjectiveHandler.check(
                (FkInstance) getInstance(),
                (Player) event.getWhoClicked(),
                ObjectiveType.CRAFT,
                event.getRecipe().getResult().getType(),
                event.getRecipe().getResult().getAmount() // à tester
        );
    }
    
    /*
     * manage bridge
     */
    @EventHandler
    public void on(PlayerInteractEvent ev) {
    	UniPlayer player = (UniPlayer) ev.getPlayer();
    	if (ev.getItem() == null)
			return;
		else if (!ev.getItem().hasItemMeta())
			return;    	
    	if (ev.getItem().getType().equals(Material.SKULL_ITEM)) {
			if (ev.getItem().getItemMeta().getDisplayName().contains("pont")) {
				ev.setCancelled(true);
				player.getInventory().remove(ev.getItem());
				new BukkitRunnable() {
					final Location loc = player.getEyeLocation();
					final Vector direction = loc.getDirection().normalize();
					double t = 0;

					@Override
					public void run() {
						t += 1;
						double xtrav = direction.getX() * t;
						double ytrav = loc.getWorld().getHighestBlockYAt(loc) - loc.getWorld().getHighestBlockYAt(loc)
								- 1;
						double ztrav = direction.getZ() * t;
						loc.add(xtrav, ytrav, ztrav);

						Block b = loc.getWorld().getBlockAt(loc);
						if (b.getType().equals(Material.AIR) || b.getType().equals(Material.WATER)
								|| b.getType().equals(Material.LAVA) || b.getType().equals(Material.STATIONARY_LAVA)
								|| b.getType().equals(Material.STATIONARY_WATER)) {
							b.setType(Material.COBBLESTONE);
							player.getInventory().remove(ev.getItem());
						}
						loc.subtract(xtrav, ytrav, ztrav);
						if (t > 5) {
							cancel();
						}
					}
				}.runTaskTimer(UnitaleSDK.getInstance(), 0, 1);			
			}
    	}
    }
    
    /**
     * manage enchantment
     */
    @EventHandler
	public void on(InventoryOpenEvent ev) {
    	UniPlayer p = (UniPlayer) ev.getPlayer();
    	FkTeam t = getInstance().getTeamModule(FkTeam.class).getTeamOf(p);
    	
    	if (t.getAcquiredUpgrades().contains(Upgrades.ENCHANT_3)){
    		if(p instanceof EnchantingInventory) {
    			EnchantingInventory inv = (EnchantingInventory) ev.getInventory();
    			Dye d = new Dye();
    			d.setColor(DyeColor.BLUE);
    			ItemStack i = d.toItemStack();
    			i.setAmount(64);
    			inv.setItem(1, i);
    		}
    	}
	}
    
    @EventHandler
	public void on(InventoryCloseEvent ev) {
    	if (ev.getInventory() instanceof EnchantingInventory) {
			ev.getInventory().remove(Material.INK_SACK);
		}
    }
    
    /*@EventHandler
	public void on(InventoryClickEvent ev) {
    	if (ev.getInventory() instanceof EnchantingInventory) {    		
        	FkTeam t = UniTeam.getTeam(instance,(Player) ev.getWhoClicked());
        	if(t.getAcquiredUpgrades().contains(Upgrades.ENCHANT_3) && ev.getCurrentItem().getType().equals(new UniItemStack(Material.INK_SACK).getType())){
        		ev.setCancelled(true);
        	}
    	}
    }*/
    
    /**
     * manage player in move world
     * 
     * (besoin de check un truc plus tard)
     */
    
    @EventHandler
    public void on(AreaMoveEvent ev) {
      if (!(ev.getArea() instanceof FkTeamBase))
        return; 
      UniPlayer p = ev.getPlayer();
      FkTeamBase cr = (FkTeamBase)ev.getArea();
      FkTeam def = cr.getOwner();
      FkTeam atk = (FkTeam)getInstance().getTeamModule(FkTeam.class).getTeamOf((Player)p);
      if (def == atk) {
        if (atk.getAcquiredUpgrades().contains(Upgrades.SPEED_1)) {
          ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2400, -1, false, false));
        } else if (atk.getAcquiredUpgrades().contains(Upgrades.SPEED_2)) {
          ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2400, -1, false, false));
        } else if (atk.getAcquiredUpgrades().contains(Upgrades.SPEED_3)) {
          ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2400, -1, false, false));
        }else {
        	ev.getPlayer().removePotionEffect(PotionEffectType.SPEED);
        }
        if (atk.getAcquiredUpgrades().contains(Upgrades.PROTECTED_1)) {
          ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, -1, false, false));
        } else if (atk.getAcquiredUpgrades().contains(Upgrades.PROTECTED_2)) {
          ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, -1, false, false));
        } else if (atk.getAcquiredUpgrades().contains(Upgrades.PROTECTED_3)) {
          ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, -1, false, false));
        }else {
        	ev.getPlayer().removePotionEffect(PotionEffectType.ABSORPTION);    
        }
      }
      
      if(def != atk) {
    	  if(isAssaulting(def, atk) && atk.canAssault(this) && atk.objectiveCompled()) {
    		  tryToAssault(ev.getPlayer(), def, atk);
    	  }else if(!atk.canAssault(this)) {
    		  atk.iniFailedBar(Lang.str(ev.getPlayer(), "game.fk.endbar.assaultdeny"));
    	  }else if(!atk.objectiveCompled()) {
    		  atk.iniFailedBar(Lang.str(ev.getPlayer(), "game.fk.endbar.objectivedeny"));
    	  }else if(!isAssaulting(def, atk)) {
    		  atk.iniFailedBar(Lang.str(ev.getPlayer(), "game.fk.endbar.teamdeny"));
    	  }
    	  atk.linkBar(ev.getPlayer());
      }
    }
    
    @EventHandler
    public void on(AreaJoinEvent ev) {
    	if (ev.getArea() instanceof FkTeamBase) {
    		FkTeamBase b = (FkTeamBase) ev.getArea();
            FkTeam t = (FkTeam) UniTeam.getTeam(instance, ev.getPlayer().getUniqueId());
            if (t == b.getOwner()) {
            	t.iniBar(Lang.str(ev.getPlayer(), "game.fk.core.heal", t.getHeartCrystal().toString()));
            	t.getCaptureBar().setColor(BarColor.BLUE);
            	t.linkBar(ev.getPlayer());
            	ev.getPlayer().removePotionEffect(PotionEffectType.SPEED);
                ev.getPlayer().removePotionEffect(PotionEffectType.ABSORPTION);
            }
    	}
    }
    
    @EventHandler
    public void on(AreaLeaveEvent ev) {
    	if (ev.getArea() instanceof FkTeamBase) {
    		FkTeamBase b = (FkTeamBase) ev.getArea();
            FkTeam t = (FkTeam) UniTeam.getTeam(instance, ev.getPlayer().getUniqueId());
            if (t == b.getOwner()) {
                ev.getPlayer().getActivePotionEffects().clear();
                t.unlinkBar(ev.getPlayer());
                ev.getPlayer().removePotionEffect(PotionEffectType.SPEED);
                ev.getPlayer().removePotionEffect(PotionEffectType.ABSORPTION);
                if (t.getAcquiredUpgrades().contains((Upgrades.SPEED_1)) || 
                		t.getAcquiredUpgrades().contains((Upgrades.SPEED_2)) || 
                		t.getAcquiredUpgrades().contains((Upgrades.SPEED_3))){
                    ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2400, -1, false, false));
                }

                if (t.getAcquiredUpgrades().contains((Upgrades.PROTECTED_1)) || 
                		t.getAcquiredUpgrades().contains((Upgrades.PROTECTED_2)) || 
                		t.getAcquiredUpgrades().contains((Upgrades.PROTECTED_3))){
                    ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, -1, false, false));
                }
            }else {
            	t.unlinkBar(ev.getPlayer());
            }
        }
    }
    
    /**
     * manager player teleport
     */
    @EventHandler
	public void onPlayerTeleportEvent(PlayerTeleportEvent e) {
		if (e.getCause() == TeleportCause.END_PORTAL) {
			e.setCancelled(true);
		} else if (e.getCause() == TeleportCause.NETHER_PORTAL) {
			e.setCancelled(true);
		}
	}
    
    /**
     * manage chat format
     */
    @EventHandler
	public void on(AsyncPlayerChatEvent ev) {
    	UniPlayer p = (UniPlayer) ev.getPlayer();
    	String message = ev.getMessage();
    	FkTeam t = getInstance().getTeamModule(FkTeam.class).getTeamOf(p);
    	if (message.startsWith("!")) {
			if (t != null) {			
				ev.setFormat(t.getColor() + "[" + t.getName() + "] " + p.getName() + ":" + UniColor.WHITE + " " + message);
			}
		} else {
			ev.setCancelled(true);
			t.broadcast(t.getColor() + "[Team][" + p.getName() + "]: " + message);
		}
    }

    /**
     * manage crystal damage
     */
    @EventHandler
    public void on(EntityDamageByEntityEvent ev){
        if (!(ev.getDamager() instanceof UniPlayer)) {
            return;
        }
        UniPlayer damager = (UniPlayer)ev.getDamager();
        if(ev.getEntity() instanceof EnderCrystal){
            EnderCrystal crystal = (EnderCrystal) ev.getEntity();
            ev.setCancelled(true);

            FkTeam playerTeam = getInstance().getTeamModule(FkTeam.class).getTeamOf(damager);
            FkTeam crystalTeam = getInstance().getTeamModule(FkTeam.class).getTeams().stream()
                    .filter(t -> t.getHeartCrystal().equals(crystal))
                    .findAny().orElse(null);

            if(crystalTeam == null)return;
            if(crystalTeam.equals(playerTeam))return;
            if(!playerTeam.canAssault(this)){
                damager.sendMessage(Lang.str(damager, "game.fk.no.assault"));
                return;
            }
            crystalTeam.damageCore((int)ev.getFinalDamage());
        }
    }
    
    /**
     * manage team win/loose
     */
    @EventHandler
	public void on(EliminateTeamEvent ev) {
    	if (!check(ev)) return;
    	
    	UniLogger.info("Elimination de l'équipe : " + ev.getTeam().getName());
        if (instance.getStatus() == ServerTypes.GameStatus.END) return;
    	
    	FkTeam t = (FkTeam) ev.getTeam();
    	
    	if (instance.getCompetingTeamCount() == 0) {
            instance.endGame(200L);
    	} else if (instance.getCompetingTeamCount() == 1) {
    		// clear entities
            instance.getMap().getWorld().getEntities().stream()
                    .filter(entity -> entity instanceof Creature)
                    .forEach(Entity::remove);
            final TeamModule<FkInstance, UniTeam> tm = instance.getTeamModule(UniTeam.class);
            for (final UniTeam team : tm.getTeams()) {
            	if (!team.isEliminated()) {
            		Bukkit.getPluginManager().callEvent(new GamePlayerWinEvent(instance, team.getOnlineCompetingPlayers()));
            		win(team);
                    instance.endGame(200L);
                    instance.unregister(this);
                    TimeManager._instance.removeTimer(timer);
                    return;
            	}
            }            
	    	for (final OfflinePlayer o : t.getOfflinePlayers()) {
				if (o.isOnline()) {
					o.getPlayer().setGameMode(GameMode.SPECTATOR);
					instance.defeatPlayer((UniPlayer)o);
				}
			}	
	    	t.getOnlinePlayers().forEach(p -> p.sendMessage(Lang.str(p, "game.fk.team.eliminated", t.getName())));
	    	t.eliminate();  	
    	}
    }
    
    /**
     * 
     * @param d
     * @param a
     * @param heal
     */
    private void coreCapture(FkTeam d, FkTeam a, int heal) {
    	a.updateBar(heal);
    	if(heal == 0) {
    		for(UniPlayer pls : a.getOnlineCompetingPlayers())a.title(Lang.str(pls, "game.fk.captured", d.getName()));
    		for (UniPlayer pls : d.getOnlinePlayers())d.title(Lang.str(pls, "game.fk.eliminated", a.getName()));
    		d.eliminate();
    		a.unlinkBar();
    	}
    }
    
    /**
     * 
     * @param p
     * @param d
     * @param a
     */
    private void tryToAssault(UniPlayer p, FkTeam d, FkTeam a) {
    	try {
    		if(d.isEliminated() || a.isEliminated())return;
    		for(UniPlayer pls : a.getOnlineCompetingPlayers()) {
    			a.iniBar(Lang.str(pls, "game.fk.capturebar", d.getColor() + d.getName()));
				a.linkBar(pls);
    			a.broadcast(Lang.str(pls, "game.fk.attack", d.getColor() + d.getName()));    			
    		}
    		a.broadcast(Lang.str(p, "game.fk.attack", d.getColor() + d.getName()));
    		d.broadcast(Lang.str(p, "game.fk.attack.defend", a.getColor() + a.getName()));
    		coreCapture(d, a, 1);    		
    	}catch (Exception e) {}
    }
    
    /**
     * 
     * @param d
     * @param a
     * @return
     */
    private boolean isAssaulting(FkTeam d, FkTeam a) {
		if (d == null || a == null) return false;
		for (final OfflinePlayer op : a.getOfflinePlayers()) {
			if (!availablePlayer(op)) {
				return false;
			}
		}
		return true;
	}
    
    /**
     * 
     * @return
     */
    public ArrayList<Material> getMaterials() {
		return materials;
	}

    /**
     * 
     * @param materials
     */
	public void setMaterials(ArrayList<Material> materials) {
		this.materials = materials;
	}
	
	/**
	 * say win game and add stats
	 * @param team
	 */
	private void win(UniTeam team) {
        if (instance.getTeamSize() > 1) {
            instance.broadcast("game.fk.win.team", team.getColor() + team.getName());        
        }
        for (final UniPlayer p : instance.getOnlinePlayers()) {
            if (team.contains(p)) {
            	TimeManager._instance.removeTimer(timer);
                FireworkFactory.spawnRandomFirework(p.getLocation(), true);   
                GameSDK2.getInstance(p ).broadcast("game.fk.win", team.getColor() + team.getName());
                instance.victoryPlayer(p);
            } else {
                instance.defeatPlayer(p);
            }            
        }
    }
	
	/**
	 * 
	 * @param uuid
	 * @return
	 */
	public boolean availablePlayer(UUID uuid) {
		OfflinePlayer player = Bukkit.getOfflinePlayer(uuid);
		return player != null && availablePlayer(player);
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean availablePlayer(OfflinePlayer player) {
		return getInstance().isEliminated(player.getUniqueId()) || player.isOnline();
	}
    
   /**
    * Get the killer
    * @return
    */

 	private Player getKiller(LivingEntity e) {
 		final Player en = e.getKiller();
 		if (en != null) {
 			return en;
 		}
 		if ((en instanceof Projectile)) {
 			((Projectile) en).getShooter();
 		}
 		return null;
 	}

    /**
     * Get the game's running timer
     * @return
     */
    public UniTimer getTimer() {
        return timer;
    }

    /**
     * @return Current day in the game
     */
    public int getCurrentDay() {
        return timer.getMinutes() / MINUTES_PER_DAY + 1;
    }

    /**
     * @return whether the players can PvP
     */
    public boolean canPvP(){
        return getCurrentDay() >= 2;
    }
    
    @Override
    public void start() {}

    /**
     * When timer is updated
     */
    @Override
    public void update() {
    	getInstance().getTeamModule(FkTeam.class).getTeams().forEach(t -> t.getOnlineCompetingPlayers().forEach(p -> ((FkScoreboard)p.getEndScoreboard()).update()));
        
    }

    @Override
    public void end() {
    	TimeManager._instance.removeTimer(timer);
    }
}
