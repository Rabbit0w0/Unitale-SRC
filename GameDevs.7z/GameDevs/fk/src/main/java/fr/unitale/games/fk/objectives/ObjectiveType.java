package fr.unitale.games.fk.objectives;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public enum ObjectiveType {
    KILL("games.fk.objective.kill", EntityType.class),
    CRAFT("games.fk.objective.craft", Material.class);

    private final String display;
    private final Class<?> clazz;

    ObjectiveType(String display, Class<?> clazz) {
        this.display = display;
        this.clazz = clazz;
    }

    @SuppressWarnings("unchecked")
    public <T extends Enum<T>> T getObject(String name) {
        return Enum.valueOf((Class<T>) clazz, name);
    }
}
