package fr.unitale.games.fk.ui.panel;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.ui.FkPanelType;
import fr.unitale.games.fk.utils.Hat;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.Arrays;

/**
 * Forge panel to get new items
 */
public class ForgePanel extends FkPanel implements UIFormHandler<ForgePanel.ForgeEntry> {

    public ForgePanel(UniPlayer player) {
        super(54, Lang.str(player, FkPanelType.FORGE.getName()));

        Arrays.stream(ForgeEntry.values()).forEach(entry -> setComponent(entry.slot, new UIButton<ForgeEntry>(entry, entry.getStack(player))));
    }

    @Override
    public void update() {
        getWindow().getDisplay().clear();
        Arrays.stream(ForgeEntry.values()).forEach(entry -> setComponent(entry.slot, new UIButton<ForgeEntry>(entry, entry.getStack(getWindow().getPlayer()))));
    }

    @Override
    public void onSubmit(Player player, ForgeEntry entry) {
        int playerMoney = ((UniPlayer)player).getStorage().getInteger(FkInstance.PLAYER_MONEY_KEY);
        if(entry.price <= playerMoney){//can afford
            ((UniPlayer)player).getStorage().addInteger(FkInstance.PLAYER_MONEY_KEY, playerMoney-entry.price);
            player.getInventory().addItem(entry.stack);
        }else{
            player.sendMessage(Lang.str(player, "game.fk.money.cantafford"));
        }
    }

    public enum ForgeEntry {
        HELMET_V1(new UniItemStack(Material.CHAINMAIL_HELMET), 19, 50),
        HELMET_V2(new UniItemStack(Material.IRON_HELMET), 20, 150),
        HELMET_V3(new UniItemStack(Material.DIAMOND_HELMET), 21, 300),

        CHESTPLATE_V1(new UniItemStack(Material.CHAINMAIL_CHESTPLATE), 28, 50),
        CHESTPLATE_V2(new UniItemStack(Material.IRON_CHESTPLATE), 29, 150),
        CHESTPLATE_V3(new UniItemStack(Material.DIAMOND_CHESTPLATE), 30, 300),

        LEGGINGS_V1(new UniItemStack(Material.CHAINMAIL_LEGGINGS), 37, 50),
        LEGGINGS_V2(new UniItemStack(Material.IRON_LEGGINGS), 38, 150),
        LEGGINGS_V3(new UniItemStack(Material.DIAMOND_LEGGINGS), 39, 300),

        BOOTS_V1(new UniItemStack(Material.CHAINMAIL_BOOTS), 46, 50),
        BOOTS_V2(new UniItemStack(Material.IRON_BOOTS), 47, 150),
        BOOTS_V3(new UniItemStack(Material.DIAMOND_BOOTS), 48, 300),

        SWORD_V1(new UniItemStack(Material.GOLD_SWORD), 10, 50),
        SWORD_V2(new UniItemStack(Material.IRON_SWORD), 11, 200),
        SWORD_V3(new UniItemStack(Material.DIAMOND_SWORD), 12, 300),

        FLINT_AND_STEEL(new UniItemStack(Material.FLINT_AND_STEEL), 24, 300),

        IRON_PICKAXE(new UniItemStack(Material.IRON_PICKAXE), 23, 200),

        GOLDEN_APPLE(new UniItemStack(Material.GOLDEN_APPLE), 16, 200),

        BOW(new UniItemStack(Material.BOW), 20, 200),
        ARROW(new UniItemStack(Material.ARROW), 21, 100),

        TNT(new UniItemStack(Material.TNT), 15, 400),

        BRIDGE_V1(Hat.BRIDGE_V1.getItemStack(), 14, 300);

        UniItemStack stack;
        int price, slot;

        ForgeEntry(UniItemStack stack, int slot, int price){
            this.stack = stack;
            this.stack.setName("game.fk.forge."+name().toLowerCase()+".name");
            this.stack.setLores("game.fk.forge."+name().toLowerCase()+".desc");
            this.slot = slot;
            this.price = price;
        }

        public UniItemStack getStack(UniPlayer player) {
            return stack.translate(player).addLore(Lang.str(player, "game.fk.forge.item.price", ""+price));
        }
    }
}
