package fr.unitale.games.fk.utils.upgrade.core;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class CoreUpgrade2 extends CoreUpgrade{

    public CoreUpgrade2(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 2;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeCore(player, 2);
    }
}
