package fr.unitale.games.fk.ui.panel;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.ui.FkPanelType;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.ui.elements.UISorter;
import fr.unitale.sdk.ui.elements.sorters.RoundSortPattern;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;

/**
 * Vendor panel to sell items
 */
public class VendorPanel extends FkPanel implements UIFormHandler<VendorPanel.VendorEntry> {

	private UISorter sorter;

	public VendorPanel(UniPlayer player) {
		super(54, Lang.str(player, FkPanelType.VENDOR.getName()));

		sorter = new UISorter(new RoundSortPattern());

		Arrays.stream(VendorEntry.values()).forEach(entry -> sorter.add(new UIButton<>(entry, entry.getStack(player))));
	}

	@Override
	protected void onDisplayed() {
		super.onDisplayed();
		sorter.render(this);
	}

	@Override
	public void update() {
		sorter.clear();
		getWindow().getDisplay().clear();
		Arrays.stream(VendorEntry.values())
				.forEach(entry -> sorter.add(new UIButton<>(entry, entry.getStack(getWindow().getPlayer()))));
		sorter.render(this);
	}

	@Override
	public void onSubmit(Player player, VendorEntry entry) {
		int playerMoney = ((UniPlayer) player).getStorage().getInteger(FkInstance.PLAYER_MONEY_KEY);
		int moneyAdded = 0;

		for (ItemStack is : player.getInventory().getStorageContents()) {
			// check for matching item
			if ( is != null && entry.matches(is)) {
				moneyAdded += entry.price * is.getAmount();
				((UniPlayer) player).getStorage().addInteger(FkInstance.PLAYER_MONEY_KEY, playerMoney + moneyAdded);
				player.getInventory().remove(is);
			}
		}

		player.sendMessage(Lang.str(player, "game.fk.money.added"));

	}

	public enum VendorEntry {
		EVENT(100, Material.BEACON),
		LOG(1, Material.LOG, Material.LOG_2),
		COAL(2, Material.COAL),
		IRON_INGOT(5, Material.IRON_INGOT),
		REDSTONE_INGOT(3, Material.REDSTONE),
		GOLD_INGOT(10, Material.GOLD_INGOT),
		DIAMOND(20, Material.DIAMOND),
		EMERALD(50, Material.EMERALD),
		SPIDER_EYE(5, Material.SPIDER_EYE),
		STRING(5, Material.STRING),
		BONE(5, Material.BONE),
		ENDER_PEARL(20, Material.ENDER_PEARL),
		ROTTENFLESH(5, Material.ROTTEN_FLESH);

		private List<Material> materials;
		UniItemStack stack;
		int price;

		VendorEntry(int price, Material... m) {
			this.materials = Arrays.asList(m);

			this.stack = new UniItemStack(m[0]);
			this.stack.setName("game.fk.vendor." + name().toLowerCase() + ".name");
			this.stack.setLores("game.fk.vendor." + name().toLowerCase() + ".desc");

			this.price = price;
		}

		public UniItemStack getStack(UniPlayer player) {
			return stack.translate(player).addLore(Lang.str(player, "game.fk.vendor.item.price", "" + price));
		}

		public boolean matches(ItemStack stack) {
			return materials.contains(stack.getType());
		}
	}
}
