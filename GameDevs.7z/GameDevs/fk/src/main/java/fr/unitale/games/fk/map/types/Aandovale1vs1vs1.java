package fr.unitale.games.fk.map.types;

import fr.unitale.games.fk.map.FKMap;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.sdk.utils.color.UniColor;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Arrays;

public class Aandovale1vs1vs1 extends FKMap{

    public Aandovale1vs1vs1(String name, World world) {
        super(FKMapType.FK_AANDOVALE_1VS1VS1, name, world, 5, 3,
                new Location(world, 0, 200, 0),
                new Location(world, 85, 119, 21),
                new Location(world, -128, 121, 6),
                new Location(world, -26, 117, -112));
    }

    @Override
    public String defaultNameFromId(int id) {
        return Arrays.asList("Rouge", "Bleu", "Vert").get(id);
    }

    @Override
    public UniColor defaultColorFromId(int id) {
        return Arrays.asList(UniColor.RED, UniColor.BLUE, UniColor.GREEN).get(id);
    }
}
