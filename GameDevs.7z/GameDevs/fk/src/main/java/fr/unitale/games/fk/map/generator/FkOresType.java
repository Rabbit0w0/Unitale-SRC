package fr.unitale.games.fk.map.generator;

import org.bukkit.Material;

import java.util.Random;

public enum FkOresType {
	
	COAL_ORE(Material.COAL_ORE, 65, 5, 100, 65),
	IRON_ORE(Material.IRON_ORE, 65, 5, 90, 60),
	LAPIS_ORE(Material.LAPIS_ORE, 16, 14, 50, 40),
	REDSTONE_ORE(Material.REDSTONE_ORE, 12, 5, 70, 50),
	GOLD_ORE(Material.GOLD_ORE, 29, 5, 80, 50),
	DIAMOND_ORE(Material.DIAMOND_ORE, 12, 5, 40, 40),
	EMERALD_ORE(Material.EMERALD_ORE, 29, 5, 10, 30);

	private final Integer maxy;
	private final Integer miny;
	private Integer size;
	private final Integer percentage;

    FkOresType(Material ore, Integer maxy, Integer miny, Integer size, Integer percentage) {
		this.maxy = maxy;
		this.miny = miny;
        this.size = size;
		this.size = new Random().nextInt(size);
		if (this.size < 3 && ore != Material.EMERALD_ORE)
			this.size = 3;
		this.percentage = percentage;
	}

	/**
	 * @return the maxy
	 */
	public Integer getMaxy() {
		return maxy;
	}

	/**
	 * @return the miny
	 */
	public Integer getMiny() {
		return miny;
	}

	/**
	 * @return the size
	 */
	public Integer getSize() {
		return size;
	}

	/**
	 * @return the percentage
	 */
	public Integer getPercentage() {
		return percentage;
	}
}
