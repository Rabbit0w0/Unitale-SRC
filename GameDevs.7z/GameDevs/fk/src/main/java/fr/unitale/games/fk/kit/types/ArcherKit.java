package fr.unitale.games.fk.kit.types;

import fr.unitale.games.fk.kit.StartKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;

public class ArcherKit extends StartKit {

    public ArcherKit(IKit kit) {
        super(kit);
    }

    @Override
    public void onGameStart(UniPlayer player) {
        switch(getLevel()){
            case 1:
                player.getInventory().addItem(new UniItemStack(Material.BOW));
                player.getInventory().addItem(new UniItemStack(Material.ARROW, 32));
                break;
            case 2:
                player.getInventory().addItem(new UniItemStack(Material.BOW));
                player.getInventory().addItem(new UniItemStack(Material.ARROW, 64));
                break;
            case 3:
                player.getInventory().addItem(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_DAMAGE, 1));
                player.getInventory().addItem(new UniItemStack(Material.ARROW, 32));
                break;
            case 4:
                player.getInventory().addItem(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_DAMAGE, 1));
                player.getInventory().addItem(new UniItemStack(Material.ARROW, 32));
                player.getInventory().addItem(new UniItemStack(Material.LEATHER_BOOTS).addNewEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2).addNewEnchantment(Enchantment.PROTECTION_FALL, 4));
                break;
            case 5:
                player.getInventory().addItem(new UniItemStack(Material.BOW).addNewEnchantment(Enchantment.ARROW_DAMAGE, 2));
                player.getInventory().addItem(new UniItemStack(Material.ARROW, 32));
                player.getInventory().addItem(new UniItemStack(Material.LEATHER_BOOTS).addNewEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 2).addNewEnchantment(Enchantment.PROTECTION_FALL, 4));
                break;
        }
    }
}
