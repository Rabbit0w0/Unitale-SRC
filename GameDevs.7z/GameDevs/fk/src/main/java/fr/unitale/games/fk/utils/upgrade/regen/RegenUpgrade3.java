package fr.unitale.games.fk.utils.upgrade.regen;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class RegenUpgrade3 extends RegenUpgrade {

    public RegenUpgrade3(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeRegen(player, 3);
    }
}
