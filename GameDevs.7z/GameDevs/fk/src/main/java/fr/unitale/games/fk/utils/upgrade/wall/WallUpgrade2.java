package fr.unitale.games.fk.utils.upgrade.wall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.ui.panel.FkPanel;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Material;

public class WallUpgrade2 extends WallUpgrade{

    public WallUpgrade2(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 2;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeWall(player, 11, 2, Material.STAINED_CLAY);
    }
}
