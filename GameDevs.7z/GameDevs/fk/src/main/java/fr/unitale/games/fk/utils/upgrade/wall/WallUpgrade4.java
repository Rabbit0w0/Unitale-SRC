package fr.unitale.games.fk.utils.upgrade.wall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.ui.panel.FkPanel;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Material;

public class WallUpgrade4 extends WallUpgrade{

    public WallUpgrade4(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 4;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeWall(player, 12, 2, Material.ENDER_STONE);
    }
}
