package fr.unitale.games.fk.kit.types;

import fr.unitale.games.fk.kit.StartKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemStack;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;

public class MinerKit extends StartKit {

    public MinerKit(IKit kit) {
        super(kit);
    }

    @Override
    public void onGameStart(UniPlayer player) {
        switch (getLevel()){
            case 1:
                player.getInventory().addItem(new UniItemStack(Material.STONE_PICKAXE).addNewEnchantment(Enchantment.DIG_SPEED, 1));
                break;
            case 2:
                player.getInventory().addItem(new UniItemStack(Material.IRON_PICKAXE));
                break;
            case 3:
                player.getInventory().addItem(new UniItemStack(Material.IRON_PICKAXE).addNewEnchantment(Enchantment.DIG_SPEED, 1));
                break;
            case 4:
                player.getInventory().addItem(new UniItemStack(Material.IRON_PICKAXE).addNewEnchantment(Enchantment.DIG_SPEED, 2).addNewEnchantment(Enchantment.DURABILITY, 1));
                break;
            case 5:
                player.getInventory().addItem(new UniItemStack(Material.DIAMOND_PICKAXE).addNewEnchantment(Enchantment.DIG_SPEED, 1));
                break;
        }
    }
}
