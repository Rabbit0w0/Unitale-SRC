package fr.unitale.games.fk.ui;

public enum FkPanelType {
    BUILDER("game.fk.panel.builder.name"),
    FORGE("game.fk.panel.forge.name"),
    VENDOR("game.fk.panel.vendor.name");

    private String name;

    FkPanelType(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
