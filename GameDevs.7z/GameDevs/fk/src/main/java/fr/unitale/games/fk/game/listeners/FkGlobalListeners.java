package fr.unitale.games.fk.game.listeners;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.map.FKMap;
import fr.unitale.sdk.features.fallenkingdoms.FKKitType;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.GlobalListener;
import fr.unitale.sdk.game2.event.instance.PlayerJoinInstanceEvent;
import fr.unitale.sdk.game2.kit.KitManager;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;

public class FkGlobalListeners extends GlobalListener {

    /*
     * Cancel damages in waiting room
     */
    @EventHandler
    public void on(EntityDamageEvent event) {
        if (event.getEntity().getType() != EntityType.PLAYER) return;
        if (GameSDK2.getInstance((Player) event.getEntity()).getStatus().equals(ServerTypes.GameStatus.WAIT)) {
            event.setCancelled(true);
        }
    }

    /*
     * Teleport player to spawn at joining
     */
    @EventHandler
    protected void userJoin(PlayerJoinInstanceEvent event) {
        if (GameSDK2.getInstance(event.getPlayer()).getUniqueId().equals(event.getInstance().getUniqueId())) return;
        event.getPlayer().teleport(event.getInstance().getMap(FKMap.class).getWaitingRoomLocation());

        //load kits
        KitManager.loadFeatures(event.getPlayer(), FKKitType.values());
    }

    
}
