package fr.unitale.games.fk.map.types;

import fr.unitale.games.fk.map.FKMap;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.sdk.utils.color.UniColor;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Arrays;

public class Candy1vs1vs1vs1 extends FKMap {

    public Candy1vs1vs1vs1(String name, World world) {
        super(FKMapType.FK_CANDY_1VS1VS1VS1, name, world, 5, 4,
                new Location(world, 0, 200, 0),
                new Location(world, -151, 71, -10),
                new Location(world, 155, 74, -25),
                new Location(world, -28, 69, 198),
                new Location(world, 47, 95, -281));
    }

    @Override
    public String defaultNameFromId(int id) {
        return Arrays.asList("Rouge", "Bleu", "Vert", "Jaune").get(id);
    }

    @Override
    public UniColor defaultColorFromId(int id) {
        return Arrays.asList(UniColor.RED, UniColor.BLUE, UniColor.GREEN, UniColor.YELLOW).get(id);
    }
}
