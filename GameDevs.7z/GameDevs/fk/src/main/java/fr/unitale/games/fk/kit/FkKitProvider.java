package fr.unitale.games.fk.kit;

import fr.unitale.games.fk.kit.types.ArcherKit;
import fr.unitale.games.fk.kit.types.EnchanterKit;
import fr.unitale.games.fk.kit.types.GuerrierKit;
import fr.unitale.games.fk.kit.types.MinerKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.game2.kit.AbstractKit;
import fr.unitale.sdk.game2.kit.KitProvider;

/**
 * Provide kit classes from {@link IKit} instance
 */
public class FkKitProvider implements KitProvider {

    @Override
    public Class<? extends AbstractKit> getTypeFromKit(IKit iKit) {
        switch(iKit.getKitKey()){
            case "miner":return MinerKit.class;
            case "archer":return ArcherKit.class;
            case "guerrier":return GuerrierKit.class;
            case "enchanter":return EnchanterKit.class;
            default: return null;
        }
    }
}
