package fr.unitale.games.fk.map;

import fr.unitale.games.fk.map.types.Aandovale1vs1vs1;
import fr.unitale.games.fk.map.types.AngelVsDemon;
import fr.unitale.games.fk.map.types.Candy1vs1vs1vs1;
import fr.unitale.games.fk.map.types.Nordique;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;

public class FKMapType extends MapType {

    private String schematicName;

    public static final FKMapType FK_ANGEL_VS_DEMON = new FKMapType("FK_ANGEL_VS_DEMON", "angel_vs_demon", AngelVsDemon.class, "game.fk.map.angel_vs_demon.name", "angelvsdemon");
    public static final FKMapType FK_AANDOVALE_1VS1VS1 = new FKMapType("FK_AANDOVALE_1VS1VS1", "aandovale_1vs1vs1", Aandovale1vs1vs1.class, "game.fk.map.aandovale_1vs1vs1.name", "aandovale");
    public static final FKMapType FK_CANDY_1VS1VS1VS1 = new FKMapType("FK_CANDY_1VS1VS1VS1", "candy_1vs1vs1vs1", Candy1vs1vs1vs1.class, "game.fk.map.candy_1vs1vs1vs1.name", "candy");
    public static final FKMapType FK_NORDIQUE = new FKMapType("FK_NORDIQUE", "nordique", Nordique.class, "game.fk.map.nordique.name", "nordique");

    protected FKMapType(String key, String name, Class<? extends GameMap> clazz, String publicName, String schematicName) {
        super(key, name, clazz, publicName);
        this.schematicName = schematicName;
    }

    public static FKMapType[] values() {
        return new FKMapType[]{
                FK_ANGEL_VS_DEMON,
                FK_AANDOVALE_1VS1VS1,
                FK_CANDY_1VS1VS1VS1,
                FK_NORDIQUE
        };
    }

    public String getSchematicName() {
        return schematicName;
    }

    @Override
    public boolean shouldDeleteMapWhenUnloading() {
        return true;
    }
}
