package fr.unitale.games.fk.utils.upgrade.fall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class FallUpgrade1 extends FallUpgrade {

    public FallUpgrade1(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 1;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeFall(player, 3);
    }
}
