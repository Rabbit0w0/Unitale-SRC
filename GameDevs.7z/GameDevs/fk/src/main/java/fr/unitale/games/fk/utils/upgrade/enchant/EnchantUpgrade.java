package fr.unitale.games.fk.utils.upgrade.enchant;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;

public abstract class EnchantUpgrade implements IUpgrade {

    FkTeam team;

    public EnchantUpgrade(FkTeam team){
        this.team = team;
    }

    public boolean generateEnchant(UniPlayer player, int layers){
        if(team.isUpgradingEnchant()){
            player.sendMessage(Lang.str(player, "game.fk."));
        }

        Bukkit.getScheduler().runTask(GameSDK2.getInstance(), () -> {
            team.setUpgradingEnchant(true);
            Location enchantTableLoc = team.getBase().getCenter().clone();
            enchantTableLoc.add(6, 0, -6);
            for(int y = 0 ; y <= layers ; y++){
                for(int x = -2 ; x <= 2 ; x++){
                    for(int z = -2 ; z <= 2 ; z++){
                        if(Math.abs(x) == 2 || Math.abs(z) == 2){

                            Location _loc = enchantTableLoc.clone();
                            _loc.add(x,y,z);
                            _loc.getBlock().setType(Material.BOOKSHELF);
                        }
                    }
                }
            }
            enchantTableLoc.getBlock().setType(Material.ENCHANTMENT_TABLE);
            team.setUpgradingEnchant(false);
        });
        return true;
    }
}
