package fr.unitale.games.fk;

import java.util.List;
import java.util.stream.Collectors;

import org.bukkit.plugin.java.JavaPlugin;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.game.FkInstanceType;
import fr.unitale.games.fk.game.listeners.FkGlobalListeners;
import fr.unitale.games.fk.kit.FkKitProvider;
import fr.unitale.games.fk.map.FKMapType;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.features.fallenkingdoms.FKKitType;
import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.instance.Instance;
import fr.unitale.sdk.game2.instance.InstanceType;
import fr.unitale.sdk.game2.kit.KitManager;
import fr.unitale.sdk.game2.room.PassingRoom;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.utils.chat.UniLogger;

public class Wrapper extends JavaPlugin {

    @Override
    public void onEnable() {
        UniLogger.info("FK Wrapper launched !");
        
        //set gameplay
        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);

        //setup kits
        KitManager.setupKit(new FkKitProvider(), FKKitType.values());

        //register global listeners
        GameSDK2.register(new FkGlobalListeners());

        //init instance factory
        Engine<FkInstance> engine = new Engine<FkInstance>(this, new FkInstanceType(), new PassingRoom()) {
        	
        	@Override
            public List<Instance<FkInstance>> getInstances(InstanceType instanceType) {
        	FkInstanceType type = (FkInstanceType) instanceType;
			return getInstances().stream()
					.filter(instance -> type.getMode() == instance.getServerMode() && ((FkInstance) instance).getTeamSize() == type.getSize())
					.collect(Collectors.toList());
        	}
        };

        //add all factory
        //Arrays.stream(FKMapType.values()).forEach(m -> engine.addFactory(new FkInstanceType(m), f -> new FkInstance(engine, m)));

        //pour les tests en local
        engine.addFactory(new FkInstanceType(
        		FKMapType.FK_NORDIQUE,
        		1,
        		ServerTypes.ServerMode.NORMAL
        ), f -> new FkInstance(
        		engine,
        		FKMapType.FK_NORDIQUE,
        		1,
        		ServerTypes.ServerMode.NORMAL
        ));
        
        /*Arrays.stream(FKMapType.values()).forEach(type -> IntStream.range(1, 4).forEach(i -> {
        	engine.addFactory(new FkInstanceType(FKMapType.FK_NORDIQUE, 15, ServerTypes.ServerMode.NORMAL), f -> new FkInstance(engine, FKMapType.FK_NORDIQUE, 1, ServerTypes.ServerMode.NORMAL));
        }));*/
        
        //start the engine
        GameSDK2.startEngine(engine);
    }
}