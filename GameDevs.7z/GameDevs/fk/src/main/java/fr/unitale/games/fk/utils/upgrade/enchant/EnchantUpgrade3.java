package fr.unitale.games.fk.utils.upgrade.enchant;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class EnchantUpgrade3 extends EnchantUpgrade{

    public EnchantUpgrade3(FkTeam team){
        super(team);
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return generateEnchant(player, 3);
    }
}
