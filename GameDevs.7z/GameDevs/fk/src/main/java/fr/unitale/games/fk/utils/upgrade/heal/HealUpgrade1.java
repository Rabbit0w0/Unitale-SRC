package fr.unitale.games.fk.utils.upgrade.heal;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class HealUpgrade1 extends HealUpgrade {

    public HealUpgrade1(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 1;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeHeal(player, 1);
    }
}
