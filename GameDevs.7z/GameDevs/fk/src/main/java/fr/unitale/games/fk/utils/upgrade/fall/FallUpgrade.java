package fr.unitale.games.fk.utils.upgrade.fall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;

public abstract class FallUpgrade implements IUpgrade {

    private static final int FALL_RADIUS = 14;
    private static final int FALL_DEEP = 3;

    FkTeam team;

    public FallUpgrade(FkTeam team){
        this.team = team;
    }

    public boolean upgradeFall(UniPlayer player, int thickness){
        if(team.isUpgradingFalls()){
            player.sendMessage(Lang.str(player, "game.fk.upgrade.fall.already"));
            return false;
        }
        
        
        Bukkit.getScheduler().runTask(GameSDK2.getInstance(), () -> {
            team.setUpgradingFalls(true);
            int minX = team.getBase().getCenter().getBlockX()-FALL_RADIUS-thickness;
            int maxX = team.getBase().getCenter().getBlockX()+FALL_RADIUS+thickness;
            int minY = team.getBase().getCenter().getBlockY()-FALL_DEEP;
            int maxY = team.getBase().getCenter().getBlockY();
            int minZ = team.getBase().getCenter().getBlockZ()-FALL_RADIUS-thickness;
            int maxZ = team.getBase().getCenter().getBlockZ()+FALL_RADIUS+thickness;

            for(int x = minX; x <= maxX ; x++){
                for(int z = minZ; z <= maxZ ; z++){
                    for(int y = minY; y <= maxY ; y++){
                        if((x <= minX+thickness && x >= maxX-thickness) || (z <= minZ+thickness && z >= maxZ-thickness)){
                            Location _loc = team.getBase().getCenter().clone();
                            _loc.add(x,y,z);
                            _loc.getBlock().setType(Material.AIR);
                        }
                    }
                }
            }
            team.setUpgradingFalls(false);
        });
        return true;
    }
}
