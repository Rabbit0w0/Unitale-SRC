package fr.unitale.games.fk.utils.upgrade.wall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.ui.panel.FkPanel;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Material;

public class WallUpgrade1 extends WallUpgrade{

    public WallUpgrade1(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 1;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeWall(player, 10, 1, Material.STAINED_CLAY);
    }
}
