package fr.unitale.games.fk.ui.panel;

import fr.unitale.games.fk.ui.FkWindow;
import fr.unitale.sdk.ui.elements.UIPanel;

public abstract class FkPanel extends UIPanel {

    public FkPanel(int size, String title) {
        super(size, title);
    }

    @Override
    public FkWindow getWindow() {
        return (FkWindow)super.getWindow();
    }

    public abstract void update();
}
