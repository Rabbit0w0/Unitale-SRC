package fr.unitale.games.fk.ui.panel;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.ui.FkPanelType;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.games.fk.utils.upgrade.Upgrades;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.ui.elements.UIButton;
import fr.unitale.sdk.ui.elements.UIFormHandler;
import fr.unitale.sdk.ui.elements.UISorter;
import fr.unitale.sdk.ui.elements.sorters.RoundSortPattern;
import org.bukkit.entity.Player;

import java.util.Arrays;

/**
 * Upgrade panel to upgrade team's data
 */
public class UpgradePanel extends FkPanel implements UIFormHandler<Upgrades>{

    UISorter sorter;

    public UpgradePanel(UniPlayer player) {
        super(54, Lang.str(player, FkPanelType.BUILDER.getName()));

        sorter = new UISorter(new RoundSortPattern());

        FkTeam team = GameSDK2.getInstance(player).getTeamModule(FkTeam.class).getTeamOf(player);
        Arrays.stream(Upgrades.values())
                .filter(upgrade -> !upgrade.has(team))
                .forEach(upgrade -> sorter.add(new UIButton<>(upgrade, upgrade.getStack(player))));
    }

    @Override
    protected void onDisplayed() {
        super.onDisplayed();
        sorter.render(this);
    }

    @Override
    public void update() {
        sorter.clear();
        getWindow().getDisplay().clear();
        FkTeam team = GameSDK2.getInstance(getWindow().getPlayer()).getTeamModule(FkTeam.class).getTeamOf(getWindow().getPlayer());
        Arrays.stream(Upgrades.values())
                .filter(upgrade -> !upgrade.has(team))
                .forEach(upgrade -> sorter.add(new UIButton<>(upgrade, upgrade.getStack(getWindow().getPlayer()))));
        sorter.render(this);
    }

    @Override
    public void onSubmit(Player player, Upgrades upgrades) {
        int playerMoney = ((UniPlayer)player).getStorage().getInteger(FkInstance.PLAYER_MONEY_KEY);

        if(upgrades.getPrice() <= playerMoney){//can afford
            FkTeam team = GameSDK2.getInstance(player).getTeamModule(FkTeam.class).getTeamOf(player);
            ((UniPlayer) player).getStorage().addInteger(FkInstance.PLAYER_MONEY_KEY, playerMoney - upgrades.getPrice());
            //upgrade
            IUpgrade up = upgrades.createInstance(team);
            up.upgrade((UniPlayer) player);
            //acquire upgrade
            team.getAcquiredUpgrades().add(upgrades);
            //update panel
            update();
        }else{
            player.sendMessage(Lang.str(player, "game.fk.money.cantafford"));
        }
    }
}
