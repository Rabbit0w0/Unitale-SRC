package fr.unitale.games.fk.utils.upgrade.regen;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class RegenUpgrade1 extends RegenUpgrade {

    public RegenUpgrade1(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 1;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeRegen(player, 3);
    }
}
