package fr.unitale.games.fk.utils.upgrade.wall;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.FallingBlock;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class WallUpgrade implements IUpgrade {

	private FkTeam team;

	public WallUpgrade(FkTeam team) {
		this.team = team;
	}

	public FkTeam getTeam() {
		return team;
	}

	@SuppressWarnings("deprecation")
	protected boolean upgradeWall(UniPlayer player, int radius, int thickness, Material material) {
		if (team.isUpgradingWalls()) {
			player.sendMessage(Lang.str(player, "game.fk.upgrade.wall.already"));
			return false;
		}

		byte color = 0;
		if (material == org.bukkit.Material.STAINED_CLAY)
			color = getTeam().getColor().getWoolByte();

		team.setUpgradingWalls(true);
		team.setTaskWall(Bukkit.getScheduler().scheduleAsyncRepeatingTask(GameSDK2.getInstance(),
				new FallingBlockThread(team, radius, material, color), 0l, 4l));
		team.setUpgradingWalls(false);
		return true;
	}

	private class FallingBlockThread extends BukkitRunnable {

		private FkTeam team;
		private int radius;
		private Material material;
		private byte color;
		private List<Block> queue;
		private Iterator<Block> queueIterator;

		public FallingBlockThread(FkTeam team, int radius, Material material, byte color) {
			this.team = team;
			this.radius = radius;
			this.material = material;
			this.color = color;
			this.queue = new ArrayList<>();
			computeListAndCleanWalls();
		}

		/**
		 * Compute the list of blocks to update Cleans walls replacing by air
		 */
		private void computeListAndCleanWalls() {
			int minX = (int) team.getBase().getCenter().getX() - radius;
			int maxX = (int) team.getBase().getCenter().getX() + radius;
			int minZ = (int) team.getBase().getCenter().getZ() - radius;
			int maxZ = (int) team.getBase().getCenter().getZ() + radius;

			for (int x = minX; x <= maxX; x++) {
				for (int z = minZ; z <= maxZ; z++) {
					for (int y = (int) team.getBase().getCenter().getY(); y <= (team.getBase().getCenter().getY()
							+ 6); y++) {
						if (x == minX || x == maxX || z == minZ || z == maxZ) {
							Block b2 = team.getBase().getCenter().getWorld().getBlockAt(x, y + 6, z);
							Block b = team.getBase().getCenter().getWorld().getBlockAt(x, y - 3, z);
							b2.setType(Material.AIR);
							b.setType(Material.AIR);
							queue.add(b2);
						}
					}
				}
			}
			queueIterator = queue.listIterator();
		}

		@Override
		public void run() {
			// if queue is at end
			if (!queueIterator.hasNext()) {
				// cancel task
                Bukkit.getScheduler().cancelTask(team.getTaskCore());
				return;
			}
			// get the current entry
			Block block = queueIterator.next();
			Location loc = block.getLocation();
			Bukkit.getScheduler().runTask(GameSDK2.getInstance(), () -> {

				FallingBlock fb = loc.getWorld().spawnFallingBlock(loc.add(0.5, 5, 0.5), material, color);
				fb.setDropItem(false);
			});
		}
	}
}
