package fr.unitale.games.fk.map;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.game2.map.GameMap;
import fr.unitale.sdk.game2.map.MapType;
import fr.unitale.sdk.utils.color.UniColor;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public abstract class FKMap extends GameMap {

    private int teamSize;
    private int teamCount;
    private List<Location> spawns;
    private final Location waitingRoom;

    /**
     * Represents a Fk map,
     *
     * @param type      {@link MapType} type of the map
     * @param name      {@link String} map name
     * @param world     {@link World} in which the map create
     * @param teamSize  {@link Integer} size of the team to create
     * @param teamCount {@link Integer}amount of team to create
     * @param spawns    {@link Location}[] spawn locations for teams
     */
    public FKMap(MapType type, String name, World world, int teamSize, int teamCount, Location waitingRoom, Location... spawns) {
        super(type, name, world);
        this.teamCount = teamCount;
        this.teamSize = teamSize;
        this.waitingRoom = waitingRoom;
        this.spawns = Arrays.asList(spawns);
    }

    public int getTeamCount() {
        return teamCount;
    }

    public int getTeamSize() {
        return teamSize;
    }

    public List<Location> getSpawns() {
        return spawns;
    }

    public void generateTeams(FkInstance instance) {
        IntStream.range(0, teamCount).mapToObj(i -> new FkTeam(
                instance,
                defaultNameFromId(i),
                defaultColorFromId(i),
                teamSize,
                spawns.get(i))
        ).forEach(team -> instance.getTeamModule(FkTeam.class).addTeam(team));
    }

    public Location getWaitingRoomLocation() {
        return waitingRoom;
    }

    public abstract String defaultNameFromId(int id);

    public abstract UniColor defaultColorFromId(int id);

}
