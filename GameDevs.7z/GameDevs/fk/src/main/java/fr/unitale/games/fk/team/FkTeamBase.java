package fr.unitale.games.fk.team;

import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.area.Cuboid;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;

import java.util.UUID;

public class FkTeamBase extends Cuboid {

    private FkTeam owner;

    /**
     * Represent a team base as an {@link fr.unitale.sdk.utils.area.Area} to register
     *
     * @param owner  {@link FkTeam} owner of this base
     * @param center {@link Location} center of the base
     * @param size   {@link Vector} size of the base from center in block unit
     */
    public FkTeamBase(FkTeam owner, Location center, Vector size) {
        //set cuboid name to team name and add a random UUID
        super(owner.getName() + "-" + UUID.randomUUID().toString(), center, size.getX(), size.getY(), size.getZ());
        this.owner = owner;
    }

    public FkTeam getOwner() {
        return owner;
    }

    /**
     * Spawn a 5*5*4 bedrock based platform
     */
    public void spawnPlatform() {
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                for (int y = -1; y <= 6; y++) {
                    Location _loc = getCenter().clone();
                    _loc.add(x, y, z);
                    Material replace;
                    if (y == -1) {
                        replace = Material.BEDROCK;
                    } else {
                        replace = Material.AIR;
                    }
                    _loc.getBlock().setType(replace);
                }
            }
        }
        
        final int x = (int) (this.center.getBlockX() - this.xSize / 2);
        final int y = (int) this.center.getBlockY();
        final int z = (int) (this.center.getBlockZ() - this.zSize / 2);
        Block b;
        for (int i = 0; i < this.xSize; i++) {
			for (int k = 0; k < this.zSize; k++) {
				if (i == 0 || i == this.xSize-1 || k == 0 || k == this.zSize-1) {					
					b = this.center.getWorld().getBlockAt(x + i, y, z + k);
					b.setType(Material.COBBLESTONE);
				}
			}
		}
    }

    @Override
    public void moveIn(UniPlayer p) {
        if(owner.contains(p)){
            p.sendMessage(Lang.str(p, "game.fk.base.own.enter"));
        }else {
            p.sendMessage(Lang.str(p, "game.fk.base.other.enter", owner.getColor().getChatColor()+owner.getName()));
        }
    }

    @Override
    public void moveOut(UniPlayer p) {
        if(owner.contains(p)){
            p.sendMessage(Lang.str(p, "game.fk.base.own.exit"));
        }else {
            p.sendMessage(Lang.str(p, "game.fk.base.other.exit", owner.getColor().getChatColor()+owner.getName()));
        }
    }
}
