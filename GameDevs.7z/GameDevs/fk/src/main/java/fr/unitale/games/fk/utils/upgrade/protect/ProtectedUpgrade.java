package fr.unitale.games.fk.utils.upgrade.protect;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.games.fk.utils.upgrade.IUpgrade;
import fr.unitale.sdk.players.UniPlayer;

public abstract class ProtectedUpgrade implements IUpgrade {

    FkTeam team;

    public ProtectedUpgrade(FkTeam team){
        this.team = team;
    }

    public boolean upgradeProtected(UniPlayer player, int thickness){
		return false;    	
    }
}
