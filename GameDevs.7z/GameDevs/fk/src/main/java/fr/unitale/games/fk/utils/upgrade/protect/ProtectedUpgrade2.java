package fr.unitale.games.fk.utils.upgrade.protect;

import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.players.UniPlayer;

public class ProtectedUpgrade2 extends ProtectedUpgrade {

    public ProtectedUpgrade2(FkTeam team) {
        super(team);
    }

    @Override
    public int getLevel() {
        return 1;
    }

    @Override
    public boolean upgrade(UniPlayer player) {
        return upgradeProtected(player, 3);
    }
}
