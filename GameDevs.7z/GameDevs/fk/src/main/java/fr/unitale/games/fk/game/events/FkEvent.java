package fr.unitale.games.fk.game.events;

import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_10_R1.CraftWorld;

import fr.unitale.sdk.game2.Engine;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.color.UniColor;

public class FkEvent {
	
	private final net.minecraft.server.v1_10_R1.World w;
	private final int x;
	private final int z;
	private final int y;
	private Engine engine;
	private UniPlayer player;	
	
	public FkEvent() {
		//GameSDK2.getEngine().get
		w = ((CraftWorld) Bukkit.getWorld(Bukkit.getWorlds().get(0).getName())).getHandle();
		//x = engine.getInstance(player).getMap().
		x = 0;
		z = 0;
		y = 0;
		engine.getInstance(player).broadcast(UniColor.GREEN + "⚠⚠⚠ Event Mobs au centre de la map ⚠⚠⚠");
	}

}
