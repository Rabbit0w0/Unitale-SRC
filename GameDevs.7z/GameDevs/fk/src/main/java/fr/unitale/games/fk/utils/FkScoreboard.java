package fr.unitale.games.fk.utils;

import fr.unitale.games.fk.game.FkInstance;
import fr.unitale.games.fk.game.listeners.FkGameInstance;
import fr.unitale.games.fk.objectives.Objective;
import fr.unitale.games.fk.team.FkTeam;
import fr.unitale.sdk.game2.GameSDK2;
import fr.unitale.sdk.game2.module.team.TeamModule;
import fr.unitale.sdk.game2.module.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.utils.chat.ChatUtils;
import org.bukkit.ChatColor;
import org.bukkit.scoreboard.DisplaySlot;

public class FkScoreboard extends UniScoreboard{

    UniPlayer owner;

    public FkScoreboard(UniPlayer owner){
        this.owner = owner;
        init();
    }

    private void init(){
        int i = 0;
        createSideBoard(ChatColor.YELLOW+"FallenKingdom");

        FkInstance instance = (FkInstance) GameSDK2.getInstance(owner);
        FkGameInstance gameModule = instance.getListener(FkGameInstance.class);

        addScore("day_timer", Lang.str(owner, "game.fk.scoreboard.day", ""+gameModule.getCurrentDay()) + ChatColor.GRAY + " | " + ChatColor.GREEN + gameModule.getTimer().getITime(), i++, DisplaySlot.SIDEBAR);
        addScore("space_1", " ", i++, DisplaySlot.SIDEBAR);

        
        final TeamModule<FkInstance, UniTeam> tm = new TeamModule<>(instance);
        for(int j = 0 ; j < tm.getTeams().size() ; j++){
            FkTeam team = (FkTeam) tm.getTeams().get(j);
            String dir = ChatUtils.getDirectionLocation(owner.getLocation(), team.getBase().getCenter());
            int dist = (int) owner.getLocation().distance(team.getBase().getCenter());
            if(team.contains(owner)){
                addScore("team_"+j, Lang.str(owner, "game.fk.scoreboard.team.own", dir, ""+dist), i++, DisplaySlot.SIDEBAR);
            }else{
                addScore("team_"+j, Lang.str(owner, "game.fk.scoreboard.team.other", team.getColor().getChatColor()+team.getName(), dir, ""+dist), i++, DisplaySlot.SIDEBAR);
            }
        }

        addScore("space_2", "  ", i++, DisplaySlot.SIDEBAR);
        addScore("pvp", Lang.str(owner, ChatColor.RED + "game.fk.scoreboard.pvp", gameModule.getCurrentDay() >= 2 ? Lang.str(owner, ChatColor.GREEN + "game.fk.scoreboard.activated") : Lang.str(owner, "game.fk.scoreboard.day", ""+2)), i++, DisplaySlot.SIDEBAR);
        addScore("assault", Lang.str(owner, ChatColor.RED + "game.fk.scoreboard.assault", gameModule.getCurrentDay() >= 2 ? Lang.str(owner, ChatColor.GREEN + "game.fk.scoreboard.activated") : Lang.str(owner, "game.fk.scoreboard.day", ""+2)), i++, DisplaySlot.SIDEBAR);

        addScore("space_3", "   ", i++, DisplaySlot.SIDEBAR);
        addScore("gold_display", Lang.str(owner, "game.fk.scoreboard.gold.display"), i++, DisplaySlot.SIDEBAR);
        addScore("gold", Lang.str(owner, "game.fk.scoreboard.gold", ""+owner.getStorage().getInteger(FkInstance.PLAYER_MONEY_KEY, 0)), i++, DisplaySlot.SIDEBAR);

        addScore("space_4", "    ", i++, DisplaySlot.SIDEBAR);
        addScore("objectives_display", Lang.str(owner, "game.fk.scoreboard.objectives.display"), i++, DisplaySlot.SIDEBAR);
        addScore("objective", computeObjectiveName(instance.getTeamModule(FkTeam.class).getTeamOf(owner)), i++, DisplaySlot.SIDEBAR);
        
        addScore("space_5", "     ", i++, DisplaySlot.SIDEBAR);
        addScore("play_unitale", (ChatColor.YELLOW + "‣ play.unitale.fr"), i++, DisplaySlot.SIDEBAR);
    }

    public void update(){
        FkInstance instance = (FkInstance) GameSDK2.getInstance(owner);
        FkGameInstance gameModule = instance.getListener(FkGameInstance.class);

        getScore("day_timer").setData(Lang.str(owner, "game.fk.scoreboard.day", ""+gameModule.getCurrentDay()) + ChatColor.GRAY + " | " + ChatColor.GREEN + gameModule.getTimer().getITime());
        final TeamModule<FkInstance, UniTeam> tm = new TeamModule<>(instance);
        for(int j = 0 ; j < tm.getTeams().size() ; j++){
            FkTeam team = (FkTeam) tm.getTeams().get(j);
            String dir = ChatUtils.getDirectionLocation(owner.getLocation(), team.getBase().getCenter());
            int dist = (int) owner.getLocation().distance(team.getBase().getCenter());
            if(team.contains(owner)){
                getScore("team_"+j).setData(Lang.str(owner, "game.fk.scoreboard.team.own", dir, ""+dist));
            }else{
                getScore("team_"+j).setData(Lang.str(owner, "game.fk.scoreboard.team.other", team.getColor().getChatColor()+team.getName(), dir, ""+dist));
            }
        }
        getScore("pvp").setData(Lang.str(owner, ChatColor.RED + "game.fk.scoreboard.pvp", gameModule.getCurrentDay() >= 2 ? Lang.str(owner, ChatColor.GREEN + "game.fk.scoreboard.activated") : Lang.str(owner, "game.fk.scoreboard.day", ""+2)));
        getScore("assault").setData(Lang.str(owner, ChatColor.RED + "game.fk.scoreboard.assault", gameModule.getCurrentDay() >= 2 ? Lang.str(owner, ChatColor.GREEN + "game.fk.scoreboard.activated") : Lang.str(owner, "game.fk.scoreboard.day", ""+2)));
        
        ((UniPlayer)owner).getStorage().addInteger(FkInstance.PLAYER_MONEY_KEY, owner.getStorage().getInteger(FkInstance.PLAYER_MONEY_KEY,0)+1);
        getScore("gold").setData(Lang.str(owner, "game.fk.scoreboard.gold", ""+owner.getStorage().getInteger(FkInstance.PLAYER_MONEY_KEY,0)));        
    }

    private String computeObjectiveName(FkTeam team){
        Objective obj = team.getObjectiveHandler().getCurrentObjective();
        return obj != null ?
                Lang.str(owner, "game.fk.scoreboard.objective", obj.getName(owner))
                :
                Lang.str(owner, "game.fk.scoreboard.assault.possible");
    }


}
