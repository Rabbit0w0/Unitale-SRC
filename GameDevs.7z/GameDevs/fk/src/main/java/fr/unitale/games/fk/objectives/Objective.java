package fr.unitale.games.fk.objectives;

import fr.unitale.sdk.players.UniPlayer;

public class Objective {

    private ObjectiveType type;
    private int amount, needed;
    private Object object;
    private Objective last;
    private Objective next;

    /**
     * {
     * "type" : "KILL",
     * "needed" : "5",
     * "object" : "SPIDER"
     * }
     *
     * @param type   {@link ObjectiveType}
     * @param needed {@link int}
     * @param object {@link Enum}
     * @param last   {@link Objective}
     * @param next   {@link Objective}
     */
    public Objective(ObjectiveType type, int needed, Object object, Objective last, Objective next) {
        this.type = type;
        this.amount = 0;
        this.needed = needed;
        this.object = object;
        this.last = last;
        this.next = next;
    }

    public ObjectiveType getType() {
        return type;
    }

    public Object getObject() {
        return object;
    }

    public void increment(int amount) {
        this.amount += amount;
    }

    public boolean isComplete() {
        return amount >= needed;
    }

    public Objective getNext() {
        return next;
    }

    public void setNext(Objective object) {
        this.next = object;
    }

    public String getName(UniPlayer player){
        //TODO
        return "";
    }
}
