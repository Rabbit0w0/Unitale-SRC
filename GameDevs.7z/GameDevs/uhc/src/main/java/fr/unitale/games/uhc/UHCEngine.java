package fr.unitale.games.uhc;

import fr.unitale.api.type.MoneyType;
import fr.unitale.api.type.ServerTypes;
import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.ServerMode;
import fr.unitale.games.uhc.commands.ScenarioCommand;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.kit.UHCKitProvider;
import fr.unitale.games.uhc.modules.PhaseModule;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.games.uhc.modules.phases.deathmatch.DeathmatchPhase;
import fr.unitale.games.uhc.modules.phases.fight.FightPhase;
import fr.unitale.games.uhc.modules.phases.recolte.RecoltePhase;
import fr.unitale.games.uhc.modules.phases.reduction.ReductionPhase;
import fr.unitale.games.uhc.modules.scenarios.ScenarioManager;
import fr.unitale.games.uhc.stat.UHCPlayerStat;
import fr.unitale.games.uhc.utils.UHCTeamDispatcher;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.features.uhc.UHCRandomKitType;
import fr.unitale.sdk.features.uhc.UHCRunKitType;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.map.uhc.UHCMap;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.randomtp.RandomTPModule;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.wait.WaitingModule;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.gameengine.utils.kit.KitManager;
import fr.unitale.sdk.gameplay.GameplayAPI;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.lang.Locale;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.math.RandomUtils;
import fr.unitale.sdk.utils.resourcepack.ResourcePackType;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import net.minecraft.server.v1_10_R1.NBTCompressedStreamTools;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;

import java.io.IOException;

/**
 * UHC engine
 */
public class UHCEngine extends GameEngine<UHCMap> {

    public static final int CENTER_MAX_RANDOM = 100;

    private static UHCEngine _instance; //singleton instance

    private PhaseModule phaseModule; //the phase Manager
    private GameplayType gameplay; //type of gameplay
    private Location mapCenter; //location of the highest block at center
    private ScenarioManager scenarioManager;
    private boolean isRanked; // TODO utiliser le ServerMode à la place

    public UHCEngine(JavaPlugin plugin, String json) {
        super(plugin, json);

        if (_instance == null) _instance = this;

        try {
            Schematic s = SchematicAPI.loadSchematic(NBTCompressedStreamTools.a(Wrapper.class.getResourceAsStream("spawn.schematic")));
            //define the game map object
            gameMap = new UHCMap(getConfig("teamcount", 16), s, RandomUtils.nextInt(-CENTER_MAX_RANDOM, CENTER_MAX_RANDOM), RandomUtils.nextInt(-CENTER_MAX_RANDOM, CENTER_MAX_RANDOM));
        } catch (IOException e) {
            e.printStackTrace();
        }

        new ScenarioCommand().register();
        scenarioManager = new ScenarioManager();

        setServerMode(ServerMode.NORMAL);
        setGameStatus(GameStatus.WAIT);
        //set gameplay from config or default to normal
        gameplay = GameplayType.valueOf(getConfig("gameplay", GameplayType.NORMAL.name()));
        ServerManager.type = gameplay.getServerType();

        UnitaleSDK.getAPI(GameplayAPI.class).setGameplay(GameplayAPI.V1_8);

        //mode is defined in GameEngine as a config parameter
        UniLogger.info("UHC plugin started with mode = " + mode + " and gameplay = " + gameplay);

        setKeepOffline(true);//keep player data offline
        getModuleManager().clear();//clear all active modules

        DropModule dm = new DropModule();
        getModuleManager().addModule(dm, true);

        gameplay.getGameplay().preInit(); //init the gameplay
        gameMap.buildMap(getConfig("start.bordersize", 1000), gameplay == GameplayType.RUN, !getConfig("dev", false), false);
        gameplay.getGameplay().postInit();

        if (gameplay == GameplayType.RANDOM) {
            int enchantAmount = RandomUtils.nextInt(3) + 1;
            int enchantLevel = RandomUtils.nextInt(3) + 1;
            dm.setEnchantAmount(() -> enchantAmount);
            dm.setEnchantLevel(() -> enchantLevel);
        }
        TeamModule<UniTeam> tm = new TeamModule<>(UniTeam.class);
        tm.setDispatcher(new UHCTeamDispatcher(tm));
        getModuleManager().addModule(tm, true);

        WeatherAPI.setTime(TimeSet.DAWN);
        WeatherAPI.disableTime();

        mapCenter = new Location(gameMap.getWorld(), gameMap.getCenterX(), gameMap.getCenterY(), gameMap.getCenterZ());
        getModuleManager().addModule(new RandomTPModule(gameMap.getWorld()), true);

        KitManager.setupKit(new UHCKitProvider(), getKitFromGameplay(gameplay));

        WaitingModule wm = new WaitingModule(PhaseModule.class); //create wait module starting phaseModule
        wm.setMinPlayers(mode == ServerTypes.Mode.TEAM ? 24 : 20);
        wm.setVoteStartByPlayers(() -> false);

        phaseModule = new PhaseModule();
        phaseModule.setDuration(PhaseType.RECOLTE, getConfig("start.phaseduration.recolte", RecoltePhase.DEFAULT_RECOLTE_DURATION));
        phaseModule.setDuration(PhaseType.FIGHT, getConfig("start.phaseduration.fight", FightPhase.DEFAULT_FIGHT_DURATION));
        phaseModule.setDuration(PhaseType.REDUCTION, getConfig("start.phaseduration.reduction", ReductionPhase.DEFAULT_REDUCTION_DURATION));
        phaseModule.setDuration(PhaseType.DEATHMATCH, getConfig("start.phaseduration.deathmatch", DeathmatchPhase.DEFAULT_DEATHMATCH_DURATION));
        getModuleManager().addModule(phaseModule); //add the phase module but don't start it
        getModuleManager().addModule(wm, true);//add and load the waiting module

        wm.getBoard().setObjectiveTitle(Lang.str(Locale.fr_FR, gameplay.getTitle()), DisplaySlot.SIDEBAR);

        //declare money value for each actions
        PlayerGameStat.VICTORY.setMoney(MoneyType.GOLD, 30);
        PlayerGameStat.VICTORY.setMoney(MoneyType.EMERALDS, 3);
        PlayerGameStat.KILL.setMoney(MoneyType.GOLD, 10);
        UHCPlayerStat.SURVIVE.setMoney(MoneyType.GOLD, 5);
    }

    public static UHCEngine getInstance() {
        return _instance;
    }

    public PhaseModule getPhaseModule() {
        return phaseModule;
    }

    public GameplayType getGameplay() {
        return gameplay;
    }

    public Location getMapCenter() {
        return mapCenter;
    }

    public ScenarioManager getScenarioManager() {
        return scenarioManager;
    }

    /**
     * @return the isRanked
     */
    public boolean isRanked() {
        return isRanked;
    }

    /**
     * @param isRanked the isRanked to set
     */
    public void setRanked(boolean isRanked) {
        this.isRanked = isRanked;
    }

    @Override
    protected void userJoin(UniPlayer player) {
        Bukkit.getScheduler().runTask(getPlugin(), () -> ResourcePackType.HUB.send(player));
        if (getGameStatus().equals(GameStatus.WAIT)) player.teleport(mapCenter);
        KitManager.loadFeatures(player, getKitFromGameplay(gameplay));
    }

    private static IKit[] getKitFromGameplay(GameplayType type) {
        switch (type) {
            case RUN:
                return UHCRunKitType.values();
            case RANDOM:
                return UHCRandomKitType.values();
            default:
                return new IKit[0];
        }
    }

    @Override
    protected void userSpectate(UniPlayer player) {
        player.setGameMode(GameMode.SPECTATOR);
    }
}
