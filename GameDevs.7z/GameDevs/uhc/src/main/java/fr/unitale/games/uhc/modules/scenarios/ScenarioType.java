package fr.unitale.games.uhc.modules.scenarios;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.bukkit.Material;

import fr.unitale.games.uhc.modules.scenarios.types.BugScenario;
import fr.unitale.games.uhc.modules.scenarios.types.CreeperManiaScenario;
import fr.unitale.games.uhc.modules.scenarios.types.DiamondLessScenario;
import fr.unitale.games.uhc.modules.scenarios.types.DoctorScenario;
import fr.unitale.games.uhc.modules.scenarios.types.DoubleHealthScenario;
import fr.unitale.games.uhc.modules.scenarios.types.FishingScenario;
import fr.unitale.games.uhc.modules.scenarios.types.FlashScenario;
import fr.unitale.games.uhc.modules.scenarios.types.GoldenDeathScenario;
import fr.unitale.games.uhc.modules.scenarios.types.HotScenario;
import fr.unitale.games.uhc.modules.scenarios.types.HotbarScenario;
import fr.unitale.games.uhc.modules.scenarios.types.LevelOneScenario;
import fr.unitale.games.uhc.modules.scenarios.types.LuckyBlockScenario;
import fr.unitale.games.uhc.modules.scenarios.types.NoBowScenario;
import fr.unitale.games.uhc.modules.scenarios.types.NoFallScenario;
import fr.unitale.games.uhc.modules.scenarios.types.SkyWarsScenario;
import fr.unitale.sdk.utils.items.UniItemSkull;
import fr.unitale.sdk.utils.items.UniItemStack;

public enum ScenarioType {
    DOCTOR(DoctorScenario.class, new UniItemStack(Material.POTION), "game.uhc.scenario.doctor"),
    NO_BOW(NoBowScenario.class, new UniItemStack(Material.BOW), "game.uhc.scenario.nobow"),
    HOT(HotScenario.class, new UniItemStack(Material.LAVA_BUCKET), "game.uhc.scenario.hot"),
    CREEPER_MANIA(CreeperManiaScenario.class, new UniItemSkull("MHF_Creeper"), "game.uhc.scenario.creepermania"),
    HOTBAR(HotbarScenario.class, new UniItemStack(Material.BARRIER), "game.uhc.scenario.hotbar"),
    DOUBLE_HEALTH(DoubleHealthScenario.class, new UniItemStack(Material.GOLDEN_APPLE), "game.uhc.scenario.doublehealth"),
    LEVEL_ONE(LevelOneScenario.class, new UniItemStack(Material.EXP_BOTTLE), "game.uhc.scenario.levelone"),
    NO_FALL(NoFallScenario.class, new UniItemStack(Material.FEATHER), "game.uhc.scenario.nofall"),
    DIAMONDLESS(DiamondLessScenario.class, new UniItemStack(Material.DIAMOND), "game.uhc.scenario.diamondless"),
    FISHING(FishingScenario.class, new UniItemStack(Material.FISHING_ROD), "game.uhc.scenario.fishing"),
    SKYWARS(SkyWarsScenario.class, new UniItemStack(Material.FIREWORK), "game.uhc.scenario.skywars"),
    FLASH(FlashScenario.class, new UniItemStack(Material.REDSTONE), "game.uhc.scenario.flash"),
    BUG(BugScenario.class, new UniItemStack(Material.COMMAND), "game.uhc.scenario.bug"),
    GOLDENDEATH(GoldenDeathScenario.class, new UniItemStack(Material.GOLDEN_APPLE), "game.uhc.scenario.goldendeath"),
    LUCKYBLOCK(LuckyBlockScenario.class, new UniItemStack(Material.EMERALD_BLOCK), "game.uhc.scenario.luckyblock");

    /*
     * GOLD_DEATH -> gapple on player death -> "game.uhc.scenario.type.golddeath": "{{chatcolor.gold}}Têtes dorées",
     * IRON_AGE -> iron stuff max -> "game.uhc.scenario.type.ironage": "{{chatcolor.gray}}Âge de fer",
     * NO_ENCHANT -> self explaining -> "game.uhc.scenario.type.noenchants": "{{chatcolor.red}}Pas d'enchantements",
     * NO_FISH -> no fishing -> "game.uhc.scenario.type.nofish": "{{chatcolor.red}}Pas de pêche",
     * STONE_AGE -> stone and leather stuff max -> "game.uhc.scenario.type.stoneage": "{{chatcolor.dark_gray}}Âge de pierre",
     */

    private Class<? extends ScenarioModule> clazz;
    private UniItemStack icon;
    private String name;

    private ScenarioType(Class<? extends ScenarioModule> clazz, UniItemStack icon, String name) {
        this.clazz = clazz;
        this.icon = icon;
        this.name = name;
    }

    public Class<? extends ScenarioModule> getClazz() {
        return clazz;
    }

    public UniItemStack getIcon() {
        return icon;
    }

    public String getName() {
        return name;
    }

    public ScenarioModule newInstance() {
        if (clazz != null) {
            try {
                Constructor<? extends ScenarioModule> cons = clazz.getConstructor();
                return cons.newInstance();
            } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
