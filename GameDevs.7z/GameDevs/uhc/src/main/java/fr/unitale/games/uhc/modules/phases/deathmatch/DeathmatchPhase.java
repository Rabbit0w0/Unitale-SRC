package fr.unitale.games.uhc.modules.phases.deathmatch;

import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Location;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.modules.PhaseModule;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.math.RandomUtils;

public class DeathmatchPhase extends Phase {
    public static final int DEFAULT_DEATHMATCH_DURATION = 5; // 5 minutes in seconds
    private static final int CHANGING_TIME = 30, UPDATING_TIME = 1;
    private static final double MOVE_DISTANCE = 10.0;

    private Location oldLocation, newLocation;
    private double moveScale, moveScaleFactor;
    private int taskID;

    public DeathmatchPhase(Map<PhaseType, Integer> phaseDurations) {
        super(phaseDurations.get(PhaseType.DEATHMATCH), PhaseType.DEATHMATCH);
        this.moduleListener = new DeathmatchPhaseListener(this);
        this.moveScaleFactor = (double) CHANGING_TIME / (double) UPDATING_TIME;
    }

    @Override
    public void startModule() {
        super.startModule();
        oldLocation = UHCEngine.getInstance().getMapCenter().clone();
        newLocation = UHCEngine.getInstance().getMapCenter().clone();
        Lang.bcst("game.uhc.deathmatch.end");

        taskID = Bukkit.getScheduler().scheduleSyncRepeatingTask(UHCEngine.getInstance().getPlugin(), new Runnable() {
            @Override
            public void run() {
                GameEngine.getInstance().getOnlinePlayers().forEach(p -> {
                    p.damage(1);
                });
            }
        }, 0, 40);
    }

    @Override
    public void update() {
        PhaseModule.setTimerBoard("Fin du jeu", getTimer().getITime());
        PhaseModule.updatePlayersBoard();
        if (getTimer().getSeconds() % CHANGING_TIME == 0) {//every CHANGING_TIME seconds
            oldLocation = UHCEngine.getInstance().getMapCenter().clone();
            double angle = RandomUtils.nextDouble(0, 2 * Math.PI);
            double newX = oldLocation.getX() + Math.cos(angle) * MOVE_DISTANCE;
            double newZ = oldLocation.getZ() + Math.sin(angle) * MOVE_DISTANCE;
            newLocation = UHCEngine.getInstance().getMapCenter().clone();
            newLocation.setX(newX);
            newLocation.setZ(newZ);
            moveScale = 0;
            //EndLogger.info("Border will now be progressively moving towards "+newLocation.getX()+","+newLocation.getZ());
            return;
        }
        //every UPDATING_TIME seconds
        double distX = newLocation.getX() - oldLocation.getX();
        double distZ = newLocation.getZ() - oldLocation.getZ();
        double newX = oldLocation.getX() + (moveScale / moveScaleFactor) * distX;
        double newZ = oldLocation.getZ() + (moveScale / moveScaleFactor) * distZ;
        UHCEngine.getInstance().getMapCenter().setX(newX);
        UHCEngine.getInstance().getMapCenter().setZ(newZ);
        UHCEngine.getInstance().getMap().getWorld().getWorldBorder().setCenter(UHCEngine.getInstance().getMapCenter());
        moveScale++;
    }

    @Override
    public void endModule() {
        Lang.bcst("game.uhc.deathmatch.end.game");
        Bukkit.getScheduler().cancelTask(taskID);
        UHCEngine.getInstance().setGameStatus(GameStatus.END);
        UHCEngine.getInstance().endGame(TimeManager.second * 10);
    }
}
