package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerExpChangeEvent;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;

public final class LevelOneScenario extends ScenarioModule {

    public LevelOneScenario() {
        super(ScenarioType.LEVEL_ONE);
        moduleListener = new LevelOneScenarioListener(this);
    }

    @Override
    public void startModule() {
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> p.setExp(0));
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class LevelOneScenarioListener extends ScenarioModuleListener {

        public LevelOneScenarioListener(ScenarioModule module) {
            super(module);
        }

        @EventHandler
        public void onExp(PlayerExpChangeEvent ev) {
            if (ev.getPlayer().getLevel() > 1) {
                ev.getPlayer().setLevel(1);
            }
        }
    }
}
