package fr.unitale.games.uhc.modules.phases.fight;

import java.util.Map;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.PhaseModule;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.games.uhc.modules.phases.reduction.ReductionPhase;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;

public class FightPhase extends Phase {

    public static final int DEFAULT_FIGHT_DURATION = 30; //30 minutes
    private Map<PhaseType, Integer> phaseDurations;

    public FightPhase(Map<PhaseType, Integer> phaseDurations) {
        super(phaseDurations.get(PhaseType.FIGHT), PhaseType.FIGHT);
        this.moduleListener = new FightPhaseListener(this);
        this.phaseDurations = phaseDurations;
    }

    @Override
    public void startModule() {
        super.startModule();
        Lang.bcst("game.uhc.pvp");
    }

    @Override
    public void update() {
        PhaseModule.setTimerBoard(UHCEngine.getInstance().getGameplay().equals(GameplayType.NORMAL) ? "Réduction" : "Téléportation", getTimer().getITime());
        PhaseModule.updatePlayersBoard();
        if (getTimer().getMinutes() == 0 && getTimer().getSeconds() <= 5 && getTimer().getSeconds() != 0) {
            Lang.bcst("game.uhc.phase.reduction.start", "" + getTimer().getSeconds());
        }
    }

    @Override
    public void endModule() {
        //add the new phase and then start it
        GameEngine.getInstance().getModuleManager().addModule(new ReductionPhase(phaseDurations), true);
    }
}
