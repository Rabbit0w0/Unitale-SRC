package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.Material;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.utils.items.UniItemStack;

public final class HotScenario extends ScenarioModule {

    public HotScenario() {
        super(ScenarioType.HOT);
    }

    @Override
    public void startModule() {
        DropModule dm = UHCEngine.getInstance().getModuleManager().getModule(DropModule.class);
        dm.addConvertItem(ConvertType.DROP, Material.POTATO_ITEM, new UniItemStack(Material.BAKED_POTATO));
        dm.addConvertItem(ConvertType.DROP, Material.RAW_BEEF, new UniItemStack(Material.COOKED_BEEF));
        dm.addConvertItem(ConvertType.DROP, Material.RAW_CHICKEN, new UniItemStack(Material.COOKED_CHICKEN));
        dm.addConvertItem(ConvertType.DROP, Material.RAW_FISH, new UniItemStack(Material.COOKED_FISH));
        dm.addConvertItem(ConvertType.DROP, Material.MUTTON, new UniItemStack(Material.COOKED_MUTTON));
        dm.addConvertItem(ConvertType.DROP, Material.RABBIT, new UniItemStack(Material.COOKED_RABBIT));
        dm.addConvertItem(ConvertType.DROP, Material.PORK, new UniItemStack(Material.GRILLED_PORK));
        dm.addConvertItem(ConvertType.BLOCK, Material.IRON_ORE, new UniItemStack(Material.IRON_INGOT));
        dm.addConvertItem(ConvertType.BLOCK, Material.GOLD_ORE, new UniItemStack(Material.GOLD_INGOT));
    }

    @Override
    public void endModule() {
    }


    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return !type.equals(GameplayType.RUN);
    }
}
