package fr.unitale.games.uhc.modules.scenarios;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import fr.unitale.sdk.players.UniPlayerContainer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.json.simple.JSONArray;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.sdk.advancement.AdvancementAPI;
import fr.unitale.sdk.advancement.display.EndAdvancementFrameType;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.lang.Locale;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.ActionBar;
import fr.unitale.sdk.utils.chat.ActionBarManager;
import fr.unitale.sdk.utils.chat.UniLogger;

public class ScenarioManager {

    public static final int MAX_CHAR = 64, SCROLL_SPEED = 30;

    private EnumMap<ScenarioType, ScenarioModule> scenarios;
    private Map<Locale, ActionBar> scenarioBars;

    public ScenarioManager() {
        scenarios = new EnumMap<>(ScenarioType.class);
        JSONArray scenariosString = UHCEngine.getInstance().getConfig("scenarios", new JSONArray());
        UniLogger.info("loading scenarios... (" + scenariosString.size() + ")");
        for (Object o : scenariosString) {
            String scenario = (String) o;
            ScenarioType type = ScenarioType.valueOf(scenario);
            addScenario(type);
        }

        scenarioBars = new HashMap<>();
    }

    private String initScenarioString(Locale l) {
        return scenarios.keySet().stream()
                .map(t -> ChatColor.GOLD + Lang.str(l, t.getName()) + ChatColor.GRAY + " - ")
                .collect(Collectors.joining());
    }

    public void startAll() {
        for (ScenarioModule m : scenarios.values()) {
            UHCEngine.getInstance().getModuleManager().addModule(m, true);
            Bukkit.getOnlinePlayers().stream().map(p -> (UniPlayer) p).forEach(p -> {
                AdvancementAPI.throwFakeAdvancement(p, Lang.str(p, m.getType().getName()), EndAdvancementFrameType.TASK, m.getType().getIcon());
            });
        }
        UHCEngine.getInstance().getOnlinePlayers().stream()
                .map(UniPlayerContainer::getLocale)
                .distinct()
                .forEach(l -> {
                    ActionBar bar = ActionBarManager.getInstance().addActionBar("SCENARIOS_" + l.toString(), initScenarioString(l), true, true, MAX_CHAR, SCROLL_SPEED);
                    scenarioBars.put(l, bar);
                });
        ;
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> {
            scenarioBars.get(p.getLocale()).addPlayer(p);
        });
    }

    private void addScenario(ScenarioType t) {
        if (!scenarios.containsKey(t)) {
            ScenarioModule m = t.newInstance();
            if (m.isCompatibleWith(UHCEngine.getInstance().getGameplay())) {
                UniLogger.info("Adding scenario " + t);
                scenarios.put(t, m);
            } else {
                UniLogger.warning("Scenario " + t + " is not compatible with current gameplay");
            }
        }
    }

    public ScenarioModule getScenario(ScenarioType t) {
        return scenarios.getOrDefault(t, null);
    }

    public EnumMap<ScenarioType, ScenarioModule> getScenarios() {
        return scenarios;
    }
}
