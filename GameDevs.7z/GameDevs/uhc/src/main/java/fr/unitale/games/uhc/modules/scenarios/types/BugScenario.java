package fr.unitale.games.uhc.modules.scenarios.types;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemPotion;
import fr.unitale.sdk.utils.items.UniItemSkull;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.math.RandomUtils;
import net.minecraft.server.v1_10_R1.Item;

@SuppressWarnings("deprecation")
public final class BugScenario extends ScenarioModule {

    private static final double DEFAULT_SWITCH_PERCENT = 0.05;
    private static List<Material> forbidMaterial;
    private static List<Material> availableMaterials;

    static {
        forbidMaterial = new ArrayList<>();
        forbidMaterial.add(Material.BEDROCK);
        forbidMaterial.add(Material.MONSTER_EGG);
        forbidMaterial.add(Material.BARRIER);
        forbidMaterial.add(Material.END_GATEWAY);
        forbidMaterial.add(Material.ENDER_PORTAL);
        forbidMaterial.add(Material.ENDER_PORTAL_FRAME);
        forbidMaterial.add(Material.PORTAL);
        forbidMaterial.add(Material.COMMAND);
        forbidMaterial.add(Material.COMMAND_CHAIN);
        forbidMaterial.add(Material.COMMAND_MINECART);
        forbidMaterial.add(Material.COMMAND_REPEATING);
        forbidMaterial.addAll(Arrays.stream(Material.values()).filter(m -> Item.getById(m.getId()) == null).collect(Collectors.toList()));
    }

    public BugScenario() {
        super(ScenarioType.BUG);
        availableMaterials = Arrays.stream(Material.values()).filter(m -> !forbidMaterial.contains(m)).collect(Collectors.toList());
        moduleListener = new BugScenarioListener(this, getConfig("switchpercent", DEFAULT_SWITCH_PERCENT));
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return !type.equals(GameplayType.RANDOM);
    }

    private static final class BugScenarioListener extends ScenarioModuleListener {

        private double switchPercent;

        public BugScenarioListener(ScenarioModule module, double switchPercent) {
            super(module);
            this.switchPercent = switchPercent;
        }

        @EventHandler
        public void onBlockBreak(BlockBreakEvent ev) {
            UniItemStack eis = UniItemStack.fromItemStack(ev.getPlayer().getInventory().getItemInMainHand());
            if (eis == null) return;
            if (RandomUtils.nextFloat() > 1.0 - switchPercent) {
                UniItemStack newItem = randItem(eis, (UniPlayer) ev.getPlayer());
                ev.getPlayer().sendMessage(Lang.str(ev.getPlayer(), "game.uhc.scenario.bug.itemchanged"));
                ev.getPlayer().getInventory().setItemInMainHand(newItem);
            }
        }

        private UniItemStack randItem(UniItemStack old, UniPlayer ep) {
            Material m = availableMaterials.get(RandomUtils.nextInt(availableMaterials.size()));
            UniItemStack is;
            if (m == Material.POTION || m == Material.LINGERING_POTION || m == Material.SPLASH_POTION) {
                is = new UniItemPotion();
                int effectNb = RandomUtils.nextInt(1, 4);
                for (int i = 0; i < effectNb; i++) {
                    ((UniItemPotion) is).addEffect(new PotionEffect(PotionEffectType.values()[RandomUtils.nextInt(PotionEffectType.values().length)], RandomUtils.nextInt(1, 120) * 20, RandomUtils.nextInt(1, 3)));
                }
            } else if (m == Material.SKULL_ITEM || m == Material.SKULL) {
                is = new UniItemSkull(ep.getName());
            } else if (m == Material.ENCHANTED_BOOK) {
                is = new UniItemStack(m);
                int enchantNb = RandomUtils.nextInt(1, 4);
                for (int i = 0; i < enchantNb; i++) {
                    is.addUnsafeEnchantment(Enchantment.values()[RandomUtils.nextInt(Enchantment.values().length)], RandomUtils.nextInt(1, 4));
                }
            } else {
                is = new UniItemStack(m);
            }
            is.setAmount(old.getAmount());
            return is;
        }
    }
}
