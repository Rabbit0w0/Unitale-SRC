package fr.unitale.games.uhc.modules.scenarios.types;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.utils.items.UniItemStack;

public class SkyWarsScenario extends ScenarioModule {

    public static final int DEFAULT_MIN_HEIGHT = 200, DEFAULT_DAMAGE_DELAY = 1000;

    public SkyWarsScenario() {
        super(ScenarioType.SKYWARS);
        moduleListener = new SkyWarsScenarioListener(this, getConfig("minheight", DEFAULT_MIN_HEIGHT), getConfig("damagedelay", DEFAULT_DAMAGE_DELAY));
    }

    @Override
    public void startModule() {
        Lang.bcst("game.uhc.scenario.skywars.startwarn", "" + getConfig("minheight", DEFAULT_MIN_HEIGHT));
        ItemStack is = new UniItemStack(Material.DIRT);
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> p.getInventory().addItem(is));
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class SkyWarsScenarioListener extends ScenarioModuleListener {

        private Map<Player, Long> timings;
        private int minHeight, damageDelay;

        public SkyWarsScenarioListener(ScenarioModule module, int minHeight, int damageDelay) {
            super(module);
            timings = new HashMap<>();
            this.minHeight = minHeight;
            this.damageDelay = damageDelay;
        }

        @EventHandler
        public void onMove(PlayerMoveEvent ev) {
            if (ev.getTo().getBlockY() < minHeight &&
                    (UHCEngine.getInstance().getPhaseModule().isCurrentPhase(PhaseType.REDUCTION) ||
                            UHCEngine.getInstance().getPhaseModule().isCurrentPhase(PhaseType.DEATHMATCH))) {
                timings.putIfAbsent(ev.getPlayer(), System.currentTimeMillis());
                if (System.currentTimeMillis() - timings.get(ev.getPlayer()) > damageDelay) {
                    ev.getPlayer().sendMessage(Lang.str(ev.getPlayer(), "game.uhc.scenario.skywars.damage"));
                    ev.getPlayer().sendMessage(Lang.str(ev.getPlayer(), "game.uhc.scenario.skywars.layer", "" + minHeight));
                    ev.getPlayer().damage(1);
                    timings.replace(ev.getPlayer(), System.currentTimeMillis());
                }
            }
        }

        @EventHandler
        public void onBlockPlace(BlockPlaceEvent ev) {
            if (ev.getBlock().getType() == Material.DIRT &&
                    (UHCEngine.getInstance().getPhaseModule().isCurrentPhase(PhaseType.REDUCTION) ||
                            UHCEngine.getInstance().getPhaseModule().isCurrentPhase(PhaseType.DEATHMATCH))) {
                ev.getItemInHand().setAmount(ev.getItemInHand().getAmount() + 1);
            }
        }
    }
}
