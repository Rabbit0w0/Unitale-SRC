package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;

public final class NoFallScenario extends ScenarioModule {

    public NoFallScenario() {
        super(ScenarioType.NO_FALL);
        moduleListener = new NoFallScenarioListener(this);
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class NoFallScenarioListener extends ScenarioModuleListener {

        public NoFallScenarioListener(ScenarioModule module) {
            super(module);
        }

        @EventHandler(priority = EventPriority.HIGHEST)
        public void onDamage(EntityDamageEvent ev) {
            if (ev.getEntityType() == EntityType.PLAYER && ev.getCause() == DamageCause.FALL) {
                ev.setCancelled(true);
            }
        }
    }
}
