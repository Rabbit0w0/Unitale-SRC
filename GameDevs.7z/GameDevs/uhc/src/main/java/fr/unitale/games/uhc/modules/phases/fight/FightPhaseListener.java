package fr.unitale.games.uhc.modules.phases.fight;

import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseListener;

public class FightPhaseListener extends PhaseListener {

    public FightPhaseListener(Phase module) {
        super(module);
    }
}
