package fr.unitale.games.uhc.modules.scenarios.types;

import java.util.Random;

import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.generator.BlockPopulator;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.utils.block.luckyblocks.LuckyBlockFactory;
import fr.unitale.sdk.utils.block.luckyblocks.LuckyBlockType;

public class LuckyBlockScenario extends ScenarioModule {

    public LuckyBlockScenario() {
        super(ScenarioType.LUCKYBLOCK);
        UHCEngine.getInstance().getMap().getWorldData().addBlockPopulator(new LuckyBlockPopulator());
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class LuckyBlockPopulator extends BlockPopulator {

        @Override
        public void populate(World world, Random random, Chunk chunk) {
            int X, Y, Z;
            boolean isStone;
            for (int i = 1; i < 15; i++) {  // Number of tries
                if (random.nextInt(100) < 60) {  // The chance of spawning
                    X = random.nextInt(15);
                    Z = random.nextInt(15);
                    Y = random.nextInt(40) + 20;  // Get randomized coordinates
                    if (chunk.getBlock(X, Y, Z).getType() == Material.STONE) {
                        isStone = true;
                        while (isStone) {
                            Block b = chunk.getBlock(X, Y, Z);
                            LuckyBlockFactory.createBlock(b, LuckyBlockType.values()[random.nextInt(LuckyBlockType.values().length)], false, true);
                            chunk.getBlock(X, Y, Z).setType(Material.EMERALD_BLOCK);
                            if (random.nextInt(100) < 5) {   // The chance of continuing the vein
                                switch (random.nextInt(40)) {  // The direction chooser
                                    case 0:
                                        X++;
                                        break;
                                    case 1:
                                        Y++;
                                        break;
                                    case 2:
                                        Z++;
                                        break;
                                    case 3:
                                        X--;
                                        break;
                                    case 4:
                                        Y--;
                                        break;
                                    case 5:
                                        Z--;
                                        break;
                                }
                                isStone = (chunk.getBlock(X, Y, Z).getType() == Material.STONE) && (chunk.getBlock(X, Y, Z).getType() != Material.EMERALD_BLOCK);
                            } else isStone = false;
                        }
                    }
                }
            }
        }
    }
}
