package fr.unitale.games.uhc.modules.scenarios.types;

import java.util.Arrays;

import org.bukkit.Material;
import org.bukkit.event.Event.Result;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.utils.items.UniItemStack;

public final class DiamondLessScenario extends ScenarioModule {

    public DiamondLessScenario() {
        super(ScenarioType.DIAMONDLESS);
        moduleListener = new DiamondLessScenarioListener(this);
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class DiamondLessScenarioListener extends ScenarioModuleListener {

        public DiamondLessScenarioListener(ScenarioModule module) {
            super(module);
        }

        @EventHandler
        public void blockBreak(BlockBreakEvent ev) {
            if (ev.getBlock().getType() == Material.DIAMOND_ORE) {
                ev.getPlayer().sendMessage(Lang.str(ev.getPlayer(), "uhc.scenario.diamondless.disappear"));
                ev.setCancelled(true);
                ev.getBlock().setType(Material.AIR);
                ev.getBlock().getWorld().dropItem(ev.getBlock().getLocation(), new UniItemStack(Material.COBBLESTONE));
            }
        }

        @EventHandler
        public void prepareCraftItem(PrepareItemCraftEvent ev) {
            if (Arrays.asList(ev.getInventory().getMatrix()).stream().anyMatch(i -> i.getType() == Material.DIAMOND)) {
                ev.getRecipe().getResult().setType(Material.AIR);
            }
        }

        @EventHandler
        public void craftItem(CraftItemEvent ev) {
            if (Arrays.asList(ev.getInventory().getMatrix()).stream().anyMatch(i -> i.getType() == Material.DIAMOND)) {
                ev.setResult(Result.DENY);
                ev.setCancelled(true);
            }
        }
    }
}
