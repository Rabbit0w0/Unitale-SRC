package fr.unitale.games.uhc.modules.phases.reduction;

import org.bukkit.event.EventHandler;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseListener;
import fr.unitale.sdk.players.event.UnitalePlayerQuitEvent;

public class ReductionPhaseListener extends PhaseListener {

    public ReductionPhaseListener(Phase module) {
        super(module);
    }

    @EventHandler
    public void onEndarielPlayerQuit(UnitalePlayerQuitEvent e) {
        UHCEngine.getInstance().eliminatePlayer(e.getPlayer());
    }
}
