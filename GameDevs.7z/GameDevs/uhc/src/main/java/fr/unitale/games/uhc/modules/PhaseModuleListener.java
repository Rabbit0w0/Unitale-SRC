package fr.unitale.games.uhc.modules;

import fr.unitale.api.type.ServerTypes.GameStatus;
import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.kit.types.run.EnchanterKit;
import fr.unitale.games.uhc.kit.types.run.HunterKit;
import fr.unitale.games.uhc.kit.types.run.MinerKit;
import fr.unitale.games.uhc.stat.UHCPlayerStat;
import fr.unitale.games.uhc.utils.DeadBody;
import fr.unitale.sdk.chat.events.UnitaleGlobalChatPrepareEvent;
import fr.unitale.sdk.gameengine.events.eliminate.EliminateEvent;
import fr.unitale.sdk.gameengine.events.eliminate.EliminatePlayerEvent;
import fr.unitale.sdk.gameengine.events.players.GamePlayerWinEvent;
import fr.unitale.sdk.gameengine.modules.ModuleListener;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.stat.PlayerGameStat;
import fr.unitale.sdk.gameengine.utils.EndMoneyManager;
import fr.unitale.sdk.gameengine.utils.kit.KitManager;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.stat.StatManager;
import fr.unitale.sdk.utils.generic.ParticleEffect;
import fr.unitale.sdk.utils.generic.ParticleEffect.BlockData;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.sound.SoundCreator;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class PhaseModuleListener extends ModuleListener<PhaseModule> {

    //list of all ore that can be duplicated with the Miner kit
    private static List<Material> duplicableOre;
    //whether the end is finished and no event should be fired
    private boolean gameEnded = false;

    static {
        duplicableOre = new ArrayList<>();
        duplicableOre.add(Material.COAL_ORE);
        duplicableOre.add(Material.IRON_ORE);
        duplicableOre.add(Material.GOLD_ORE);
        duplicableOre.add(Material.DIAMOND_ORE);
        duplicableOre.add(Material.LAPIS_ORE);
        duplicableOre.add(Material.REDSTONE_ORE);
    }

    public PhaseModuleListener(PhaseModule module) {
        super(module);
    }

    @EventHandler
    public void eliminate(EliminateEvent ev) {
        //always check for end of the game after a generic eliminate event
        checkEnd();
    }

    @EventHandler
    public void eliminate(EliminatePlayerEvent e) {
        if (UHCEngine.getInstance().getGameStatus().equals(GameStatus.WAIT)) return;

        UniPlayer p = e.getPlayer();

        SoundCreator.playSound(Sound.ENTITY_WITHER_SPAWN, 1f);
        new DeadBody(p).generate();
        p.setGameMode(GameMode.SPECTATOR);

        //drop all items except barrier
        Arrays.stream(p.getInventory().getContents()).filter(Objects::nonNull).filter(is -> is.getType() != Material.BARRIER).forEach(is -> p.getLocation().getWorld().dropItemNaturally(p.getLocation(), is));

        //drop golden apple
        p.getLocation().getWorld().dropItemNaturally(p.getLocation(), new UniItemStack(Material.GOLDEN_APPLE));

        p.getInventory().clear();
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void damage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof UniPlayer) || gameEnded) return;
        UniPlayer p = (UniPlayer) e.getEntity();

        Location particleSpawnLoc = p.getLocation().clone();
        particleSpawnLoc.add(0, 1.3, 0);
        ParticleEffect.BLOCK_CRACK.display(new BlockData(Material.REDSTONE_WIRE, (byte) 0), 0.2f, 0.2f, 0.2f, 2, 50, particleSpawnLoc);

        if (p.getHealth() - e.getFinalDamage() <= 0) {//should die
            p.setHealth(20);
            if (e instanceof EntityDamageByEntityEvent) {
                EntityDamageByEntityEvent ebe = (EntityDamageByEntityEvent) e;
                if (ebe.getDamager() instanceof UniPlayer) {
                    UniPlayer killer = (UniPlayer) ebe.getDamager();
                    Lang.bcst("game.uhc.kill", killer.getName(), p.getName());
                    giveKillStat(killer, p);
                } else {
                    Lang.bcst("game.uhc.killed", p.getName());
                    giveKillStat(null, p);
                }
            } else {
                Lang.bcst("game.uhc.killed", p.getName());
                giveKillStat(null, p);
            }

            UHCEngine.getInstance().eliminatePlayer(p);
            UHCEngine.getInstance().getOnlinePlayers().forEach(PhaseModule::updateAvailablePlayerBoard);
            if (UHCEngine.getInstance().getCompetingPlayersCount() != 1) EndMoneyManager.printGain(p);
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!p.hasPermission("game.specend")) p.sendToHub();
                }
            }.runTaskLater(UHCEngine.getInstance().getPlugin(), 200L);
        }
    }

    @EventHandler
    public void entityDeath(EntityDeathEvent e) {
        if (e.getEntity().getKiller() == null || !(e.getEntity().getKiller() instanceof UniPlayer)) return;

        HunterKit hunterKit = KitManager.fromPlayer(e.getEntity().getKiller(), HunterKit.class);
        if (hunterKit != null) {
            hunterKit.onEntityKill(e);
        }

        EnchanterKit enchanterKit = KitManager.fromPlayer(e.getEntity().getKiller(), EnchanterKit.class);
        if (enchanterKit != null) {
            enchanterKit.onEntityKill(e);
        }
    }

    private void checkEnd() {
        if (UHCEngine.getInstance().getMode().equals(Mode.TEAM)) {//mode team
            switch (UHCEngine.getInstance().getCompetingTeamCount()) {
                case 0:
                    gameEnded = true;
                    UHCEngine.getInstance().endGame(400L);//end without winner
                    break;
                case 1:
                    TeamModule<UniTeam> tm = UHCEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
                    UniTeam winner = tm.getTeams().stream().filter(t -> !t.isEliminated()).findFirst().orElse(null);
                    UHCEngine.getInstance().broadcast("game.uhc.win.team", winner.getColor() + winner.getName());
                    Bukkit.getPluginManager().callEvent(new GamePlayerWinEvent(winner.getOnlineCompetingPlayers()));
                    win(winner);
                    gameEnded = true;
                    UHCEngine.getInstance().endGame(400L);
                    break;
                default:
                    break;
            }
        } else {//mode solo
            switch (UHCEngine.getInstance().getCompetingPlayersCount()) {
                case 0:
                    UHCEngine.getInstance().endGame(400L);//end without winner
                    gameEnded = true;
                    break;
                case 1:
                    UniPlayer winner = UHCEngine.getInstance().getOnlinePlayers().stream().filter(f -> !f.isEliminated()).findFirst().orElse(null);
                    UHCEngine.getInstance().broadcast("game.uhc.win.solo", winner.getName());
                    Bukkit.getPluginManager().callEvent(new GamePlayerWinEvent(winner));
                    win(winner);
                    gameEnded = true;
                    UHCEngine.getInstance().endGame(400L);
                    break;
                default:
                    break;
            }
        }
    }

    @EventHandler
    public void on(UnitaleGlobalChatPrepareEvent ev){
        if(ev.getSender().getPlayer().isEliminated()){
            ev.getSender().sendMessage(Lang.str(ev.getSender(), "game.uhc.chat.eliminated.speak"));
            ev.setCancelled(true);
        }
    }

    @EventHandler
    public void portal(PlayerPortalEvent ev) {
        if (!canGoNether() || gameEnded) ev.setCancelled(true);
    }

    @EventHandler
    public void createPortal(PortalCreateEvent ev) {
        if (!canGoNether() ||gameEnded) ev.setCancelled(true);
    }

    @EventHandler
    public void regen(EntityRegainHealthEvent ev) {
        if (ev.getEntity() instanceof Player) {
            if (ev.getRegainReason() == RegainReason.EATING || ev.getRegainReason() == RegainReason.SATIATED) {
                ev.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onInventory(InventoryOpenEvent ev) {
        ItemStack[] stacks = ev.getInventory().getContents();
        //iterate trough each items
        for (ItemStack stack : stacks) {
            if(stack == null)continue;
            //if it's a notch apple
            if (stack.getType() == Material.GOLDEN_APPLE && stack.getDurability() == 1) {
                ev.getInventory().removeItem(stack);
            }
        }
    }

    @EventHandler
    public void onCraft(PrepareItemCraftEvent ev) {
        //only change items for run and random gameplay
        if (UHCEngine.getInstance().getGameplay() != GameplayType.RUN || gameEnded) return;

        //if item is a tool, then add efficiency 2 to the result
        UniItemStack stack = UniItemStack.fromItemStack(ev.getRecipe().getResult());
        if (Arrays.asList(Material.DIAMOND_PICKAXE, Material.GOLD_PICKAXE, Material.IRON_PICKAXE, Material.STONE_PICKAXE, Material.WOOD_PICKAXE,
                Material.DIAMOND_AXE, Material.GOLD_AXE, Material.IRON_AXE, Material.STONE_AXE, Material.WOOD_AXE,
                Material.DIAMOND_SPADE, Material.GOLD_SPADE, Material.IRON_SPADE, Material.STONE_SPADE, Material.WOOD_SPADE).contains(stack.getType())) {
            stack.addEnchantment(Enchantment.DIG_SPEED, 2);
            ev.getInventory().setResult(stack);
        }
    }

    @EventHandler
    public void blockBreak(BlockBreakEvent ev) {
        if (UHCEngine.getInstance().getGameplay() == GameplayType.RUN || gameEnded) return;

        MinerKit minerKit = KitManager.fromPlayer(ev.getPlayer(), MinerKit.class);
        if (minerKit != null) {
            minerKit.onBlockBreak(ev.getBlock());
        }

        EnchanterKit enchanterKit = KitManager.fromPlayer(ev.getPlayer(), EnchanterKit.class);
        if (enchanterKit != null) {
            enchanterKit.onBlockBreak(ev);
        }
    }

    @EventHandler
    public void obsidian(BlockDamageEvent ev) {
        if(gameEnded)return;
        if (UHCEngine.getInstance().getGameplay() == GameplayType.RUN && ev.getBlock().getType().equals(Material.OBSIDIAN)) {
            ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, 30, 2));
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent ev) {
        if(gameEnded)return;
        if (ev.getPlayer().getGameMode().equals(GameMode.SPECTATOR)) {
            ev.getPlayer().sendMessage(Lang.str(ev.getPlayer(), "game.uhc.spectate"));
            ev.setCancelled(true);
        }
    }

    //
    private void win(UniTeam t) {
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> {
            if(t.contains(p)){
                UHCEngine.getInstance().spawk(p);
                StatManager.getInstance().addStat(p, PlayerGameStat.VICTORY);
            }else{
                p.eliminate();
            }
        });
    }

    private void win(Player p) {
        UHCEngine.getInstance().getCompetingPlayers().forEach(pl -> {
            if(pl.equals(p)){
                UHCEngine.getInstance().spawk(pl);
                StatManager.getInstance().addStat(pl, PlayerGameStat.VICTORY);
            }else{
                pl.eliminate();
            }
        });
    }

    private boolean canGoNether() {
        GameplayType gt = UHCEngine.getInstance().getGameplay();
        return gt != GameplayType.RUN;
    }

    private void giveKillStat(UniPlayer killer, UniPlayer victim) {
        UHCEngine.getInstance().getCompetingPlayers()
                .stream()
                .filter(p -> !victim.equals(p))
                .forEach(p -> StatManager.getInstance().addStat(p, UHCPlayerStat.SURVIVE));
        if (killer != null) {
            StatManager.getInstance().addStat(killer, PlayerGameStat.KILL);
        }
    }
}
