package fr.unitale.games.uhc.kit.types.random;

import fr.unitale.games.uhc.kit.types.StartKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class AdventurerKit extends StartKit {

    public AdventurerKit(IKit kit) {
        super(kit);
    }

    @Override
    public void onGameStart(UniPlayer player) {
        switch (getLevel()) {
            case 1:
                player.getInventory().addItem(new ItemStack(Material.WOOD_SPADE));
                break;
            case 2:
                player.getInventory().addItem(new ItemStack(Material.WOOD_SPADE));
                player.getInventory().addItem(new ItemStack(Material.WOOD_AXE));
                break;
            case 3:
                player.getInventory().addItem(new ItemStack(Material.WOOD_SPADE));
                player.getInventory().addItem(new ItemStack(Material.WOOD_AXE));
                player.getInventory().addItem(new ItemStack(Material.STONE_PICKAXE));
                break;
            case 4:
                player.getInventory().addItem(new ItemStack(Material.WOOD_SPADE));
                player.getInventory().addItem(new ItemStack(Material.WOOD_AXE));
                player.getInventory().addItem(new ItemStack(Material.STONE_PICKAXE));
                player.getInventory().addItem(new ItemStack(Material.STONE_SWORD));
                break;
            case 5:
                player.getInventory().addItem(new ItemStack(Material.WOOD_SPADE));
                player.getInventory().addItem(new ItemStack(Material.WOOD_AXE));
                player.getInventory().addItem(new ItemStack(Material.STONE_PICKAXE));
                player.getInventory().addItem(new ItemStack(Material.STONE_SWORD));
                player.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE));
                break;
        }
    }
}
