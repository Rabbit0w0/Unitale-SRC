package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.utils.items.UniItemStack;

public final class FishingScenario extends ScenarioModule {

    private static final int DEFAULT_LEVEL = 10;
    private int lureLevel, luckLevel;

    public FishingScenario() {
        super(ScenarioType.FISHING);
        lureLevel = getConfig("lurelevel", DEFAULT_LEVEL);
        luckLevel = getConfig("lucklevel", DEFAULT_LEVEL);
    }

    @Override
    public void startModule() {
        UniItemStack fishingrod = new UniItemStack(Material.FISHING_ROD);
        fishingrod.addUnsafeEnchantment(Enchantment.LURE, lureLevel);
        fishingrod.addUnsafeEnchantment(Enchantment.LUCK, luckLevel);
        fishingrod.addUnsafeEnchantment(Enchantment.DURABILITY, 10);
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> {
            p.getInventory().addItem(fishingrod);
        });
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }
}
