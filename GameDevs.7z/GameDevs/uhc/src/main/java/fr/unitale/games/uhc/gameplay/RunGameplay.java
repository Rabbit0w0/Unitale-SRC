package fr.unitale.games.uhc.gameplay;

import fr.unitale.games.uhc.kit.types.run.FarmerKit;
import fr.unitale.sdk.gameengine.utils.kit.KitManager;
import org.bukkit.Material;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.generation.NetherStructureBlockPopulator;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.gameengine.modules.treecut.TreeCutModule;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.math.RandomUtils;
import fr.unitale.sdk.world.WorldData;

public class RunGameplay implements IGameplay {

    @Override
    public void preInit() {
        DropModule dm = UHCEngine.getInstance().getModuleManager().getModule(DropModule.class);
        if (dm == null)
            UHCEngine.getInstance().emergencyShutdown("Rungameplay has started but no drop module has been found !");
        UHCEngine.getInstance().getModuleManager().addModule(
                new TreeCutModule(dm, true)
                        .setBreakLeaves(true)
                        .setAppleDropBonus(player -> {
                            FarmerKit kit = KitManager.fromPlayer(player, FarmerKit.class);
                            if (kit != null) {
                                return (double) (kit.getLevel() * 2);
                            } else {
                                return (double) 0;
                            }
                        }),
                true
        );

        // BLOCKS BROKEN
        dm.addConvertItem(ConvertType.BLOCK, Material.CACTUS, new UniItemStack(Material.WOOD));
        dm.addConvertItem(ConvertType.BLOCK, Material.FLINT, new UniItemStack(Material.ARROW, RandomUtils.nextInt(2, 6)));
        dm.addConvertItem(ConvertType.BLOCK, Material.GRAVEL, new UniItemStack(Material.ARROW, RandomUtils.nextInt(2, 6)));
        dm.addConvertItem(ConvertType.BLOCK, Material.SAND, new UniItemStack(Material.GLASS_BOTTLE));
        dm.addConvertItem(ConvertType.BLOCK, Material.COAL, new UniItemStack(Material.TORCH, 3));
        dm.addConvertItem(ConvertType.BLOCK, Material.IRON_ORE, new UniItemStack(Material.IRON_INGOT, 2));
        dm.addConvertItem(ConvertType.BLOCK, Material.GOLD_ORE, new UniItemStack(Material.GOLD_INGOT, 2));
        dm.addConvertItem(ConvertType.BLOCK, Material.DIAMOND, new UniItemStack(Material.DIAMOND, 2));
        dm.addConvertItem(ConvertType.BLOCK, Material.LOG, new UniItemStack(Material.LOG));
        dm.addConvertItem(ConvertType.BLOCK, Material.LOG_2, new UniItemStack(Material.LOG));
        dm.addConvertItem(ConvertType.BLOCK, Material.DEAD_BUSH, new UniItemStack(Material.BREAD, 3));
        dm.addConvertItem(ConvertType.BLOCK, Material.STONE, new UniItemStack(Material.COBBLESTONE));
        dm.addConvertItem(ConvertType.BLOCK, Material.BROWN_MUSHROOM, new UniItemStack(Material.MUSHROOM_SOUP, 2));
        dm.addConvertItem(ConvertType.BLOCK, Material.RED_MUSHROOM, new UniItemStack(Material.MUSHROOM_SOUP, 2));
        dm.addConvertItem(ConvertType.BLOCK, Material.EMERALD_ORE, new UniItemStack(Material.DIAMOND, 10));
        dm.addConvertItem(ConvertType.BLOCK, Material.WHEAT, new UniItemStack(Material.BREAD));
        dm.addConvertItem(ConvertType.BLOCK, Material.POTATO_ITEM, new UniItemStack(Material.BAKED_POTATO));
        // ITEMS DROPPED
        dm.addConvertItem(ConvertType.DROP, Material.INK_SACK, new UniItemStack(Material.COOKED_FISH, 2));
        dm.addConvertItem(ConvertType.DROP, Material.ROTTEN_FLESH, new UniItemStack(Material.COOKED_BEEF, 2));
        dm.addConvertItem(ConvertType.DROP, Material.SULPHUR, new UniItemStack(Material.TNT, 2));
        dm.addConvertItem(ConvertType.DROP, Material.POTATO_ITEM, new UniItemStack(Material.BAKED_POTATO));
        dm.addConvertItem(ConvertType.DROP, Material.RAW_BEEF, new UniItemStack(Material.COOKED_BEEF));
        dm.addConvertItem(ConvertType.DROP, Material.RAW_CHICKEN, new UniItemStack(Material.COOKED_CHICKEN));
        dm.addConvertItem(ConvertType.DROP, Material.RAW_FISH, new UniItemStack(Material.COOKED_FISH));
        dm.addConvertItem(ConvertType.DROP, Material.WOOL, new UniItemStack(Material.STRING, 2));
        dm.addConvertItem(ConvertType.DROP, Material.MUTTON, new UniItemStack(Material.COOKED_MUTTON));
        dm.addConvertItem(ConvertType.DROP, Material.RABBIT, new UniItemStack(Material.COOKED_RABBIT));
        dm.addConvertItem(ConvertType.DROP, Material.PORK, new UniItemStack(Material.GRILLED_PORK));
        dm.addConvertItem(ConvertType.DROP, Material.FEATHER, new UniItemStack(Material.ARROW));
        // ITEMS CRAFTED
        dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_AXE, new UniItemStack(Material.STONE_AXE));
        dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_HOE, new UniItemStack(Material.STONE_HOE));
        dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_PICKAXE, new UniItemStack(Material.STONE_PICKAXE));
        dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_SPADE, new UniItemStack(Material.STONE_SPADE));
        dm.addConvertItem(ConvertType.CRAFT, Material.WOOD_SWORD, new UniItemStack(Material.STONE_SWORD));

        dm.addMaterialXp(Material.IRON_ORE, 3);
        dm.addMaterialXp(Material.GOLD_ORE, 4);
        dm.addMaterialXp(Material.COAL_ORE, 2);

        // OVERRIDE WORLD DATA IF NOT EXISTING
        final WorldData worldData = UHCEngine.getInstance().getMap().getWorldData();

        worldData.setCoalCount(UHCEngine.getInstance().getConfig("mapgen.coal.count", 40));
        worldData.setCoalSize(UHCEngine.getInstance().getConfig("mapgen.coal.size", 20));
        worldData.setCoalMinHeight(UHCEngine.getInstance().getConfig("mapgen.coal.minHeight", 0));
        worldData.setCoalMaxHeight(UHCEngine.getInstance().getConfig("mapgen.coal.maxHeight", 256));
        worldData.setIronCount(UHCEngine.getInstance().getConfig("mapgen.iron.count", 60));
        worldData.setIronSize(UHCEngine.getInstance().getConfig("mapgen.iron.size", 9));
        worldData.setIronMinHeight(UHCEngine.getInstance().getConfig("mapgen.iron.minHeight", 0));
        worldData.setIronMaxHeight(UHCEngine.getInstance().getConfig("mapgen.iron.maxHeight", 256));
        worldData.setGoldCount(UHCEngine.getInstance().getConfig("mapgen.gold.count", 60));
        worldData.setGoldSize(UHCEngine.getInstance().getConfig("mapgen.gold.size", 9));
        worldData.setGoldMinHeight(UHCEngine.getInstance().getConfig("mapgen.gold.minHeight", 0));
        worldData.setGoldMaxHeight(UHCEngine.getInstance().getConfig("mapgen.gold.maxHeight", 256));
        worldData.setRedstoneCount(UHCEngine.getInstance().getConfig("mapgen.redstone.count", 60));
        worldData.setRedstoneSize(UHCEngine.getInstance().getConfig("mapgen.redstone.size", 10));
        worldData.setRedstoneMinHeight(UHCEngine.getInstance().getConfig("mapgen.redstone.minHeight", 0));
        worldData.setRedstoneMaxHeight(UHCEngine.getInstance().getConfig("mapgen.redstone.maxHeight", 256));
        worldData.setDiamondCount(UHCEngine.getInstance().getConfig("mapgen.diamond.count", 50));
        worldData.setDiamondSize(UHCEngine.getInstance().getConfig("mapgen.diamond.size", 6));
        worldData.setDiamondMinHeight(UHCEngine.getInstance().getConfig("mapgen.diamond.minHeight", 0));
        worldData.setDiamondMaxHeight(UHCEngine.getInstance().getConfig("mapgen.diamond.maxHeight", 256));
        worldData.setLapisCount(UHCEngine.getInstance().getConfig("mapgen.lapis.count", 50));
        worldData.setLapisSize(UHCEngine.getInstance().getConfig("mapgen.lapis.size", 6));
        worldData.setLapisCenterHeight(UHCEngine.getInstance().getConfig("mapgen.lapis.centerHeight", 128));
        worldData.setLapisSpread(UHCEngine.getInstance().getConfig("mapgen.lapis.spread", 128));

        worldData.setUseMonuments(false);// causing strange thing if not set because of the ocean removal ;D https://i.netsuu.fr/n5N5UbER
    }

    @Override
    public void postInit() {
        double netherSpawnRate = UHCEngine.getInstance().getConfig("netherSpawn", 0.05);
        int mapSize = UHCEngine.getInstance().getConfig("start.bordersize", 1000);
        new NetherStructureBlockPopulator(UHCEngine.getInstance().getMap().getWorld(), netherSpawnRate).populate(mapSize);
    }
}
