package fr.unitale.games.uhc.kit.types.run;

import fr.unitale.sdk.gameengine.utils.kit.AbstractKit;
import fr.unitale.sdk.features.IKit;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;

public class EnchanterKit extends AbstractKit {

    public EnchanterKit(IKit kit) {
        super(kit);
    }

    public void onEntityKill(EntityDeathEvent event) {
        event.setDroppedExp(event.getDroppedExp() + event.getDroppedExp() * (getLevel() / 100));
    }

    public void onBlockBreak(BlockBreakEvent event) {
        event.setExpToDrop(event.getExpToDrop() + event.getExpToDrop() * (getLevel() / 100));
    }
}
