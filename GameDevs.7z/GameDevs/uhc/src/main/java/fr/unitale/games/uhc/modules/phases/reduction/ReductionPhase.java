package fr.unitale.games.uhc.modules.phases.reduction;

import fr.unitale.api.type.ServerTypes;
import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.PhaseModule;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.games.uhc.modules.phases.deathmatch.DeathmatchPhase;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.math.RandomUtils;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public class ReductionPhase extends Phase {

    public static final int DEFAULT_REDUCTION_DURATION = 20;
    private Map<PhaseType, Integer> phaseDurations;

    private static final int FINAL_BORDER_SIZE = 50, CHANGING_TIME = 30, UPDATING_TIME = 1;
    private static final double MOVE_DISTANCE = 10.0;

    private Location oldLocation, newLocation;
    private double moveScale, moveScaleFactor;

    public ReductionPhase(Map<PhaseType, Integer> phaseDurations) {
        super(phaseDurations.get(PhaseType.REDUCTION), PhaseType.REDUCTION);
        this.moduleListener = new ReductionPhaseListener(this);
        this.phaseDurations = phaseDurations;
        this.moveScaleFactor = (double) CHANGING_TIME / (double) UPDATING_TIME;
    }

    @Override
    public void startModule() {
        super.startModule();
        oldLocation = UHCEngine.getInstance().getMapCenter().clone();
        newLocation = UHCEngine.getInstance().getMapCenter().clone();

        final double initialBorder = UHCEngine.getInstance().getConfig("start.bordersize", 1000.0);
        final double initialReductedBorder = initialBorder * 0.5;
        final double tpBorder = initialBorder * 0.4;

        final GameplayType type = UHCEngine.getInstance().getGameplay();
        final AtomicReference<Double> _angle = new AtomicReference<>(0D);
        final double diff = Math.PI * 2 / UHCEngine.getInstance().getCompetingPlayersCount();

        if (type != GameplayType.RUN && type != GameplayType.RANDOM) return;

        if(UHCEngine.getInstance().getMode() == ServerTypes.Mode.TEAM){
            UHCEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class).getTeams().stream()
                    .filter(t -> ! t.isEliminated())
                    .forEach(t -> {
                        final Location spawnLoc = UHCEngine.getInstance().getMap().getWorld().getHighestBlockAt(
                                (int) (Math.cos(_angle.get()) * tpBorder),
                                (int) (Math.sin(_angle.get()) * tpBorder)).getLocation();
                        spawnLoc.add(0, 2, 0);

                        t.getOnlinePlayers().stream()
                                .filter(p -> !p.isEliminated() && p.getGameMode() == GameMode.SURVIVAL)
                                .forEach(p -> teleport(p, spawnLoc));

                        _angle.getAndUpdate(v -> v + diff);
                    });
        }else{
            UHCEngine.getInstance().getCompetingPlayers().forEach(p -> {
                //compute spawn location if we have to use it
                final Location spawnLoc = UHCEngine.getInstance().getMap().getWorld().getHighestBlockAt(
                        (int) (Math.cos(_angle.get()) * tpBorder),
                        (int) (Math.sin(_angle.get()) * tpBorder)).getLocation();
                spawnLoc.add(0, 2, 0);
                teleport(p, spawnLoc);
                _angle.getAndUpdate(v -> v + diff);
            });

        }

        UHCEngine.getInstance().setKeepOffline(false);//no more reconnection
        Lang.bcst("game.uhc.offlineDeath");
        UHCEngine.getInstance().getMap().getWorld().getWorldBorder().setSize(initialReductedBorder*2);
        UHCEngine.getInstance().getMap().getWorld().getWorldBorder().setSize(FINAL_BORDER_SIZE, getDuration() * 60);//set world border
        Lang.bcst("game.uhc.worldborder.isreducing");
    }

    @Override
    public void update() {
        PhaseModule.setTimerBoard("Deathmatch", getTimer().getITime());
        PhaseModule.updatePlayersBoard();
        if (getTimer().getMinutes() == 0 && getTimer().getSeconds() <= 5 && getTimer().getSeconds() != 0) {
            Lang.bcst("game.uhc.phase.deathmatch.start", "" + getTimer().getSeconds());
        }
        if (getTimer().getSeconds() % CHANGING_TIME == 0) {//every CHANGING_TIME seconds
            oldLocation = UHCEngine.getInstance().getMapCenter().clone();
            double angle = RandomUtils.nextDouble(0, 2 * Math.PI);
            double newX = oldLocation.getX() + Math.cos(angle) * MOVE_DISTANCE;
            double newZ = oldLocation.getZ() + Math.sin(angle) * MOVE_DISTANCE;
            newLocation = UHCEngine.getInstance().getMapCenter().clone();
            newLocation.setX(newX);
            newLocation.setZ(newZ);
            moveScale = 0;
            //EndLogger.info("Border will now be progressively moving towards "+newLocation.getX()+","+newLocation.getZ());
            return;
        }
        //every UPDATING_TIME seconds
        double distX = newLocation.getX() - oldLocation.getX();
        double distZ = newLocation.getZ() - oldLocation.getZ();
        double newX = oldLocation.getX() + (moveScale / moveScaleFactor) * distX;
        double newZ = oldLocation.getZ() + (moveScale / moveScaleFactor) * distZ;
        UHCEngine.getInstance().getMapCenter().setX(newX);
        UHCEngine.getInstance().getMapCenter().setZ(newZ);
        UHCEngine.getInstance().getMap().getWorld().getWorldBorder().setCenter(UHCEngine.getInstance().getMapCenter());
        moveScale++;
    }

    @Override
    public void endModule() {
        //add the new phase and then start it
        GameEngine.getInstance().getModuleManager().addModule(new DeathmatchPhase(phaseDurations), true);
    }

    //teleport a player at the reduction
    private void teleport(UniPlayer p, Location spawnLoc){
        final GameplayType type = UHCEngine.getInstance().getGameplay();
        final World.Environment environment = p.getWorld().getEnvironment();
        if (environment == World.Environment.NETHER || environment == World.Environment.THE_END) {
            p.damage(5);
            p.sendMessage(Lang.str(p, "game.uhc.nether.close"));
        }
        p.teleport(spawnLoc);
        p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 20*30, 10));
        p.sendMessage(Lang.str(p, "game.uhc.phase.reduction.tp"));
    }
}
