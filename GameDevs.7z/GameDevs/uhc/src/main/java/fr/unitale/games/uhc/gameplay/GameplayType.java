package fr.unitale.games.uhc.gameplay;

import fr.unitale.api.type.ServerTypes.ServerType;

public enum GameplayType {
    NORMAL(new NormalGameplay(), ServerType.UHC),// basic gameplay for semi-long/long game, default minecraft functions
    RUN(new RunGameplay(), ServerType.UHCRUN),//speed games up to 30 minutes, fast breaking and smelting
    RANDOM(new RandomGameplay(), ServerType.UHCRANDOM);//same as basic but with random item dropping

    private IGameplay gameplay;
    private ServerType serverType;
    private String title;

    private GameplayType(IGameplay gameplay, ServerType type) {
        this.gameplay = gameplay;
        this.serverType = type;
        title = "game.uhc.gameplay." + name().toLowerCase();
    }

    public IGameplay getGameplay() {
        return gameplay;
    }

    /**
     * @return the serverType
     */
    public ServerType getServerType() {
        return serverType;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }


}
