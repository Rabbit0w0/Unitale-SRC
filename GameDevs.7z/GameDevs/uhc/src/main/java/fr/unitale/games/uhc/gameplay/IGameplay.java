package fr.unitale.games.uhc.gameplay;

public interface IGameplay {
    /**
     * Init stuff relative to the gameplay choosen
     */
    void preInit();

    void postInit();
}
