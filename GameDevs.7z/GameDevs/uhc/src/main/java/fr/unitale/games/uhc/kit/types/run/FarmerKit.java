package fr.unitale.games.uhc.kit.types.run;

import fr.unitale.sdk.gameengine.utils.kit.AbstractKit;
import fr.unitale.sdk.features.IKit;

public class FarmerKit extends AbstractKit {

    public FarmerKit(IKit kit) {
        super(kit);
    }
}
