package fr.unitale.games.uhc.modules.scenarios;

import fr.unitale.sdk.gameengine.modules.ModuleListener;

public abstract class ScenarioModuleListener extends ModuleListener<ScenarioModule> {

    public ScenarioModuleListener(ScenarioModule module) {
        super(module);
    }
}
