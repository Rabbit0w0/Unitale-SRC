package fr.unitale.games.uhc.gameplay.generation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.schematics.SchematicAPI;
import fr.unitale.sdk.utils.block.async.BlockAction;
import fr.unitale.sdk.utils.block.async.BlockModification;
import fr.unitale.sdk.utils.chat.UniLogger;
import net.minecraft.server.v1_10_R1.NBTCompressedStreamTools;

public class NetherStructureBlockPopulator {

    private static final int NETHER_CHUNK_MIN_SPACE = 12;//number of chunk the other nether has to be to be able to be placed
    private static Schematic schematic;

    private List<Chunk> populatedChunks;
    private double netherSpawnRate;
    private World world;

    static {
        try {
            schematic = SchematicAPI.loadSchematic(NBTCompressedStreamTools.a(NetherStructureBlockPopulator.class.getResourceAsStream("nether.schematic")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public NetherStructureBlockPopulator(World world, double netherSpawnRate) {
        this.netherSpawnRate = netherSpawnRate;
        this.world = world;
        this.populatedChunks = new ArrayList<>();
    }

    private void populate(Chunk chunk) {
        Predicate<Chunk> isSpacedX = ch -> Math.abs(ch.getX() - chunk.getX()) >= NETHER_CHUNK_MIN_SPACE;
        Predicate<Chunk> isSpacedZ = ch -> Math.abs(ch.getZ() - chunk.getZ()) >= NETHER_CHUNK_MIN_SPACE;
        if (populatedChunks.stream().allMatch(isSpacedX.or(isSpacedZ))) {
            populatedChunks.add(chunk);
            int x = chunk.getX() * 16;
            int z = chunk.getZ() * 16;
            Location spawnLoc = new Location(world, x, 1, z);
            List<BlockModification> blocks = new ArrayList<BlockModification>();
            Location schematicCenter = spawnLoc.clone().add(schematic.getWidth() / 2, schematic.getHeight() / 2, schematic.getLength() / 2);
            for (int offX = 0; offX < schematic.getWidth(); offX++) {
                for (int offY = 0; offY < schematic.getHeight(); offY++) {
                    for (int offZ = 0; offZ < schematic.getLength(); offZ++) {
                        Location _loc = spawnLoc.clone().add(offX, offY, offZ);
                        if (_loc.distance(schematicCenter) < schematic.getHeight() * (2.0 / 3.0)) {
                            blocks.add(new BlockAction(_loc, l -> {
                                Block b = l.getBlock();
                                if (b.getType() == Material.STONE ||
                                        b.getType() == Material.COAL_ORE ||
                                        b.getType() == Material.DIAMOND_ORE ||
                                        b.getType() == Material.EMERALD_ORE ||
                                        b.getType() == Material.GOLD_ORE ||
                                        b.getType() == Material.IRON_ORE ||
                                        b.getType() == Material.LAPIS_ORE ||
                                        b.getType() == Material.REDSTONE_ORE ||
                                        b.getType() == Material.DIRT ||
                                        b.getType() == Material.GRAVEL ||
                                        b.getType() == Material.LAVA ||
                                        b.getType() == Material.STATIONARY_LAVA ||
                                        b.getType() == Material.WATER ||
                                        b.getType() == Material.STATIONARY_WATER) {
                                    b.setType(Material.AIR);
                                }
                            }));
                        }
                    }
                }
            }

            SchematicAPI.pasteSchematic(spawnLoc, schematic, false);
            blocks.forEach(BlockModification::apply);
            //spawn the schematic
            UniLogger.info("Nether spawned in chunk " + chunk.getX() + ", " + chunk.getZ() + " (" + x + "," + z + ")");
        }
    }

    public void populate(int mapBlockSize) {
        UniLogger.info("Starting generating nether structures...");
        Random rand = new Random();
        for (int x = -mapBlockSize / 16; x < mapBlockSize / 16; x++) {
            for (int z = -mapBlockSize / 16; z < mapBlockSize / 16; z++) {
                double random = rand.nextDouble();
                if (random > netherSpawnRate / 10.0) continue;
                Chunk chunk = world.getChunkAt(x, z);
                if (chunk != null) {
                    populate(chunk);
                }
            }
        }

        UniLogger.info("Finished generating nether structures !");
    }
}
