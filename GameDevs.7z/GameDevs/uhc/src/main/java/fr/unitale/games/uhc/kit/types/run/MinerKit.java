package fr.unitale.games.uhc.kit.types.run;

import fr.unitale.sdk.gameengine.utils.kit.AbstractKit;
import fr.unitale.sdk.features.IKit;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.Random;

public class MinerKit extends AbstractKit {

    public MinerKit(IKit kit) {
        super(kit);
    }

    public void onBlockBreak(Block block) {
        if (new Random().nextInt(100) >= getLevel() * 2) return;

        block.getDrops().forEach(stack -> {
            Material type = stack.getType();
            if (!type.equals(Material.COAL_ORE) && !type.equals(Material.IRON_ORE) && !type.equals(Material.GOLD_ORE)
                    && !type.equals(Material.EMERALD_ORE) && !type.equals(Material.DIAMOND_ORE) && !type.equals(Material.REDSTONE_ORE)
                    && !type.equals(Material.QUARTZ_ORE) && !type.equals(Material.LAPIS_ORE) && !type.equals(Material.GLOWING_REDSTONE_ORE))
                return;

            stack.setAmount(stack.getAmount() + 1);
        });
    }
}
