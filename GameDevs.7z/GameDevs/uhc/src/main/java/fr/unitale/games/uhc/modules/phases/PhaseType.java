package fr.unitale.games.uhc.modules.phases;

/**
 * All current phases for a UHC game
 *
 * @author Axicer
 */
public enum PhaseType {
    RECOLTE,
    FIGHT,
    REDUCTION,
    DEATHMATCH;
}
