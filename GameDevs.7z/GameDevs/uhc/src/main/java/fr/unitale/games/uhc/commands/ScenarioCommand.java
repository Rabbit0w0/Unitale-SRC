package fr.unitale.games.uhc.commands;

import java.util.List;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.sdk.commands.AbstractCommand;
import fr.unitale.sdk.lang.Lang;

public class ScenarioCommand extends AbstractCommand {

    public ScenarioCommand() {
        super("scenarios", "sc");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            sender.sendMessage(Lang.str((Player) sender, "game.uhc.scenarios.list.header"));
            UHCEngine.getInstance().getScenarioManager().getScenarios().keySet().forEach(s -> {
                sender.sendMessage(Lang.str((Player) sender, "game.uhc.scenarios.list.name", s.toString()));
            });
            sender.sendMessage(Lang.str((Player) sender, "game.uhc.scenarios.list.footer"));
        } else {
            sender.sendMessage(UHCEngine.getInstance().getScenarioManager().getScenarios().keySet().toString());
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return null;
    }
}
