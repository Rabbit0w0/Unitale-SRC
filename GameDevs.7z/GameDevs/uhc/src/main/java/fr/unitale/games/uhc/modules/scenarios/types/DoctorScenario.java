package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityRegainHealthEvent;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;

public final class DoctorScenario extends ScenarioModule {

    private static final int DEFAULT_DIST = 10;

    public DoctorScenario() {
        super(ScenarioType.DOCTOR);
        moduleListener = new DoctorScenarioListener(this, getConfig("maxdist", DEFAULT_DIST));
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class DoctorScenarioListener extends ScenarioModuleListener {

        private int distance;

        public DoctorScenarioListener(ScenarioModule module, int distance) {
            super(module);
            this.distance = distance;
        }

        @EventHandler
        public void regen(EntityRegainHealthEvent ev) {
            if (ev.getEntityType() == EntityType.PLAYER) {
                UniPlayer ep = (UniPlayer) ev.getEntity();
                TeamModule<UniTeam> tm = UHCEngine.getInstance().getModuleManager().getTeamModule(UniTeam.class);
                if (tm != null) {
                    UniTeam team = UniTeam.getTeam(ep);
                    if (team != null) {
                        if (team.getOnlineCompetingPlayers().stream()
                                .filter(p -> !p.equals(ep))
                                .anyMatch(p -> ep.getLocation().distance(p.getLocation()) > distance)) {
                            ev.setCancelled(true);
                            ep.sendMessage(Lang.str(ep, "game.uhc.scenario.doctor.toofar", "" + distance));
                        }
                    }
                }
            }
        }

    }
}
