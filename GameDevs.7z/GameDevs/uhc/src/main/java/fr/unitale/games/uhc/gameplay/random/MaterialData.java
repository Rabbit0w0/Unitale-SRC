package fr.unitale.games.uhc.gameplay.random;

import org.bukkit.Material;

public class MaterialData {
    private Material material;
    private Byte data;

    public MaterialData(Material material, Byte data) {
        this.material = material;
        this.data = data;
    }

    /**
     * @return the material
     */
    public Material getMaterial() {
        return material;
    }

    /**
     * @return the data
     */
    public Byte getData() {
        return data;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MaterialData other = (MaterialData) obj;
        if (!data.equals(other.data))
            return false;
        return material == other.material;
    }

    @Override
    public String toString() {
        return "MaterialData [material=" + material + ", data=" + data + "]";
    }
}
