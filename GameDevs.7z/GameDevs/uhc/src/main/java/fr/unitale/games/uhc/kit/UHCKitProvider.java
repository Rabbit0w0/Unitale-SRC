package fr.unitale.games.uhc.kit;

import fr.unitale.games.uhc.kit.types.random.AdventurerKit;
import fr.unitale.games.uhc.kit.types.random.GourmetKit;
import fr.unitale.games.uhc.kit.types.random.SpeedKit;
import fr.unitale.games.uhc.kit.types.run.EnchanterKit;
import fr.unitale.games.uhc.kit.types.run.FarmerKit;
import fr.unitale.games.uhc.kit.types.run.HunterKit;
import fr.unitale.games.uhc.kit.types.run.MinerKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.gameengine.utils.kit.AbstractKit;
import fr.unitale.sdk.gameengine.utils.kit.KitProvider;

public class UHCKitProvider implements KitProvider {

    @Override
    public Class<? extends AbstractKit> getTypeFromKit(IKit kit) {
        switch (kit.getKitKey()) {
            case "miner":
                return MinerKit.class;
            case "farmer":
                return FarmerKit.class;
            case "hunter":
                return HunterKit.class;
            case "enchanter":
                return EnchanterKit.class;
            case "speed":
                return SpeedKit.class;
            case "gourmet":
                return GourmetKit.class;
            case "adventurer":
                return AdventurerKit.class;
            default:
                return null;
        }
    }
}
