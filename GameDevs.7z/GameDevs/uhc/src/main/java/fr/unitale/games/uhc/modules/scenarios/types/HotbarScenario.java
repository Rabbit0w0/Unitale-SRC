package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.utils.items.UniItemStack;

public final class HotbarScenario extends ScenarioModule {

    public HotbarScenario() {
        super(ScenarioType.HOTBAR);
        moduleListener = new HotbarScenarioListener(this);
    }

    @Override
    public void startModule() {
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> {
            for (int i = 9; i < 36; i++) {
                p.getInventory().setItem(i, new UniItemStack(Material.BARRIER));
            }
        });
    }

    @Override
    public void endModule() {
    }

    private static final class HotbarScenarioListener extends ScenarioModuleListener {

        public HotbarScenarioListener(ScenarioModule module) {
            super(module);
        }

        @EventHandler
        public void inventoryClick(InventoryClickEvent ev) {
            if ((ev.getCursor().getType() == Material.BARRIER || ev.getCurrentItem().getType() == Material.BARRIER)
                    && ev.getClickedInventory().getType() == InventoryType.PLAYER) {
                ev.setCancelled(true);
            }
        }
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }
}
