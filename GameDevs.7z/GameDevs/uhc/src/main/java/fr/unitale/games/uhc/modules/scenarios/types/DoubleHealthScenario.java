package fr.unitale.games.uhc.modules.scenarios.types;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;

public final class DoubleHealthScenario extends ScenarioModule {

    public DoubleHealthScenario() {
        super(ScenarioType.DOUBLE_HEALTH);
    }

    @Override
    public void startModule() {
        UHCEngine.getInstance().getCompetingPlayers().forEach(p -> {
            p.setMaxHealth(40);
            p.setHealth(40);
        });
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }
}
