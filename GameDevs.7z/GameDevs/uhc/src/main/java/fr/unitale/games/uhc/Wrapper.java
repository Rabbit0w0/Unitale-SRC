package fr.unitale.games.uhc;

import java.io.File;

import org.bukkit.plugin.java.JavaPlugin;

import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.utils.chat.UniLogger;

/**
 * JavaPlugin entry point for UHC
 *
 * @author Axicer
 */
public class Wrapper extends JavaPlugin {

    public static final String CONFIG_NAME = "uhc.json"; //config name for this gameengine

    @Override
    public void onEnable() {
        super.onEnable();

        UniLogger.info("UHC Wrapper launched !");
        final File file = new File("plugins", CONFIG_NAME); //path is ./plugins/{CONFIG_NAME}
        if (file.exists()) {
            new UHCEngine(this, GameEngine.getJSONContent(file));
        } else {
            //load from default configuration
            new UHCEngine(this, GameEngine.getDefaultJSONContent(Wrapper.class, CONFIG_NAME));
        }
    }
}
