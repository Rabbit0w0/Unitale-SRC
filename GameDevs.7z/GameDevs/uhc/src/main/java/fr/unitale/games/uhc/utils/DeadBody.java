package fr.unitale.games.uhc.utils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.items.UniItemSkull;

public class DeadBody {

    private UniPlayer player;

    public DeadBody(Player p) {
        this.player = (UniPlayer) p;
    }

    public void generate() {
        final Location spawnLocation = player.getLocation().clone();
        spawnLocation.subtract(0, 1.2, 0);
        final ArmorStand as1 = (ArmorStand) player.getWorld().spawnEntity(spawnLocation, EntityType.ARMOR_STAND);
        as1.setBasePlate(false);
        as1.setArms(true);
        as1.setHeadPose(new EulerAngle(Math.toRadians(285), 0, 0));
        as1.setBodyPose(new EulerAngle(Math.toRadians(90), Math.toRadians(180), 0));
        as1.setLeftArmPose(new EulerAngle(Math.toRadians(260), 0, 0));
        as1.setRightArmPose(new EulerAngle(Math.toRadians(260), 0, 0));
        as1.setHelmet(new UniItemSkull(player.getProfile()));
        as1.setChestplate(player.getInventory().getChestplate());
        as1.setItemInHand(player.getInventory().getItemInMainHand());
        as1.setVisible(false);
        as1.setCanPickupItems(false);
        as1.setGravity(false);

        Vector leggingsvec = player.getLocation().getDirection().normalize().multiply(0.9);
        leggingsvec.setY(1);
        leggingsvec.multiply(0.6);
        Location leggingsLoc = spawnLocation.clone().add(leggingsvec);
        final ArmorStand as2 = (ArmorStand) player.getWorld().spawnEntity(leggingsLoc, EntityType.ARMOR_STAND);
        as2.setBasePlate(false);
        as2.setBodyPose(new EulerAngle(0, 0, 0));
        as2.setLeftLegPose(new EulerAngle(Math.toRadians(270), 0, 0));
        as2.setRightLegPose(new EulerAngle(Math.toRadians(270), 0, 0));
        as2.setLeggings(player.getInventory().getLeggings());
        as2.setBoots(player.getInventory().getBoots());
        as2.setVisible(false);
        as2.setCanPickupItems(false);
        as2.setGravity(false);

        Bukkit.getScheduler().scheduleSyncDelayedTask(UHCEngine.getInstance().getPlugin(), () -> {
            as1.remove();
            as2.remove();
        }, 5 * 20);
    }
}
