package fr.unitale.games.uhc.utils;

import fr.unitale.sdk.gameengine.modules.team.TeamDispatcher;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.utils.chat.UniLogger;
import fr.unitale.sdk.utils.color.UniColor;
import fr.unitale.sdk.utils.math.RandomUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * UHC specific dispatcher
 * <p>
 * This dispatcher fill the already filled teams (those which are not empty)
 * then it dispatch others players in other teams depending of the team size
 */
public class UHCTeamDispatcher extends TeamDispatcher<UniTeam> {

    public UHCTeamDispatcher(TeamModule<UniTeam> tm) {
        super(tm);
    }

    @Override
    public void dispatch() {
        //get all teams with some players in it
        final List<UniTeam> filledTeams = module.getTeams().stream()
                .filter(t -> !t.isEmpty())
                .collect(Collectors.toList());
        log("teams " + filledTeams.stream().map(UniTeam::getName).collect(Collectors.joining(", ")) + " are not empty");
        //get all players without teams
        final List<UniPlayer> playersWithoutTeam = Bukkit.getOnlinePlayers().stream()
                .map(p -> (UniPlayer) p)
                .filter(p -> UniTeam.getTeam(p) == null)
                .collect(Collectors.toList());
        log("players " + playersWithoutTeam.stream().map(Player::getName).collect(Collectors.joining(", ")) + " are not in a team");
        final int teamSize = module.getTeamSize();
        log("teamsize = " + teamSize);

        //special case if there is only one team filled, and not enough player to create new team
        if (filledTeams.size() == 1 && playersWithoutTeam.size() <= teamSize-filledTeams.get(0).getCompetingCount() && playersWithoutTeam.size() != 0) {
            log("getting a new team");
            //get a team
            UniTeam team = module.getSmallerTeam();
            if(team.getCompetingCount() == teamSize){
                team = new UniTeam("team" + UUID.randomUUID().toString(), UniColor.random(), teamSize);
                module.addTeam(team);
                log("team is full ! creating a new one : " + team.getName());
            }

            log("Dispatching all players to the team "+team.getName());
            //dispatch all players into another team
            UniTeam finalTeam = team;
            playersWithoutTeam.forEach(finalTeam::addPlayer);
            return;
        }

        //while all teams not empty are not entirely filled
        while (!filledTeams.stream().allMatch(t -> t.getCompetingCount() == teamSize)) {
            log("not all teams teams are full");
            //get the first team with wich is not empty from the list
            //if we get null then the while condition is false
            final UniTeam team = filledTeams.stream().filter(t -> t.getCompetingCount() < teamSize).findAny().orElse(null);
            log("team " + team.getName() + " is not full");
            //get a random player, if null then the list is empty
            final UniPlayer player = playersWithoutTeam.size() == 0 ? null : playersWithoutTeam.get(RandomUtils.nextInt(playersWithoutTeam.size()));
            if (player == null) {
                log("But no player has been found to dispatch, stopping the dispatch.");
                //dispath is done
                return;
            } else {
                log("player " + player.getName() + " has been found and his not in a team, sending to team " + team.getName());
                //dispatch the player in the team
                team.addPlayer(player);
                playersWithoutTeam.remove(player);
            }
        }

        //if there is some player after the dispatch
        if (playersWithoutTeam.isEmpty()) return;

        //special case, if there is no team chosen
        if(filledTeams.size() == 0 && playersWithoutTeam.size() <= teamSize){
            log("No team chosen and not enough players to create 2 teams, dispatching in 2 teams");
            UniTeam teamA = module.getSmallerTeam();
            UniTeam teamB = null;
            for(int i = 0 ; i < playersWithoutTeam.size() ; i++){
                UniPlayer player = playersWithoutTeam.get(i);
                if(i%2 == 0){
                    log("Adding "+player.getName()+" to team "+teamA.getName());
                    teamA.addPlayer(player);
                    //here we define the teamB if null
                    if(teamB == null){
                        //getSmallestTeam can't return teamA because teamA has at least 1 player
                        teamB = module.getSmallerTeam();
                    }
                }else{
                    log("Adding "+player.getName()+" to team "+teamB.getName());
                    teamB.addPlayer(player);
                }
            }
            playersWithoutTeam.clear();
            return;
        }

        log("starting team creation for players whithout a team");
        //get the amount of empty team to get
        final int teamAmount = playersWithoutTeam.size() / teamSize + 1;
        log("We have to create " + teamAmount + " more teams");
        for (int i = 0; i < teamAmount; i++) {
            //if the list is empty then end here
            if (playersWithoutTeam.isEmpty()) {
                log("No more players to dispatch, stopping the dispatcher.");
                return;
            }
            UniTeam team = module.getSmallerTeam();
            log("Getting the smallest team : " + team.getName());
            //if the team is full, then we need to register a new team
            if (team.getCompetingCount() == teamSize) {
                team = new UniTeam("team" + UUID.randomUUID().toString(), UniColor.random(), teamSize);
                module.addTeam(team);
                log("team is full ! creating a new one : " + team.getName());
            }
            log("starting dispatching players in the team !");
            //iterate through
            for (int j = 0; j < teamSize; j++) {
                log("iterating through place n°" + i + " in the team");
                //get a random player, if null then the list is empty
                UniPlayer player = playersWithoutTeam.size() == 0 ? null : playersWithoutTeam.get(RandomUtils.nextInt(playersWithoutTeam.size()));
                if (player == null) {
                    log("no player to dispatch, stopping dispatcher");
                    //dispatch is done
                    return;
                } else {
                    log("found random player " + player.getName() + " dispatching in team " + team.getName());
                    //dispatch the player in the team
                    team.addPlayer(player);
                    playersWithoutTeam.remove(player);
                }
            }
        }
    }

    private void log(String msg){
        UniLogger.info(msg);
    }
}
