package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.inventory.ItemStack;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;
import fr.unitale.sdk.gameengine.events.eliminate.EliminatePlayerEvent;
import fr.unitale.sdk.players.UniPlayer;

public class GoldenDeathScenario extends ScenarioModule {

    private static final int DEFAULT_DROP_AMOUNT = 1;

    public GoldenDeathScenario() {
        super(ScenarioType.GOLDENDEATH);
        moduleListener = new GoldenDeathScenarioListener(this, getConfig("dropamount", DEFAULT_DROP_AMOUNT));
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    public static final class GoldenDeathScenarioListener extends ScenarioModuleListener {

        private int dropAmount;

        public GoldenDeathScenarioListener(ScenarioModule module, int dropAmount) {
            super(module);
            this.dropAmount = dropAmount;
        }

        @EventHandler
        public void onEliminate(EliminatePlayerEvent ev) {
            UniPlayer p = ev.getPlayer();
            p.getWorld().dropItem(p.getLocation(), new ItemStack(Material.GOLDEN_APPLE, dropAmount));
        }
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }
}
