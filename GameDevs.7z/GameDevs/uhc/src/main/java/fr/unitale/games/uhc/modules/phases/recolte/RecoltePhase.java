package fr.unitale.games.uhc.modules.phases.recolte;

import fr.unitale.games.uhc.modules.PhaseModule;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.games.uhc.modules.phases.fight.FightPhase;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.lang.Lang;

import java.util.Map;

/**
 * First phase on a UHC game
 *
 * @author Axicer
 */
public class RecoltePhase extends Phase {

    public static final int DEFAULT_RECOLTE_DURATION = 10; //10 minutes
    private Map<PhaseType, Integer> phaseDurations;

    public RecoltePhase(Map<PhaseType, Integer> phaseDurations) {
        super(phaseDurations.get(PhaseType.RECOLTE), PhaseType.RECOLTE);
        this.moduleListener = new RecoltePhaseListener(this);
        this.phaseDurations = phaseDurations;
    }

    @Override
    public void startModule() {
        super.startModule();
    }

    @Override
    public void update() {
        PhaseModule.setTimerBoard("PVP", getTimer().getITime());
        PhaseModule.updatePlayersBoard();
        if (getTimer().getMinutes() == 0 && getTimer().getSeconds() <= 5 && getTimer().getSeconds() != 0) {
            Lang.bcst("game.uhc.phase.fight.start", "" + getTimer().getSeconds());
        }
    }

    @Override
    public void endModule() {
        //add the new phase and then start it
        GameEngine.getInstance().getModuleManager().addModule(new FightPhase(phaseDurations), true);
    }
}
