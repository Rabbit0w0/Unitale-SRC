package fr.unitale.games.uhc.kit.types.random;

import fr.unitale.games.uhc.kit.types.StartKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.players.UniPlayer;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class SpeedKit extends StartKit {

    public SpeedKit(IKit kit) {
        super(kit);
    }

    public void onGameStart(UniPlayer player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60 * getLevel(), 1));
    }
}
