package fr.unitale.games.uhc.stat;

import fr.unitale.sdk.players.money.IMoneyTransactionType;
import fr.unitale.sdk.stat.PlayerStatType;
import fr.unitale.sdk.stat.PlayerStatType.PlayerStatMode;

public class UHCPlayerStat {
    public static enum UHCMoneyTransaction implements IMoneyTransactionType {
        SCENARIO, SURVIVE;
    }

    public static PlayerStatType SCENARIO = new PlayerStatType("scenario", "SCENARIO", "Scenario", PlayerStatMode.UNIQUE, UHCMoneyTransaction.SCENARIO);
    public static PlayerStatType SURVIVE = new PlayerStatType("survive", "SURVIVE", "Survie", PlayerStatMode.ADDITIONNABLE, UHCMoneyTransaction.SURVIVE);
}
