package fr.unitale.games.uhc.gameplay;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.sdk.world.WorldData;

public class NormalGameplay implements IGameplay {

    @Override
    public void preInit() {
        WorldData worldData = UHCEngine.getInstance().getMap().getWorldData();

        worldData.setCoalCount(20);
        worldData.setCoalSize(17);
        worldData.setCoalMinHeight(0);
        worldData.setCoalMaxHeight(128);
        worldData.setIronCount(20);
        worldData.setIronSize(9);
        worldData.setIronMinHeight(0);
        worldData.setIronMaxHeight(64);
        worldData.setGoldCount(2);
        worldData.setGoldSize(9);
        worldData.setGoldMinHeight(0);
        worldData.setGoldMaxHeight(32);
        worldData.setRedstoneCount(8);
        worldData.setRedstoneSize(8);
        worldData.setRedstoneMinHeight(0);
        worldData.setRedstoneMaxHeight(16);
        worldData.setDiamondCount(1);
        worldData.setDiamondSize(8);
        worldData.setDiamondMinHeight(0);
        worldData.setDiamondMaxHeight(16);
        worldData.setLapisCount(1);
        worldData.setLapisSize(7);
        worldData.setLapisCenterHeight(16);
        worldData.setLapisSpread(16);
    }

    @Override
    public void postInit() {
    }
}
