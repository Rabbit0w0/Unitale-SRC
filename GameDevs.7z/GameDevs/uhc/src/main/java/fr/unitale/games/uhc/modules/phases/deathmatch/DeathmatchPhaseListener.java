package fr.unitale.games.uhc.modules.phases.deathmatch;

import org.bukkit.event.EventHandler;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseListener;
import fr.unitale.sdk.players.event.UnitalePlayerQuitEvent;

public class DeathmatchPhaseListener extends PhaseListener {

    public DeathmatchPhaseListener(Phase module) {
        super(module);
    }

    @EventHandler
    public void onEndarielPlayerQuit(UnitalePlayerQuitEvent e) {
        UHCEngine.getInstance().eliminatePlayer(e.getPlayer());
    }
}
