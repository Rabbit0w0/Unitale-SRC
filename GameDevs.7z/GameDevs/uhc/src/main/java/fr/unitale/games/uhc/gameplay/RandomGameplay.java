package fr.unitale.games.uhc.gameplay;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.gameplay.random.MaterialData;
import fr.unitale.sdk.gameengine.modules.drop.DropModule;
import fr.unitale.sdk.gameengine.modules.drop.DropModule.ConvertType;
import fr.unitale.sdk.utils.items.UniItemStack;
import net.minecraft.server.v1_10_R1.Item;
import org.bukkit.Material;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@SuppressWarnings({"deprecation"})
public class RandomGameplay implements IGameplay {

    private static List<Material> forbiddenMaterials;
    private static Map<MaterialData, MaterialData> seed;

    static {
        seed = new HashMap<>();
        forbiddenMaterials = new ArrayList<>();
        forbiddenMaterials.add(Material.AIR);
        forbiddenMaterials.add(Material.BEDROCK);
        forbiddenMaterials.add(Material.MONSTER_EGG);
        forbiddenMaterials.add(Material.BARRIER);
        forbiddenMaterials.add(Material.END_GATEWAY);
        forbiddenMaterials.add(Material.ENDER_PORTAL);
        forbiddenMaterials.add(Material.ENDER_PORTAL_FRAME);
        forbiddenMaterials.add(Material.PORTAL);
        forbiddenMaterials.add(Material.COMMAND);
        forbiddenMaterials.add(Material.COMMAND_CHAIN);
        forbiddenMaterials.add(Material.COMMAND_MINECART);
        forbiddenMaterials.add(Material.COMMAND_REPEATING);
        forbiddenMaterials.add(Material.MOB_SPAWNER);
        forbiddenMaterials.add(Material.TIPPED_ARROW);
        forbiddenMaterials.add(Material.BANNER);
        forbiddenMaterials.add(Material.GOLD_RECORD);
        forbiddenMaterials.add(Material.GREEN_RECORD);
        forbiddenMaterials.add(Material.STRUCTURE_VOID);
        forbiddenMaterials.add(Material.STRUCTURE_BLOCK);
        forbiddenMaterials.add(Material.SPECTRAL_ARROW);
        forbiddenMaterials.add(Material.SPLASH_POTION);
        forbiddenMaterials.add(Material.SKULL_ITEM);
        forbiddenMaterials.add(Material.SHIELD);
        forbiddenMaterials.add(Material.LINGERING_POTION);
        forbiddenMaterials.add(Material.DRAGONS_BREATH);
        forbiddenMaterials.add(Material.WRITTEN_BOOK);
        
		forbiddenMaterials.add(Material.GRASS_PATH);
		forbiddenMaterials.add(Material.STONE_SLAB2);
		forbiddenMaterials.remove(Material.LONG_GRASS);
        IntStream.rangeClosed(3, 12).forEach(i -> forbiddenMaterials.add(Material.valueOf("RECORD_" + i)));
        forbiddenMaterials.addAll(Arrays.stream(Material.values()).filter(m -> Item.getById(m.getId()) == null).collect(Collectors.toList()));

        List<Material> allowedMaterials = new ArrayList<Material>();
        Arrays.stream(Material.values()).filter(m -> !forbiddenMaterials.contains(m)).forEach(allowedMaterials::add);
        List<MaterialData> allowedDatas = computeMaterialData(allowedMaterials);
        List<MaterialData> randomDatas = new ArrayList<MaterialData>(allowedDatas);
        Collections.shuffle(randomDatas);

        IntStream.range(0, allowedDatas.size()).forEach(i -> seed.put(allowedDatas.get(i), randomDatas.get(i)));
    }

    @Override
    public void preInit() {
        DropModule dm = UHCEngine.getInstance().getModuleManager().getModule(DropModule.class);
        if (dm == null)
            UHCEngine.getInstance().emergencyShutdown("RandomGameplay has started but no drop module has been found !");
        seed.forEach((searched, replaced) -> {
            if (searched.getData() == null) {
                dm.addConvertItem(ConvertType.BLOCK, searched.getMaterial(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
                dm.addConvertItem(ConvertType.DROP, searched.getMaterial(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
                dm.addConvertItem(ConvertType.BREW, searched.getMaterial(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
                dm.addConvertItem(ConvertType.FISH, searched.getMaterial(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
            } else {
                dm.addConvertItem(ConvertType.BLOCK, searched.getMaterial(), searched.getData(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
                dm.addConvertItem(ConvertType.DROP, searched.getMaterial(), searched.getData(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
                dm.addConvertItem(ConvertType.BREW, searched.getMaterial(), searched.getData(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
                dm.addConvertItem(ConvertType.FISH, searched.getMaterial(), searched.getData(), new UniItemStack(replaced.getMaterial(), replaced.getData() == null ? 0 : replaced.getData()));
            }
        });
    }

    @Override
    public void postInit() {
    }

    private static List<MaterialData> computeMaterialData(List<Material> materials) {
        List<MaterialData> list = new ArrayList<>();
        materials.forEach(m -> {
            switch (m) {
                case SAND:
                case SPONGE:
                case COBBLE_WALL:
                case LEAVES_2:
                case LOG_2:
                    for (byte i = 0; i <= 1; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case DIRT:
                case SANDSTONE:
                case QUARTZ_BLOCK:
                case RED_SANDSTONE:
                    for (byte i = 0; i <= 2; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case LOG:
                case LEAVES:
                case PRISMARINE:
                    for (byte i = 0; i <= 3; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case WOOD:
                case SAPLING:
                case MONSTER_EGGS:
                case SMOOTH_BRICK:
                case WOOD_STEP:
                case DOUBLE_PLANT:
                    for (byte i = 0; i <= 5; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case STONE:
                    for (byte i = 0; i <= 6; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case STEP:
                    for (byte i = 0; i <= 7; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case RED_ROSE:
                    for (byte i = 0; i <= 8; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                case WOOL:
                case STAINED_GLASS:
                case STAINED_CLAY:
                case STAINED_GLASS_PANE:
                case CARPET:
                    for (byte i = 0; i <= 15; i++) {
                        list.add(new MaterialData(m, i));
                    }
                    break;
                default:
                    list.add(new MaterialData(m, null));
                    break;
            }
        });
        return list;
    }
}
