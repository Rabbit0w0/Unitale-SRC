package fr.unitale.games.uhc.modules.scenarios;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.sdk.gameengine.modules.Module;

public abstract class ScenarioModule extends Module<ScenarioModuleListener> {

    private ScenarioType type;

    public ScenarioModule(ScenarioType type) {
        this.type = type;
    }

    public ScenarioType getType() {
        return type;
    }

    public abstract boolean isCompatibleWith(GameplayType type);
}
