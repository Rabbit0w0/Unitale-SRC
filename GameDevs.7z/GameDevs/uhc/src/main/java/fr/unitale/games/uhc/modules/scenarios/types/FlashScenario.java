package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;

public final class FlashScenario extends ScenarioModule {

    private static final int DEFAULT_SPEED_LEVEL = 3, DURATION = 2 * 60 * 60 * 20;

    public FlashScenario() {
        super(ScenarioType.FLASH);
        moduleListener = new FlashScenarioListener(this, getConfig("speedlevel", DEFAULT_SPEED_LEVEL));
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    private static final class FlashScenarioListener extends ScenarioModuleListener {

        private int speedLevel;

        public FlashScenarioListener(ScenarioModule module, int speedLevel) {
            super(module);
            this.speedLevel = speedLevel;
        }

        @EventHandler
        public void onMove(PlayerMoveEvent ev) {
            if (!ev.getPlayer().hasPotionEffect(PotionEffectType.SPEED)) {
                ev.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, DURATION, speedLevel));
            }
        }

    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }
}
