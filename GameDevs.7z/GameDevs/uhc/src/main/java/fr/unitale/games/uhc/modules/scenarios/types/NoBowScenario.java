package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Event.Result;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;

public final class NoBowScenario extends ScenarioModule {

    public NoBowScenario() {
        super(ScenarioType.NO_BOW);
        moduleListener = new NoBowScenarioListener(this);
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

    private static final class NoBowScenarioListener extends ScenarioModuleListener {

        public NoBowScenarioListener(ScenarioModule module) {
            super(module);
        }

        @EventHandler
        public void onCraft(CraftItemEvent ev) {
            if (ev.getRecipe().getResult().getType() == Material.BOW) {
                ev.setResult(Result.DENY);
                ev.setCancelled(true);
            }
        }

        @EventHandler
        public void onPrepareCraft(PrepareItemCraftEvent ev) {
            if (ev.getRecipe().getResult().getType() == Material.BOW) {
                ev.getRecipe().getResult().setType(Material.AIR);
            }
        }

        @EventHandler
        public void onShoot(EntityShootBowEvent ev) {
            ev.setCancelled(true);
        }
    }
}
