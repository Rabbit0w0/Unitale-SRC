package fr.unitale.games.uhc.utils;

public class Utils {

}
