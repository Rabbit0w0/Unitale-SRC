package fr.unitale.games.uhc.modules.phases;

import org.bukkit.scheduler.BukkitRunnable;

import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.sdk.UnitaleSDK;
import fr.unitale.sdk.gameengine.GameEngine;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.utils.generic.TimeManager;
import fr.unitale.sdk.utils.generic.UniTimer;
import fr.unitale.sdk.utils.generic.Updater;

/**
 * An abstract UHC Phase
 *
 * @author Axicer
 */
public abstract class Phase extends Module<PhaseListener> implements Updater {

    private PhaseType phase; //internal phase type
    private int duration; //timer duration
    private UniTimer timer;

    public Phase(int duration, PhaseType phase) {
        this.duration = duration;
        this.phase = phase;
    }

    /**
     * Executed when the module is started
     */
    @Override
    public void startModule() {
        UHCEngine.getInstance().getPhaseModule().setCurrentPhase(this);//set the current phase to this one
        this.timer = TimeManager.getInstance().addTimer(new UniTimer("UHC_PHASE_" + phase, this, this.duration, 0));
    }

    /**
     * Executed when the timer is ended
     */
    @Override
    public void end() {
        //run a new task after 1 tick
        new BukkitRunnable() {
            @Override
            public void run() {
                phaseEnd();
            }
        }.runTaskLater(UnitaleSDK.getInstance(), 1L);
    }

    /**
     * Executed when the timer is started
     */
    @Override
    public void start() {
    }

    /**
     * End this phase
     */
    private void phaseEnd() {
        TimeManager.getInstance().removeTimer(this.timer); //remove the timer
        GameEngine.getInstance().getModuleManager().removeModule(this.getClass());//remove this module from the module Manager (calling endModule())
    }

    /**
     * Get the phase duration
     *
     * @return int duration in seconds
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Get this phase timer
     *
     * @return {@link UniTimer} timer
     */
    public UniTimer getTimer() {
        return timer;
    }

    /**
     * Get the internal phase enum type
     *
     * @return {@link PhaseType} type
     */
    public PhaseType getPhase() {
        return phase;
    }
}
