package fr.unitale.games.uhc.modules.phases.recolte;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseListener;
import fr.unitale.sdk.players.UniPlayer;

public class RecoltePhaseListener extends PhaseListener {

    public RecoltePhaseListener(Phase module) {
        super(module);
    }

    //pas de PVP
    @EventHandler(priority = EventPriority.LOWEST)
    public void damage(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof UniPlayer && e.getDamager() instanceof UniPlayer) {
            e.setCancelled(true);
        }
    }
}
