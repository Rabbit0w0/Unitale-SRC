package fr.unitale.games.uhc.modules.scenarios.types;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Monster;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntitySpawnEvent;

import fr.unitale.games.uhc.gameplay.GameplayType;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModule;
import fr.unitale.games.uhc.modules.scenarios.ScenarioModuleListener;
import fr.unitale.games.uhc.modules.scenarios.ScenarioType;

public final class CreeperManiaScenario extends ScenarioModule {

    public CreeperManiaScenario() {
        super(ScenarioType.CREEPER_MANIA);
        moduleListener = new CreeperManiaScenarioListener(this);
    }

    @Override
    public void startModule() {
    }

    @Override
    public void endModule() {
    }

    private static final class CreeperManiaScenarioListener extends ScenarioModuleListener {

        public CreeperManiaScenarioListener(ScenarioModule module) {
            super(module);
        }

        @EventHandler
        public void onEntitySpawn(EntitySpawnEvent ev) {
            if (ev.getEntityType() != EntityType.CREEPER && ev.getEntity() instanceof Monster) {
                ev.getLocation().getWorld().spawnEntity(ev.getLocation(), EntityType.CREEPER);
                ev.setCancelled(true);
            }
        }
    }

    @Override
    public boolean isCompatibleWith(GameplayType type) {
        return true;
    }

}
