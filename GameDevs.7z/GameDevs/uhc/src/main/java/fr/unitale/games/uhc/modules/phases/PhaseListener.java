package fr.unitale.games.uhc.modules.phases;

import fr.unitale.sdk.gameengine.modules.ModuleListener;

public abstract class PhaseListener extends ModuleListener<Phase> {

    public PhaseListener(Phase module) {
        super(module);
    }
}
