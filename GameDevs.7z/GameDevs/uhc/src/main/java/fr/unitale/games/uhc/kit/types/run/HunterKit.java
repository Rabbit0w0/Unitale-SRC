package fr.unitale.games.uhc.kit.types.run;

import fr.unitale.sdk.gameengine.utils.kit.AbstractKit;
import fr.unitale.sdk.features.IKit;
import org.bukkit.Material;
import org.bukkit.entity.Animals;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.Random;

public class HunterKit extends AbstractKit {

    public HunterKit(IKit kit) {
        super(kit);
    }

    public void onEntityKill(EntityDeathEvent event) {
        if (!(event.getEntity() instanceof Animals)) return;
        if (new Random().nextInt(100) >= getLevel() * 2) return;

        event.getDrops().forEach(stack -> {
            Material type = stack.getType();
            if (!type.equals(Material.RAW_FISH) && !type.equals(Material.RAW_BEEF) && !type.equals(Material.RAW_CHICKEN)
                    && !type.equals(Material.RABBIT)) return;
            stack.setAmount(stack.getAmount() + 1);
        });
    }
}
