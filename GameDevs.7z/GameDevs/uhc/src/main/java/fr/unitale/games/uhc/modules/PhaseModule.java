package fr.unitale.games.uhc.modules;

import fr.unitale.api.type.ServerTypes.Mode;
import fr.unitale.games.uhc.UHCEngine;
import fr.unitale.games.uhc.kit.types.StartKit;
import fr.unitale.games.uhc.modules.phases.Phase;
import fr.unitale.games.uhc.modules.phases.PhaseType;
import fr.unitale.games.uhc.modules.phases.deathmatch.DeathmatchPhase;
import fr.unitale.games.uhc.modules.phases.fight.FightPhase;
import fr.unitale.games.uhc.modules.phases.recolte.RecoltePhase;
import fr.unitale.games.uhc.modules.phases.reduction.ReductionPhase;
import fr.unitale.sdk.gameengine.modules.Module;
import fr.unitale.sdk.gameengine.modules.randomtp.RandomTPModule;
import fr.unitale.sdk.gameengine.modules.team.TeamModule;
import fr.unitale.sdk.gameengine.modules.team.UniTeam;
import fr.unitale.sdk.lang.Lang;
import fr.unitale.sdk.players.UniPlayer;
import fr.unitale.sdk.schematics.Schematic;
import fr.unitale.sdk.scoreboard.UniScoreboard;
import fr.unitale.sdk.server.ServerManager;
import fr.unitale.sdk.utils.chat.ChatUtils;
import fr.unitale.sdk.utils.items.UniItemStack;
import fr.unitale.sdk.utils.weather.TimeSet;
import fr.unitale.sdk.utils.weather.WeatherAPI;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;

import java.util.EnumMap;

/**
 * Manage the UHC's phases
 *
 * @author Axicer
 */
public class PhaseModule extends Module<PhaseModuleListener> {

    private Phase currentPhase; //current phase
    private EnumMap<PhaseType, Integer> phasesDuration = new EnumMap<>(PhaseType.class); //map of phases and duration in minutes

    public PhaseModule() {
        this.moduleListener = new PhaseModuleListener(this);
        this.currentPhase = null;
    }

    /**
     * Set the duration for a specific phase
     * WARNING : you have to set the timing for the phases before using start() method !
     *
     * @param phase    {@link PhaseType}
     * @param duration int duration in seconds
     */
    public void setDuration(PhaseType phase, int duration) {
        phasesDuration.put(phase, duration);
    }

    /**
     * Hard set the current phase
     * WARINING: if the previous phase is not stopped, it will probably override this call
     *
     * @param phase
     */
    public void setCurrentPhase(Phase phase) {
        currentPhase = phase;
    }

    /**
     * get the current phase
     *
     * @return {@link Phase}
     */
    public Phase getCurrentPhase() {
        return currentPhase;
    }

    /**
     * Check for a specific phase
     *
     * @param phase {@link PhaseType}
     * @return true if the phase correspond to the given enum else false;
     */
    public boolean isCurrentPhase(PhaseType phase) {
        boolean res = false;
        if (currentPhase != null) {
            res = currentPhase.getPhase().equals(phase);
        }
        return res;
    }

    @Override
    public void startModule() {
        WeatherAPI.setTime(TimeSet.DAY);
        UHCEngine.getInstance().getMap().getWorld().setGameRuleValue("doDaylightCycle", "false");
        destroyLobby();
        initTeam();
        initBoard();
        UHCEngine.getInstance().getScenarioManager().startAll();
        UHCEngine.getInstance().getModuleManager().getModule(RandomTPModule.class).teleportAllDelayed(res -> new BukkitRunnable() {
            int count = 3;

            @Override
            public void run() {
                if (count <= 0) {
                    //check for not entered key and set to default
                    phasesDuration.putIfAbsent(PhaseType.RECOLTE, RecoltePhase.DEFAULT_RECOLTE_DURATION);
                    phasesDuration.putIfAbsent(PhaseType.FIGHT, FightPhase.DEFAULT_FIGHT_DURATION);
                    phasesDuration.putIfAbsent(PhaseType.REDUCTION, ReductionPhase.DEFAULT_REDUCTION_DURATION);
                    phasesDuration.putIfAbsent(PhaseType.DEATHMATCH, DeathmatchPhase.DEFAULT_DEATHMATCH_DURATION);
                    //start first phase
                    UHCEngine.getInstance().getModuleManager().addModule(new RecoltePhase(phasesDuration), true);
                    Bukkit.getOnlinePlayers().stream().map(p -> (UniPlayer) p).forEach(PhaseModule::spawn);
                    cancel();
                } else {
                    Lang.bcst("game.uhc.start.timer", "" + count);
                    count--;
                }
            }
        }.runTaskTimer(UHCEngine.getInstance().getPlugin(), 0L, 20L));
    }

    private static void spawn(UniPlayer player) {
        UniItemStack sword = new UniItemStack(Material.WOOD_SWORD);
        UniItemStack pickaxe = new UniItemStack(Material.WOOD_PICKAXE);

        sword.addUnsafeEnchantment(Enchantment.DURABILITY, 500);
        pickaxe.addUnsafeEnchantment(Enchantment.DURABILITY, 500);

        ItemMeta smeta = sword.getItemMeta();
        smeta.spigot().setUnbreakable(true);
        sword.setItemMeta(smeta);
        sword.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);

        ItemMeta pmeta = pickaxe.getItemMeta();
        pmeta.spigot().setUnbreakable(true);
        pickaxe.setItemMeta(pmeta);
        pickaxe.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);

        player.setHealth(20);
        player.setSaturation(10);
        player.getInventory().clear();
        player.getInventory().addItem(sword, pickaxe);
        // call start kits
        StartKit.check(player);
    }

    @Override
    public void endModule() {
    }

    private void destroyLobby() {
        Schematic s = UHCEngine.getInstance().getMap().getCenterSchematic();
        Location center = UHCEngine.getInstance().getMapCenter();
        for (int x = (center.getBlockX() - s.getWidth() / 2) - 1; x <= center.getBlockX() + s.getWidth() / 2; x++) {
            for (int y = (center.getBlockY() - s.getHeight() / 2) - 1; y <= center.getBlockY() + s.getHeight() / 2; y++) {
                for (int z = (center.getBlockZ() - s.getLength() / 2) - 1; z <= center.getBlockZ() + s.getLength() / 2; z++) {
                    Location l = center.clone();
                    l.setX(x);
                    l.setY(y);
                    l.setZ(z);
                    l.getBlock().setType(Material.AIR);
                }
            }
        }
    }

    private void initBoard() {
        UHCEngine.getInstance().getOnlinePlayers().forEach(p -> {
            setNewBoard(p);
            p.clear();
            p.setGameMode(GameMode.SURVIVAL);
        });
    }

    private static String showDistance(UniPlayer from, UniPlayer to) {
        if (to.isEliminated()) {
            return Lang.str(from, "game.uhc.tab.distance.eliminated", to.getName());
        }
        if (!to.isOnline()) {
            return Lang.str(from, "game.uhc.tab.distance.notonline", to.getName());
        }
        if (!from.getWorld().equals(to.getWorld())) {
            return Lang.str(from, "game.uhc.tab.distance.otherworld", to.getName());
        }
        String dir = ChatUtils.getDirectionLocation(from.getLocation(), to.getLocation());
        int dist = (int) from.getLocation().distance(to.getLocation());
        return Lang.str(from, "game.uhc.tab.distance", to.getName(), dir, "" + dist);
    }

    private static String showCenter(UniPlayer p) {
        Location center = UHCEngine.getInstance().getMapCenter();
        if (!p.getWorld().equals(center.getWorld())) {
            return Lang.str(p, "game.uhc.tab.center.otherworld");
        }
        Location from = p.getLocation().clone();
        from.setY(200);
        String dir = ChatUtils.getDirectionLocation(from, center);
        int dist = (int) from.distance(center);
        return Lang.str(p, "game.uhc.tab.center", dir, "" + dist);
    }

    private void setNewBoard(UniPlayer p) {
        UniScoreboard b = new UniScoreboard();
        int i = 0;
        b.createLifeScore();
        b.createSideBoard(ChatColor.GOLD + ServerManager.type.name() + " " + UHCEngine.getInstance().getMode().name().toLowerCase());
        b.addScore("Space_1", " ", i++, DisplaySlot.SIDEBAR);
        if (UHCEngine.getInstance().getMode() == Mode.SOLO) {
            b.addScore("SOLO", Lang.str(p, "game.uhc.tab.playerscount", "" + UHCEngine.getInstance().getCompetingPlayersCount()), i++, DisplaySlot.SIDEBAR);
        } else {
            UniTeam t = UniTeam.getTeam(p);
            if (t != null) {
                for (UniPlayer ep : t.getOnlinePlayers()) {
                    if (p != ep)
                        b.addScore(ep.getUniqueId().toString(), showDistance(p, ep), i++, DisplaySlot.SIDEBAR);
                }
            }
            b.addScore("Space_2", "  ", i++, DisplaySlot.SIDEBAR);
            b.addScore("TEAM", Lang.str(p, "game.uhc.tab.teamscount", "" + UHCEngine.getInstance().getCompetingTeamCount(), "" + UHCEngine.getInstance().getCompetingPlayersCount()), i++, DisplaySlot.SIDEBAR);
        }
        b.addScore("Center", Lang.str(p, "game.uhc.tab.sendingchunks"), i++, DisplaySlot.SIDEBAR);
        b.addScore("Space_3", " ", i++, DisplaySlot.SIDEBAR);
        b.addScore("Timer", Lang.str(p, "game.uhc.tab.loading"), i++, DisplaySlot.SIDEBAR);

        p.setScoreboard(b);
    }

    public static void setTimerBoard(String nextPhase, String timer) {
        UHCEngine.getInstance().getOnlinePlayers().forEach(p -> setTimerBoard(p, nextPhase, timer));
    }

    private static void setTimerBoard(UniPlayer ep, String nextPhase, String timer) {
        ep.getEndScoreboard().updateScore("Timer", Lang.str(ep, "game.uhc.tab.timer", nextPhase, timer));
    }

    public static void updatePlayersBoard() {
        UHCEngine.getInstance().getOnlinePlayers().forEach(p -> updatePlayerBoard(p));
    }

    public static void updateAvailablePlayerBoard(UniPlayer p) {
        UniScoreboard b = p.getEndScoreboard();
        if (UHCEngine.getInstance().getMode() == Mode.SOLO) {
            b.updateScore("SOLO", Lang.str(p, "game.uhc.tab.playerscount", "" + UHCEngine.getInstance().getCompetingPlayersCount()));
        } else {
            b.updateScore("TEAM", Lang.str(p, "game.uhc.tab.teamscount", "" + UHCEngine.getInstance().getCompetingTeamCount(), "" + UHCEngine.getInstance().getCompetingPlayersCount()));
        }
    }

    private static void updatePlayerBoard(UniPlayer p) {
        UniScoreboard b = p.getEndScoreboard();
        if (UHCEngine.getInstance().getMode() == Mode.SOLO) {
            b.updateScore("SOLO", Lang.str(p, "game.uhc.tab.playerscount", "" + UHCEngine.getInstance().getCompetingPlayersCount()));
        } else {
            UniTeam t = UniTeam.getTeam(p);
            if (t != null) {
                for (UniPlayer ep : t.getOnlinePlayers()) {
                    if (p != ep)
                        b.updateScore(ep.getUniqueId().toString(), showDistance(p, ep));
                }
            }
            b.updateScore("Space_2", "  ");
            b.updateScore("TEAM", Lang.str(p, "game.uhc.tab.teamscount", "" + UHCEngine.getInstance().getCompetingTeamCount(), "" + UHCEngine.getInstance().getCompetingPlayersCount()));
        }
        b.updateScore("Center", showCenter(p));
    }

    private void initTeam() {
        if (UHCEngine.getInstance().getMode() == Mode.TEAM) {
            TeamModule<?> tm = UHCEngine.getInstance().getModuleManager().getModule(TeamModule.class);
            if (tm != null) {
                tm.getTeams().forEach(t -> {
                    if (t.isEmpty()) t.eliminate();
                });
            }
        }
    }
}
