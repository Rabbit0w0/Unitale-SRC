package fr.unitale.games.uhc.kit.types;

import fr.unitale.games.uhc.kit.types.random.AdventurerKit;
import fr.unitale.games.uhc.kit.types.random.GourmetKit;
import fr.unitale.games.uhc.kit.types.random.SpeedKit;
import fr.unitale.sdk.features.IKit;
import fr.unitale.sdk.gameengine.utils.kit.AbstractKit;
import fr.unitale.sdk.gameengine.utils.kit.KitManager;
import fr.unitale.sdk.players.UniPlayer;

import java.util.stream.Stream;

public abstract class StartKit extends AbstractKit {

    public StartKit(IKit kit) {
        super(kit);
    }

    public abstract void onGameStart(UniPlayer player);

    public static void check(UniPlayer player) {
        Stream.of(SpeedKit.class, GourmetKit.class, AdventurerKit.class).forEach(kitType -> {
            StartKit kit = KitManager.fromPlayer(player, kitType);
            if (kit != null) {
                kit.onGameStart(player);
            }
        });
    }
}
